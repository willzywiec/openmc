/* 
Copyright (c) 2006-2016 Lawrence Livermore National Security, LLC.
Produced at the Lawrence Livermore National Laboratory 
UCRL-CODE-224807.

All rights reserved. Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

o Redistributions of source code must retain the above copyright notice, this list of conditions and the disclaimer below.

o Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the disclaimer (as noted below) in the documentation and/or other materials provided with the distribution.

o Neither the name of the LLNS/LLNL nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL LAWRENCE LIVERMORE NATIONAL SECURITY, LLC, THE U.S. DEPARTMENT OF ENERGY OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
Additional BSD Notice

1. This notice is required to be provided under our contract with the U.S. Department of Energy (DOE). This work was produced at Lawrence Livermore National Laboratory under Contract No. DE-AC52-07NA27344 with the DOE. 

2. Neither the United States Government nor Lawrence Livermore National Security, LLC nor any of their employees, makes any warranty, express or implied, or assumes any liability or responsibility for the accuracy, completeness, or usefulness of any information, apparatus, product, or process disclosed, or represents that its use would not infringe privately-owned rights. 

3. Also, reference herein to any specific commercial products, process, or services by trade name, trademark, manufacturer or otherwise does not necessarily constitute or imply its endorsement, recommendation, or favoring by the United States Government or Lawrence Livermore National Security, LLC. The views and opinions of authors expressed herein do not necessarily state or reflect those of the United States Government or Lawrence Livermore National Security, LLC, and shall not be used for advertising or product endorsement purposes.
*/


#include <math.h>
#include "fissionEvent.h"

double fissionEvent::SmpGEng() {

/*
  Description
    Sample energy spectrum for photons emitted by fission-induced reactions. 
    The energy spectrum of the prompt fission gamma rays is obtained from
    Maienschein's measurements.
*/

/*
  Input
  Return
    energy of photon emitted by neutron-induced fission
*/

   double r;
/*
  Calculate the energy of photons emitted from fission
*/
   r=fisslibrng();

   if (r == 0.0) return 0.085;
   if (r <= 0.0001) return 0.0855+0.01692*(r/0.0001)-0.02401*pow(r/0.0001,2)+0.01274*pow(r/0.0001,3);
   if (r > 0.0001 && r <= 0.01) return 0.09141+0.23846*((r-0.0001)/0.0099)-1.75947*pow((r-.0001)/0.0099,2)+10.98611*pow((r-0.0001)/0.0099,3)-43.19181*pow((r-.0001)/0.0099,4)+105.70005*pow((r-.0001)/.0099,5)-160.72894*pow((r-.0001)/.0099,6)+147.43399*pow((r-.0001)/.0099,7)-74.60043*pow((r-.0001)/0.0099,8)+15.97547*pow((r-.0001)/0.0099,9);
   if (r > 0.01 && r <= 0.1537) return 0.14486+0.40914*((r-.01)/.1437)-1.28150*pow((r-0.01)/0.1437,2)+5.07377*pow((r-0.01)/0.1437,3)-15.42031*pow((r-0.01)/0.1437,4)+31.96346*pow((r-0.01)/0.1437,5)-43.12605*pow((r-0.01)/0.1437,6)+36.02908*pow((r-0.01)/0.1437,7)-16.87185*pow((r-0.01)/0.1437,8)+3.37941*pow((r-0.01)/0.1437,9);
   if (r > 0.1537 && r <= 0.7114) return (-1./2.3)*log(0.71956*(0.1537-r)+0.50158);
   if (r > 0.7114 && r <= 1.0) return (-1./1.1)*log(1.15292*(0.7114-r)+0.33287);
   return 0.;
}
