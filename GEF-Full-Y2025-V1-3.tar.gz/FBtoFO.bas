' Steps from GEF.BAS to GEFSUB.FOR
' 1. ./ExtractSub
' 2. ./FBtoFO     (File: GEFSUB)
' 3. Rename  GEFSUBdlc.FOR  into  GEFSUBdlc2.FOR
' 4. ./FBtoFO     (File: GEFSUB)
' 5. Compile  GEFSUB.FOR

' INFO 1: The code to be translated from FreeBASIC to FORTRAN must not contain
'         implicite type conversions. 

' INFO2: Functions and subroutines inside functions and subroutines must be
'        explicitely declared in GEF.bas with a statement like this: /'<FO REAL*4 U_SHELL FO>'/

' INFO3: GEFSUBdcl requires two runs of FBtoFO
'        After the first run, GEFSUBdcl.FOR is renamed to GEFSUBdlc2.FOR.

' INFO4: The translator supports only those kind of statements that appear in GEFSUB.bas.
'        It is not a comprehensive FreeBASIC-to-Fortran translator! 



Dim As Integer I,J,K
Dim As String C_Test

Redim As String Sub_List(1) 
Dim As Integer N_Sub
Dim As Integer I_Sub_Active = 0

Redim As String Function_List(1)
Dim As Integer N_Function
Dim As Integer I_Function_Active = 0

Redim Shared As String Type_List(100,2)
Dim Shared As Integer N_Type

Restore Data_types
For I = 1 To 100
  Read Type_List(I,1),Type_List(I,2)
  If Type_list(I,1) = "EOF" Then Exit For
  N_Type = I
Next

Data_types:
Data "INTEGER","INTEGER*4", _
      "UBYTE","INTEGER*4", _
      "LONGINT","INTEGER*8", _
      "SINGLE","REAL*4", _
      "DOUBLE","REAL*8", _
      "STRING","CHARACTER*(*)", _
      "EOF","EOF"

Declare Sub U_Replace(CIn As String, C1 As String, C2 As String)

Declare Sub CC_Cut(CIn As String, CDiv As String, COut() As String, _
     ByRef N As Integer) 
     
Declare Sub CC_Cut_FB(CIn As String, CDiv As String, COut() As String, _
     CComment As String, ByRef N As Integer) 
     
Declare Sub CC_Parm(CIn As String, CMain As String, CParm As String)     

Declare Function Tally(CIn As String,CTest As String) As Integer

Declare Function U_Type(CIn As String) As String

Declare Sub U_Print(C_out As String)

Dim Shared As String C_File
Dim As String C_Line,C_Line_Mem,C_Line_Raw
ReDim As String C_Part(100)
Redim As String Csub_Part(100)
Dim As String C_Part_Comment
Dim As String Csub_Part_Comment
Dim As Integer N_Part
Dim As Integer Nsub_Part
Dim As Ubyte B_glue = 0
Dim As String C_Main,C_Parm
ReDim As String CV_Parm(100)
Dim As Integer N_Parm
ReDim As String CV_Div(100)
Dim As Integer N_Div
Dim As String C_Out
Redim As String C_More(100)
Dim As Integer N_More 
Dim As String C_Return
Dim As Integer Parpos
Dim As Ubyte B_nodcl = 0
Dim As String C_Type


Print "This code translates FreeBASIC source files into Fortran."
Input "Enter FreeBASIC input file (without qualifier .bas): ",C_File
Dim Shared As Integer Fin,Fout,Fdcl

Fin = Freefile
Open C_File+".bas" For Input As #Fin
Fout = Freefile
Open C_File+".FOR" For Output As #Fout
Print #Fout, "C     Output of FBtoFO from ";C_FILE;".BAS"
If Ucase(C_FILE) = "GEFSUB" Then
  Print #Fout, "      PROGRAM MAIN"
  Print #Fout, "      IMPLICIT NONE"
End If  
Close #Fout
Open C_File+"dcl.FOR" For Output As #Fout
Print #Fout, "C     Output of FBtoFO from ";C_FILE;".BAS"
Close #Fout
Open C_File+".FOR" For Append As #Fout

' Declares outside subroutines and functions
'Fdcl = Freefile
'Open C_File+"dcl.for" For Output As #Fdcl

Do Until EOF(Fin)
  Line Input #Fin,C_Line
'Print C_Line
  If Trim(C_Line) = "" Then
    C_Line = "'"
  End If
  C_Line = RTrim(C_Line)
  If Right(C_Line,1) = "_" Then
    C_Line_Mem = C_Line_Mem + Left(C_Line,Len(C_Line)-1)
    B_glue = 1
  Else 
    C_Line_Raw = C_Line_mem + C_Line
    C_line_mem = ""  
    B_glue = 0
  End If
  
  '*** Suppress statements that are unsupported in Fortran
  
  ' Print
  If Left(Trim(Ucase(C_Line_Raw)),5) = "PRINT" Then
    C_LIne_Raw = "'" + C_Line_Raw
  ENd If
    
  ' SCOPE
  If Left(Trim(Ucase(C_Line_Raw)),5) = "SCOPE" Then
    C_Line_Raw = "'"  + C_Line_Raw
  End If
  If Left(Trim(Ucase(C_Line_Raw)),3) = "END" And _
          Instr(Ucase(C_Line_Raw),"SCOPE") > 0 Then
    C_Line_Raw = "'" + C_Line_Raw        
  End If        

  ' To suppress Pre-processor Statements for the moment 
  If Left(Trim(C_line_Raw),1) = "#" Then
    C_line_Raw = "'"+C_line_Raw
  End If
  
  ' To suppress "Randomize" for the moment
  If Instr(Ucase(C_Line_Raw),"RANDOMIZE") > 0 Then
    C_Line_Raw = "'"+C_line_Raw
  End If  

  ' PUBLIC FUNCTION
  If Instr(Ucase(Trim(C_Line_Raw)),"PUBLIC") = 1 Then
    C_Line_Raw = Mid(C_Line_Raw,Instr(Ucase(C_Line_Raw),"PUBLIC") + 7) 
  End If  
  
  If B_glue = 0 Then         ' complete line in C_line_Raw
  
    ' Pre-processing for Fortran
    If Len(C_Line_Raw) > 5 Then
      If Instr(Trim(C_Line_Raw),"/'<FO") = 1 Then
        C_Line_Raw = Trim(C_Line_Raw)
        C_Line_Raw = Mid(C_Line_Raw,6)
      End If  
      If Instr(C_Line_Raw,"FO>'/") = Len(C_Line_Raw)-4 Then
        C_Line_Raw = Trim(C_Line_Raw)
        C_Line_Raw = Mid(C_Line_Raw,1,Len(C_Line_Raw)-5)
      End If
    End If        
    
    
    IF Instr(C_Line_Raw,"/'<") > 0 Or Instr(C_Line_Raw,">'/") > 0 Or _
       Instr(C_Line_Raw,"/'>") > 0 Or Instr(C_Line_Raw,"<'/") > 0 THEN
      C_Line_Raw = Trim(C_Line_Raw)
      If Instr(Ucase(C_Line_Raw),"/'<INCLUDE") = 1 And Instr(C_Line_Raw,">'/") > 0 Then
        C_out = Mid(C_Line_Raw,4,Instr(C_Line_Raw,">'/")-4)
      ElseIf Instr(Ucase(C_Line_Raw),"/'<MODULE") = 1 And Instr(C_Line_Raw,">'/") > 0 Then
        C_out = "USE "+MID(C_Line_Raw,4,Instr(C_Line_Raw,">'/")-4)
      ElseIf Instr(Ucase(C_Line_Raw),"/'MODULE") = 1 Then
        Close #Fout
        Fout = Freefile
        Open C_File+".FOR" For Append As #Fout
      
        C_out = Mid(C_Line_Raw,3,Len(C_Line_Raw)-5)
        C_More(1) = "IMPLICIT NONE"
        C_More(2) = "SAVE"
        N_More = 2
        B_nodcl = 1
      ElseIf Instr(Ucase(C_Line_Raw),"/'>MODULE") = 1 Then
        C_out = "END "+Mid(C_Line_Raw,4,Len(C_Line_Raw)-5)
        B_nodcl = 0
      Else  ' do nothing
      End If   
    ELSE
    CC_Cut_FB(C_line_Raw," ",C_Part(),C_Part_Comment,N_Part)
    
    If N_Part > 0 Then  ' Switch output file back 
      Close #Fout
      Fout = Freefile
      Open C_File+".FOR" For Append As #Fout     
    End If
    
    Dim As Integer I_exit 
    I_exit = 0
    For I = 1 To N_Part
    
      If Ucase(C_Part(I)) = "NEXT" Then
        I_exit = I
      End If
  '    U_Replace(C_Part(I),"PRINT","WRITE (*,*)")
      U_Replace(C_Part(I),"AND",".AND.")
      U_Replace(C_Part(I),"OR",".OR.")
      U_Replace(C_Part(I),"NOT",".NOT.")
      U_Replace(C_Part(I),"<>",".NE.")
      U_Replace(C_Part(I),">=",".GE.")
      U_Replace(C_Part(I),"<=",".LE.")
      U_Replace(C_Part(I),"<",".LT.")
      U_Replace(C_Part(I),">",".GT.")
      U_Replace(C_Part(I),"APPEND","ACCESS = APPEND")
      U_Replace(C_Part(I),"ATN(","ATAN(")
      U_Replace(C_Part(I),"ELSEIF","ELSE IF")
      U_Replace(C_Part(I),"ENDIF","END IF")
      U_Replace(C_Part(I),"INSTR(","INDEX(")
      U_Replace(C_Part(I),"FOR","DO")
      U_Replace(C_Part(I),"TO",",")
      U_Replace(C_Part(I),"STEP",",")
      U_Replace(C_Part(I),"NEXT","END DO")
      U_Replace(C_Part(I),"WHILE","DO WHILE(")
      U_Replace(C_Part(I),"WEND","END DO")
      U_Replace(C_Part(I),"/SQR(/","SQRT(")
      U_Replace(C_Part(I),"/CSNG(/","REAL(")
      U_Replace(C_Part(I),"/CINT(/","NINT(")
      U_Replace(C_Part(I),"/SGN(/","SIGN(1.0,")
      U_Replace(C_Part(I),"/^/","**")
      If C_Part(I) = "DO WHILE(" Then C_Part(N_part) = C_Part(N_part) + ")"       
      If Left(C_Part(I),1) = "_" And C_Part(I) <> "_" Then 
        C_Part(I) = "x"+Mid(C_Part(I),2)
      End If
      If Instr(C_Part(I),"=_") > 0 Then
        C_Part(I) = Left(C_Part(I),Instr(C_Part(I),"=_")-1) + _
                "=x" + Mid(C_Part(I),Instr(C_Part(I),"=_")+2) 
      End If 
      If I_exit > 0 And I >= I_exit Then
        N_Part = I_exit 
        Exit For
      End If   
    Next
                
    ' Modulo
    Dim As Integer Ikla,Ifirst,Ilast
    Dim As String C_Work
    For I = 2 To N_Part - 1
      If Ucase(C_Part(I)) = "MOD" Then
        C_Part(I) = "MOD"+"("+C_Part(I-1)+","+C_Part(I+1)+")"
        C_Part(I-1) = ""
        C_Part(I+1) = ""
      End If
    Next  
    For I = 1 To N_Part
      For J = 2 To Len(C_Part(I))-1
        Ikla = 0
        If Instr(Ucase(C_Part(I))," MOD ") = J Then
           For K = J-1 To 1 Step -1
             If Mid(C_Part(I),K,1) = ")" Then Ikla = Ikla + 1
             If Mid(C_Part(I),K,1) = "(" Then Ikla = Ikla - 1
             If (Ikla = 0 And Mid(C_Part(I),K,1) = " ") Or Ikla = -1 Then
               Ifirst = K+1 
               Exit For
             End If
           Next K
           For K = J+5 To Len(C_Part(I)) 
             If Mid(C_Part(I),K,1) = "(" Then Ikla = Ikla + 1
             If Mid(C_Part(I),K,1) = ")" Then Ikla = Ikla - 1
             If (Ikla = 0 And Mid(C_Part(I),K,1) = " ") Or Ikla = -1 Then
               Ilast = K-1
               Exit For
             End If
             Ilast = K
           Next K
           C_Work = Left(C_Part(I),Ifirst-1)+ _
                  "MOD("+Mid(C_Part(I),Ifirst,J-Ifirst+1) + "," + _
                  Mid(C_Part(I),J+4,Ilast-J-3) + ")" 
           If Len(C_Part(I)) > Ilast Then 
                  C_Work = C_Work + Mid(C_Part(I),Ilast+1)
           End If     
           C_Part(I) = C_Work  
        End If
      Next
    Next    
    
    ' SELECT 
    If Ucase(C_Part(1)) = "SELECT" And Ucase(C_Part(2)) = "CASE" Then
      U_Replace(C_Part(2),"CASE","CASE(")
      C_Part(N_Part) = C_Part(N_Part) + ")"
    End If
    If UCase(C_Part(1)) = "CASE" Then
      If UCase(C_Part(2)) = "ELSE" Then
        U_Replace(C_Part(2)),"ELSE","DEFAULT"
      Else 
        U_Replace(C_Part(1),"CASE","CASE(")
        C_Part(N_Part) = C_Part(N_Part) + ")"
      End If
    End If
    
    ' IF ... THEN ... ELSE in one line
    If Ucase(C_Part(1)) = "IF" Then
       For I = 2 To N_Part
         If Ucase(C_Part(I)) = "THEN" Then
            For J = I To N_Part
              If UCase(C_Part(J)) = "ELSE" Then
                N_More = 1
                C_More(N_More) = C_Part(I+1)
                For K = I + 2 To J - 1
                  C_More(N_More) = C_MOre(N_More) +" "+  C_Part(K)
                Next
                N_More = N_More + 1
                C_More(N_More) = C_Part(J)
                N_More = N_More + 1
                C_More(N_More) = C_Part(J + 1)
                For K = J + 2 To N_Part
                  C_More(N_More) = C_More(N_More) +" "+ C_Part(K)
                Next
                N_MOre = N_More + 1
                C_More(N_More) = "END IF"
                For K = I+1 To N_Part
                  C_Part(K ) = ""
                Next
                N_Part = I
                EXIT FOR
              End If
            Next
            EXIT FOR
         End If
       Next 
    End If    
    
    ' IF ...
    IF Ucase(C_Part(1)) = "IF" Or Ucase(C_Part(1)) = "ELSEIF" Or Ucase(C_Part(1)) = "ELSE IF" Then
      If UCase(C_Part(N_Part)) = "THEN" Then
        C_Part(N_Part) = " ) THEN"
        For I = 2 To N_Part - 1
           U_Replace(C_Part(I),"/=/",".EQ.")
        Next
      Else
        For I = 2 To N_Part -1
          If Ucase(C_Part(I)) = "THEN" Then
            For J = 2 To I
              U_Replace(C_Part(J),"/=/",".EQ.")
            Next
            C_Part(I) = " ) "
          End If 
        Next
      End If    
'      C_Part(1) = "IF ( "
      C_Part(1) = C_Part(1)+" ( "
    End If 
    If Ucase(C_Part(1)) = "ELSE" And Ucase(C_Part(2)) = "IF" Then
      C_Part(2) = " IF ( "
    End If
    IF Ucase(C_Part(1)) = "ELSEIF" Then
      C_Part(1) = "ELSEIF ( "
    End If
    


    ' Add "CALL" for call of subroutines
    C_Test = Trim(Ucase(C_Part(1)))
    If Instr(C_Test,"(") > 1 Then
      C_Test = Left(C_Test,Instr(C_Test,"(")-1)
    End If
    For I = 1 To N_Sub
      If C_Test = Sub_list(I) Then
        C_Part(1) = "CALL "+C_Part(1)
      End If
    Next
    
    If UCase(C_Part(1)) = "DECLARE" Then
      If I_Function_Active = 0 And I_Sub_Active = 0 And B_nodcl = 0 Then
        Close #Fout
        Fout = Freefile
        Open C_File+"dcl.FOR" For Append As #Fout
      End If       
      If UCase(C_Part(2)) = "FUNCTION" Then
        N_Function = N_Function + 1
        Redim Preserve Function_List(N_Function)
        CC_Parm(C_part(3),C_Main,C_Parm)
        If C_Main <> "" Then
          Function_list(N_Function) = UCase(C_Main)
        End If
        For I = 1 To N_Type
          If Ucase(C_Part(5)) = Type_List(I,1) Then
            C_Type = Type_List(I,2)
          End If  
        Next 
PRINT C_Type,C_Main        
        C_Out = C_Type+" "+C_Main
      End If
       
      If UCase(C_part(2)) = "SUB" Then
        N_Sub = N_Sub + 1
        Redim Preserve Sub_List(N_Sub)
        CC_Parm(C_part(3),C_Main,C_Parm)
        If C_Main <> "" Then
          Sub_list(N_Sub) = Ucase(C_Main)
        End If
      End If
'   End If
    ' Special treatment for "FUNCTION"
    ElseIf Ucase(C_Part(1)) = "FUNCTION" Then
      N_More = 1
      C_More(1) = "IMPLICIT NONE"
      ' Example: C_Line_Raw = "Function U_MASS(Z As Single,A As Single) As Single"
      '          C_Part(1) = "Function"
      For I = 1 To N_Function
        CC_Parm(C_Part(2),C_Test,C_Parm)
        ' Example: C_Part(2) = "U_MASS(Z As Single, A As Single)"
        '          C_Parm = "Z As Single, A As Single"
        If Function_List(I) = UCase(C_Test) Then
          I_Function_Active = I
          C_Out = U_Type(C_Part(4)) + " FUNCTION "+C_Test
          ' Example: C_Out = "FUNCTION U_MASS"
        End If
      Next
      CC_Cut(C_Parm,",",CV_Parm(),N_Parm)
      ' Example: C_Parm = "Z As Single, A As Single"
      '          CV_Parm(1) = "Z As Single"
      C_Out = C_Out + "("
      For I = 1 To N_Parm
        CC_Cut(CV_Parm(I)," ",CV_Div(),N_Div)
        If I = N_Parm Then
          C_Out = C_Out + CV_Div(1) 
        Else
          C_Out = C_Out + CV_Div(1) + "," 
        End If
        N_More = I+1
        C_More(I+1) = U_Type(CV_Div(3)) + " " + CV_Div(1)
      Next
      C_Out = C_Out + ")"
      ' Example: C_Out = "FUNCTION U_MASS(Z,A)"
      
      ' Example: C_Part(3) = "As"
      '          C_Part(4) = "Single" 
'     N_More = N_More + 1
'     C_More(N_More) = "AUTOMATIC"  ' from MS Fortran
    ElseIf UCase(C_Part(1)) = "SUB" Then
      N_More = 1
      C_More(1) = "IMPLICIT NONE"
      For I = 1 To N_Sub
        CC_Parm(C_Part(2),C_Test,C_Parm)
        If Sub_List(I) = UCase(C_Test) Then
          If UCase(C_Test) <> "GEFSUB" Then I_Sub_Active = I
          C_Out = "SUBROUTINE "+C_Test           
        End If
      Next
      CC_Cut(C_Parm,",",CV_Parm(),N_Parm)
      C_Out = C_Out + "("
      For I = 1 To N_Parm
        CC_Cut(CV_Parm(I)," ",CV_Div(),N_Div)
        If Ucase(CV_Div(1)) = "BYREF" or _
           Ucase(CV_Div(1)) = "BYVAL" Then
          Parpos = 2   
        Else
          Parpos = 1
        End If    
        If I = N_Parm Then
          C_Out = C_Out + CV_Div(Parpos) 
        Else
          C_Out = C_Out + CV_Div(Parpos) + "," 
        End If
        N_More = I+1
        C_More(I+1) = U_Type(CV_Div(Parpos+2)) + " " + CV_Div(Parpos)
      Next
      C_Out = C_Out + ")"   
'      N_More = N_More + 1
'      C_More(N_More) = "AUTOMATIC"
'    End If

    ' Declaration of variables (standard and user-defined types) 
    ElseIf Ucase(C_Part(1)) = "DIM" or Ucase(C_Part(1)) = "REDIM" _
       Or Ucase(C_Part(1)) = "CONST" Or Ucase(C_Part(1)) = "STATIC" And _
       Instr(Ucase(C_Line_Raw)," AS ") > 0 Then 
       
      ' Declarations must appear at the beginning of the program.
      ' Therefore, they are written on a separate file and
      ' included by the preprocessor at the appropriate place. 
      ' Exception: Declarations in additional functions and subroutines
      ' are not moved. These should already be grouped at the beginning 
      ' of the function or subroutine in the FreeBASIC source test.
      If I_Function_Active = 0 And I_Sub_Active = 0 And B_nodcl = 0 Then
        Close #Fout
        Fout = Freefile
        Open C_File+"dcl.FOR" For Append As #Fout
      End If         
       
      Dim As String C_Var = ""
      Dim As String C_Var_Name
      Dim As String C_Var_Extensions
      Dim As Integer I_Var_Dim
      For I = 1 To N_Type
        For J = 2 To N_Part
          If Ucase(C_Part(J)) = Type_List(I,1) Then
            C_Part(J) = Type_List(I,2)
            C_Type = Type_List(I,2)
          End If
        Next
      Next
      C_Out = C_Type + " "
      For I = 1 To N_Part
        If Ucase(C_Part(I)) <> "DIM" And _
           Ucase(C_Part(I)) <> "REDIM" And _ 
           Ucase(C_Part(I)) <> "PRESERVE" And _
           Ucase(C_Part(I)) <> "SHARED" And _
           Ucase(C_Part(I)) <> "CONST" And _
           Ucase(C_Part(I)) <> "STATIC" And _
           Ucase(C_Part(I)) <> "AS" And _
           Ucase(C_Part(I)) <> C_Type Then
          C_Var = C_Part(I)
          If Ucase(C_Part(1)) <> "REDIM" Then
            If Instr(C_Var,"=") = 0 Then
              C_Out = C_Out + " " + C_Var
            Else
              C_Out = C_Out + " " + Left(C_Var,Instr(C_Var,"=")-1)
              N_More = N_More + 1
              C_More(N_More) = "DATA " + Left(C_Var,Instr(C_Var,"=")-1) + "/" + _
                           Mid(C_Var,Instr(C_Var,"=")+1) + "/"
            End If               
          End If
        End If   
      Next
      
      ' For the first appearance of REDIM only: (MS Frotran only)
  /'  If Ucase(C_Part(1)) = "REDIM" Then
        CC_Parm(C_Var,C_Var_Name,C_Var_Extensions)
        C_Out = "DIMENSION " + C_Var_Name + " [ALLOCATABLE] " 
        If C_Var_Extensions <> "" Then
          C_Out = C_Out + "(:"
          I_Var_Dim = Tally(C_Var_Extensions,",") + 1
          For I = 2 To I_Var_Dim
            C_Out = C_Out + ",:"
          Next
          C_Out = C_Out + ")"
        End If  
        Print #Fout, "      " + C_Out
        C_Out = "ALLOCATE ("+C_Var+", STAT = error)"
      End If  
      ' For the next appearences of REDIM:
      If Ucase(C_Part(1)) = "REDIM" Then
        CC_Parm(C_Var,C_Var_Name,C_Var_Extensions)       
        C_Out = "DEALLOCATE "+C_Var_Name
        Print #Fout, "      " + C_Out
        C_Out = "ALLOCATE ("+C_Var+", STAT = error)"
      End If '/
      
      ' gFortran 95:
      'Example: INTEGER, DIMENSION(-1:1, -1:2) :: A
      If Ucase(C_Part(1)) = "REDIM" Then
        CC_Parm(C_Var,C_Var_Name,C_Var_Extensions)       
		C_Out = C_Out + ", DIMENSION("
		U_Replace(C_Var_Extensions,"/ TO /",":")
		C_Out = C_Out + C_Var_Extensions + ")"
		C_Out = C_Out + " :: " + C_Var_Name
      End If
      If Ucase(C_Part(1)) = "CONST" Then 
        N_More = 1
        C_More(N_More) = "PARAMETER (" + C_Part(N_Part) + ")"
      End If
     
      ' User-defined data types
    ElseIf N_Part = 2 And Ucase(C_Part(1)) = "TYPE" Then

      ' Declarations must be inside the subroutine
      ' Therefore, they are written on a separate file and
      ' included by the preprocessor at the appropriate place. 
      If I_Function_Active = 0 And I_Sub_Active = 0 Then
        Close #Fout
        Fout = Freefile
        Open C_File+"dcl.FOR" For Append As #Fout
      End If         

      N_Type = N_Type + 1
      Type_List(N_Type,1) = C_Part(2)
      Type_List(N_Type,2) = C_Part(2)
      C_Out = "STRUCTURE" + " " + C_Part(2)

    ElseIf N_Part = 2 And Ucase(C_Part(1)) = "END" And Ucase(C_Part(2)) = "TYPE" Then

      ' Declarations must be inside the subroutine
      ' Therefore, they are written on a separate file and
      ' included by the preprocessor at the appropriate place. 
      If I_Function_Active = 0 And I_Sub_Active = 0 Then
        Close #Fout
        Fout = Freefile
        Open C_File+"dcl.FOR" For Append As #Fout
      End If         

      C_Out = "END STRUCTURE"

      ' End function
    ElseIf N_Part = 2 And I_Function_Active > 0 _
        And Ucase(C_Part(1)) = "END" And Ucase(C_Part(2)) = "FUNCTION" Then
        C_Out = "END"
        I_Function_Active = 0
     
      ' End sub
    ElseIf N_Part = 2 And I_Sub_Active > 0 _
        And Ucase(C_Part(1)) = "END" And Ucase(C_Part(2)) = "SUB" Then
          C_Out = "END"
        I_Sub_Active = 0
    ElseIf Instr(Ucase(C_Line_Raw),"EXIT") > 0 And N_Part > 1  Then 
  Print "1",C_Line_Raw  
      If Ucase(C_Part(N_Part-1)) = "EXIT" And Ucase(C_Part(N_Part)) = "DO" Then
        N_Part = N_Part - 1  
        C_Out = ""
        For I = 1 To N_Part
          C_Out = C_Out + C_Part(I) + " "
        Next
      Print "2",C_Out    
      End If   
      If Ucase(C_Part(N_Part-1)) = "EXIT" And Ucase(C_Part(N_Part)) = "FOR" Then
        N_Part = N_Part - 1
        C_Out = ""  
        For I = 1 To N_Part
          C_Out = C_Out + C_Part(I) + " "
        Next
      Print "2",C_Out    
      End If   
    Else
      ' END SUB
      If Ucase(C_Part(1)) = "END" And Ucase(C_Part(2)) = "SUB" Then
        C_Part(2) = ""
      End If  

      C_Out = ""
      For I = 1 To N_Part
        C_Out = C_Out + C_Part(I) + " "
      Next
    End If
    END IF  

  
    ' Printing
    U_print(C_out)
    C_Out = ""

    If C_Part_Comment <> "" Then
      Print #Fout, "C     " + C_Part_Comment
    End If
    C_Part_Comment = ""
          
    For I = 1 To N_More
      U_print(C_More(I))
    Next
    N_More = 0
     
  End If
Loop  

Close #Fin
Close #Fout


Sub U_Replace(CIn As String, C1 As String, C2 As String)
  Dim As Integer Iplace
  Dim As String Ctest
  If Left(C1,1) = "/" And Right(C1,1) = "/" Then
    Ctest = Mid(Ucase(C1),2,Len(C1)-2)
    Iplace = Instr(Ucase(CIn),Ctest)
    Do While(Iplace > 0)
      CIn = Mid(CIn,1,Iplace-1) + C2 + Mid(CIn,Iplace+Len(C1)-2)
      Iplace = Instr(Ucase(CIn),Ctest)
    Loop
  Else
    If Ucase(CIn) = C1 Then
      CIn = C2 
    End If
  End If    
End Sub


Sub CC_Cut(CIn As String, CDiv As String, COut() As String, _
               ByRef N As Integer) 
  /' Cuts a string into pieces with CDiv as divider '/ 
  /' Special treatment for blank as devider: 
       multiple blanks count as one divider '/              
  Dim As Integer I = 0
  Dim As String CRest
  CRest = Trim(CIn)  ' remove leading and trailing blanks
  N = 0
  If CRest = "" Then
    Return
  End If
  I = Instr(CRest,CDiv)
  If I = 0 then
     N = 1
     COut(1) = CIn
     Return
  Else
     While I > 0
        N = N + 1
        If N > Ubound(COut) Then 
          N = N - 1
          Print "<E> Dimension of COut too small in CC_cut(";CIn;")" 
        End if
        COut(N) = Mid(CRest,1,I-1)
        CRest = Mid(CRest,I+Len(CDiv))
        CRest = Trim(CRest)
        I = Instr(CRest,CDiv)
     Wend 
     N = N + 1
     If N > Ubound(COut) Then
          N = N - 1
          Print "<E> Dimension of COut too small in CC_cut(";CIn;")" 
     End if
     COut(N) = CRest
     Return
  End if
End Sub

Sub CC_Cut_FB(CIn As String, CDiv As String, COut() As String, _
     CComment As String, ByRef N As Integer) 
  /' Cuts a string into pieces with CDiv as divider '/ 
  /' Special treatment for blank as devider: 
       multiple blanks count as one divider '/  
  /' Does not devide parts in brackets. '/
  /' Any kind of brackets not allowed as divider. '/ 
  /' FreeBASIC-type comments are cut and stored separately '/
  Dim As Integer I, I_Level, I_Comment_Final, I_cut
  Static As Integer I_Comment = 0
  
  If Left(CIn,1) = "(" And Right(CIn,1) = ")" Then
    CIn = Mid(CIn,2,Len(CIn)-2)
  End If   
  If CDiv = " " Then   ' Blanks before or after commas should not divide
    Do While Instr(CIn," ,") > 0
      I_cut = Instr(CIn," ,") 
      CIn = Mid(CIn,1,I_cut-1) + Mid(CIn,I_cut+1) 
    Loop
    Do While Instr(CIn,", ") > 0 
      I_cut = Instr(CIn,", ") + 1 
      CIn = Mid(CIn,1,I_cut-1) + Mid(CIn,I_cut+1)
    Loop    
    CIn = Trim(CIn)+" "
  End If
  
  If (Instr(Ucase(CIn),"DIM") = 1 _
    Or Instr(Ucase(CIn),"REDIM") = 1 _
    Or Instr(Ucase(CIn),"CONST") = 1 _
    Or Instr(Ucase(CIn),"STATIC") = 1) _
    And Instr(Ucase(CIn),"AS") > 0 Then 
    Do While Instr(CIn," =") > 0
      I_cut = Instr(CIn," =") 
      CIn = Mid(CIn,1,I_cut-1) + Mid(CIn,I_cut+1) 
    Loop
    Do While Instr(CIn,"= ") > 0 
      I_cut = Instr(CIn,"= ") + 1 
      CIn = Mid(CIn,1,I_cut-1) + Mid(CIn,I_cut+1)
    Loop
  End If       
  
  I_Comment_Final = 0
  CComment = ""
  
  If LBound(COut,1) > 1 Or UBound(COut,1) < 1 Or CIn = "" Then
    ' Illegal input
    N = 0 
  ElseIf Instr("()[]{}",CDiv) > 0 Then
    ' Brackets not allowed as divider, return whole string
    N = 1
    COut(1) = CIn
  Else
    ' Normal treatment
    N = 1
    COut(N) = ""

    For I = 1 To Len(CIn)

    ' Comments are separated and not further divided
      If I < Len(CIn) Then
        If Mid(CIn,I,2) = "/'" Then 
          I_Comment = I_Comment + 1
          If I_Comment = 1 Then
            COut(N) = Trim(COut(N))
            If COut(N) <> "" Then
              N = N + 1
              COut(N) = ""
            End If
          End If
        End If
        If Mid(CIn,I,1) = "'" And Mid(CIn,I+1,1) <> "/" Then
          I_Comment_Final = 1
          COut(N) = Trim(COut(N))
          If COut(N) <> "" Then
            N = N + 1
            COut(N) = ""
          End If  
        End If       
      End If
      If I >= 2 Then  
        If Mid(CIn,I-1,2) = "'/" Then
          I_Comment = I_Comment - 1
          If I_Comment = 1 Then
            COut(N) = Trim(COut(N))
            If COut(N) <> "" Then
              N = N + 1
              COut(N) = ""
            End If  
          End If          
        End If  
        If Mid(CIn,I,1) = "'" And Mid(CIn,I-1,1) <> "/" Then
          I_Comment_Final = 1
          COut(N) = Trim(COut(N))
          If COut(N) <> "" Then
            N = N + 1
            COut(N) = ""
          End If  
        End If
      End If
      
      ' Copy comments unmodified into CComment
      If I_Comment > 0 Or I_Comment_Final > 0 Then
        CComment = CComment + Mid(CIn,I,1)
      End If  
      
      ' Count brackets outside comments
      If I_Comment = 0 And I_Comment_Final = 0 Then
        If Instr("([{",Mid(CIn,I,1)) > 0 Then
          I_Level = I_Level + 1
        End If
        If I > 1 Then
          If Instr(")]}",Mid(CIn,I-1,1)) > 0 Then
            I_Level = I_Level - 1
          End If
        End If  
      End If  
      
      If I_Level = 0 And I_Comment = 0 And I_Comment_Final = 0 Then
        If I = Len(CIn) Then  ' last character in CIn
          COut(N) = COut(N) + Mid(CIn,I,1)
        End If
        If I < Len(CIn) Then
          
          If Mid(CIn,I,2) = "  " Then
             ' ignore multiple blanks: do nothing   

          ElseIf Mid(CIn,I,1) = CDiv Then
             ' Divider found (divider is not copied)
            COut(N) = Trim(COut(N))
            N = N + 1
            COut(N) = ""
          Else
            COut(N) = COut(N) + Mid(CIn,I,1)  
          End If 
        End If
      End If  
      
      ' Do not divide inside brackets, just copy
      If I_Level > 0 And I_Comment = 0 And I_Comment_Final = 0 Then
        COut(N) = COut(N) + Mid(CIn,I,1)  
      End If
      
    Next
    
    For I = 2 To N
      COut(N) = Trim(COut(N))
    Next
      
    If COut(N) = "" Then
      N = N - 1
    End If
      
  End If  ' Normal treatment
  
  COut(N) = Trim(COut(N))
  
End Sub

Sub CC_Parm(CIn As String, CMain As String, CParm As String)
  If CIn <> "" Then     
    If Instr(CIn,"(") > 0 And Right(CIn,1) = ")" Then
      CMain = Mid(CIn,1,Instr(CIn,"(")-1)
      CParm = Mid(CIn,Instr(CIn,"(")+1)
      CParm = Left(CParm,Len(CParm)-1)
    Else 
      CMain = CIn
      CParm = ""
    End If
  Else
    CMain = ""
    CParm = ""
  End If   
End Sub

Function Tally(CIn As String,CTest As String) As Integer
  Dim As Integer I, Icnt
  Icnt = 0
  If CIn <> "" Then
    For I = 1 To Len(CIn) - Len(CTest)
      If Instr(I,CIn,CTest) = I Then 
        Icnt = Icnt + 1
      End If
    Next
  End If
  Tally = Icnt
End Function

Function U_Type(CIn As String) As String
  Dim As String C_fortran = "NONE"
  Dim As Integer I
  For I = 1 To N_Type
    If Ucase(CIn) = Type_List(I,1) Then
      C_fortran = Type_List(I,2)
    End If
  Next
  U_Type = C_fortran
'  Print "C_FB, C_Fortran ";CIn,C_fortran
End Function

Sub U_Print(C_out As String)
     ' Printing
     Dim As Ubyte B_cont = 0
     Dim As Integer I
     Dim As String C_Out_Trunc
     If C_out <> "" Then
       While Len(C_out) > 66 
         For I = 66 To 1 Step -1
           If Mid(C_out,I,1) = " " Or Mid(C_Out,I,1) = "," Then
             C_Out_Trunc = Left(C_out,I)
             If B_cont = 1 Then
               Print #Fout, "     *" + C_Out_Trunc
             Else
               Print #Fout, "      " + C_Out_Trunc  
             End If
             C_Out = Mid(C_out,I+1)
             Exit For
           End If
         Next
         B_cont = 1
       Wend
       If B_cont = 1 Then
         Print #Fout, "     *" + C_Out
       Else
         Print #Fout, "      " + C_Out
       End If
     End If
End Sub     

