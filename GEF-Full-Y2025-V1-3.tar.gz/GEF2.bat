Rem This bat file starts 2 batch jobs of GEF for input from file.
Rem The delay is necessary for the multi-thread organisation.
start GEF.exe
Pause
start GEF.exe
