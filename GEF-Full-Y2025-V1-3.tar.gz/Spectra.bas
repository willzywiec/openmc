  /' Calculated spectra: '/

  /' I. Potential energy as a function of Z partition '/

    Redim EMpot(7,150) As Single
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EMpot"
    Anl_Par(I_Anl).C_Title = "Potential energy for first-chance fission"
    Anl_Par(I_Anl).C_xaxis = "Fragment atomic number"
    Anl_Par(I_Anl).C_yaxis = "E / MeV"
    Anl_Par(I_Anl).C_Linesymbol = "LTBR1"
    Anl_Par(I_Anl).C_Type = "digital"

  /' II. Multi-chance energies at fission '/
  
    Redim Emultichance(0 to 1000) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Emultichance"
    Anl_Par(I_Anl).C_Title = "E* at fission"
    Anl_Par(I_Anl).C_xaxis = "Ee$x$c$ / MeV"
    Anl_Par(I_Anl).C_yaxis = "Probability"
    Anl_Par(I_Anl).R_Alim(1,1) = 0.1
    Anl_Par(I_Anl).R_Alim(1,3) = 0.1    
    Anl_Par(I_Anl).C_Linesymbol = "HTB0"
    Anl_Par(I_Anl).C_Type = "digital"

  /' III. Nuclide distributions '/

    ReDim ZPROV(150) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ZPROV"
    Anl_Par(I_Anl).C_Title = "Provisional element distribution"
    Anl_Par(I_Anl).C_xaxis = "Atomic number"
    Anl_Par(I_Anl).C_yaxis = "Yield"
    Anl_Par(I_Anl).C_Linesymbol = "LTR11"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim ZMPROV(0 To 7,150) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ZMPROV"
    Anl_Par(I_Anl).C_Title = "Provisional element distribution"
    Anl_Par(I_Anl).C_xaxis = "Atomic number"
    Anl_Par(I_Anl).C_yaxis = "Yield"
    Anl_Par(I_Anl).C_Linesymbol = "RBT1"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim Shared _NZPOST(0 To 50,20 To 70) As Double   ' N-Z and Z
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NZPOST"
    Anl_Par(I_Anl).C_Title = "Nuclide distribution, post-neutron"
    Anl_Par(I_Anl).C_xaxis = "Neutron number"
    Anl_Par(I_Anl).C_yaxis = "Atomic number"
    Anl_Par(I_Anl).C_Type = "digital"
    Declare Function NZPOST(I_N As Integer, I_Z As Integer) As Double   ' N and Z
    Function NZPOST (I_N As Integer, I_Z As Integer) As Double
       ' Read value of _NZPOST
      Dim As Integer I_NminusZ
      I_NminusZ = I_N - I_Z
      If I_NminusZ >= Lbound(_NZPOST,1) And I_NminusZ <= Ubound(_NZPOST,1) And _ 
         I_Z >= Lbound(_NZPOST,2) And I_Z <= Ubound(_NZPOST,2) Then
         NZPOST = _NZPOST(I_NminusZ,I_Z)
      Else
        NZPOST = 0
      End If     
    End Function    
    Sub Acc_NZPOST(I_N As Integer, I_Z As Integer, Value As Double)
      ' Accumulate value in _NZPOST
      Dim As Integer I_NminusZ  
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2
      I_NminusZ = I_N - I_Z
      If I_NminusZ < Lbound(_NZPOST,1) Or I_NminusZ > Ubound(_NZPOST,1) _
         Or I_Z < Lbound(_NZPOST,2) Or I_Z > Ubound(_NZPOST,2) Then 
        I_Lbound1 = Min(Lbound(_NZPOST,1),I_NminusZ)
        I_Ubound1 = Max(Ubound(_NZPOST,1),I_NminusZ)
        I_Lbound2 = Min(Lbound(_NZPOST,2),I_Z)
        I_Ubound2 = Max(Ubound(_NZPOST,2),I_Z)
        Extend_2dim(_NZPOST(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2)
      End If
      _NZPOST(I_NminusZ,I_Z) = _NZPOST(I_NminusZ,I_Z) + Value
    End Sub 

    ReDim ZPOST(150) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ZPOST"
    Anl_Par(I_Anl).C_Title = "Element distribution, post-neutron"
    Anl_Par(I_Anl).C_xaxis = "Atomic number"
    Anl_Par(I_Anl).C_yaxis = "Yield"
    Anl_Par(I_Anl).C_Linesymbol = "RT11"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim ZMPOST(0 To 7,150) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ZMPOST"
    Anl_Par(I_Anl).C_Title = "Element distribution, post-neutron"
    Anl_Par(I_Anl).C_xaxis = "Atomic number"
    Anl_Par(I_Anl).C_yaxis = "Yield"
    Anl_Par(I_Anl).C_Linesymbol = "RBT1"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim NPRE(200) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NPRE"
    Anl_Par(I_Anl).C_Title = "Neutron-number distribution, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Neutron number"
    Anl_Par(I_Anl).C_yaxis = "Yield"
    Anl_Par(I_Anl).C_Linesymbol = "RT11"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim NMPRE(0 To 7,200) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NMPRE"
    Anl_Par(I_Anl).C_Title = "Neutron-number distribution, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Neutron number"
    Anl_Par(I_Anl).C_yaxis = "Yield"
    Anl_Par(I_Anl).C_Linesymbol = "RBT1"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim NPOST(200) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NPOST"
    Anl_Par(I_Anl).C_Title = "Neutron-number distribution, post-neutron"
    Anl_Par(I_Anl).C_xaxis = "Neutron number"
    Anl_Par(I_Anl).C_yaxis = "Yield"
    Anl_Par(I_Anl).C_Linesymbol = "RT11"  
    Anl_Par(I_Anl).C_Type = "digital"
    
    ReDim NMPOST(0 To 7,200) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NMPOST"
    Anl_Par(I_Anl).C_Title = "Neutron-number distribution, post-neutron"
    Anl_Par(I_Anl).C_xaxis = "Neutron number"
    Anl_Par(I_Anl).C_yaxis = "Yield"
    Anl_Par(I_Anl).C_Linesymbol = "RBT1"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim Shared APOST(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "APOST"
    Anl_Par(I_Anl).C_Title = "Mass distribution, post-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Yield"
    Anl_Par(I_Anl).C_Linesymbol = "BT11"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim AMPOST(0 To 7,350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "AMPOST"
    Anl_Par(I_Anl).C_Title = "Mass distribution, post-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Yield"
    Anl_Par(I_Anl).C_Linesymbol = "GT1"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim APROV(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "APROV"
    Anl_Par(I_Anl).C_Title = "Provisional mass distribution, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Yield"
    Anl_Par(I_Anl).C_Linesymbol = "GT11"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim AMPROV(0 To 7,350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "AMPROV"
    Anl_Par(I_Anl).C_Title = "Provisional mass distribution, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Yield"
    Anl_Par(I_Anl).C_Linesymbol = "GT1"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim APRE(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "APRE"
    Anl_Par(I_Anl).C_Title = "Mass distribution, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Yield"
    Anl_Par(I_Anl).C_Linesymbol = "GT11"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim AMPRE(0 To 7,350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "AMPRE"
    Anl_Par(I_Anl).C_Title = "Mass distribution, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Yield"
    Anl_Par(I_Anl).C_Linesymbol = "GT1"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim Shared _ZISOPRE(50 To 160,20 To 80) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ZISOPRE"
    Anl_Par(I_Anl).C_Title = "Isobaric Z distribution for A = &, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Atomic number"
    Anl_Par(I_Anl).C_Linesymbol = "LRT11"  
    Anl_Par(I_Anl).C_Type = "digital"
    Declare Function ZISOPRE(I_A As Integer, I_Z As Integer) As Double   ' A and neutron energy
    Function ZISOPRE (I_A As Integer, I_Z As Integer) As Double
       ' Read value of ZISOPRE
      If I_A >= Lbound(_ZISOPRE,1) And I_A <= Ubound(_ZISOPRE,1) And _ 
         I_Z >= Lbound(_ZISOPRE,2) And I_Z <= Ubound(_ZISOPRE,2) Then
         ZISOPRE = _ZISOPRE(I_A,I_Z)
      Else
        ZISOPRE = 0
      End If     
    End Function    
    Sub Acc_ZISOPRE(I_A As Integer, I_Z As Integer, Value As Double)
      ' Accumulate value in _ZISOPRE
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2
      If I_A < Lbound(_ZISOPRE,1) Or I_A > Ubound(_ZISOPRE,1) _
         Or I_Z < Lbound(_ZISOPRE,2) Or I_Z > Ubound(_ZISOPRE,2) Then 
        I_Lbound1 = Min(Lbound(_ZISOPRE,1),I_A)
        I_Ubound1 = Max(Ubound(_ZISOPRE,1),I_A)
        I_Lbound2 = Min(Lbound(_ZISOPRE,2),I_Z)
        I_Ubound2 = Max(Ubound(_ZISOPRE,2),I_Z)
        Extend_2dim(_ZISOPRE(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2)
      End If
      _ZISOPRE(I_A,I_Z) = _ZISOPRE(I_A,I_Z) + Value
    End Sub             

    ReDim Shared _ZISOPOST(50 To 160,20 To 80) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ZISOPOST"
    Anl_Par(I_Anl).C_Title = "Isobaric Z distribution for A = &, post-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Atomic number"
    Anl_Par(I_Anl).C_Linesymbol = "LRT11"  
    Anl_Par(I_Anl).C_Type = "digital"
    Declare Function ZISOPOST(I_A As Integer, I_Z As Integer) As Double   ' A and neutron energy
    Function ZISOPOST (I_A As Integer, I_Z As Integer) As Double
       ' Read value of ZISOPOST
      If I_A >= Lbound(_ZISOPOST,1) And I_A <= Ubound(_ZISOPOST,1) And _ 
         I_Z >= Lbound(_ZISOPOST,2) And I_Z <= Ubound(_ZISOPOST,2) Then
         ZISOPOST = _ZISOPOST(I_A,I_Z)
      Else
        ZISOPOST = 0
      End If     
    End Function    
    Sub Acc_ZISOPOST(I_A As Integer, I_Z As Integer, Value As Double)
      ' Accumulate value in _ZISOPOST
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2
      If I_A < Lbound(_ZISOPOST,1) Or I_A > Ubound(_ZISOPOST,1) _
         Or I_Z < Lbound(_ZISOPOST,2) Or I_Z > Ubound(_ZISOPOST,2) Then 
        I_Lbound1 = Min(Lbound(_ZISOPOST,1),I_A)
        I_Ubound1 = Max(Ubound(_ZISOPOST,1),I_A)
        I_Lbound2 = Min(Lbound(_ZISOPOST,2),I_Z)
        I_Ubound2 = Max(Ubound(_ZISOPOST,2),I_Z)
        Extend_2dim(_ZISOPOST(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2)
      End If
      _ZISOPOST(I_A,I_Z) = _ZISOPOST(I_A,I_Z) + Value
    End Sub             

    ReDim SigmaZpre(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "SigmaZpre"
    Anl_Par(I_Anl).C_Title = "Sigma of isobaric Z distribution"
    Anl_Par(I_Anl).C_xaxis = "Mass number, pre-neutron"
    Anl_Par(I_Anl).C_yaxis = "si^Z$"
    Anl_Par(I_Anl).C_Linesymbol = "LRT11"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim SigmaZpost(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "SigmaZpost"
    Anl_Par(I_Anl).C_Title = "Sigma of isobaric Z distribution"
    Anl_Par(I_Anl).C_xaxis = "Mass number, post-neutron"
    Anl_Par(I_Anl).C_yaxis = "si^Z$"
    Anl_Par(I_Anl).C_Linesymbol = "LRT11"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim Zpolarpre(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Zpolarpre"
    Anl_Par(I_Anl).C_Title = "Charge polarisation"
    Anl_Par(I_Anl).C_xaxis = "Mass number, pre-neutron"
    Anl_Par(I_Anl).C_yaxis = "Zb$a$r$ - ZU$C$D$"
    Anl_Par(I_Anl).C_Linesymbol = "LRT11"  
    Anl_Par(I_Anl).C_Type = "digital"
                               
    ReDim Zpolarmac(350) As Double                            
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Zpolarmac"
    Anl_Par(I_Anl).C_Title = "Charge polarisation, macroscopic"
    Anl_Par(I_Anl).C_xaxis = "Mass number, pre-neutron"
    Anl_Par(I_Anl).C_yaxis = "Zb$a$r$ - ZU$C$D$"
    Anl_Par(I_Anl).C_Linesymbol = "LGT11"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim Zpolarpost(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Zpolarpost"
    Anl_Par(I_Anl).C_Title = "Charge polarisation"
    Anl_Par(I_Anl).C_xaxis = "Mass number, post-neutron"
    Anl_Par(I_Anl).C_yaxis = "Zb$a$r$ - ZU$C$D$"
    Anl_Par(I_Anl).C_Linesymbol = "LRT11"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim Shared _Edefo2d(50 To 200,100) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Edefo2d"
    Anl_Par(I_Anl).C_Title = "Deformation energy over mass number, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Ed$e$f$o$ / MeV"
    Anl_Par(I_Anl).R_Alim(2,3) = 0.1
    Anl_Par(I_Anl).I_Dim = 2
    Anl_Par(I_Anl).C_Type = "digital"
    Declare Function Edefo2d(I_A As Integer, I_E As Integer) As Double   ' A and neutron energy
    Function Edefo2d (I_A As Integer, I_E As Integer) As Double
       ' Read value of Edefo2d
      If I_A >= Lbound(_Edefo2d,1) And I_A <= Ubound(_Edefo2d,1) And _ 
         I_E >= Lbound(_Edefo2d,2) And I_E <= Ubound(_Edefo2d,2) Then
         Edefo2d = _Edefo2d(I_A,I_E)
      Else
        Edefo2d = 0
      End If     
    End Function    
    Sub Acc_Edefo2d(I_A As Integer, I_E As Integer, Value As Double)
      ' Accumulate value in _Edefo2d
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2
      If I_A < Lbound(_Edefo2d,1) Or I_A > Ubound(_Edefo2d,1) _
         Or I_E < Lbound(_Edefo2d,2) Or I_E > Ubound(_Edefo2d,2) Then 
        I_Lbound1 = Min(Lbound(_Edefo2d,1),I_A)
        I_Ubound1 = Max(Ubound(_Edefo2d,1),I_A)
        I_Lbound2 = Min(Lbound(_Edefo2d,2),I_E)
        I_Ubound2 = Max(Ubound(_Edefo2d,2),I_E)
        Extend_2dim(_Edefo2d(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2)
      End If
      _Edefo2d(I_A,I_E) = _Edefo2d(I_A,I_E) + Value
    End Sub         
    
    Redim EdefoA(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EdefoA"
    Anl_Par(I_Anl).C_Title = "Mean deformation energy versus mass number, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "<Ed$e$f$o$> / MeV"
    Anl_Par(I_Anl).R_Alim(1,3) = 1
    Anl_Par(I_Anl).C_Linesymbol = "LGT11"
    Anl_Par(I_Anl).C_Type = "digital"

     
    Redim Shared _JFRAGpre(0 To 50,20 To 70,0 To 20) As Double  ' Array of N-Z and Z
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "JFRAGpre"
    Anl_Par(I_Anl).C_Title = "Fragment spin distribution, unit 1 hb^, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "J / hb^"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "LTR11"  
    Anl_Par(I_Anl).C_Type = "digital"
    Declare Function JFRAGpre(I_N As Integer, I_Z As Integer,I_Spin As Integer) As Double
    Function JFRAGpre (I_N As Integer, I_Z As Integer, I_Spin As Integer) As Double
       ' Read value of _JFRAGpre
      Dim As Integer I_NminusZ
      I_NminusZ = I_N - I_Z
      If I_NminusZ >= Lbound(_JFRAGpre,1) And I_NminusZ <= Ubound(_JFRAGpre,1) And _ 
         I_Z >= Lbound(_JFRAGpre,2) And I_Z <= Ubound(_JFRAGpre,2) And _
         I_Spin >= Lbound(_JFRAGpre,3) And I_Spin <= Ubound(_JFRAGpre,3) Then
        JFRAGpre = _JFRAGpre(I_NminusZ,I_Z,I_Spin)
      Else
        JFRAGpre = 0
      End If     
    End Function
    Declare Sub Acc_JFRAGpre(I_N As Integer, I_Z As Integer, I_Spin As Integer, Value As Double) 
    Sub Acc_JFRAGpre(I_N As Integer, I_Z As Integer, I_Spin As Integer, Value As Double)
      ' Accumulate value in _JFRAGpre
      Dim As Integer I_NminusZ  
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2,I_Lbound3, I_Ubound3
      I_NminusZ = I_N - I_Z
      If I_NminusZ < Lbound(_JFRAGpre,1) Or I_NminusZ > Ubound(_JFRAGpre,1) _
         Or I_Z < Lbound(_JFRAGpre,2) Or I_Z > Ubound(_JFRAGpre,2) _
         Or I_Spin < Lbound(_JFRAGpre,3) Or I_Spin > Ubound(_JFRAGpre,3) Then
        I_Lbound1 = Min(Lbound(_JFRAGpre,1),I_NminusZ)
        I_Ubound1 = Max(Ubound(_JFRAGpre,1),I_NminusZ)
        I_Lbound2 = Min(Lbound(_JFRAGpre,2),I_Z)
        I_Ubound2 = Max(Ubound(_JFRAGpre,2),I_Z)
        I_Lbound3 = Min(Lbound(_JFRAGpre,3),I_Spin)
        I_Ubound3 = Max(Ubound(_JFRAGpre,3),I_Spin)
        Extend_3dim(_JFRAGpre(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2,I_Lbound3,I_Ubound3)
      End If
      _JFRAGpre(I_NminusZ,I_Z,I_Spin) = _JFRAGpre(I_NminusZ,I_Z,I_Spin) + Value
    End Sub 

    Redim Shared _JFRAGpost(0 To 50,20 To 70,0 To 20) As Double  ' Array of N-Z and Z
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "JFRAGpost"
    Anl_Par(I_Anl).C_Title = "Fragment spin distribution, unit 1 hb^, post-neutron"
    Anl_Par(I_Anl).C_xaxis = "J / hb^"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "LTR11"  
    Anl_Par(I_Anl).C_Type = "digital"
    Declare Function JFRAGpost(I_N As Integer,I_Z As Integer,I_Spin As Integer) As Double
    Function JFRAGpost (I_N As Integer,I_Z As Integer, I_Spin As Integer) As Double
       ' Read value of _JFRAGpost
      Dim As Integer I_NminusZ
      I_NminusZ = I_N - I_Z
      If I_NminusZ >= Lbound(_JFRAGpost,1) And I_NminusZ <= Ubound(_JFRAGpost,1) And _
         I_Z >= Lbound(_JFRAGpost,2) And I_Z <= Ubound(_JFRAGpost,2) And _
         I_Spin >= Lbound(_JFRAGpost,3) And I_Spin <= Ubound(_JFRAGpost,3) Then
        JFRAGpost = _JFRAGpost(I_NminusZ,I_Z,I_Spin)
      Else
        JFRAGpost = 0
      End If     
    End Function
    Declare Sub Acc_JFRAGpost(I_N As Integer, I_Z As Integer, I_Spin As Integer, Value As Double) 
    Sub Acc_JFRAGpost(I_N As Integer, I_Z As Integer, I_Spin As Integer, Value As Double)
      ' Accumulate value in _JFRAGpost
      Dim As Integer I_NminusZ  
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2,I_Lbound3, I_Ubound3
      I_NminusZ = I_N - I_Z
      If I_NminusZ < Lbound(_JFRAGpost,1) Or I_NminusZ > Ubound(_JFRAGpost,1) Or _
         I_Z < Lbound(_JFRAGpost,2) Or I_Z > Ubound(_JFRAGpost,2) Or _ 
         I_Spin < Lbound(_JFRAGpost,3) Or I_Spin > Ubound(_JFRAGpost,3) Then
        I_Lbound1 = Min(Lbound(_JFRAGpost,1),I_NminusZ)
        I_Ubound1 = Max(Ubound(_JFRAGpost,1),I_NminusZ)
        I_Lbound2 = Min(Lbound(_JFRAGpost,2),I_Z)
        I_Ubound2 = Max(Ubound(_JFRAGpost,2),I_Z)
        I_Lbound3 = Min(Lbound(_JFRAGpost,3),I_Spin)
        I_Ubound3 = Max(Ubound(_JFRAGpost,3),I_Spin)
        Extend_3dim(_JFRAGpost(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2,I_Lbound3,I_Ubound3)
      End If
      _JFRAGpost(I_NminusZ,I_Z,I_Spin) = _JFRAGpost(I_NminusZ,I_Z,I_Spin) + Value
    End Sub 

    ReDim Shared _Eintr2d(80 To 160,50) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Eintr2d"
    Anl_Par(I_Anl).C_Title = "Intrinsic energy over mass number, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Ei$n$t$r$ / MeV"
    Anl_Par(I_Anl).R_Alim(2,3) = 0.1
    Anl_Par(I_Anl).I_Dim = 2
    Anl_Par(I_Anl).C_Type = "digital"
    Declare Function Eintr2d(I_A As Integer,I_E As Integer) As Double
    Function Eintr2d (I_A As Integer,I_E As Integer) As Double
       ' Read value of _Eintr2d
      If I_A >= Lbound(_Eintr2d,1) And I_A <= Ubound(_Eintr2d,1) And _
         I_E >= Lbound(_Eintr2d,2) And I_E <= Ubound(_Eintr2d,2) Then
        Eintr2d = _Eintr2d(I_A,I_E)
      Else
        Eintr2d = 0
      End If     
    End Function
    Declare Sub Acc_Eintr2d(I_A As Integer, I_E As Integer, Value As Double) 
    Sub Acc_Eintr2d(I_A As Integer, I_E As Integer, Value As Double)
      ' Accumulate value in _Eintr2d
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2
      If I_A < Lbound(_Eintr2d,1) Or I_A > Ubound(_Eintr2d,1) Or _
         I_E < Lbound(_Eintr2d,2) Or I_E > Ubound(_Eintr2d,2) Then
        I_Lbound1 = Min(Lbound(_Eintr2d,1),I_A)
        I_Ubound1 = Max(Ubound(_Eintr2d,1),I_A)
        I_Lbound2 = Min(Lbound(_Eintr2d,2),I_E)
        I_Ubound2 = Max(Ubound(_Eintr2d,2),I_E)
        Extend_2dim(_Eintr2d(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2)
      End If
      _Eintr2d(I_A,I_E) = _Eintr2d(I_A,I_E) + Value
    End Sub 

    Redim EintrA(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EintrA"
    Anl_Par(I_Anl).C_Title = "Mean intrinsic energy versus mass number, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "<Ei$n$t$r$> / MeV"
    Anl_Par(I_Anl).C_Linesymbol = "LGT11"
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim Shared _Ecoll2d(80 To 160,50) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Ecoll2d"
    Anl_Par(I_Anl).C_Title = "Collective energy over mass number, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Ec$o$l$l$ / MeV"
    Anl_Par(I_Anl).R_Alim(2,3) = 0.1
    Anl_Par(I_Anl).I_Dim = 2
    Anl_Par(I_Anl).C_Type = "digital"
    Declare Function Ecoll2d(I_A As Integer,I_E As Integer) As Double
    Function Ecoll2d (I_A As Integer,I_E As Integer) As Double
       ' Read value of _Ecoll2d
      If I_A >= Lbound(_Ecoll2d,1) And I_A <= Ubound(_Ecoll2d,1) And _
         I_E >= Lbound(_Ecoll2d,2) And I_E <= Ubound(_Ecoll2d,2) Then
        Ecoll2d = _Ecoll2d(I_A,I_E)
      Else
        Ecoll2d = 0
      End If     
    End Function
    Declare Sub Acc_Ecoll2d(I_A As Integer, I_E As Integer, Value As Double) 
    Sub Acc_Ecoll2d(I_A As Integer, I_E As Integer, Value As Double)
      ' Accumulate value in _Ecoll2d
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2
      If I_A < Lbound(_Ecoll2d,1) Or I_A > Ubound(_Ecoll2d,1) Or _
         I_E < Lbound(_Ecoll2d,2) Or I_E > Ubound(_Ecoll2d,2) Then
        I_Lbound1 = Min(Lbound(_Ecoll2d,1),I_A)
        I_Ubound1 = Max(Ubound(_Ecoll2d,1),I_A)
        I_Lbound2 = Min(Lbound(_Ecoll2d,2),I_E)
        I_Ubound2 = Max(Ubound(_Ecoll2d,2),I_E)
        Extend_2dim(_Ecoll2d(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2)
      End If
      _Ecoll2d(I_A,I_E) = _Ecoll2d(I_A,I_E) + Value
    End Sub 

    Redim EcollA(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EcollA"
    Anl_Par(I_Anl).C_Title = "Mean collective energy versus mass number, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "<Ec$o$l$l$> / MeV"
    Anl_Par(I_Anl).R_Alim(1,3) = 1
    Anl_Par(I_Anl).C_Linesymbol = "LGT11"
    Anl_Par(I_Anl).C_Type = "digital"

    Redim Shared _EexcA2d(80 To 160,100) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Eexc2dlight"
    Anl_Par(I_Anl).C_Title = "Excitation energy over mass number, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Ee$x$c$ / MeV"
    Anl_Par(I_Anl).C_Linesymbol = "LTR11"  
    Anl_Par(I_Anl).R_Alim(2,3) = 0.1
    Anl_Par(I_Anl).I_Dim = 2
    Anl_Par(I_Anl).C_Type = "digital"
    Declare Function EexcA2d(I_A As Integer,I_E As Integer) As Double
    Function EexcA2d (I_A As Integer,I_E As Integer) As Double
       ' Read value of _EexcA2d
      If I_A >= Lbound(_EexcA2d,1) And I_A <= Ubound(_EexcA2d,1) And _
         I_E >= Lbound(_EexcA2d,2) And I_E <= Ubound(_EexcA2d,2) Then
        EexcA2d = _EexcA2d(I_A,I_E)
      Else
        EexcA2d = 0
      End If     
    End Function
    Declare Sub Acc_EexcA2d(I_A As Integer, I_E As Integer, Value As Double) 
    Sub Acc_EexcA2d(I_A As Integer, I_E As Integer, Value As Double)
      ' Accumulate value in _EexcA2d
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2
      If I_A < Lbound(_EexcA2d,1) Or I_A > Ubound(_EexcA2d,1) Or _
         I_E < Lbound(_EexcA2d,2) Or I_E > Ubound(_EexcA2d,2) Then
        I_Lbound1 = Min(Lbound(_EexcA2d,1),I_A)
        I_Ubound1 = Max(Ubound(_EexcA2d,1),I_A)
        I_Lbound2 = Min(Lbound(_EexcA2d,2),I_E)
        I_Ubound2 = Max(Ubound(_EexcA2d,2),I_E)
        Extend_2dim(_EexcA2d(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2)
      End If
      _EexcA2d(I_A,I_E) = _EexcA2d(I_A,I_E) + Value
    End Sub     
    
    Redim EexcL2dlight(1000,50) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EexcL2dlight"
    Anl_Par(I_Anl).C_Title = "Intrinsic excitation energy over angular momentum"
    Anl_Par(I_Anl).C_xaxis = "L / hb^"
    Anl_Par(I_Anl).C_yaxis = "Ee$x$c$ / MeV"
    Anl_Par(I_Anl).R_Alim(2,3) = 0.1
    Anl_Par(I_Anl).I_Dim = 2
    Anl_Par(I_Anl).C_Type = "digital"

    Redim ErotL2dlight(500,50) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ErotL2dheavy"
    Anl_Par(I_Anl).C_Title = "Rotational energy over angular momentum"
    Anl_Par(I_Anl).C_xaxis = "L / hb^"
    Anl_Par(I_Anl).C_yaxis = "Er$o$t$ / MeV"
    Anl_Par(I_Anl).R_Alim(2,3) = 0.1
    Anl_Par(I_Anl).I_Dim = 2
    Anl_Par(I_Anl).C_Type = "digital"
    Redim EexcL2dheavy(1000,50) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EexcL2dheavy"
    Anl_Par(I_Anl).C_Title = "Intrinsic excitation energy over angular momentum"
    Anl_Par(I_Anl).C_xaxis = "L / hb^"
    Anl_Par(I_Anl).C_yaxis = "Ee$x$c$ / MeV"
    Anl_Par(I_Anl).R_Alim(2,3) = 0.1
    Anl_Par(I_Anl).I_Dim = 2

    Redim ErotL2dheavy(500,50) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ErotL2d"
    Anl_Par(I_Anl).C_Title = "Rotational energy over angular momentum"
    Anl_Par(I_Anl).C_xaxis = "L / hb^"
    Anl_Par(I_Anl).C_yaxis = "Er$o$t$ / MeV"
    Anl_Par(I_Anl).R_Alim(2,3) = 0.1
    Anl_Par(I_Anl).I_Dim = 2
    Anl_Par(I_Anl).C_Type = "digital"

    Redim Nmulti2dpre(350,20) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Nmulti2dpre"
    Anl_Par(I_Anl).C_Title = "Prompt-neutron multiplicity (from CN) over pre-neutron mass"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Neutron multiplicity"
    Anl_Par(I_Anl).I_Dim = 2
    Anl_Par(I_Anl).C_Type = "digital"

    Redim Nmulti2dpost(350,20) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Nmulti2dpost"
    Anl_Par(I_Anl).C_Title = "Prompt-neutron multiplicity (from CN) over post-neutron mass"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Neutron multiplicity"
    Anl_Par(I_Anl).I_Dim = 2
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim N2dpre(350,20) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "N2dpre"
    Anl_Par(I_Anl).C_Title = "Prompt-neutron multiplicity (from fragments) over pre-neutron mass"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Neutron multiplicity"
    Anl_Par(I_Anl).I_Dim = 2
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim N2dpost(350,20) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "N2dpost"
    Anl_Par(I_Anl).C_Title = "Prompt-neutron multiplicity (from fragments) over post-neutron mass"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Neutron multiplicity"
    Anl_Par(I_Anl).I_Dim = 2
    Anl_Par(I_Anl).C_Type = "digital"
                               
    ReDim NmultiApre(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NmultiApre"
    Anl_Par(I_Anl).C_Title = "Mean prompt neutron multiplicity (from CN) as a function of pre-neutron mass"
    Anl_Par(I_Anl).C_xaxis = "Mass number, pre-neutron"
    Anl_Par(I_Anl).C_yaxis = "Mean neutron multiplicity"
    Anl_Par(I_Anl).C_Linesymbol = "LTR11"  
    Anl_Par(I_Anl).C_Type = "digital"
    
    ReDim NmultiApost(350) As Double                           
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NmultiApost"
    Anl_Par(I_Anl).C_Title = "Mean prompt neutron multiplicity (from CN) as a function of post-neutron mass"
    Anl_Par(I_Anl).C_xaxis = "Mass number, post-neutron"
    Anl_Par(I_Anl).C_yaxis = "Mean neutron multiplicity"
    Anl_Par(I_Anl).C_Linesymbol = "LTR11"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim NApre(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NApre"
    Anl_Par(I_Anl).C_Title = "Mean prompt neutron multiplicity (from fragments) as a function of pre-neutron mass"
    Anl_Par(I_Anl).C_xaxis = "Mass number, pre-neutron"
    Anl_Par(I_Anl).C_yaxis = "Mean neutron multiplicity"
    Anl_Par(I_Anl).C_Linesymbol = "LTR11"  
    Anl_Par(I_Anl).C_Type = "digital"
    
    ReDim NApost(350) As Double                           
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NApost"
    Anl_Par(I_Anl).C_Title = "Mean prompt neutron multiplicity (from fragments) as a function of post-neutron mass"
    Anl_Par(I_Anl).C_xaxis = "Mass number, post-neutron"
    Anl_Par(I_Anl).C_yaxis = "Mean neutron multiplicity"
    Anl_Par(I_Anl).C_Linesymbol = "LTR11"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim Shared _EPCN(1000) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EPCN"
    Anl_Par(I_Anl).C_Title = "Prompt proton-energy spectrum from CN"
    Anl_Par(I_Anl).C_xaxis = "Energy / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTR0"  
    Anl_Par(I_Anl).C_Type = "analog"
    Anl_Par(I_Anl).R_Alim(1,3) = 0.001
    Declare Function EPCN (I_EkeV As Integer) As Double   ' Energy
    Function EPCN(I_EkeV As Integer) As Double
       ' Read value of _EPCN
      If I_EkeV >= Lbound(_EPCN,1) And I_EkeV <= Ubound(_EPCN,1)  Then
         EPCN = _EPCN(I_EkeV)
      Else
        EPCN = 0
      End If     
    End Function    
    Sub Acc_EPCN(I_EkeV As Integer, Value As Double)
      ' Accumulate value in _EPCN
      Dim As Integer I_Lbound1,I_Ubound1
      If I_EkeV < Lbound(_EPCN,1) Or I_EkeV > Ubound(_EPCN,1) Then 
        I_Lbound1 = Min(Lbound(_EPCN,1),I_EkeV)
        I_Ubound1 = Max(Ubound(_EPCN,1),I_EkeV)
        Extend_1dim(_EPCN(),I_Lbound1,I_Ubound1)
      End If
      _EPCN(I_EkeV) = _EPCN(I_EkeV) + Value
    End Sub         
                               
 /' ReDim EN(1000) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EN"
    Anl_Par(I_Anl).C_Title = "Overall prompt neutron-energy spectrum"
    Anl_Par(I_Anl).C_xaxis = "Energy / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTR0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.1 '/
                               
    ReDim Shared _ENCN(1000) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENCN"
    Anl_Par(I_Anl).C_Title = "Prompt neutron-energy spectrum from CN"
    Anl_Par(I_Anl).C_xaxis = "Energy / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTRB0"  
    Anl_Par(I_Anl).C_Type = "analog"
    Anl_Par(I_Anl).R_Alim(1,3) = 0.001
    Declare Function ENCN(I_EkeV As Integer) As Double
    Function ENCN(I_EkeV As Integer) As Double
       ' Read value of _ENCN
      If I_EkeV >= Lbound(_ENCN,1) And I_EkeV <= Ubound(_ENCN,1)  Then
         ENCN = _ENCN(I_EkeV)
      Else
        ENCN = 0
      End If     
    End Function    
    Sub Acc_ENCN(I_EkeV As Integer, Value As Double)
      ' Accumulate value in _ENCN
      Dim As Integer I_Lbound1,I_Ubound1
      If I_EkeV < Lbound(_ENCN,1) Or I_EkeV > Ubound(_ENCN,1) Then 
        I_Lbound1 = Min(Lbound(_ENCN,1),I_EkeV)
        I_Ubound1 = Max(Ubound(_ENCN,1),I_EkeV)
        Extend_1dim(_ENCN(),I_Lbound1,I_Ubound1)
      End If
      _ENCN(I_EkeV) = _ENCN(I_EkeV) + Value
    End Sub         
    
    ReDim Shared _ENsci(1000) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENsci"
    Anl_Par(I_Anl).C_Title = "Prompt neutron-energy spectrum - between saddle and scission"
    Anl_Par(I_Anl).C_xaxis = "Energy / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTRB0"  
    Anl_Par(I_Anl).C_Type = "analog"
    Anl_Par(I_Anl).R_Alim(1,3) = 0.001
    Declare Function ENsci(I_EkeV As Integer) As Double
    Function ENsci(I_EkeV As Integer) As Double
       ' Read value of _ENsci
      If I_EkeV >= Lbound(_ENsci,1) And I_EkeV <= Ubound(_ENsci,1)  Then
         ENsci = _ENsci(I_EkeV)
      Else
        ENsci = 0
      End If     
    End Function    
    Sub Acc_ENsci(I_EkeV As Integer, Value As Double)
      ' Accumulate value in _ENsci
      Dim As Integer I_Lbound1,I_Ubound1
      If I_EkeV < Lbound(_ENsci,1) Or I_EkeV > Ubound(_ENsci,1) Then 
        I_Lbound1 = Min(Lbound(_ENsci,1),I_EkeV)
        I_Ubound1 = Max(Ubound(_ENsci,1),I_EkeV)
        Extend_1dim(_ENsci(),I_Lbound1,I_Ubound1)
      End If
      _ENsci(I_EkeV) = _ENsci(I_EkeV) + Value
    End Sub         
    
    ReDim ENCNtest(1000) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENCNtest"
    Anl_Par(I_Anl).C_Title = "Prompt neutron-energy spectrum from CN"
    Anl_Par(I_Anl).C_xaxis = "Energy / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTRB0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.1
    
    ReDim Shared _ENfr(1000) As Double                         
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENfr"
    Anl_Par(I_Anl).C_Title = "Prompt neutron-energy spectrum from fragments"
    Anl_Par(I_Anl).C_xaxis = "Energy / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTRG0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.001
    Declare Function ENfr(I_EkeV As Integer) As Double
    Function ENfr(I_EkeV As Integer) As Double
       ' Read value of _ENfr
      If I_EkeV >= Lbound(_ENfr,1) And I_EkeV <= Ubound(_ENfr,1)  Then
         ENfr = _ENfr(I_EkeV)
      Else
        ENfr = 0
      End If     
    End Function    
    Sub Acc_ENfr(I_EkeV As Integer, Value As Double)
      ' Accumulate value in _ENfr
      Dim As Integer I_Lbound1,I_Ubound1
      If I_EkeV < Lbound(_ENfr,1) Or I_EkeV > Ubound(_ENfr,1) Then 
        I_Lbound1 = Min(Lbound(_ENfr,1),I_EkeV)
        I_Ubound1 = Max(Ubound(_ENfr,1),I_EkeV)
        Extend_1dim(_ENfr(),I_Lbound1,I_Ubound1)
      End If
      _ENfr(I_EkeV) = _ENfr(I_EkeV) + Value
    End Sub         

    ReDim ENfrvar(303) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENfrvar"
    Anl_Par(I_Anl).C_Title = "Prompt neutron-energy spectrum from fragments, variable binsize"
    Anl_Par(I_Anl).C_xaxis = "Energy / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTRRB0"
     ' Limits are given in eV  
    Dim As Double ENfrvar_lim(303) = _
    {0,0.00001,0.00002,0.00004,0.00006,0.00008,0.0001,0.0002,0.0004, _
     0.0006,0.0008,0.001,0.002,0.004,0.006,0.008,0.01,0.02,0.04,0.06, _
     0.08,0.1,0.2,0.4,0.6,0.8,1.0000E+00,2.0000E+00,4.0000E+00,6.0000E+00, _
     8.0000E+00,1.0000E+01,2.0000E+01,4.0000E+01,6.0000E+01,8.0000E+01, _
     1.0000E+02,2.0000E+02,4.0000E+02,6.0000E+02,8.0000E+02,1.0000E+03, _
     2.0000E+03,4.0000E+03,6.0000E+03,8.0000E+03,1.0000E+04,2.0000E+04, _
     3.0000E+04,4.0000E+04,5.0000E+04,6.0000E+04,7.0000E+04,8.0000E+04, _
     9.0000E+04,1.0000E+05,1.5000E+05,2.0000E+05,2.5000E+05,3.0000E+05, _
     3.5000E+05,4.0000E+05,4.5000E+05,5.0000E+05,5.5000E+05,6.0000E+05, _
     6.5000E+05,7.0000E+05,7.5000E+05,8.0000E+05,8.5000E+05,9.0000E+05, _
     9.5000E+05,1.0000E+06,1.0500E+06,1.1000E+06,1.1500E+06,1.2000E+06, _
     1.2500E+06,1.3000E+06,1.3500E+06,1.4000E+06,1.4500E+06,1.5000E+06, _
     1.5500E+06,1.6000E+06,1.6500E+06,1.7000E+06,1.7500E+06,1.8000E+06, _ 
     1.8500E+06,1.9000E+06,1.9500E+06,2.0000E+06,2.0500E+06,2.1000E+06, _
     2.1500E+06,2.2000E+06,2.2500E+06,2.3000E+06,2.3500E+06,2.4000E+06, _
     2.4500E+06,2.5000E+06,2.5500E+06,2.6000E+06,2.6500E+06,2.7000E+06, _
     2.7500E+06,2.8000E+06,2.8500E+06,2.9000E+06,2.9500E+06,3.0000E+06, _
     3.0500E+06,3.1000E+06,3.1500E+06,3.2000E+06,3.2500E+06,3.3000E+06, _
     3.3500E+06,3.4000E+06,3.4500E+06,3.5000E+06,3.5500E+06,3.6000E+06, _
     3.6500E+06,3.7000E+06,3.7500E+06,3.8000E+06,3.8500E+06,3.9000E+06, _
     3.9500E+06,4.0000E+06,4.0500E+06,4.1000E+06,4.1500E+06,4.2000E+06, _
     4.2500E+06,4.3000E+06,4.3500E+06,4.4000E+06,4.4500E+06,4.5000E+06, _
     4.5500E+06,4.6000E+06,4.6500E+06,4.7000E+06,4.7500E+06,4.8000E+06, _
     4.8500E+06,4.9000E+06,4.9500E+06,5.0000E+06,5.1000E+06,5.2000E+06, _
     5.3000E+06,5.4000E+06,5.5000E+06,5.6000E+06,5.7000E+06,5.8000E+06, _
     5.9000E+06,6.0000E+06,6.1000E+06,6.2000E+06,6.3000E+06,6.4000E+06, _
     6.5000E+06,6.6000E+06,6.7000E+06,6.8000E+06,6.9000E+06,7.0000E+06, _
     7.1000E+06,7.2000E+06,7.3000E+06,7.4000E+06,7.5000E+06,7.6000E+06, _
     7.7000E+06,7.8000E+06,7.9000E+06,8.0000E+06,8.1000E+06,8.2000E+06, _
     8.3000E+06,8.4000E+06,8.5000E+06,8.6000E+06,8.7000E+06,8.8000E+06, _
     8.9000E+06,9.0000E+06,9.1000E+06,9.2000E+06,9.3000E+06,9.4000E+06, _
     9.5000E+06,9.6000E+06,9.7000E+06,9.8000E+06,9.9000E+06,1.0000E+07, _
     1.0200E+07,1.0400E+07,1.0600E+07,1.0800E+07,1.1000E+07,1.1200E+07, _
     1.1400E+07,1.1600E+07,1.1800E+07,1.2000E+07,1.2200E+07,1.2400E+07, _
     1.2600E+07,1.2800E+07,1.3000E+07,1.3200E+07,1.3400E+07,1.3600E+07, _
     1.3800E+07,1.4000E+07,1.4200E+07,1.4400E+07,1.4600E+07,1.4800E+07, _
     1.5000E+07,1.5200E+07,1.5400E+07,1.5600E+07,1.5800E+07,1.6000E+07, _
     1.6200E+07,1.6400E+07,1.6600E+07,1.6800E+07,1.7000E+07,1.7200E+07, _
     1.7400E+07,1.7600E+07,1.7800E+07,1.8000E+07,1.8200E+07,1.8400E+07, _
     1.8600E+07,1.8800E+07,1.9000E+07,1.9200E+07,1.9400E+07,1.9600E+07, _
     1.9800E+07,2.0000E+07,2.0200E+07,2.0400E+07,2.0600E+07,2.0800E+07, _
     2.1000E+07,2.1200E+07,2.1400E+07,2.1600E+07,2.1800E+07,2.2000E+07, _
     2.2200E+07,2.2400E+07,2.2600E+07,2.2800E+07,2.3000E+07,2.3200E+07, _
     2.3400E+07,2.3600E+07,2.3800E+07,2.4000E+07,2.4200E+07,2.4400E+07, _
     2.4600E+07,2.4800E+07,2.5000E+07,2.5200E+07,2.5400E+07,2.5600E+07, _
     2.5800E+07,2.6000E+07,2.6200E+07,2.6400E+07,2.6600E+07,2.6800E+07, _
     2.7000E+07,2.7200E+07,2.7400E+07,2.7600E+07,2.7800E+07,2.8000E+07, _
     2.8200E+07,2.8400E+07,2.8600E+07,2.8800E+07,2.9000E+07,2.9200E+07, _
     2.9400E+07,2.9600E+07,2.9800E+07,3.0000E+07}

    ReDim Shared _ENfrfs(1000) As Double                          
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENfrfs"
    Anl_Par(I_Anl).C_Title = "Prompt neutron-energy spectrum from fragments in fragment frame"
    Anl_Par(I_Anl).C_xaxis = "Energy / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTGB0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.001
    Declare Function ENfrfs(I_EkeV As Integer) As Double
    Function ENfrfs(I_EkeV As Integer) As Double
       ' Read value of _ENFRs
      If I_EkeV >= Lbound(_ENfrfs,1) And I_EkeV <= Ubound(_ENfrfs,1)  Then
         ENfrfs = _ENfrfs(I_EkeV)
      Else
        ENfrfs = 0
      End If     
    End Function    
    Sub Acc_ENfrfs(I_EkeV As Integer, Value As Double)
      ' Accumulate value in _ENfrfs
      Dim As Integer I_Lbound1,I_Ubound1
      If I_EkeV < Lbound(_ENfrfs,1) Or I_EkeV > Ubound(_ENfrfs,1) Then 
        I_Lbound1 = Min(Lbound(_ENfrfs,1),I_EkeV)
        I_Ubound1 = Max(Ubound(_ENfrfs,1),I_EkeV)
        Extend_1dim(_ENfrfs(),I_Lbound1,I_Ubound1)
      End If
      _ENfrfs(I_EkeV) = _ENfrfs(I_EkeV) + Value
    End Sub         

    ReDim Shared _ENfrC(5,5,1000) As Double 
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENfrC"
    Anl_Par(I_Anl).C_Title = "Prompt neutron-energy spectrum from fragments for Chances (nlost, plost)"
    Anl_Par(I_Anl).C_xaxis = "Energy / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTGB0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.001
    Declare Function ENfrC(I_N As Integer, I_P As Integer,I_E As Integer) As Double
    Function ENfrC (I_N As Integer, I_P As Integer, I_E As Integer) As Double
       ' Read value of _ENfrC
      If I_N >= Lbound(_ENfrC,1) And I_N <= Ubound(_ENfrC,1) And _ 
         I_P >= Lbound(_ENfrC,2) And I_P <= Ubound(_ENfrC,2) And _
         I_E >= Lbound(_ENfrC,3) And I_E <= Ubound(_ENfrC,3) Then
        ENfrC = _ENfrC(I_N,I_P,I_E)
      Else
        ENfrC = 0
      End If     
    End Function
    Declare Sub Acc_ENfrC(I_N As Integer, I_P As Integer, I_E As Integer, Value As Double) 
    Sub Acc_ENfrC(I_N As Integer, I_P As Integer, I_E As Integer, Value As Double)
      ' Accumulate value in _JFRAGpre
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2,I_Lbound3, I_Ubound3
      If I_N < Lbound(_ENfrC,1) Or I_N > Ubound(_ENfrC,1) _
         Or I_P < Lbound(_ENfrC,2) Or I_P > Ubound(_ENfrC,2) _
         Or I_E < Lbound(_ENfrC,3) Or I_E > Ubound(_ENfrC,3) Then
        I_Lbound1 = Min(Lbound(_ENfrC,1),I_N)
        I_Ubound1 = Max(Ubound(_ENfrC,1),I_N)
        I_Lbound2 = Min(Lbound(_ENfrC,2),I_P)
        I_Ubound2 = Max(Ubound(_ENfrC,2),I_P)
        I_Lbound3 = Min(Lbound(_ENfrC,3),I_E)
        I_Ubound3 = Max(Ubound(_ENfrC,3),I_E)
        Extend_3dim(_ENfrC(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2,I_Lbound3,I_Ubound3)
      End If
      _ENfrC(I_N,I_P,I_E) = _ENfrC(I_N,I_P,I_E) + Value
    End Sub 
                               
    Redim ENlight(100000) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENlight"
    Anl_Par(I_Anl).C_Title = "Prompt neutron-energy spectrum from light fragments"
    Anl_Par(I_Anl).C_xaxis = "Energy / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTRB0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.001
    
    Redim ENheavy(100000) As Double  
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENheavy"
    Anl_Par(I_Anl).C_Title = "Prompt neutron-energy spectrum from heavy fragments"
    Anl_Par(I_Anl).C_xaxis = "Energy / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTBG0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.001
    
    Redim ENM(0 to 7,100000) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENM"
    Anl_Par(I_Anl).C_Title = "Neutron-energy spectrum for mode &"
    Anl_Par(I_Anl).C_xaxis = "Energy / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTR0"  
    Anl_Par(I_Anl).R_Alim(2,3) = 0.001
    
    Redim ENApre2d(350,1000) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENApre2d"
    Anl_Par(I_Anl).C_Title = "Neutron-energy spectrum over pre-neutron mass (from fragments)"
    Anl_Par(I_Anl).C_xaxis = "Apre"
    Anl_Par(I_Anl).C_yaxis = "Energy / MeV"
    Anl_Par(I_Anl).R_Alim(2,3) = 0.1
    
    Redim ENApost2d(350,1000) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENApost2d"
    Anl_Par(I_Anl).C_Title = "Neutron-energy spectrum over post-neutron mass (from fragments)"
    Anl_Par(I_Anl).C_xaxis = "Apost"
    Anl_Par(I_Anl).C_yaxis = "Energy / MeV"
    Anl_Par(I_Anl).R_Alim(2,3) = 0.1
    
    Redim ENApre(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENApre"
    Anl_Par(I_Anl).C_Title = "Mean neutron energy over pre-neutron mass (from fragments)"
    Anl_Par(I_Anl).C_xaxis = "Apre"
    Anl_Par(I_Anl).C_yaxis = "Energy / MeV"
    Anl_Par(I_Anl).C_Linesymbol = "HTR0"  
    Anl_Par(I_Anl).R_Alim(2,3) = 1
    
    Redim ENApost(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENApost"
    Anl_Par(I_Anl).C_Title = "Mean neutron energy over post-neutron mass (from fragments)"
    Anl_Par(I_Anl).C_xaxis = "Apost"
    Anl_Par(I_Anl).C_yaxis = "Energy / MeV"
    Anl_Par(I_Anl).C_Linesymbol = "HTB0"  
    Anl_Par(I_Anl).R_Alim(2,3) = 1
    
    Redim Shared _ENApre2dfs(200,50) As Double  ' fs = fragment system
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENApre2dfs"
    Anl_Par(I_Anl).C_Title = "Neutron-energy spectrum over pre-neutron mass (from fragments in fragment frame)"
    Anl_Par(I_Anl).C_xaxis = "Apre"
    Anl_Par(I_Anl).C_yaxis = "Energy / MeV"
    Anl_Par(I_Anl).R_Alim(2,3) = 0.1
    Declare Function ENApre2dfs(I_A As Integer, I_EN As Integer) As Double   ' A and neutron energy
    Function ENApre2dfs (I_A As Integer, I_NE As Integer) As Double
       ' Read value of ENApre2dfs
      If I_A >= Lbound(_ENApre2dfs,1) And I_A <= Ubound(_ENApre2dfs,1) And _ 
         I_NE >= Lbound(_ENApre2dfs,2) And I_NE <= Ubound(_ENApre2dfs,2) Then
         ENApre2dfs = _ENApre2dfs(I_A,I_NE)
      Else
        ENApre2dfs = 0
      End If     
    End Function    
    Sub Acc_ENApre2dfs(I_A As Integer, I_NE As Integer, Value As Double)
      ' Accumulate value in _ENApre2dfs
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2
      If I_A < Lbound(_ENApre2dfs,1) Or I_A > Ubound(_ENApre2dfs,1) _
         Or I_NE < Lbound(_ENApre2dfs,2) Or I_NE > Ubound(_ENApre2dfs,2) Then 
        I_Lbound1 = Min(Lbound(_ENApre2dfs,1),I_A)
        I_Ubound1 = Max(Ubound(_ENApre2dfs,1),I_A)
        I_Lbound2 = Min(Lbound(_ENApre2dfs,2),I_NE)
        I_Ubound2 = Max(Ubound(_ENApre2dfs,2),I_NE)
        Extend_2dim(_ENApre2dfs(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2)
      End If
      _ENApre2dfs(I_A,I_NE) = _ENApre2dfs(I_A,I_NE) + Value
    End Sub         
    
    Redim Shared _ENApost2dfs(200,50) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENApost2dfs"
    Anl_Par(I_Anl).C_Title = "Neutron-energy spectrum over post-neutron mass (from fragments in fragment frame)"
    Anl_Par(I_Anl).C_xaxis = "Apost"
    Anl_Par(I_Anl).C_yaxis = "Energy / MeV"
    Anl_Par(I_Anl).R_Alim(2,3) = 0.1
    Declare Function ENApost2dfs(I_A As Integer, I_EN As Integer) As Double   ' A and neutron energy
    Function ENApost2dfs (I_A As Integer, I_EN As Integer) As Double
       ' Read value of ENApost2dfs
      If I_A >= Lbound(_ENApost2dfs,1) And I_A <= Ubound(_ENApost2dfs,1) And _ 
         I_EN >= Lbound(_ENApost2dfs,2) And I_EN <= Ubound(_ENApost2dfs,2) Then
         ENApost2dfs = _ENApost2dfs(I_A,I_EN)
      Else
        ENApost2dfs = 0
      End If     
    End Function    
    Sub Acc_ENApost2dfs(I_A As Integer, I_EN As Integer, Value As Double)
      ' Accumulate value in _ENApre2dfs
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2
      If I_A < Lbound(_ENApost2dfs,1) Or I_A > Ubound(_ENApost2dfs,1) _
         Or I_EN < Lbound(_ENApost2dfs,2) Or I_EN > Ubound(_ENApost2dfs,2) Then 
        I_Lbound1 = Min(Lbound(_ENApost2dfs,1),I_A)
        I_Ubound1 = Max(Ubound(_ENApost2dfs,1),I_A)
        I_Lbound2 = Min(Lbound(_ENApost2dfs,2),I_EN)
        I_Ubound2 = Max(Ubound(_ENApost2dfs,2),I_EN)
        Extend_2dim(_ENApost2dfs(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2)
      End If
      _ENApost2dfs(I_A,I_EN) = _ENApost2dfs(I_A,I_EN) + Value
    End Sub         
    
    Redim ENAprefs(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENAprefs"
    Anl_Par(I_Anl).C_Title = "Mean neutron energy over pre-neutron mass (from fragments in fragment frame)"
    Anl_Par(I_Anl).C_xaxis = "Apre"
    Anl_Par(I_Anl).C_yaxis = "Energy / MeV"
    Anl_Par(I_Anl).C_Linesymbol = "HTR0"  
    Anl_Par(I_Anl).R_Alim(2,3) = 1

    Redim ENApostfs(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ENApostfs"
    Anl_Par(I_Anl).C_Title = "Mean neutron energy over post-neutron mass (from fragments in fragment frame)"
    Anl_Par(I_Anl).C_xaxis = "Apost"
    Anl_Par(I_Anl).C_yaxis = "Energy / MeV"
    Anl_Par(I_Anl).C_Linesymbol = "HTB0"  
    Anl_Par(I_Anl).R_Alim(2,3) = 1
    
    ReDim NP(50) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NP"
    Anl_Par(I_Anl).C_Title = "Proton multiplicity"
    Anl_Par(I_Anl).C_xaxis = "Number of protons"
    Anl_Par(I_Anl).C_yaxis = "Probability"
    Anl_Par(I_Anl).C_Linesymbol = "LTR11"  
    Anl_Par(I_Anl).C_Type = "digital"
                               
    ReDim NN(50) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NN"
    Anl_Par(I_Anl).C_Title = "Neutron multiplicity"
    Anl_Par(I_Anl).C_xaxis = "Number of neutrons"
    Anl_Par(I_Anl).C_yaxis = "Probability"
    Anl_Par(I_Anl).C_Linesymbol = "LTR11"  
    Anl_Par(I_Anl).C_Type = "digital"
                               
    ReDim NNCN(50) As Double 
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NNCN"
    Anl_Par(I_Anl).C_Title = "Neutron multiplicity (from CN)"
    Anl_Par(I_Anl).C_xaxis = "Number of neutrons"
    Anl_Par(I_Anl).C_yaxis = "Probability"
    Anl_Par(I_Anl).C_Linesymbol = "LTR11"  
    Anl_Par(I_Anl).C_Type = "digital"
    
    ReDim NNCNtot(50) As Double  ' condition on E* above Bf
    Anl_Par(I_Anl).C_Name = "NNCNtot"
    Anl_Par(I_Anl).C_Title = "Neutron multiplicity (from CN) w/o fission"
    Anl_Par(I_Anl).C_xaxis = "Number of neutrons"
    Anl_Par(I_Anl).C_yaxis = "Probability"
    Anl_Par(I_Anl).C_Linesymbol = "LTRB11"  
    Anl_Par(I_Anl).C_Type = "digital"
    
    ReDim NPCNtot(50) As Double  ' condition on E* above Bf
    Anl_Par(I_Anl).C_Name = "NPCNtot"
    Anl_Par(I_Anl).C_Title = "Proton multiplicity (from CN) w/o fission"
    Anl_Par(I_Anl).C_xaxis = "Number of protons"
    Anl_Par(I_Anl).C_yaxis = "Probability"
    Anl_Par(I_Anl).C_Linesymbol = "LTRB11"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim NNsci(50) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NNsci"
    Anl_Par(I_Anl).C_Title = "Neutron multiplicity (between saddle and scission)"
    Anl_Par(I_Anl).C_xaxis = "Number of neutrons"
    Anl_Par(I_Anl).C_yaxis = "Probability"
    Anl_Par(I_Anl).C_Linesymbol = "LTRB11"
    Anl_Par(I_Anl).C_Type = "digital"
    
    ReDim NNfr(50) As Double                            
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NNfr"
    Anl_Par(I_Anl).C_Title = "Neutron multiplicity (from fragments)"
    Anl_Par(I_Anl).C_xaxis = "Number of neutrons"
    Anl_Par(I_Anl).C_yaxis = "Probability"
    Anl_Par(I_Anl).C_Linesymbol = "LTR11"  
    Anl_Par(I_Anl).C_Type = "digital"
                               
    ReDim NNlight(50) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NNlight"
    Anl_Par(I_Anl).C_Title = "Neutron multiplicity (from light fragments)"
    Anl_Par(I_Anl).C_xaxis = "Number of neutrons"
    Anl_Par(I_Anl).C_yaxis = "Probability"
    Anl_Par(I_Anl).C_Linesymbol = "LTR11"  
    Anl_Par(I_Anl).C_Type = "digital"
                               
    ReDim NNheavy(50) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NNheavy"
    Anl_Par(I_Anl).C_Title = "Neutron multiplicity (from heavy fragments)"
    Anl_Par(I_Anl).C_xaxis = "Number of neutrons"
    Anl_Par(I_Anl).C_yaxis = "Probability"
    Anl_Par(I_Anl).C_Linesymbol = "LTR11"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim Ndirlight(-100 To 100) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Ndirlight"
    Anl_Par(I_Anl).C_Title = "Neutron angle vs. light fragment (cos)"
    Anl_Par(I_Anl).C_xaxis = "cos(alpha)"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "LTR0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.01
                               
    ReDim nuTKEpre(0 To 250,0 To 20) As Double  
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "nuTKEpre"
    Anl_Par(I_Anl).C_Title = "Neutron multiplicity vs. TKE (pre-neutron)"
    Anl_Par(I_Anl).C_xaxis = "TKE / MeV"
    Anl_Par(I_Anl).C_yaxis = "nu^"
    Anl_Par(I_Anl).I_Dim = 2
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim nuTKEpost(0 To 250,0 To 20) As Double  
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "nuTKEpost"
    Anl_Par(I_Anl).C_Title = "Neutron multiplicity vs. TKE (post-neutron)"
    Anl_Par(I_Anl).C_xaxis = "TKE / MeV"
    Anl_Par(I_Anl).C_yaxis = "nu^"
    Anl_Par(I_Anl).I_Dim = 2
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim DPLOCAL(150) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "DPLOCAL"
    Anl_Par(I_Anl).C_Title = "Local even-odd effect in Z"
    Anl_Par(I_Anl).C_xaxis = "Z (add 0.5!)"
    Anl_Par(I_Anl).C_yaxis = "de^p$"
    Anl_Par(I_Anl).C_Linesymbol = "LTR11"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim DNLOCAL(200) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "DNLOCAL"
    Anl_Par(I_Anl).C_Title = "Local even-odd effect in N"
    Anl_Par(I_Anl).C_xaxis = "N (add 0.5!)"
    Anl_Par(I_Anl).C_yaxis = "de^n$"
    Anl_Par(I_Anl).C_Linesymbol = "LTB11"  
    Anl_Par(I_Anl).C_Type = "digital"

    ReDim Shared _AEkinpre(50 To 200,80 To 100) As Double    ' pre-neutron
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "AEkinpre"
    Anl_Par(I_Anl).C_Title = "Ekin over Apre"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Ek$i$n$ / MeV"
    Anl_Par(I_Anl).I_Dim = 2
    Declare Function AEkinpre(I_A As Integer, I_E As Integer) As Double   ' A and neutron energy
    Function AEkinpre (I_A As Integer, I_E As Integer) As Double
       ' Read value of AEkinpre
      If I_A >= Lbound(_AEkinpre,1) And I_A <= Ubound(_AEkinpre,1) And _ 
         I_E >= Lbound(_AEkinpre,2) And I_E <= Ubound(_AEkinpre,2) Then
         AEkinpre = _AEkinpre(I_A,I_E)
      Else
        AEkinpre = 0
      End If     
    End Function    
    Sub Acc_AEkinpre(I_A As Integer, I_E As Integer, Value As Double)
      ' Accumulate value in _AEkinpre
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2
      If I_A < Lbound(_AEkinpre,1) Or I_A > Ubound(_AEkinpre,1) _
         Or I_E < Lbound(_AEkinpre,2) Or I_E > Ubound(_AEkinpre,2) Then 
        I_Lbound1 = Min(Lbound(_AEkinpre,1),I_A)
        I_Ubound1 = Max(Ubound(_AEkinpre,1),I_A)
        I_Lbound2 = Min(Lbound(_AEkinpre,2),I_E)
        I_Ubound2 = Max(Ubound(_AEkinpre,2),I_E)
        Extend_2dim(_AEkinpre(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2)
      End If
      _AEkinpre(I_A,I_E) = _AEkinpre(I_A,I_E) + Value
    End Sub         
    
    ReDim EkinApre(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EkinApre"
    Anl_Par(I_Anl).C_Title = "Mean Ekin versus A, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "<Ek$i$n$> / MeV"
    
    ReDim Ekinpre(300) As Double    ' pre-neutron
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Ekinpre"
    Anl_Par(I_Anl).C_Title = "Fragment kinetic energy, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Ek$i$n$ / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTR0"  
    
    Redim EkinpreM(0 to 7,300) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EkinpreM"
    Anl_Par(I_Anl).C_Title = "Fragment kinetic energy, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Ek$i$n$ / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTRB0"  
    
    ReDim Shared _AEkinpost(50 To 200,80 To 100) As Double    ' post-neutron
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "AEkinpost"
    Anl_Par(I_Anl).C_Title = "Ekin over Apost"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Ek$i$n$ / MeV"
    Anl_Par(I_Anl).I_Dim = 2
    Declare Function AEkinpost(I_A As Integer, I_E As Integer) As Double   ' A and neutron energy
    Function AEkinpost (I_A As Integer, I_E As Integer) As Double
       ' Read value of AEkinpost
      If I_A >= Lbound(_AEkinpost,1) And I_A <= Ubound(_AEkinpost,1) And _ 
         I_E >= Lbound(_AEkinpost,2) And I_E <= Ubound(_AEkinpost,2) Then
         AEkinpost = _AEkinpost(I_A,I_E)
      Else
        AEkinpost = 0
      End If     
    End Function    
    Sub Acc_AEkinpost(I_A As Integer, I_E As Integer, Value As Double)
      ' Accumulate value in _AEkinpost
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2
      If I_A < Lbound(_AEkinpost,1) Or I_A > Ubound(_AEkinpost,1) _
         Or I_E < Lbound(_AEkinpost,2) Or I_E > Ubound(_AEkinpost,2) Then 
        I_Lbound1 = Min(Lbound(_AEkinpost,1),I_A)
        I_Ubound1 = Max(Ubound(_AEkinpost,1),I_A)
        I_Lbound2 = Min(Lbound(_AEkinpost,2),I_E)
        I_Ubound2 = Max(Ubound(_AEkinpost,2),I_E)
        Extend_2dim(_AEkinpost(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2)
      End If
      _AEkinpost(I_A,I_E) = _AEkinpost(I_A,I_E) + Value
    End Sub         
        
    ReDim EkinApost(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EkinApost"
    Anl_Par(I_Anl).C_Title = "Mean Ekin versus A, post-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "<Ek$i$n$> / MeV"

    Redim Ekinpost(300) As Double   ' post-neutron
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Ekinpost"
    Anl_Par(I_Anl).C_Title = "Fragment kinetic energy, post-neutron"
    Anl_Par(I_Anl).C_xaxis = "Ek$i$n$ / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTB0"  
    
    Redim EkinpostM(0 to 7,300) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EkinpostM"
    Anl_Par(I_Anl).C_Title = "Fragment kinetic energy, post-neutron"
    Anl_Par(I_Anl).C_xaxis = "Ek$i$n$ / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTRB0"  

    ReDim Shared _ATKEpre(50 To 200,200 To 200) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ATKEpre"
    Anl_Par(I_Anl).C_Title = "TKE over Apre"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "TKE / MeV"
    Anl_Par(I_Anl).I_Dim = 2
    Declare Function ATKEpre(I_A As Integer, I_E As Integer) As Double   ' A and neutron energy
    Function ATKEpre (I_A As Integer, I_E As Integer) As Double
       ' Read value of ATKEpre
      If I_A >= Lbound(_ATKEpre,1) And I_A <= Ubound(_ATKEpre,1) And _ 
         I_E >= Lbound(_ATKEpre,2) And I_E <= Ubound(_ATKEpre,2) Then
         ATKEpre = _ATKEpre(I_A,I_E)
      Else
        ATKEpre = 0
      End If     
    End Function    
    Sub Acc_ATKEpre(I_A As Integer, I_E As Integer, Value As Double)
      ' Accumulate value in _ATKEpre
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2
      If I_A < Lbound(_ATKEpre,1) Or I_A > Ubound(_ATKEpre,1) _
         Or I_E < Lbound(_ATKEpre,2) Or I_E > Ubound(_ATKEpre,2) Then 
        I_Lbound1 = Min(Lbound(_ATKEpre,1),I_A)
        I_Ubound1 = Max(Ubound(_ATKEpre,1),I_A)
        I_Lbound2 = Min(Lbound(_ATKEpre,2),I_E)
        I_Ubound2 = Max(Ubound(_ATKEpre,2),I_E)
        Extend_2dim(_ATKEpre(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2)
      End If
      _ATKEpre(I_A,I_E) = _ATKEpre(I_A,I_E) + Value
    End Sub         
    
    ReDim Shared _ATKEpost(50 To 200,200 To 200) As Double                           
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "ATKEpost"
    Anl_Par(I_Anl).C_Title = "TKE over Apost"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "TKE / MeV"
    Anl_Par(I_Anl).I_Dim = 2
    Declare Function ATKEpost(I_A As Integer, I_E As Integer) As Double   ' A and neutron energy
    Function ATKEpost (I_A As Integer, I_E As Integer) As Double
       ' Read value of ATKEpost
      If I_A >= Lbound(_ATKEpost,1) And I_A <= Ubound(_ATKEpost,1) And _ 
         I_E >= Lbound(_ATKEpost,2) And I_E <= Ubound(_ATKEpost,2) Then
         ATKEpost = _ATKEpost(I_A,I_E)
      Else
        ATKEpost = 0
      End If     
    End Function    
    Sub Acc_ATKEpost(I_A As Integer, I_E As Integer, Value As Double)
      ' Accumulate value in _ATKEpost
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2
      If I_A < Lbound(_ATKEpost,1) Or I_A > Ubound(_ATKEpost,1) _
         Or I_E < Lbound(_ATKEpost,2) Or I_E > Ubound(_ATKEpost,2) Then 
        I_Lbound1 = Min(Lbound(_ATKEpost,1),I_A)
        I_Ubound1 = Max(Ubound(_ATKEpost,1),I_A)
        I_Lbound2 = Min(Lbound(_ATKEpost,2),I_E)
        I_Ubound2 = Max(Ubound(_ATKEpost,2),I_E)
        Extend_2dim(_ATKEpost(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2)
      End If
      _ATKEpost(I_A,I_E) = _ATKEpost(I_A,I_E) + Value
    End Sub         
                               
    ReDim TKEpre(300) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "TKEpre"
    Anl_Par(I_Anl).C_Title = "TKE pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "TKE / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTR0"  
    
    ReDim TKEApre(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "TKEApre"
    Anl_Par(I_Anl).C_Title = "Mean TKE versus A, pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "<TKE> / MeV"
    Anl_Par(I_Anl).C_Linesymbol = "HTB0"

  '  Redim TKEApreM(0 to 6,350) As Double
  '  I_Anl = I_Anl + 1
  '  Anl_Par(I_Anl).C_Name = "TKEApreM"
  '  Anl_Par(I_Anl).C_Title = "Mean TKE versus A, pre-neutron, per mode"
  '  Anl_Par(I_Anl).C_xaxis = "Mass number"
  '  Anl_Par(I_Anl).C_yaxis = "<TKE> / MeV"
  '  Anl_Par(I_Anl).C_Linesymbol = "HTGB0"
                               
    ReDim TKEpreM(0 to 7,300) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "TKEpreM"
    Anl_Par(I_Anl).C_Title = "TKE pre-neutron"
    Anl_Par(I_Anl).C_xaxis = "TKE / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTBR0"  

    ReDim TKEpost(300) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "TKEpost"
    Anl_Par(I_Anl).C_Title = "TKE post-neutron"
    Anl_Par(I_Anl).C_xaxis = "TKE / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTR0"  

    ReDim TKEpostM(0 to 7,300) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "TKEpostM"
    Anl_Par(I_Anl).C_Title = "TKE post-neutron"
    Anl_Par(I_Anl).C_xaxis = "TKE / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTBR0"  

    ReDim TKEApost(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "TKEApost"
    Anl_Par(I_Anl).C_Title = "Mean TKE versus A, post-neutron"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "<TKE> / MeV"
    Anl_Par(I_Anl).C_Linesymbol = "HTB0"

  '  Redim TKEApostM(0 to 7,350) As Double
  '  I_Anl = I_Anl + 1
  '  Anl_Par(I_Anl).C_Name = "TKEApostM"
  '  Anl_Par(I_Anl).C_Title = "Mean TKE versus A, post-neutron, per mode"
  '  Anl_Par(I_Anl).C_xaxis = "Mass number"
  '  Anl_Par(I_Anl).C_yaxis = "<TKE> / MeV"
  '  Anl_Par(I_Anl).C_Linesymbol = "HTGB0"
                               
    ReDim Shared TotXE(300) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "TotXE"
    Anl_Par(I_Anl).C_Title = "Total excitation energy"
    Anl_Par(I_Anl).C_xaxis = "TXE / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTR0"  

    ReDim Shared Qvalues(300) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Qvalues"
    Anl_Par(I_Anl).C_Title = "Spectrum of Q values"
    Anl_Par(I_Anl).C_xaxis = "Q value / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTR0"  
                               
    ReDim Shared _AQpre(200,200 To 200) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "AQpre"
    Anl_Par(I_Anl).C_Title = "Q value over Ap$r$e$"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Q value / MeV"
    Anl_Par(I_Anl).I_Dim = 2
    Declare Function AQpre(I_A As Integer, I_Q As Integer) As Double   ' A and Q value
    Function AQpre (I_A As Integer, I_Q As Integer) As Double
       ' Read value of Aqpre
      If I_A >= Lbound(_AQpre,1) And I_A <= Ubound(_AQpre,1) And _ 
         I_Q >= Lbound(_AQpre,2) And I_Q <= Ubound(_AQpre,2) Then
         AQpre = _AQpre(I_A,I_Q)
      Else
        AQpre = 0
      End If     
    End Function    
    Sub Acc_AQpre(I_A As Integer, I_Q As Integer, Value As Double)
      ' Accumulate value in _AQpre
      Dim As Integer I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2
      If I_A < Lbound(_AQpre,1) Or I_A > Ubound(_AQpre,1) _
         Or I_Q < Lbound(_AQpre,2) Or I_Q > Ubound(_AQpre,2) Then 
        I_Lbound1 = Min(Lbound(_AQpre,1),I_A)
        I_Ubound1 = Max(Ubound(_AQpre,1),I_A)
        I_Lbound2 = Min(Lbound(_AQpre,2),I_Q)
        I_Ubound2 = Max(Ubound(_AQpre,2),I_Q)
        Extend_2dim(_AQpre(),I_Lbound1,I_Ubound1,I_Lbound2,I_Ubound2)
      End If
      _AQpre(I_A,I_Q) = _AQpre(I_A,I_Q) + Value
    End Sub     
    
    Redim Shared QA(350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "QA"
    Anl_Par(I_Anl).C_Title = "Mean Q value versus Ap$r$e$"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "<Q value> / MeV"
    Anl_Par(I_Anl).C_Linesymbol = "HTB0"  

    ReDim Shared _EGammaCN(1000) As Double    ' individual gammas
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EgammaCN"
    Anl_Par(I_Anl).C_Title = "Prompt-gamma spectrum, pre-fission"
    Anl_Par(I_Anl).C_xaxis = "Ega^$ / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTBR0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.001
    Declare Function EGammaCN (I_EkeV As Integer) As Double   ' Energy
    Function EGammaCN(I_EkeV As Integer) As Double
       ' Read value of _EGamma
      If I_EkeV >= Lbound(_EGammaCN,1) And I_EkeV <= Ubound(_EGammaCN,1)  Then
         EGammaCN = _EGammaCN(I_EkeV)
      Else
        EGammaCN = 0
      End If     
    End Function    
    Sub Acc_EGammaCN(I_EkeV As Integer, Value As Double)
      ' Accumulate value in _EGammaCN
      Dim As Integer I_Lbound1,I_Ubound1
      If I_EkeV < Lbound(_EGammaCN,1) Or I_EkeV > Ubound(_EGammaCN,1) Then 
        I_Lbound1 = Min(Lbound(_EGammaCN,1),I_EkeV)
        I_Ubound1 = Max(Ubound(_EGammaCN,1),I_EkeV)
        Extend_1dim(_EGammaCN(),I_Lbound1,I_Ubound1)
      End If
      _EGammaCN(I_EkeV) = _EGammaCN(I_EkeV) + Value
    End Sub         

    ReDim Shared _EGamma(1000) As Double    ' individual gammas
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Egamma"
    Anl_Par(I_Anl).C_Title = "Prompt-gamma spectrum"
    Anl_Par(I_Anl).C_xaxis = "Ega^$ / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTBR0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.001
    Declare Function EGamma (I_EkeV As Integer) As Double   ' Energy
    Function EGamma(I_EkeV As Integer) As Double
       ' Read value of _EGamma
      If I_EkeV >= Lbound(_EGamma,1) And I_EkeV <= Ubound(_EGamma,1)  Then
         EGamma = _EGamma(I_EkeV)
      Else
        EGamma = 0
      End If     
    End Function    
    Sub Acc_EGamma(I_EkeV As Integer, Value As Double)
      ' Accumulate value in _EGamma
      Dim As Integer I_Lbound1,I_Ubound1
      If I_EkeV < Lbound(_EGamma,1) Or I_EkeV > Ubound(_EGamma,1) Then 
        I_Lbound1 = Min(Lbound(_EGamma,1),I_EkeV)
        I_Ubound1 = Max(Ubound(_EGamma,1),I_EkeV)
        Extend_1dim(_EGamma(),I_Lbound1,I_Ubound1)
      End If
      _EGamma(I_EkeV) = _EGamma(I_EkeV) + Value
    End Sub         
    
  #Ifdef B_EgammaA   
    Redim Shared EgammaA2(999,350) As Double ' 0 to 2 MeV, Bin = 2 keV
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EgammaA2"
    Anl_Par(I_Anl).C_Title = "Prompt-gamma spectrum from fragments vs. pre-neutron mass, bin = 1 keV"
    Anl_Par(I_Anl).C_xaxis = "Ega^$/MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTBR0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.002
    
    Redim Shared EgammaA10(200 To 499,350) As Double ' 2 to 5 MeV, Bin = 10 keV
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EgammaA10"
    Anl_Par(I_Anl).C_Title = "Prompt-gamma spectrum from fragments vs. pre-neutron mass, bin = 10 keV"
    Anl_Par(I_Anl).C_xaxis = "Ega^$/MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTBR0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.01
    
    Redim Shared EgammaA100(50 To 99,350) As Double ' 5 to 10 MeV, Bin = 100 keV
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EgammaA100"   
    Anl_Par(I_Anl).C_xaxis = "Ega^$/MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTBR0"  
    Anl_Par(I_Anl).C_Title = "Prompt-gamma spectrum from fragemnts vs. pre-neutron mass, bin = 100 keV"
    Anl_Par(I_Anl).R_Alim(1,3) = 0.10

    Redim Shared EgammaA1000(10 To 29,350) As Double ' 10 To 30 MeV, Bin = 1000 keV
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EgammaA1000"   
    Anl_Par(I_Anl).C_xaxis = "Ega^$/MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTBR0"  
    Anl_Par(I_Anl).C_Title = "Prompt-gamma spectrum from fragments vs. pre-neutron mass, bin = 1 MeV"
    Anl_Par(I_Anl).R_Alim(1,3) = 1
  #Endif  

    ReDim Shared _EGammaL(1000) As Double    ' individual gammas
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EgammaL"
    Anl_Par(I_Anl).C_Title = "Prompt-gamma spectrum, light fragments"
    Anl_Par(I_Anl).C_xaxis = "Ega^$ / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTR0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.001
    Declare Function EGammaL (I_EkeV As Integer) As Double   ' Energy
    Function EGammaL(I_EkeV As Integer) As Double
       ' Read value of _EGammaL
      If I_EkeV >= Lbound(_EGammaL,1) And I_EkeV <= Ubound(_EGammaL,1)  Then
         EGammaL = _EGammaL(I_EkeV)
      Else
        EGammaL = 0
      End If     
    End Function    
    Sub Acc_EGammaL(I_EkeV As Integer, Value As Double)
      ' Accumulate value in _EGammaL
      Dim As Integer I_Lbound1,I_Ubound1
      If I_EkeV < Lbound(_EGammaL,1) Or I_EkeV > Ubound(_EGammaL,1) Then 
        I_Lbound1 = Min(Lbound(_EGammaL,1),I_EkeV)
        I_Ubound1 = Max(Ubound(_EGammaL,1),I_EkeV)
        Extend_1dim(_EGammaL(),I_Lbound1,I_Ubound1)
      End If
      _EGammaL(I_EkeV) = _EGammaL(I_EkeV) + Value
    End Sub         

    ReDim Shared _EGammaH(1000) As Double    ' individual gammas
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EgammaH"
    Anl_Par(I_Anl).C_Title = "Prompt-gamma spectrum, heavy fragments"
    Anl_Par(I_Anl).C_xaxis = "Ega^$ / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTB0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.001
    Declare Function EGammaH (I_EkeV As Integer) As Double   ' Energy
    Function EGammaH(I_EkeV As Integer) As Double
       ' Read value of _EGammaH
      If I_EkeV >= Lbound(_EGammaH,1) And I_EkeV <= Ubound(_EGammaH,1)  Then
         EGammaH = _EGammaH(I_EkeV)
      Else
        EGammaH = 0
      End If     
    End Function    
    Sub Acc_EGammaH(I_EkeV As Integer, Value As Double)
      ' Accumulate value in _EGammaH
      Dim As Integer I_Lbound1,I_Ubound1
      If I_EkeV < Lbound(_EGammaH,1) Or I_EkeV > Ubound(_EGammaH,1) Then 
        I_Lbound1 = Min(Lbound(_EGammaH,1),I_EkeV)
        I_Ubound1 = Max(Ubound(_EGammaH,1),I_EkeV)
        Extend_1dim(_EGammaH(),I_Lbound1,I_Ubound1)
      End If
      _EGammaH(I_EkeV) = _EGammaH(I_EkeV) + Value
    End Sub         

    ReDim Shared _EGammaE2(5000) As Double    ' individual gammas
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "EgammaE2"
    Anl_Par(I_Anl).C_Title = "Prompt-E2-gamma spectrum (from fragments)"
    Anl_Par(I_Anl).C_xaxis = "Ega^$ / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTG0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.001
    Declare Function EGammaE2 (I_EkeV As Integer) As Double   ' Energy
    Function EGammaE2(I_EkeV As Integer) As Double
       ' Read value of _EGammaE2
      If I_EkeV >= Lbound(_EGammaE2,1) And I_EkeV <= Ubound(_EGammaE2,1)  Then
         EGammaE2 = _EGammaE2(I_EkeV)
      Else
        EGammaE2 = 0
      End If     
    End Function    
    Sub Acc_EGammaE2(I_EkeV As Integer, Value As Double)
      ' Accumulate value in _EGammaE2
      Dim As Integer I_Lbound1,I_Ubound1
      If I_EkeV < Lbound(_EGammaE2,1) Or I_EkeV > Ubound(_EGammaE2,1) Then 
        I_Lbound1 = Min(Lbound(_EGammaE2,1),I_EkeV)
        I_Ubound1 = Max(Ubound(_EGammaE2,1),I_EkeV)
        Extend_1dim(_EGammaE2(),I_Lbound1,I_Ubound1)
      End If
      _EGammaE2(I_EkeV) = _EGammaE2(I_EkeV) + Value
    End Sub         
        
    Redim Shared NGammatot(100) As Double    ' number of gammas in one fission event (from fragments)
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NGammatot"
    Anl_Par(I_Anl).C_Title = "Gamma multiplicity per fission (from fragments)"
    Anl_Par(I_Anl).C_xaxis = "Gamma multiplicity"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "LTB11"  
    Anl_Par(I_Anl).C_Type = "digital"
    
    Redim Shared NgammaA(350,100) As Double  ' number of gammas per fission in one A
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "NgammaA"
    Anl_Par(I_Anl).C_Title = "Gamma multiplicity per fission"
    Anl_Par(I_Anl).C_xaxis = "Post-neutron fragment mass number"
    Anl_Par(I_Anl).C_yaxis = "Gamma multiplicity"
    Anl_Par(I_Anl).I_Dim = 2
    Anl_Par(I_Anl).C_Type = "digital"
      
    Redim Shared _EGammatot(1000) As Double   ' total gammas in 1 fission
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Egammatot"
    Anl_Par(I_Anl).C_Title = "Total gamma energy per fission"
    Anl_Par(I_Anl).C_xaxis = "Total gamma energy / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTBR0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.001
    Declare Function EGammatot (I_EkeV As Integer) As Double   ' Energy
    Function EGammatot(I_EkeV As Integer) As Double
       ' Read value of _EGammatot
      If I_EkeV >= Lbound(_EGammatot,1) And I_EkeV <= Ubound(_EGammatot,1)  Then
         EGammatot = _EGammatot(I_EkeV)
      Else
        EGammatot = 0
      End If     
    End Function    
    Sub Acc_EGammatot(I_EkeV As Integer, Value As Double)
      ' Accumulate value in _EGammatote
      Dim As Integer I_Lbound1,I_Ubound1
      If I_EkeV < Lbound(_EGammatot,1) Or I_EkeV > Ubound(_EGammatot,1) Then 
        I_Lbound1 = Min(Lbound(_EGammatot,1),I_EkeV)
        I_Ubound1 = Max(Ubound(_EGammatot,1),I_EkeV)
        Extend_1dim(_EGammatot(),I_Lbound1,I_Ubound1)
      End If
      _EGammatot(I_EkeV) = _EGammatot(I_EkeV) + Value
    End Sub     

    ReDim Shared _Eentrance(1000) As Double  ' Eentrance - Erot      
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Eentrance"
    Anl_Par(I_Anl).C_Title = "Entrance energy above yrast line"
    Anl_Par(I_Anl).C_xaxis = "Energy after last neutron / MeV"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "HTR0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.001
    Declare Function Eentrance (I_EkeV As Integer) As Double   ' Energy
    Function Eentrance(I_EkeV As Integer) As Double
       ' Read value of _Eentrance
      If I_EkeV >= Lbound(_Eentrance,1) And I_EkeV <= Ubound(_Eentrance,1)  Then
         Eentrance = _Eentrance(I_EkeV)
      Else
        Eentrance = 0
      End If     
    End Function    
    Sub Acc_Eentrance(I_EkeV As Integer, Value As Double)
      ' Accumulate value in _Eentrance
      Dim As Integer I_Lbound1,I_Ubound1
      If I_EkeV < Lbound(_Eentrance,1) Or I_EkeV > Ubound(_Eentrance,1) Then 
        I_Lbound1 = Min(Lbound(_Eentrance,1),I_EkeV)
        I_Ubound1 = Max(Ubound(_Eentrance,1),I_EkeV)
        Extend_1dim(_Eentrance(),I_Lbound1,I_Ubound1)
      End If
      _Eentrance(I_EkeV) = _Eentrance(I_EkeV) + Value
    End Sub     

  #If defined(B_delayed) 
    Redim Shared Qbeta(20000) As Double  ' 1 channel = 1 keV
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "Qbeta"
    Anl_Par(I_Anl).C_Title = "Q values of beta decay"
    Anl_Par(I_Anl).C_xaxis = "-Q / MeV"
    Anl_Par(I_Anl).C_yaxis = "Multiplicity"
    Anl_Par(I_Anl).C_Linesymbol = "HTG0"  
    Anl_Par(I_Anl).R_Alim(1,3) = 0.001
  #Endif  

   /' Spectra for error analysis '/
  
    ReDim Shared _d_NZPOST(2,0 To 50,20 To 70) As Double    ' Stage, N-Z and Z
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "d_NZPOST"
    Anl_Par(I_Anl).C_Title = "Post-neutron fragment distribution (uncertainties)"
    Anl_Par(I_Anl).C_xaxis = "Post-neutron neutron number"
    Anl_Par(I_Anl).C_yaxis = "Atomic number"
    Anl_Par(I_Anl).I_Dim = 2  
    Anl_Par(I_Anl).C_Type = "digital"
    Declare Function d_NZPOST(I_S As Integer, I_N As Integer, I_Z As Integer) As Double   ' N and Z
    Function d_NZPOST (I_S As Integer,I_N As Integer, I_Z As Integer) As Double
       ' Read value of _d_NZPOST
      Dim As Integer I_NminusZ
      I_NminusZ = I_N - I_Z
      If I_NminusZ >= Lbound(_d_NZPOST,2) And I_NminusZ <= Ubound(_d_NZPOST,2) And _  ' Stage is not protected
         I_Z >= Lbound(_d_NZPOST,3) And I_Z <= Ubound(_d_NZPOST,3) Then
         d_NZPOST = _d_NZPOST(I_S,I_NminusZ,I_Z)
      Else
        d_NZPOST = 0
      End If     
    End Function    
    Sub Acc_d_NZPOST(I_S As Integer, I_N As Integer, I_Z As Integer, Value As Double)
      ' Accumulate value in _d_NZPOST
      Dim As Integer I_NminusZ  
      Dim As Integer I_Lbound2,I_Ubound2,I_Lbound3,I_Ubound3
      I_NminusZ = I_N - I_Z
      If I_NminusZ < Lbound(_d_NZPOST,2) Or I_NminusZ > Ubound(_d_NZPOST,2) _
         Or I_Z < Lbound(_d_NZPOST,3) Or I_Z > Ubound(_NZPOST,3) Then 
        I_Lbound2 = Min(Lbound(_d_NZPOST,2),I_NminusZ)
        I_Ubound2 = Max(Ubound(_d_NZPOST,2),I_NminusZ)
        I_Lbound3 = Min(Lbound(_d_NZPOST,3),I_Z)
        I_Ubound3 = Max(Ubound(_d_NZPOST,3),I_Z)
        Extend_3dim(_d_NZPOST(),0,2,I_Lbound2,I_Ubound2,I_Lbound3,I_Ubound3)
      End If
      _d_NZPOST(I_S,I_NminusZ,I_Z) = _d_NZPOST(I_S,I_NminusZ,I_Z) + Value
    End Sub     
                               
    ReDim Shared _d_ZISOPOST(2,50 To 160,20 To 80) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "d_ZISOPOST"
    Anl_Par(I_Anl).C_Title = "Isobaric Z distribution, post-neutron (uncertainties)"
    Anl_Par(I_Anl).C_xaxis = "Z distribution for A = &"
    Anl_Par(I_Anl).C_yaxis = "Counts"
    Anl_Par(I_Anl).C_Linesymbol = "LTR11"  
    Anl_Par(I_Anl).C_Type = "digital"
     ' dim. 0,1,2: sigma, N*m1, N*m2, all logarithmic
    Declare Function d_ZISOPOST(I_S As Integer, I_A As Integer, I_Z As Integer) As Double   ' A and neutron energy
    Function d_ZISOPOST (I_S As Integer, I_A As Integer, I_Z As Integer) As Double
       ' Read value of ZISOPOST
      If I_A >= Lbound(_ZISOPOST,1) And I_A <= Ubound(_ZISOPOST,1) And _ 
         I_Z >= Lbound(_ZISOPOST,2) And I_Z <= Ubound(_ZISOPOST,2) Then
         d_ZISOPOST = _d_ZISOPOST(I_S,I_A,I_Z)
      Else
        d_ZISOPOST = 0
      End If     
    End Function    
    Sub Acc_d_ZISOPOST(I_S As Integer, I_A As Integer, I_Z As Integer, Value As Double)
      ' Accumulate value in _d_ZISOPOST
      Dim As Integer I_Lbound2,I_Ubound2,I_Lbound3,I_Ubound3
      If I_A < Lbound(_d_ZISOPOST,2) Or I_A > Ubound(_d_ZISOPOST,2) _
         Or I_Z < Lbound(_d_ZISOPOST,3) Or I_Z > Ubound(_d_ZISOPOST,3) Then 
        I_Lbound2 = Min(Lbound(_d_ZISOPOST,2),I_A)
        I_Ubound2 = Max(Ubound(_d_ZISOPOST,2),I_A)
        I_Lbound3 = Min(Lbound(_d_ZISOPOST,3),I_Z)
        I_Ubound3 = Max(Ubound(_d_ZISOPOST,3),I_Z)
        Extend_3dim(_d_ZISOPOST(),0,2,I_Lbound2,I_Ubound2,I_Lbound3,I_Ubound3)
      End If
      _d_ZISOPOST(I_S,I_A,I_Z) = _d_ZISOPOST(I_S,I_A,I_Z) + Value
    End Sub             
     
                           
    ReDim Shared d_APOST(2,350) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "d_APOST"
    Anl_Par(I_Anl).C_Title = "Mass distribution, post neutron (uncertainties)"
    Anl_Par(I_Anl).C_xaxis = "Mass number"
    Anl_Par(I_Anl).C_yaxis = "Yield"
    Anl_Par(I_Anl).C_Linesymbol = "BT11"  
    Anl_Par(I_Anl).I_Dim = 1  ' first dimension!
    Anl_Par(I_Anl).C_Type = "digital"
                               
    ReDim d_ZPOST(2,150) As Double
    I_Anl = I_Anl + 1
    Anl_Par(I_Anl).C_Name = "d_ZPOST"
    Anl_Par(I_Anl).C_Title = "Element distribution, post-neutron (uncertainties)"
    Anl_Par(I_Anl).C_xaxis = "Atomic number"
    Anl_Par(I_Anl).C_yaxis = "Yield"
    Anl_Par(I_Anl).C_Linesymbol = "RT11"  
    Anl_Par(I_Anl).C_Type = "digital"
    Anl_Par(I_Anl).I_Dim = 1  ' first dimension!

    ' Arrays for calculation of uncertainties
    Dim As Double d_NCN(2)     
    Dim As Double d_Nsci(2)
    Dim As Double d_Nfr(2)
    Dim As Double d_Nlight(2)     
    Dim As Double d_Nheavy(2)
    Dim As Double d_Ntot(2)
    Dim As Double d_ENfr(2)
    Dim As Double d_Ng(2)
    Dim As Double d_Eg(2)
    Dim As Double d_Egtot(2)
    Dim As Double d_Q(2)
    Dim As Double d_TKEpre(2)
    Dim As Double d_sigma_TKEpre(2)
    Dim As Double d_TKEpost(2)
    Dim As Double d_sigma_TKEpost(2)
    Dim As Double d_TotXE(2)
    
