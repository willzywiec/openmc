'1
    I_NS = I_NS + 1             
    C_out = "******************************************************************"
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               

'2
    I_NS = I_NS + 1             
    C_out = "**  Fission yields obtained with the GEF code, version "+C_GEF_Version+"               "
    C_out = Left(C_out,64)+"**"
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               
  
'3 
    I_NS = I_NS + 1
'   C_out = "** Isomers and cumul. yields based on ENSDF                     **"    
    C_out = "** Isomers and cumul. yields based on JEFF3.3 decay data file   **"
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               

'4             
    I_NS = I_NS + 1             
    C_out = "*Developed 2009-2025                                             *"
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               

'5             
    I_NS = I_NS + 1             
    C_out = "*2019-2025   ** Karl-Heinz Schmidt, Beatriz Jurado, Kilian Kern **"
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               
  
'6             
    I_NS = I_NS + 1             
    C_out = "******************************************************************"
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               
 
'7  
    I_NS = I_NS + 1             
    C_out = " The development of the GEF code has been supported by the        "
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               

'8          
    I_NS = I_NS + 1             
    C_out = " European Union (EFNUDAT, ERINDA and CHANDA) and the              "
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               

'9          
    I_NS = I_NS + 1             
    C_out = " OECD Nuclear Energy Agency (2010-2016)                           "
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               

'10
    I_NS = I_NS + 1
    C_out = String(66," ")
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               

'11
    I_NS = I_NS + 1             
    C_out = " The authors, the European Union and the Nuclear Energy Agency    "
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               

'12      
    I_NS = I_NS + 1             
    C_out = " cannot accept responsibility for loss occasioned to any          "
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               

'13      
    I_NS = I_NS + 1             
    C_out = " person for the use of, or reliance upon, the information         "
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               

'14      
    I_NS = I_NS + 1             
    C_out = " contained in the data or its completeness or accuracy.           "
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               

'15      
    I_NS = I_NS + 1
    C_out = String(66," ")
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               

'16             
    I_NS = I_NS + 1
    C_out = " References:" + String(66," ")
    C_out = Left(C_out,66)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               

    
'17
    I_NS = I_NS + 1
    C_out = " - K.-H. Schmidt and B. Jurado" + String(66," ")
    C_out = Left(C_out,66)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out     

'18
    I_NS = I_NS + 1
    C_out = "   Entropy-driven excitation-energy sorting in superfluid fission" + String(66," ")
    C_out = Left(C_out,66)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out     

'19
    I_NS = I_NS + 1
    C_out = "   dynamics, Phys. Rev. Lett. 104 (2010) 212501" + String(66," ")
    C_out = Left(C_out,66)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out     

'20
    I_NS = I_NS + 1
    C_out = " - K.-H. Schmidt and B. Jurado" + String(66," ")
    C_out = Left(C_out,66)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out     

'21
    I_NS = I_NS + 1
    C_out = "   Thermodynamics of nuclei in thermal contact" + String(66," ")
    C_out = Left(C_out,66)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out     

'22
    I_NS = I_NS + 1
    C_out = "   Phys. Rev. C 83 (2011) 014607" + String(66," ")
    C_out = Left(C_out,66)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out     

'23
    I_NS = I_NS + 1
    C_out = " - K.-H. Schmidt, B. Jurado, Ch. Amouroux" + String(66," ")
    C_out = Left(C_out,66)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out     
    
'24
    I_NS = I_NS + 1
    C_out = "   General Description of Fission Observables - GEF Model" + String(66," ")
    C_out = Left(C_out,66)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out     
    
'25
    I_NS = I_NS + 1
    C_out = "   JEFF Report 24, Nucl. Energy Agency of the OECD, June 2014" + String(66," ")
    C_out = Left(C_out,66)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out     
    
'26
    I_NS = I_NS + 1
    C_out = " - K.-H. Schmidt, B. Jurado, Ch. Amouroux, Ch. Schmitt" + String(66," ")
    C_out = Left(C_out,66)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               
    
'27
    I_NS = I_NS + 1
    C_out = "   General Description of Fission Observables: GEF Model Code" + String(66," ")
    C_out = Left(C_out,66)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               

'28
    I_NS = I_NS + 1
    C_out = "   Nucl. Data Sheets 131 (2016) 107-221 " + String(66," ")
    C_out = Left(C_out,66)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out     
    
'29
    I_NS = I_NS + 1
    C_out = " - See also http://www.cenbg.in2p3.fr/GEF" + String(66," ")
    C_out = Left(C_out,66)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out     

'30              
    I_NS = I_NS + 1
    C_out = String(66," ")
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out               
