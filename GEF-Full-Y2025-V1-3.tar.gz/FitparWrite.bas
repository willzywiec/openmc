' Writing optimum fit-parameter values to Fitpar.dat
Scope
  Dim As Integer F_Fitpar 
  F_Fitpar = Freefile
  Open "Fitpar.dat" for append as #F_Fitpar

  Rdatetime = Now
  Print #F_Fitpar," "
  Print #F_Fitpar,"' List of optimum Parameter values (set ";I_Fitloop; _
                       ", thread ";I_thread;") from Fit" 
  Print #F_Fitpar,"' Written on ";
  Print #F_Fitpar,Format( Rdatetime, "dd.mm.yyyy, hh:mm:ss")
  If B_Fit Then
    Print #F_Fitpar," Chisqr_Fit_present = ";Csng(Chisqr_Fit_present)
    Print #F_Fitpar," Chisqr_Fit_min = ";Csng(Chisqr_Fit_min)
  End If  
  Print #F_Fitpar,"_P_DZ_Mean_S1 = ";P_DZ_Mean_S1
  Print #F_Fitpar,"_P_corr_S1 =    ";P_corr_S1
  Print #F_Fitpar,"_P_DZ_Mean_S2 = ";P_DZ_Mean_S2
  Print #F_Fitpar,"_P_DZ_Mean_S3 = ";P_DZ_Mean_S3
  Print #F_Fitpar,"_P_DZ_Mean_S4 = ";P_DZ_Mean_S4
  Print #F_Fitpar,"_P_DZ_Mean_SL5 = ";P_DZ_Mean_SL5
  Print #F_Fitpar,"_P_DZ_Mean_S5 = ";P_DZ_Mean_S5
  Print #F_Fitpar,"_P_Z_Curv_S1 = ";P_Z_Curv_S1
  Print #F_Fitpar,"P_Z_Curvmod_S1 = ";P_Z_Curvmod_S1
  Print #F_Fitpar,"_P_Z_Curv_S2 = ";P_Z_Curv_S2
  Print #F_Fitpar,"P_Z_Curvmod_S2 = ";P_Z_Curvmod_S2
  Print #F_Fitpar,"_P_Z_Curv_S3 = ";P_Z_Curv_S3
  Print #F_Fitpar,"P_Z_Curvmod_S3 = ";P_Z_Curvmod_S3
  Print #F_Fitpar,"_P_Z_Curv_S4 = ";P_Z_Curv_S4
  Print #F_Fitpar,"P_Z_Curvmod_S4 = ";P_Z_Curvmod_S4
  Print #F_Fitpar,"_P_Z_Curv_S5 = ";P_Z_Curv_S5
  Print #F_Fitpar,"P_Z_Curvmod_S5 = ";P_Z_Curvmod_S5
  Print #F_Fitpar,"_P_Z_Curv_SL5 = ";P_Z_Curv_SL5
  Print #F_Fitpar,"_PZ_S3_olap_pos = ";PZ_S3_olap_pos
  Print #F_Fitpar,"_PZ_S3_olap_curv = ";PZ_S3_olap_curv
  Print #F_Fitpar,"_S2leftmod = ";S2leftmod
  Print #F_Fitpar,"_P_A_Width_S2 = ";P_A_Width_S2
  Print #F_Fitpar,"Fmod_slope_S2 = ";Fmod_slope_S2
  Print #F_Fitpar,"_Delta_S0 = ";Delta_S0
  Print #F_Fitpar,"_P_Shell_S1 = ";P_Shell_S1
  Print #F_Fitpar,"_P_Shell_S2 = ";P_Shell_S2
  Print #F_Fitpar,"_P_Shell_S3 = ";P_Shell_S3
  Print #F_Fitpar,"_P_Shell_S4 = ";P_Shell_S4
  Print #F_Fitpar,"_P_Shell_SL5 = ";P_Shell_SL5
  Print #f_Fitpar,"_P_Shell_S5 = ";P_Shell_S5
  Print #F_Fitpar,"_DE_Defo_S1 = ";DE_Defo_S1
  Print #F_Fitpar,"_DE_Defo_S2 = ";DE_Defo_S2
  Print #F_Fitpar,"_DE_Defo_S3 = ";DE_Defo_S3
  Print #F_Fitpar,"_DE_Defo_S4 = ";DE_Defo_S4
  Print #F_Fitpar,"_DE_Defo_S5 = ";DE_Defo_S5
  Print #F_Fitpar,"_BetaL0 = ";BetaL0
  Print #F_Fitpar,"_BetaL1 = ";BetaL1
  Print #F_Fitpar,"_BetaH0 = ";BetaH0
  Print #F_Fitpar,"_BetaH1 = ";BetaH1
  Print #F_Fitpar,"_dBeta_S3 = ";dBeta_S3
  Print #F_Fitpar,"_ECOLLFRAC = ";ECOLLFRAC
  Print #F_Fitpar,"_EDISSFRAC = ";EDISSFRAC 
  Print #F_Fitpar,"_T_low_S1 = ";T_low_S1
  Print #F_Fitpar,"_T_low_S2 = ";T_low_S2
  Print #F_Fitpar,"_T_low_S3 = ";T_low_S3
  Print #F_Fitpar,"_T_low_S4 = ",T_low_S4
  Print #F_Fitpar,"_T_low_S5 = ",T_low_S5
  Print #F_Fitpar,"_T_low_SL = ",T_low_SL
  Print #F_Fitpar,"_P_att_pol = ",P_att_pol
  Print #F_Fitpar,"_P_att_rel = ",P_att_rel
  Print #F_Fitpar,"_POLARadd = ",Polaradd  
  Print #F_Fitpar,"_HOMPOL = ",HOMPOL
  Print #F_Fitpar,"PZ_EO_Symm = ",PZ_EO_Symm
  Print #F_Fitpar,"PN_EO_Symm = ",PN_EO_Symm
  Print #F_Fitpar,"R_EO_Thresh = ",R_EO_Thresh
  Print #F_Fitpar,"R_EO_Sigma = ",R_EO_Sigma
  Print #F_Fitpar,"R_EO_Max = ",R_EO_Max
  Print #F_Fitpar,"EOScale = ",EOScale
  Print #F_Fitpar,"_Jscaling = ",Jscaling  
  
  Print #F_Fitpar,"D_Par_Fac = ",D_Par_Fac

  Close #F_Fitpar
End Scope
