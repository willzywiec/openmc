﻿1. LICENCE AND COPYRIGHT

'    The development of the GEF code has been supported by the European Union,
'    EURATOM 6, Framework Program "European Facilities for Nuclear Data
'    Measurements" (EFNUDAT), contract number FP6-036434, the Framework
'    Program "European Research Infrastructure for Nuclear Data Applications"
'    (ERINDA),  contract number FP7-269499, and by the Nuclear Energy Agency of 
'    the OECD (from 2010 to 2016).

'    Thanks to all those who helped developing GEF by contributions, testings, 
'    suggestions etc., namely
'    Emmeric Dupont, Christelle Schmitt, Charlotte Amouroux, Kilian Kern, 
'    Arjan Koning, Magali Estienne, Muriel Fallot, Asim Pal, Bamidele Ebiwonjumi,
'    Nicolas Dray, Ali Al-Adili, Anton P. Tonchev, Peter Karlsson, Diego Ramos,
'    Jeremie Dudouet, Jonathan Colllin and others. 


'    The GEF code is free software: you can redistribute it and/or modify
'    it under the terms of the GNU General Public License as published by
'    the Free Software Foundation, either version 3 of the License, or
'    (at your option) any later version.
'
'    This program is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'    GNU General Public License for more details.
'
'    You should have received a copy of the GNU General Public License
'    along with this program.  If not, see <http://www.gnu.org/licenses/>.


'    Copyright 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 
'       2019, 2020, 2021, 2022, 2023, 2024, 2025: 
'       Dr. Karl-Heinz Schmidt, Rheinstraße 4, 64390 Erzhausen, Germany
'       and 
'       Dr. Beatriz Jurado, Centre d'Etudes Nucleaires de Bordeaux-Gradignan,
'       Chemin du Solarium, Le Haut Vigneau, BP 120, 33175 Gradignan, Cedex,
'       France 
 

2. NAME OF THE PROGRAM:  GEF 2025/1.2


3. DESCRIPTION OF PROGRAM OR FUNCTION

GEF is a computer code for the simulation of the nuclear fission process. 
The GEF code calculates pre-neutron and post-neutron fission-fragment nuclide 
yields, angular-momentum distributions, isomeric yields, prompt-neutron yields 
and prompt-neutron spectra, prompt-gamma spectra, and several other quantities 
for a wide range of fissioning nuclei from mercury to seaborgium in 
spontaneous fission and neutron-induced fission. For neutron-induced fission, 
the pre-compound emission of neutrons and protons is considered. Output is 
provided as tables and as values of fission observables on an event-by-event basis.

Specific features of the GEF code:
- The mass division and the charge polarisation are calculated assuming a 
statistical population of states in the fission valleys at freeze-out. 
The freeze-out time considers the influence of fission dynamics and is not 
the same for the different collective variables.
- The separability principle [1] governs the interplay of macroscopic and 
microscopic effects.
- Five fission channels are considered. The strengths of the shells in the 
fission valleys are identical for all fissioning systems. The mean positions 
of the heavy fragments in the asymmetric fission channels are essentially 
constant in atomic number, as suggested by experimental data [2].
- The stiffness of the macroscopic potential with respect to mass asymmetry 
is deduced from the widths of measured mass distributions [3].
- The excitation-energy-sorting mechanism [4,5,6,7,11] determines the prompt 
neutron yields and the odd-even effect in fission-fragment yields of even-Z 
and odd-Z systems.
- Prompt neutron emission from the fragments is calculated with a Monte-Carlo 
statistical code using level densities from empirical systematics [8] and 
binding energies from mass tables with gamma competition included.
- Spectra and multiplicities of prompt gamma emission are provided. 
Non-statistical gamma emission is calculated with a dedicated VMI model. 
- Model uncertainties, covariances and correlation coefficients are 
determined by a series of calculations with perturbed parameters. 
Covariances and correlations of fission yields from two different systems 
are available.

The official GEF websites are http://www.khschmidts-nuclear-web.eu and 
http://www.cenbg.in2p3.fr/GEF.


4. METHOD OF SOLUTION

The Monte-Carlo method is used. 
Uncertainties are deduced from perturbed calculations. 


5. TYPICAL RUNNING TIME

A typical calculation with 100 000 events takes about 10 seconds on one processor 
of an Intel i7 CPU (2.80GHz). Calculations with perturbed parameters and 
calculations at higher excitation energies, where multi-chance fission occurs, 
require somewhat more time.


6. RELATED AND AUXILIARY PROGRAMS

The main routines are written in FreeBASIC (http://www.freebasic.net/). FeeBASIC 
produces compiled binary code using the C run-time library. Graphics output is 
based on the X11 library. A graphical user interface is provided for Windows [a], 
written in JustBasic (http://www.justbasic.com/), which has a specific run-time 
library. The Windows version of GEF runs also under WINE on LINUX.

                                       
7. REFERENCES

 [1] Experimental evidence for the separability of compound-nucleus and fragment properties in fission, 
     K -H Schmidt, A Kelic, M V Ricciardi, Europh. Lett. 83 (2008) 32001
 [2] Nuclear-fission studies with relativistic secondary beams: analysis of fission channels, 
     C. Boeckstiegel et al., Nucl. Phys. A 802 (2008) 12
 [3] Shell effects in the symmetric-modal fission of pre-actinide nuclei, 
     S. I. Mulgin, K.-H. Schmidt, A. Grewe, S. V. Zhdanov, Nucl. Phys. A 640 (1998) 375
 [4] Entropy-driven excitation-energy sorting in superfluid fission dynamics,
     K.-H. Schmidt, B. Jurado, Phys. Rev. Lett. 104 (2010) 212501
 [5] New insight into superfluid nuclear dynamics from the even-odd effect in fission, 
     K.-H. Schmidt, B. Jurado, arXiv:1007.0741v1 [nucl-th]
 [6] Thermodynamics of nuclei in thermal contact, 
     K.-H. Schmidt, B. Jurado, Phys. Rev. C 82 (2011) 014607
 [7] Final excitation energy of fission fragments, 
     K.-H. Schmidt, B. Jurado, Phys. Rev. C 83 (2011) 061601(R)
 [8] Inconsistencies in the description of pairing effects in nuclear level densities, 
     K.-H. Schmidt, B. Jurado, Phys. Rev. C 86 (2012) 044322
 [9] General description of fission observables,
     K.-H. Schmidt, B. Jurado, Ch. Amouroux, JEFF-Report 24, NEA of OECD, 2014  
[10] Revealing hidden regularities with a general approach to fission
     K.-H. Schmidt, B. Jurado, Eur. Phys. J. A 51 (2015) 176
[11] Influence of complete energy sorting on the characteristics of the odd-even
     effect in fission-fragment element distributions
     B. Jurado, K.-H. Schmidt, J. Phys. G: Nucl. Part. Phys. 42 (2015) 055101
[12] General description of fission observables: GEF model code
     K.-H. Schmidt, B. Jurado, C. Amouroux, C. Schmitt, Nucl. Data Sheets 131 (2016) 107   
[13] Review on the progress in nuclear fission - experimental methods and theoretical descriptions
     K.-H. Schmidt, B. Jurado, Rep. Progr. Phys. 81 (2018) 106301
[14] Extensive study of the quality of fission yields from experiment, evaluation and 
     GEF for antineutrino studies and applications,
     K.-H. Schmidt, M. Estienne, M. Fallot, S. Cormon, A. Cucoanes, T. Shiba, B. Jurado, 
     K. Kern, Ch. Schmitt, Nucl. Data Sheets 173 (2021) 54 
[15] Evidence for the general dominance of proton shells in low-energy fission,
     K. Mahata, C. Schmitt, Shilpi Gupta, A. Shrivastava, G. Scamps, K.-H. Schmidt
     Phys. Lett. B 825 (2022) 136859   
[17] Identifying and overcoming deficiencies of nuclear data on the fission of light actinides 
     by use of the GEF code,
     K.-H. Schmidt, Ch. Schmitt, A. Heinz, B. Jurado
     Annals of Nuclear Energy 208 (2024) 110784           


8. HARDWARE REQUIREMENTS

GEF can be compiled and installed under Windows [a] and Linux, using exactly 
the same sources files. Specific executables are provided for the two systems.
GEF was tested on Windows [a] and Linux.

Memory about 30 MByte; Disc < 100 MByte, eventually more for event-wise output.


9. PROGRAMMING LANGUAGE(S) USED

Computer language
on Linux: FreeBASIC; on Windows [a]: FreeBASIC and JustBasic


10. OPERATING SYSTEM UNDER WHICH PROGRAM IS EXECUTED

a) Windows [a] XP or newer
b) Any Linux distribution, 32-bit or 64-bit. Eventually, some additional 
libraries need to be installed, see www.freebasic.net -> documentation 
-> using the FreeBASIC compiler -> Installing FreeBASIC.


11. OTHER PROGRAMMING OR OPERATING INFORMATION OR RESTRICTIONS 

Multi-chance fission is supported. 
The results on neutron emission prior to fission and prompt-neutron emission 
between saddle and scission, and from the fragments are given separately. 
The sequence of the events in the list-mode output is sorted by energy at 
fission in the case of multi-chance fission in order to save computing time.
An optional enhancement factor may be specified. A value >1 increases the 
statistics of the Monte-Carlo calculation and hence reduces the statistical 
uncertainties and fluctuations of the results. Default value is 1.E5 events.
This is adapted for a rough overview, but the number of events should be
appreciably increased, when accurate results are required. This is particularly 
useful to compare different systems, to study systematic trends and to 
determine reliable covariances. 
GEF provides all results event by event in a list-mode file on demand.


12. NAME AND ESTABLISHMENT OF AUTHORS

K.-H. Schmidt, Rheinstr. 4, D-64390 Erzhausen, Germany
B. Jurado, LP2iB CNRS/IN2P3 19 Chemin du Solarium F-33170 Gradignan, France 


13. MATERIAL AVAILABLE

FreeBASIC [c] source files. JustBasic [d] executable and run-time-library.
Executables for Windows [a] and Linux.
ReadMe file with technical instructions.


14. CATEGORIES

Nuclear fission

Keywords: Monte-Carlo method, event generator, macroscopic-microscopic model, 
separability principle, energy sorting, statistical model, pre-equilibrium emission, 
multi-chance fission, independent and cumulative yields, neutron evaporation,
prompt-gamma emission, delayed neutron emission, anti-neutrinos,
uncertainties and covariance matrix of fission-fragment yields.


15. PRACTICAL HINTS

Please keep the sub-folder structure of GEF.zip. Subfolders that are 
needed by the code for output are created automatically, if they do 
not exist. GEF does not overwrite or delete the output files. Files 
in the folders /out, /tmp, and /dmp (+) that are not needed any more should 
be deleted explicitly.
"/out" contains the main output as ASCII tables.
"/ptb" contains full results of perturbed calculations (optional).
"/tmp" contains more specific or internal information as ASCII tables.
"/dmp" contains spectra in SATAN analyzer format. 
"/ctl" contains control files for multithreaded calculations.

On Windows [a]:
The file GEF.zip provides an executable of the main programm (GEF.exe) 
and - in the subfolder GUI - a graphical user interface.
GEF is started by running "GEF.bat" (!) in a command window.
All user input must be entered by the GUI window!

If you want to apply any changes, use an IDE (e.g. FBIDE [b]) for editing
any of the source files (*.bas). Compile the main routine GEF.bas under 
FreeBASIC [c]. The other files are automatically included in the compilation 
process. (Compile by pressing the "compile" botton of FBIDE when GEF.bas is open.) 
The GUI is written in JustBasic [d].

On Linux:
The file GEF.zip provides an executable (GEF) that runs directly in a 
terminal by entering "./GEF". (Do not forget to set the file properties to
"execute as a program".)

The GUI that is provided in the Windows version may also be used under Linux
by running the Windows version of GEF under Wine [e] without any loss of
performance.

If you want to make any changes to GEF, prepare an executable, using 
an IDE (e.g. GEANY [f]) with the FreeBASIC [c] compiler. GEF.bas is the main 
routine. The other files are automatically included in the compilation process.
Compile by pressing the "compile" botton of GEANY when GEF.bas is open or
by the command "fbc GEF.bas".
Remark: Installation of additional packages may be required. (See
http://www.freebasic.net/ -> Documentation -> User Manual -> 
Using the FreeBASIC Compiler -> Installing FreeBASIC.)
E.g. the graphics output requires the installation of the X11 library. 
If the graphics does not work, you may suppress it by commenting the line
( #Include Once "DCLPlotting.bas" ) in GEF.BAS.

REQUIRED INPUT OF GEF:

Z and A of fissioning nucleus or target
Excitation mode and excitation energy, respectively projectile energy

OUTPUT OF GEF:

The standard output is written as an ASCII file with some XML features in the /out +) folder.
The XML tags structure the file and allow fast navigating. For this purpose, the GEANY (f)
editor (available on WINDOWS and on LINUX) is well suited, because it is fast, and it 
respects the ASCII line breaks.  
The name of the file is composed of the fissioning system (not the target 
nucleus!) and the entrance channel.

Quantities available on output of GEF:

Contributions of fission chances
Relative yields of fission channels
Element-yield distribution*) 
Isotonic-yield distribution (pre- and post-neutron)
Isobaric-yield distribution*)
Mass-chain yields (pre- and post-neutron)*)
Fragment angular-momentum distributions (for every nuclide)
Relative independent isomeric yields
Prompt-gamma spectrum 
Prompt-neutron spectrum 
Neutron-multiplicity distribution
Energies and directions of prompt neutrons (pre- and post-scission)
(Many more quantities are internally calculated and may be listed.)

*) Including uncertainties and covariances.

Additional output is written to specific files of the /dmp (+) folder in
SATAN format.
The name of the dmp file is composed of the fissioning system 
(not the target nucleus!) and the entrance channel.

When beta-delayed processes are included in GEF (e.g. delayed neutrons,
anti-neutrino production, cumulative yields), tables of independent and 
cumulative yields are provided in ENDF format, when this option is
activated.
In the case of n-, p- or alpha-induced fission, the ENDF file name is 
composed of the target nucleus!

Nuclear properties, used for calculating isomeric yields, are provided 
by JEFF-3.1.1, JEFF-3.3 or NUBASE-2020.
The choice is made by including the appropriate file NucPropxxx.bas in 
the compilation of GEF (further information in the file GEF.bas).

Nuclear properties, used for calculating beta-delayed processes and 
cumulative yields are provided by JEFF-3.1.1, JEFF-3.3 or NUBASE 2020.
The choice is made by including the appropriate file DCLbranching.bas in 
the compilation of GEF (further information in the file GEF.bas).

ADVANCED OPTIONS:

- UNCERTAINTIES
Uncertainty analysis from calculations with perturbed parameters is available.
These calculations are also used to determine covariances and correlations 
between different observables as required by the model. Covariances and
correlations between the fission yields of two different systems can also 
be provided. 

The program ReadCorr may be used to convert the output of the covariance 
and correlation matrices of the independent yields (specified in A and Z) 
in the GEF output file into an extended format.
It reads the data and explicitly lists the 4-dimensional (Z1, A1, Z2, A2) 
coordinates and the corresponding matrix values. 

Due to the Monte-Carlo method, the calculated uncertainty, correlation and
covariance values fluctuate from one to another calculation. 
There are two effects that contribute to these fluctuations. These are the 
sampling of perturbed parameters from the corresponding Gaussian 
distributions and the statistical fluctuations of the calculations with a 
specific parameter set. In order to keep the influences of both effects at 
a similar level, both the number of perturbed parameter sets (N_par) 
(sampled from the appropriate Gaussian distribution) and the number of 
perturbed calculations (N_stat) with a specific parameter set vary as a 
function of the total number (N_tot) of calculations, given as input option. 
N_par is given by the following relation:
   N_par = Int(sqr(N_tot / 1000)).
Table 1 gives on overview on these variations.

                            TABLE 1
                            
   N_tot        Enhancement factor           N_par           N_stat
                given on input
                (Fenhance)
    
   1.E5         1                              10             10000
   2.E5         2                              14             14285
   5.E5         5                              22             22727
   1.E6         10                             31             32258
   2.E6         20                             44             45454
   5.E6         50                             70             71428
   1.E7         100                           100            100000
   2.E7         200                           141            141844
   5.E7         500                           223            224215
   1.E8         1000                          316            316455
   2.E8         2000                          447            447427
   5.E8         5000                          707            707214
   1.E9         10000                        1000           1000000
   2.E9         20000                        1414           1414427
   5.E9         50000                        2236           2236136
   
The calculations with the perturbed parameter values are only performed
to determine the uncertainties, correlations and covariances. The 
nominal (most probable) values are calculated with the nominal
parameter values. Note that the calculations with the nominal parameter 
values are performed with N_tot events.   

The values of the perturbed parameters are listed in the file
/tmp/{system}/par. The corresponding multi-variate distributions of GEF
yields can be found in /tmp/{system}/mvd (+).

The variation of the perturbed parameters (the width of the appropriate
Gaussian distribution, the perturbed parameter values are sampled from) 
can be modified by a scaling parameter.
Values smaller than one are useful for avoiding the problem that the yields of 
some nuclides become zero with some of the perturbed parameter sets, because 
GEF will not provide covariances/correlations for these nuclei. For example, 
a scaling factor of 0.5 may be used. Note that this leads to a reduction of the 
calculated uncertainties by the same factor and a reduction of the variances 
and covariances by a factor of 0.25. The correlations are not systematically 
modified.

Another effect of the Monte-Carlo method of the GEF code is a noise of 
fluctuations in the case of low statistics in the determined 
covariance/correlation values. In particular covariances/correlations of 
strongly correlated quantities (correlation coefficients close to one) are 
reduced. This effect is particularly strong when covariances/correlations of 
independent yields of two different systems are considered. It is also
aggravated when the variation of the perturbed parameters is reduced as
described above.
 
Both effects (lower yield threshold for calculated uncertainties/covariances/
correlations and reduction of covariances/correlations of strongly correlated
quantities) are reduced to the desired degree by performing the GEF calculation 
with higher statistics (a larger number of fission events.

Note that also the uncertainties determined by GEF include the effect of the 
statistical fluctuations in the case of insufficient statistics. In consequence,
the calculated uncertainties are increased. This effect can be investigated by 
calculations with an increasing number of events. The influence of statistical 
fluctuations becomes negligible, when the uncertainties given by GEF attain an 
asymptotic value.

THE USER SHOULD CAREFULLY ESTIMATE THE NECESSARY NUMBER OF EVENTS TO BE 
CALCULATED (and chose the corresponding enhancement factor) IN ORDER TO 
REACH A SUFFICIENTLY SMALL LEVEL OF STATISTICAL FLUCTUATIONS OF THE
SPECIFIC QUANTITY HE IS INTERESTED IN.

- USER-DEFINED PARAMETER VALUES
The user may provide his own parameter values in a data file. A sample file,
named MyParameters_sample.dat is included in the GEF package. This file provides
more practical information about this option.

- ENERGY DISTRIBUTION
Instead of a single energy, also a distribution of excitation energies
above the ground-state at fission may be provided in a file. 
The default file name is: in/Espectrum.in (+). 
     - Example: (energy, weight)
                   ' energy distribution 
                   ' as an example
                   3.9    0.1
                   4.0    0.2
                   4.1    0.4
                   4.2    0.7
                   ...
Each line gives an energy (in MeV) and a weight. 
One or several comment lines can be inserted at the beginning of the file.
Energy steps of about 100 keV are recommended. The spectrum may be
un-normalized. 
It is also possible to insert the rms compound-nucleus angular momentum as
the second row to the input data in in/Espectrum.in (+). (Zero angular momentum is 
replaced by the ground-state spin of the compound nucleus.)
     - Example: (energy, spin, weight)
             '   E/MeV   spin   weight
                  3.9     9.8    0.1
                  4.0    10.1    0.2
                  4.1    10.4    0.4
                  4.2    10.9    0.7
                  ...
The first lines of the file can contain some comments. These lines must 
begin with a "'" sign. 
The corresponding option is chosen by the GUI under Windows or by the 
option "ES" (for first-chance fission) or "EM" (for multi-chance fission) 
under Linux. 

- INPUT LIST
GEF supports reading an input list from file. The calculation is performed in 
batch mode without an input dialogue or a GUI. This option is chosen if 
the file "file.in" is found.

Instructions:

When this option is used, at least two files must be provided.
The file "file.in" is created in the folder, where the exectable of GEF
is situated. It gives the names of the files with the specific information
of the cases to be processed. It is convenient to place those files in
the subfolder "/in" (+). Detailed information on these files is given below:

1. Create a file (for example in the subfolder "/in" (+)) with the following information: 
   FIRST BLOCK:
     First line: Statistical enhancement factor (default = 1 corresponds
                 to 10^5 events per system). A larger factor increases 
                 the number of calculated events accordingly.
     Second line: Energy value, list of energy values, or the name of file 
         with an energy spectrum.
         For neutron-induced fission: List of energy values in ascending order.
         For fission from a given energy above the ground-state,
         only one energy value is allowed. Zero energy specifies spontaneous fission.
         In case of an energy spectrum, the name of the file, containing the 
          energy spectrum (as described above under "ENERGY DISTRIBUTION"), 
          is given.
         For compound-nucleus fission (option "CN", see below), also the
         angular momentum can be specified. Example: 30/5 for E=30, Spin=5. 
   SECOND BLOCK:       
     Special options (optional)  
                 Options(xxx,yyy,...)
                 Supported options are 'local' : use locally adjusted model parameters
                                                 (if available). This is the default.
                                       'global': use global model parameters.
                                       'MyParameters' : read parameter values from file
                                                           MyParameters.dat,
                                       'err' : perturbed-parameter calculations,
                                       'FIT(observables)' : fit option,
                                       'ptb' : output of perturbed calculations,
                                       'cor' : output of correlations,
                                       'cov' : output of covariances,
                                       'lmd' : list-mode output,
                                       'lmd+': list-mode output, including prompt neutrons and gammas,
                                                and different contributions to E* of the fragments
                                                (intrinsic, deformation and rotation), 
                                       'neo' : even-odd staggering in Z and N 
                                                at scission suppressed,
                                       'nosupp' : no suppression of compact shapes at scission,         
                                       'ENDF' : output of FY in ENDF format,
                                       'random' : produce ENDF random files.     
                   In preparation:     'dparfac(value)' : factor to scale the
                                          variation of perturbed parameters, 
     List of observables to be included in the fit process
                 FIT(xxx,yyy,...)
                 Supported observables are 'APRE'   : pre-neutron mass distributions,
                                           'APOST'  : post-neutron mass distributions,
                                           'NUBAR'  : prompt-neutron multiplicities,
                                           'NDEL'   : delayed-neutron multiplicities,  
                                           'TKEPRE' : pre-neutron TKE values,
                                           'TKEPOST': post-neutron TKE values.
                                           'ZPOST'  : Z distribution
                                           'ZEMFRS' : Z distribution for el.-magn.-induced fission
                                                        (FRS experiments with Pb or U targets)
                                           'ZEO'    : Z even-odd effect
                                           'ZVSAPOST': Zmean over Apost             
                 Remark: The Monte-Carlo fit procedure optimizes the GEF parameters by
                         searching for a minimum of rms deviations from specific fission 
                         observables. It runs only in batch mode. 
                         The fit can only be performed, when the corresponding 
                         empirical data are present in the data compilation of the
                         GEF code in the file DCLplotting.bas, and when the 
                         corresponding code sequences for the calculations exist in 
                         Plotting.bas. 
                         The file tmp/Fitlog.dat provides a log file of the fit.
                         The calculated fission yields of the last iteration are
                         written to the folder /GRAF in SATAN format. 
                         When a new set of optimum parameters is found, the parameter
                         values are written to Fitpar.dat, and the fission yields are
                         copied from /GRAF to BestFit/GRAF.                                       
     Filter on a specific fission mode (optional)
                 Mode(i) 
                     i = 0: Super-long mode
                     i = 1: Standard 1
                     i = 2: Standard 2
                     i = 3: Super-asymmetric mode
                     i = 4: Mode created by shell near Z = 82
                     i = 5: Mode created by shell near Z = 36
                     i = 6: Overlap of Standard 1 in both fragments
                     i = 7: Overlap of Standard 2 in both fragments 
   THIRD BLOCK:                                          
     Specification of the fissioning system.
                 (Z_CN, A_CN, kind of fission)
         A range of consecutive isotopes can be specified in a shorter way:            
                 (Z_CN, A_CN_first - A_CN_last, kind of fission)
         If a second system is given, the correlations between the two systems 
                 are calculated: (Z_CN, A_CN, Z_CN_2, A_CN_2, E_CN_2, kind of fission)  
         Options for the "kind of fission" are
             "GS" for spontaneous fission or fission from an excited compound nucleus,
             "EB" for CN nucleus fission (The energy value is defined as the energy
               above the outer fission barrier.).
             "EN" for neutron-induced fission. (The energy value is the neutron kinetic energy.)    
             "EP" for proton-induced fission. (The energy value is the proton kinetic energy.)
             "EA" for alpha-induced fission. (The energy value is the alpha kinetic eneergy.) 
             "ES" for fission with an excitation-energy distribution, limmited to
                first-chance fission.
                Instead of one energy value, the name of the file providing the
                excitation-energy distribution (above the ground state) is given. 
                The energy steps must be equidistant.
                The option "ES" is not compatible with output in ENDF format. 
             "EM" for fission with an excitation-energy distribution and multi-chance 
                fission considered. The excitation-energy distribution on input is
                the distribution of initial excitation energies of the system. 
                (The energy steps must be equidistant.)
                The option "EM" is not compatible with output in ENDF format. 
                The total fission probability and the relative contributions from 
                the different fission chances are calculated by GEF.         

     - Example for spontaneous fission:
             10
             0
             98, 250, "GS"
             ' 98, 250, "GS"
             98, 252, "GS"
             94, 238-242+2, "GS"
             END
             99, 250, "GS"
             99, 251, "GS"
       In this example, the system 98, 250 is skipped due to the comment sign,
       and calculations for a series of even Pu isotopes between mass 238 and
       242 are performed. The last two lines after the END line are disregarded.    
       
     - Example for neutron-induced fission with additional options:
             2
             0.0253E-6, 0.4, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14  
             Options(err,cor)
             92, 234-239, "EN"
             ...
       Five independent calculations for a sequence of uranium isotopes are performed 
       with the energies given in the second line of the input file. This feature is 
       supported for the options "GS", "EN", and "EB".
       (Correlations between two systems can only be calculated at one
        energy step, or with the option "ES").
        
     - Example for fission from an excited compound nucleus. A sequence of
       excitation energies and of the corresponding average angular momenta is given:
             100
             0/0, 5/3.5, 10/9, 15/12
             94, 242, "GS"
       This feature is supported for the option "GS".
           
     - Example for neutron-induced fission, target in an isomeric state:
             10  
             0.0253E-6, 0.4, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14  
             95, 243, "EN1"
             ...
             The target nucleus (242Am) is in the first isomeric state.
             (The isomers must be listed in the file NucPropxxx.bas.)

     - Example for fission, providing an excitation-energy distribution from file:
             5
             "Edistri.in"
             92, 233, "ES"
             ...

     - Example for fission from a shape isomer:
       (The isomers must be listed in the file NucPropxxx.bas.)
             100
             0 
             94, 241, "IS1"
             94, 242, "IS1"
             ...

     - Example for correlations between two systems with additional options:
             10
             0.5
             Options(err,ptb)
             92, 236, 94, 240, 0.5, "EN"    

     - Example for correlations between two systems with two (eventually different) 
       distributions of excitation energies above ground state from file:
             1000
             "Edistri1"
             92, 234, 92, 236, "Edistri2", "ES"    
             
     - Example for a contribution of different data from 239Pu(nth,f) to 
       a fit procedure:
             10
             0.0253E-6
             FIT(NUBAR,APOST,NUDEL,ZEO)
             94,240,"EN"  

2. Create the file "file.in", which contains the names of the input
   files (one per line) in the folder, where the executable of GEF is
   situated.. Again, single lines marked by a comment sign are
   disregarded, and reading is stopped by an "END" line.
     - Example (+)
       "/in/U238NF.in"
       ' "/in/CF252SF.in"     
       "/in/PU240SF.in"    
   In this example, only the files U238NF.in and PU240SF.in are treated.
   CF252SF.in is skipped due to the comment sign.
   The number of iterations in the fit mode can be limited by adding a 
   line like: "NITER(n)". Otherwise, the fit will continue to search for
   an even better parameter set, until GEF is stopped.  
    - Example
       NITER(1000)

- PARALLEL COMPUTING 
It is recommended to run only one GEF calculation at a time. Otherwise,
there is a risk for collisions in writing data to the disk. 
The only way to run several calculations simultaneously is the special
procedure that is described in the following: 
GEF supports running several processes in parallel, which calculate
the systems given in the input files (specified in "input.in") in parallel 
in a coordinated way. This enables making efficient use of multi-processor 
machines. Before starting a new sequence of calculations, the files 
"/ctl/done.ctl", "/ctl/sync.ctl and "/ctl/thread.ctl" MUST be deleted! 
You may also delete the complete "/ctl" folder (+).
(This ensures that the first process runs as thread = 1.
This process governs the time management and the proper organization 
of the parallel computing of a series of GEF calculations in batch mode.)
After this, open a new command window (terminal) for each GEF process to 
be started (Linux: "./GEF", Windows: "GEF.bat"), until you reach the limit 
that is stored in the variable I_thread_max in GEF.bas.
Before launching the next job, please wait, until the previous one started
the calculation!
Under Windows, this can be done with a suitable bat file, when the
input data are provided by an input file. In the following example, 
4 terminals are opened, and one GEF calculation is started on each of 
them (after each started job, the ENTER key must be pressed to continue).
This procedure works also under WINE on Linux.

    start GEF.exe
    Pause
    start GEF.exe
    Pause
    start GEF.exe
    Pause
    start GEF.exe

The following shell for the same purpose works on LINUX:

    #!/bin/bash
    echo "************************************************************"
    echo This shell starts 4 batch jobs of GEF for input from file.
    echo The delay is necessary for the multi-thread organisation.
    echo "(Chose 'Preferences/Title and command/Keep the terminal open'"
    echo "on a GNOM terminal to keep the terminal open when GEF stops.)"
    echo "************************************************************"
    gnome-terminal --title="GEF 1" --zoom=0.65 -- "./GEF"
    sleep 1
    gnome-terminal --title="GEF 2" --zoom=0.65 -- "./GEF"
    sleep 1
    gnome-terminal --title="GEF 3" --zoom=0.65 -- "./GEF"
    sleep 1
    gnome-terminal --title="GEF 4" --zoom=0.65 -- "./GEF"
    
Some sample .bat and .sh files for 2, 4 and 8 parallel processes are provided.
They start the subsequent GEF runs automatically. Under LINUX, please check that
the executable suited for your system has the name "GEF". (Special
versions for 32-bit and 64-bit systems are provided with the names
"GEF32" and "GEF64". The suitable version for your sytem must be renamed.)     

Make sure that the value of I_thread_max has the right value for your system!
(I_thread_max is the maximum number of parallel calculations that can be
efficiently performed on your system.)
If necessary, change the value of I_thread_max in GEF.bas and recompile GEF.bas! 
Multi-processing calculations are performed without graphics output.
Note that multi-processing is not compatible with the list-mode output!

- DELAYED PROCESSES (available in the full GEF version)
The full version of GEF calculates also the delayed processes after beta 
decay: like beta-delayed neutron emission and cumulative yields. The decay
data from JEFF-3.3 are used by default. (Also JEFF-3.1.1 can be used.) 
The output is found in the /out (+) folder.

- ENDF FORMAT (available in the full GEF version)
Tables of independent and cumulative yields in ENDF format are written, 
if the corresponding subroutines DCLbranching.bas, BRANCHINGS.bas, 
DCLendf.bas, ENDF.bas, ENDF_tape_description.bas, and ENDF_EOT.bas
are included in the link process. This option is activated, if the line 
#define B_delayed in GEF.bas is uncommented and the option ENDF is chosen.  
The nuclear-decay data used for the calculation of the cumulative yields
are listed in the file BRANCHINGS.bas. The output is written to the subfolder 
/ENDF (+). This folder is automatically created, if it does not exist.  

Uncertainties are determined by calculations with perturbed parameters, taking
into account the covariances of the independent fission-fragment yields.
The cumulative nuclide yields, including isomeric yields, are also written in 
plain ASCII to the output file in the /out folder (+). There is also a list of
delayed-neutron emitters.

It is recommended to use the option "input list from file" for these calculations 
(see above), if they have to be done for a larger number of systems.

Random files of fission yields in ENDF format are produced, if the
corresponding input option is chosen. If the input list from file is used,
the option 'random' must be specified on the input file.

- NUCLEAR SPECTROSCOPIC AND DECAY DATA
Spectroscopic data, used for the calculation of isomeric yields, are
available from JEFF-3.1.1, JEFF-3.3 and NUBASE-2020. Decay tables, used
for the calculation of beta-delayed processes and cumulative yields,
are available from JEFF-3.1.1 andJEFF-3.3. 
The appropriate tables are chosen by including the corresponding files 
NucPropxxx.bas, respectively DCLbranchingxxx.bas, in the source of GEF.bas.
Re-compilation is necessary.
These tables may be modified or extended by the user (by respecting the
appropriate format). For example, additional isomers may be included. 
No further adjustments of the GEF code are required. 


16. CUMULATION PROCESS FROM EXTERNAL POST-NEUTRON FISSION YIELDS

The full GEF version provides the possibility to calculate the cumulation
process by radioactive decay, starting from external fragment yields.
The output comprises properties of beta decay, delayed neutron emission,
anti-neutrino production and cumulative yields.
This option requires the input of fission-fragment yields in the folder
\External with the following specifications:
The structure of the file is illustrated by the following example:

' The first lines of the file may contain some comments, which are disregarded
' by GEF. They must begin with a comment character of FREEBasic. 
' The following lines provide the external fission yields. The sequence is free.
'    Z        A       Yield
    40       100       0.65
    40       101       0.79
 ...

The name of the file specifies the fissioning system and the entrance 
channel (including the energy) in accordance with the origin of the 
external data, for example Z92_A236_n_E1MeV.dat in the case of 235U(n,f), 
En = 1 MeV.
A practical way to verify the required file name in other cases is to
perform a short GEF calculation with the corresponding parameters 
(fissioning system and entrance channel) and to look up the name of the
subfolder in the \dmp folder, which is created by GEF.
There is no further action required to trigger the calculation with the
external fission yields; GEF always checks the presence of the suitable input
file in the \External folder.  

For this calculation, the initial population of isomeric states is
required. Since this information is often not available from experiment,
it is taken from GEF. Therefore, the cumulation calculation is performed
at the end of a "normal" GEF calculation, from which the necessary
isomeric ratios are used.


17. DETERMINISTIC VERSION OF GEF AS A SUBROUTINE IN FREEBASIC AND FORTRAN.

A deterministic version of the GEF code provides pre-neutron fission-fragment 
nuclide distributions and kinetic energies. It is written as a subroutine that
is called with a specific compound nucleus, its excitation energy and its
angular momentum on input. See the file "GEFSUB.pdf" for details.

The deterministic version of GEF uses the global parameter set. Locally
adjusted parameters are not available.


+) Note that the folders are denoted by a "/" sign on Linux and a "\" sign
on Windows.

[a] Windows is either a registered trademark or a trademark of Microsoft 
Corporation in the United States and/or other countries.
[b] FBIDE is available from http://fbide.freebasic.net/ with no cost.
[c] FreeBASIC is available from http://www.freebasic.net/ with no cost.
[d] JustBasic is available from http://www.justbasic.com/ with no cost.
[e] Wine is a windows compatibility layer for Linux (http://www.winehq.org/)
[f] Geany is available from http://www.geany.org/ with no cost.


In case of problems, please contact  schmidt-erzhausen at t-online.de .
