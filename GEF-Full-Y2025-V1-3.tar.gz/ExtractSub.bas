' Extract parts of the GEF.BAS code
' to construct a stand-alone version of GEF as a subroutine.

Dim As String Cline
Dim As Ubyte Bout = 0


Dim As Integer Fin
Fin = freefile
Open "GEF.bas" For Input As #Fin

Dim As Integer Fout
Fout = freefile
Open "GEFSUB.bas" For Output As #Fout

Do Until EOF(Fin)
  Line Input #Fin, Cline
  If Instr(Cline,"/'>'/") > 0 Then
    Bout = 0
  End If
  If Bout = 1 Then
    Print #Fout, Cline
  End If
  If Instr(Cline,"/'<'/") > 0 Then
    Bout = 1
  End If
Loop

Close #Fin
Close #Fout
Print "Finished"
End

