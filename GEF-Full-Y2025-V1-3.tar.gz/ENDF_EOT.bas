' Write EOT (End of Tape) line.
' Not used any more, moved to ENDF.bas.

Scope
  Dim As String C_out
  C_out = " 0.000000+0 0.000000+0          0          0          0          0  -1 0  0    0"
  fENDF = Freefile
  Open CGEFY For Append As #fENDF
  Print #fENDF,C_out 
  Close #fENDF 
End Scope
I_Print_Title_Line = 1
