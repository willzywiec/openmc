cd GUI
start GUI.exe
cd ..
start GEF.exe
