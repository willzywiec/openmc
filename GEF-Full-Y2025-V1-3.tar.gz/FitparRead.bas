' Reading optimum fit-parameter values from Fitpar.dat
If Fileexists("Fitpar.dat") Then  ' Read Fit parameters from previous fit result
  Scope 
    Dim As String Cline
    Dim As Integer Ileft,Iright
    Dim As Integer Ndiv,N
    Dim As String Cdiv(2)
    Dim As String Cpar
    Dim As Single Valpar
    Dim As Byte B_found
    
    Print "File Fitpar.dat found."
    Print "Parameter values from file 'Fitpar.dat' are used as starting values."
    Print "To avoid this (and to keep the values of Parameters.bas), "
    Print "the file Fitpar.dat must be renamed or deleted."
    ' Reading optimum fit-parameter values from Fitpar.dat
    Dim As Integer F_Fitpar 
    F_Fitpar = Freefile
    Open "Fitpar.dat" for Input as #F_Fitpar
    Dim As Single Chisqr_Fit_stored
    DO Until EOF(F_Fitpar)
      Line Input #F_Fitpar,Cline 
' Print "FitparRead.bas: Line Input("+Cline
      #Include "ReadParameters.mac"
    Loop
    CLose F_Fitpar
  End Scope
End If
 
