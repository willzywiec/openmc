' Branchings for calculation of cumulative yields
Static As Integer Branching_first_call = 0
'Branching_first_call = Branching_first_call + 1

Branching_first_call = 1   ' Sonst vergisst GEF die Decay Table !!!

Printcontrol = 0
' Printcontrol = -1

Static As Single R_nu_delayed' multiplicity of delayed neutrons
R_nu_delayed = 0   ' reset  
Static As Single R_an ' multiplicity of anti-neutrinos
R_an = 0  ' reset

Scope
  Dim As Integer I,J,K,L

  For I = Lbound(NZIcumu,1) To Ubound(NZIcumu,1) 
    For J = Lbound(NZIcumu,2) To Ubound(NZIcumu,2)
      For K = Lbound(NZIcumu,3) To Ubound(NZIcumu,3)
        NZIcumu(I,J,K) = 0
      Next
    Next
  Next  

  If (B_Error_Analysis = 1 and I_Error = 0) Then  
     ' First passage of perturbed calculations 

    For I = Lbound(d_NZIcumu,2) To Ubound(d_NZIcumu,2)
      For J = Lbound(d_NZIcumu,3) To Ubound(d_NZIcumu,3)
        For K = Lbound(d_NZIcumu,4) To Ubound(d_NZIcumu,4)
          For L = Lbound(d_NZIcumu,1) To Ubound(d_NZIcumu,1)
            d_NZIcumu(L,I,J,K) = 0
          Next  
        Next  
      Next
    Next
  
  End If
End Scope


If Branching_first_call = 1 Then

  Scope
    Dim As Integer I_Branch = 0
    Dim As Single Rtot_beta,Rtot_beta_m,Rtot_beta_mm
    Dim As Single Rtot_beta_plus,Rtot_beta_plus_m,Rtot_beta_plus_mm
    Dim As Single beta_np,beta_2np
    Dim As Single t,r_unit
    Dim As String unit
    Dim As Integer I_m
    Dim As Single R_Dummy

    Dim As Integer I_Work
    Dim As Single R_Work
  
    Dim As Integer Alarm = -1


    Restore BranchTable

    Do
      Read I_Work
      If I_Work > 0 Then  ' negative I_Work denotes decays into isomers
        I_Branch = I_Branch + 1
      End If  
      BranchData(I_Branch).I_Z = Abs(I_Work)
  '    If BranchData(I_Branch).I_Z < 20 or BranchData(I_Branch).I_Z > 110 Then
  '      Print "<E> Error in branching table: Z , nmbr",I_Work, I_Branch
  '      Print "GEF stopped."
  '      Sleep
  '    End If
      Read BranchData(I_Branch).I_A
      Read BranchData(I_Branch).I_ISO
      If BranchData(I_Branch).I_ISO < 0 or BranchData(I_Branch).I_ISO > 9 Then
        Print "<E> Error in branching table: I_ISO, nmbr ",BranchData(I_Branch).I_ISO, I_Branch
        Print "GEF stopped."
        Sleep
      End If
  
      Read t
      Read unit
      
' Print I_work, I_Branch, BranchData(I_Branch).I_Z,BranchData(I_Branch).I_A,BranchData(I_Branch).I_ISO,t, unit            
  
      If I_Work > 0 Then
        I_m = 0

        Read Rtot_beta
        Rtot_beta = Rtot_beta * 0.01
  
        Read Rtot_beta_plus
        Rtot_beta_plus = Rtot_beta_plus * 0.01
      
        Read beta_np
        beta_np = beta_np * 0.01
      
        Read beta_2np
        beta_2np = beta_2np * 0.01
  
        If Rtot_beta > 0 Then
          BranchData(I_Branch).R_beta_n = beta_np
          BranchData(I_Branch).R_beta_2n = beta_2np
        End If  
      
        If Rtot_beta_plus > 0 Then
          BranchData(I_Branch).R_beta_p = beta_np
          BranchData(I_Branch).R_beta_2p = beta_2np
        End If   

        BranchData(I_Branch).R_beta = Rtot_beta - BranchData(I_Branch).R_beta_n _
                                              - BranchData(I_Branch).R_beta_2n
        BranchData(I_Branch).R_beta_plus = Rtot_beta_plus - BranchData(I_Branch).R_beta_p _
                                              - BranchData(I_Branch).R_beta_2p                                             
  
        Read BranchData(I_Branch).R_IT
        BranchData(I_Branch).R_IT = BranchData(I_Branch).R_IT * 0.01
       
        Read BranchData(I_Branch).R_alpha 
        BranchData(I_Branch).R_alpha = BranchData(I_Branch).R_alpha * 0.01
 
      Else
        I_m = I_m + 1
      
 '      If I_m = 1 Then
          Read Rtot_beta_m
          Rtot_beta_m = Rtot_beta_m * 0.01
  
          Read Rtot_beta_plus_m
          Rtot_beta_plus_m = Rtot_beta_plus_m * 0.01
  
          Read beta_np
          beta_np = beta_np * 0.01
      
          Read beta_2np
          beta_2np = beta_2np * 0.01
      
          If Rtot_beta_m > 0 Then
            BranchData(I_Branch).R_beta_n_m = beta_np
            BranchData(I_Branch).R_beta_2n_m = beta_2np
          End If
      
          If Rtot_beta_plus_m > 0 Then  
            BranchData(I_Branch).R_beta_p_m = beta_np
            BranchData(I_Branch).R_beta_2p_m = beta_2np
          End If

          BranchData(I_Branch).R_beta_m = Rtot_beta_m - BranchData(I_Branch).R_beta_n_m _
                                                    - BranchData(I_Branch).R_beta_2n_m
          BranchData(I_Branch).R_beta_plus_m = Rtot_beta_plus_m - BranchData(I_Branch).R_beta_p_m _
                                              - BranchData(I_Branch).R_beta_2p_m                                             
  
          Read BranchData(I_Branch).R_IT_m
          BranchData(I_Branch).R_IT_m = BranchData(I_Branch).R_IT_m * 0.01  
      
          Read BranchData(I_Branch).R_alpha_m 
          BranchData(I_Branch).R_alpha = BranchData(I_Branch).R_alpha_m * 0.01
  /'    End If
        If I_m = 2 Then
          Read Rtot_beta_mm
          Rtot_beta_mm = Rtot_beta_mm * 0.01
  
          Read Rtot_beta_plus_mm
          Rtot_beta_plus_mm = Rtot_beta_plus_mm * 0.01
  
          Read beta_np
          beta_np = beta_np * 0.01
      
          Read beta_2np
          beta_2np = beta_2np * 0.01
      
          If Rtot_beta_mm > 0 Then
            BranchData(I_Branch).R_beta_n_mm = beta_np
            BranchData(I_Branch).R_beta_2n_mm = beta_2np
          End If
      
          If Rtot_beta_plus_mm > 0 Then  
            BranchData(I_Branch).R_beta_p_mm = beta_np
            BranchData(I_Branch).R_beta_2p_mm = beta_2np
          End If

          BranchData(I_Branch).R_beta_mm = Rtot_beta_mm - BranchData(I_Branch).R_beta_n_mm _
                                                    - BranchData(I_Branch).R_beta_2n_mm
          BranchData(I_Branch).R_beta_plus_mm = Rtot_beta_plus_mm - BranchData(I_Branch).R_beta_p_mm _
                                                - BranchData(I_Branch).R_beta_2p_mm                                             
  
          Read BranchData(I_Branch).R_IT_mm
          BranchData(I_Branch).R_IT_mm = BranchData(I_Branch).R_IT_mm * 0.01  
      
          Read BranchData(I_Branch).R_alpha_mm 
          BranchData(I_Branch).R_alpha = BranchData(I_Branch).R_alpha_mm * 0.01
        End If '/
  
      End If  
  
      Select Case unit
        Case "ns"
          r_unit = 1.E-9
        Case "ms"
          r_unit = 1.E-3
        Case "s"
          r_unit = 1
        Case "min"
          r_unit = 60
        Case "h"
          r_unit = 3600
        Case "d"
          r_unit = 3600 * 24
        Case "y"
          r_unit = 3600 * 24 * 365.2422 
        Case "stable"
          r_unit = 1.E20  
        Case Else
          Print "Error in time unit ";unit;" ";I_Branch
          sleep      
      End Select
      BranchData(I_Branch).R_life = t * r_unit
  
'     print BranchData(I_Branch).I_Z,BranchData(I_Branch).I_A,BranchData(I_Branch).I_ISO, _
'          t, unit, Rtot_beta, BranchData(I_Branch).R_beta_n
        
'    If I Mod 4 = 0 Then Input "Continue",unit      
  
      If BranchData(I_Branch).I_Z = 88 and BranchData(I_Branch).I_A = 234 Then
        Alarm = 0
        Exit Do
      End If

    Loop
 '     Print "Number of nuclei in branch table: ";I_Branch

    If Alarm Then
      Print "Dimension of BranchData in DCLbranching too small!"
      Print "GEF stopped."
      Sleep
    End If

  End Scope

  Scope
    Dim As Integer IZ,IA
      ' Lower N limit at stability, eventually needed for cumulative yields
      ' Independent and cumulative yiels should be written for the same nuclei!
    Restore EndA:
    For IZ = 1 To 90
      Read IA
      INlast(IZ) = IA - IZ
    Next  
  End Scope  

End If   ' If Branching_first_call = 1 Then


If Printcontrol Then
  Print " "
  Print "*** Branchings 1"
  Print "Z=37, N=68 (105Rb) ind./cumu. ";NZPOST(68,37),NZIcumu(68,37,0),NZIcumu(68,37,1)
  Print "Z=38, N=67 (105Sr) ind./cumu. ";NZPOST(67,38),NZIcumu(67,38,0),NZIcumu(67,38,1)
  Print "Z=39, N=66 (105Y) ind./cumu. ";NZPOST(66,39),NZIcumu(66,39,0),NZIcumu(66,39,1)
  Print "Z=40, N=65 (105Zr) ind./cumu. ";NZPOST(65,40),NZIcumu(65,40,0),NZIcumu(65,40,1)
  Print "Z=41, N=64 (105Nb) ind./cumu. ";NZPOST(64,41),NZIcumu(64,41,0),NZIcumu(64,41,1)
  Print "Z=42, N=63 (105Mo) ind./cumu. ";NZPOST(63,42),NZIcumu(63,42,0),NZIcumu(63,42,1)
  Print "Z=43, N=62 (105Tc) ind./cumu. ";NZPOST(62,43),NZIcumu(62,43,0),NZIcumu(62,43,1)
  Print "Z=44, N=61 (105Ru) ind./cumu. ";NZPOST(61,44),NZIcumu(61,44,0),NZIcumu(61,44,1)
  Print "Z=45, N=60 (105Rb) ind./cumu. ";NZPOST(60,45),NZIcumu(60,45,0),NZIcumu(60,45,1)
  Print "Z=46, N=59 (105Pd) ind./cumu. ";NZPOST(59,46),NZIcumu(59,46,0),NZIcumu(59,46,1)
  Print "Z=47, N=58 (105Ag) ind./cumu. ";NZPOST(58,47),NZIcumu(58,47,0),NZIcumu(58,47,1)
  Print "Z=48, N=57 (105Cd) ind./cumu. ";NZPOST(57,48),NZIcumu(57,48,0),NZIcumu(57,48,1)
End If


' Sort direct production into NZIcumu
Scope

  Dim As Integer IZ,IN,StNmbr,Iso,Nisotab,BrNmbr,Iori
  Dim As Single Yiso,Ygs,Ybeta,Ybetan,d_Yiso
  Dim As Single Radd
  Dim As Single Rcheck
  
  For IN = 10 To 190
    For IZ = 10 To 90
      If NZPOST(IN,IZ) > 0 Then
        Nisotab = ISO_for_ZA(IZ,IZ+IN) ' number in array Isotab
        If Nisotab > 0 Then 
          StNmbr = Isotab(Nisotab).N_STATES
          For Iso = 1 To StNmbr
            ' Yield values are copied from NZPOST (with isomer index) into NZIcumu
            Radd = NZPOST(IN,IZ) * Isotab(Nisotab).R_Prob(Iso)
            Iori = Isotab(Nisotab).I_ISO(Iso) ' Iori sorted acc. to energy
            If Iori <= Ubound(NZIcumu,3) Then
              NZIcumu(IN,IZ,Iori) = NZIcumu(IN,IZ,Iori) + Radd
            Else
              Print "<W> Population of isomer nmbr. ";Iori;" of Z,A = ";Z;IN+IZ;" not supported."
            End If  
          Next
        Else  ' Nucleus is not in Isostab table -> put yield directly into ground state
          Radd = NZPOST(IN,IZ)
          NZIcumu(IN,IZ,0) = NZIcumu(IN,IZ,0) + Radd
        End If
      End If
    Next
  Next

End Scope

If Printcontrol Then
  Print "*** Branchings 2"
  Print "Z=37, N=68 (105Rb) ind./cumu. ";NZPOST(68,37),NZIcumu(68,37,0),NZIcumu(68,37,1)
  Print "Z=38, N=67 (105Sr) ind./cumu. ";NZPOST(67,38),NZIcumu(67,38,0),NZIcumu(67,38,1)
  Print "Z=39, N=66 (105Y) ind./cumu. ";NZPOST(66,39),NZIcumu(66,39,0),NZIcumu(66,39,1)
  Print "Z=40, N=65 (105Zr) ind./cumu. ";NZPOST(65,40),NZIcumu(65,40,0),NZIcumu(65,40,1)
  Print "Z=41, N=64 (105Nb) ind./cumu. ";NZPOST(64,41),NZIcumu(64,41,0),NZIcumu(64,41,1)
  Print "Z=42, N=63 (105Mo) ind./cumu. ";NZPOST(63,42),NZIcumu(63,42,0),NZIcumu(63,42,1)
  Print "Z=43, N=62 (105Tc) ind./cumu. ";NZPOST(62,43),NZIcumu(62,43,0),NZIcumu(62,43,1)
  Print "Z=44, N=61 (105Ru) ind./cumu. ";NZPOST(61,44),NZIcumu(61,44,0),NZIcumu(61,44,1)
  Print "Z=45, N=60 (105Rb) ind./cumu. ";NZPOST(60,45),NZIcumu(60,45,0),NZIcumu(60,45,1)
  Print "Z=46, N=59 (105Pd) ind./cumu. ";NZPOST(59,46),NZIcumu(59,46,0),NZIcumu(59,46,1)
  Print "Z=47, N=58 (105Ag) ind./cumu. ";NZPOST(58,47),NZIcumu(58,47,0),NZIcumu(58,47,1)
  Print "Z=48, N=57 (105Cd) ind./cumu. ";NZPOST(57,48),NZIcumu(57,48,0),NZIcumu(57,48,1)
End If

Dim As Integer Print_an = 0
If B_Error_Analysis = 0 Then 
  Print_an = 1
'  Print "*** anti-neutrinos ***"
'  Print " Z     N_anti-neutrinos    A    N  Q_beta_gg  decay"
'  For I = 1 To I_out_an
'    Print C_out_an(I_out_an)
'  Next I
Else
  Print_an = 0  
End If
'I_out_an = 0
'Redim C_out_an(1)

Print #f,"  <Delayed>" 
    
Print #f,"    <dn_emitters>"
Print #f,"--------------------------------"
Print #f,"--- Delayed-neutron emitters ---"
Print #f,"--------------------------------"
Print #f," "
Print #f," Pn            Z             A             decay"
Print #f," "
Print #f,"(Pn is the average number of delayed neutrons per fission from the listed decay.)"
Print #f," "

' follow decay path in steps of N-Z
Scope
  Dim As Integer NminusZ,IZ,IN,BrNmbr
  Dim As Single Radd
  Dim As Single Rcheck

  For NminusZ = 100 To 0 Step -1
    For IZ = 90 To 10 Step -1
      IN = IZ + NminusZ
      ' 3. isomeric state
      If NZIcumu(IN,IZ,3) > 0 Then
        BrNmbr = Ibranch_for_ZAI(IZ,IZ+IN,3) 
        If BrNmbr > 0 Then
          If BranchData(BrNmbr).R_life < 3.15E13 Then
            If IN > INlast(IZ) Then
              'alpha_m decay
              Radd = NZIcumu(IN,IZ,3) * BranchData(BrNmbr).R_alpha_m
              NZIcumu(IN-2,IZ-2,2) = NZIcumu(IN-2,IZ-2,2) + Radd
              'alpha decay
              Radd = NZIcumu(IN,IZ,3) * BranchData(BrNmbr).R_alpha
              NZIcumu(IN-2,IZ-2,0) = NZIcumu(IN-2,IZ-2,0) + Radd
                   
              'IT_m decay
              Radd =  NZIcumu(IN,IZ,3) * BranchData(BrNmbr).R_IT_m
              NZIcumu(IN,IZ,2) = NZIcumu(IN,IZ,2) + Radd
              'IT decay
              Radd = NZIcumu(IN,IZ,3) * BranchData(BrNmbr).R_IT 
              NZIcumu(IN,IZ,0) = NZIcumu(IN,IZ,0) + Radd
            End If       
            ' beta_mm decay
            Radd = NZIcumu(IN,IZ,3) * BranchData(BrNmbr).R_beta_mm  
            R_an = R_an + Radd
            NZIcumu(IN-1,IZ+1,3) = NZIcumu(IN-1,IZ+1,3) + Radd
            If Print_an Then U_Print_an(IZ,IN,Radd,"3rd isomer, beta_mm")
            ' beta_m decay
            Radd = NZIcumu(IN,IZ,3) * BranchData(BrNmbr).R_beta_m
            NZIcumu(IN-1,IZ+1,2) = NZIcumu(IN-1,IZ+1,2) + Radd
            R_an = R_an + Radd
            If Print_an Then U_Print_an(IZ,IN,Radd,"3rd isomer, beta_m")
            ' beta decay
            Radd = NZIcumu(IN,IZ,3) * BranchData(BrNmbr).R_beta  
            NZIcumu(IN-1,IZ+1,0) = NZIcumu(IN-1,IZ+1,0) + Radd
            R_an = R_an + Radd
            If Print_an Then U_Print_an(IZ,IN,Radd,"3d isomer, beta")
            ' beta_n_m decay
            Radd = NZIcumu(IN,IZ,3) * BranchData(BrNmbr).R_beta_n_m  
            NZIcumu(IN-2,IZ+1,2) = NZIcumu(IN-2,IZ+1,2) + Radd
            If Radd > 0 Then
              R_nu_delayed = R_nu_delayed + Radd
              Print #f,Radd,IZ,IZ+IN,"2nd isomer - beta_n_m "
              R_an = R_an + Radd
            End If  
            If Print_an Then U_Print_an(IZ,IN,Radd,"3rd isomer, beta_n_m")
            ' beta_n decay    
            Radd = NZIcumu(IN,IZ,3) * BranchData(BrNmbr).R_beta_n  
            NZIcumu(IN-2,IZ+1,0) = NZIcumu(IN-2,IZ+1,0) + Radd
            If Radd > 0 Then
              R_nu_delayed = R_nu_delayed + Radd
              Print #f,Radd,IZ,IZ+IN,"3rd isomer - beta_n "
              R_an = R_an + Radd
            End If  
            If Print_an Then U_Print_an(IZ,IN,Radd,"3rd isomer, beta_n")
            ' beta_2n_m decay
            Radd = NZIcumu(IN,IZ,3) * BranchData(BrNmbr).R_beta_2n_m 
            NZIcumu(IN-3,IZ+1,2) = NZIcumu(IN-3,IZ+1,2) + Radd
            If Radd > 0 Then
              R_nu_delayed = R_nu_delayed + 2*Radd
              Print #f,2*Radd,IZ,IZ+IN,"3nd isomer - beta_2n_m "
              R_an = R_an + Radd
            End If  
            If Print_an Then U_Print_an(IZ,IN,Radd,"3rd isomer, beta_2n_m")
            ' beta_2n decay    
            Radd = NZIcumu(IN,IZ,3) * BranchData(BrNmbr).R_beta_2n 
            NZIcumu(IN-3,IZ+1,0) = NZIcumu(IN-3,IZ+1,0) + Radd
            If Radd > 0 Then
              R_nu_delayed = R_nu_delayed + 2*Radd
              Print #f,2*Radd,IZ,IZ+IN,"3rd isomer - beta_2n"
              R_an = R_an + Radd
            End If  
            If Print_an Then U_Print_an(IZ,IN,Radd,"3rd isomer, beta_2n")
          End If
        Else
          If Printcontrol Then
            Print "Missing in BranchData: 3nd isomer of Z,A ";IZ;" ";IZ+IN;", IT assumed"
          End If  
          'IT
          Radd = NZIcumu(IN,IZ,2)
          NZIcumu(IN,IZ,0) = NZIcumu(IN,IZ,0) + Radd 
        End If  
      End If
      
      ' 2. isomeric state
      If NZIcumu(IN,IZ,2) > 0 Then
        BrNmbr = Ibranch_for_ZAI(IZ,IZ+IN,2) 
        If BrNmbr > 0 Then
          If BranchData(BrNmbr).R_life < 3.15E13 Then
            If IN > INlast(IZ) Then
              'alpha_m decay
              Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_alpha_m
              NZIcumu(IN-2,IZ-2,1) = NZIcumu(IN-2,IZ-2,1) + Radd
              'alpha decay
              Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_alpha
              NZIcumu(IN-2,IZ-2,0) = NZIcumu(IN-2,IZ-2,0) + Radd
                   
              'IT_m decay
              Radd =  NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_IT_m
              NZIcumu(IN,IZ,1) = NZIcumu(IN,IZ,1) + Radd
              'IT decay
              Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_IT 
              NZIcumu(IN,IZ,0) = NZIcumu(IN,IZ,0) + Radd
            End If       
            ' beta_mm decay
            Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_beta_mm  
            R_an = R_an + Radd
            NZIcumu(IN-1,IZ+1,2) = NZIcumu(IN-1,IZ+1,2) + Radd
            If Print_an Then U_Print_an(IZ,IN,Radd,"2nd isomer, beta_mm")
            ' beta_m decay
            Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_beta_m
            NZIcumu(IN-1,IZ+1,1) = NZIcumu(IN-1,IZ+1,1) + Radd
            R_an = R_an + Radd
            If Print_an Then U_Print_an(IZ,IN,Radd,"2nd isomer, beta_m")
            ' beta decay
            Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_beta  
            NZIcumu(IN-1,IZ+1,0) = NZIcumu(IN-1,IZ+1,0) + Radd
            R_an = R_an + Radd
            If Print_an Then U_Print_an(IZ,IN,Radd,"2nd isomer, beta")
            ' beta_n_m decay
            Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_beta_n_m  
            NZIcumu(IN-2,IZ+1,1) = NZIcumu(IN-2,IZ+1,1) + Radd
            If Radd > 0 Then
              R_nu_delayed = R_nu_delayed + Radd
              Print #f,Radd,IZ,IZ+IN,"2nd isomer - beta_n_m "
              R_an = R_an + Radd
            End If  
            If Print_an Then U_Print_an(IZ,IN,Radd,"2nd isomer, beta_n_m")
            ' beta_n decay    
            Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_beta_n  
            NZIcumu(IN-2,IZ+1,0) = NZIcumu(IN-2,IZ+1,0) + Radd
            If Radd > 0 Then
              R_nu_delayed = R_nu_delayed + Radd
              Print #f,Radd,IZ,IZ+IN,"2nd isomer - beta_n "
              R_an = R_an + Radd
            End If  
            If Print_an Then U_Print_an(IZ,IN,Radd,"2nd isomer, beta_n")
            ' beta_2n_m decay
            Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_beta_2n_m 
            NZIcumu(IN-3,IZ+1,1) = NZIcumu(IN-3,IZ+1,1) + Radd
            If Radd > 0 Then
              R_nu_delayed = R_nu_delayed + 2*Radd
              Print #f,2*Radd,IZ,IZ+IN,"2nd isomer - beta_2n_m "
              R_an = R_an + Radd
            End If  
            If Print_an Then U_Print_an(IZ,IN,Radd,"2nd isomer, beta_2n_m")
            ' beta_2n decay    
            Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_beta_2n 
            NZIcumu(IN-3,IZ+1,0) = NZIcumu(IN-3,IZ+1,0) + Radd
            If Radd > 0 Then
              R_nu_delayed = R_nu_delayed + 2*Radd
              Print #f,2*Radd,IZ,IZ+IN,"2nd isomer - beta_2n"
              R_an = R_an + Radd
            End If  
            If Print_an Then U_Print_an(IZ,IN,Radd,"2nd isomer, beta_2n")
          End If
        Else
          If Printcontrol Then
            Print "Missing in BranchData: 2nd isomer of Z,A ";IZ;" ";IZ+IN;", IT assumed"
          End If  
          'IT
          Radd = NZIcumu(IN,IZ,2)
          NZIcumu(IN,IZ,0) = NZIcumu(IN,IZ,0) + Radd 
        End If  
      End If
      

      ' 1. isomeric state
      If NZIcumu(IN,IZ,1) > 0 Then
        BrNmbr = Ibranch_for_ZAI(IZ,IZ+IN,1) 
        If BrNmbr > 0 Then
          If BranchData(BrNmbr).R_life < 3.15E13 Then
            If IN > INlast(IZ) Then
              'alpha_m decay
              Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_alpha_m
              NZIcumu(IN-2,IZ-2,1) = NZIcumu(IN-2,IZ-2,1) + Radd
              'alpha decay
              Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_alpha
              NZIcumu(IN-2,IZ-2,0) = NZIcumu(IN-2,IZ-2,0) + Radd
              ' IT decay
              Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_IT
              NZIcumu(IN,IZ,0) = NZIcumu(IN,IZ,0) + Radd
            End If       
            ' beta_mm decay
            Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_beta_mm
            NZIcumu(IN-1,IZ+1,2) = NZIcumu(IN-1,IZ+1,2) + Radd
            R_an = R_an + Radd
            If Print_an Then U_Print_an(IZ,IN,Radd,"1st isomer, beta_mm")
            ' beta_m decay
            Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_beta_m 
            NZIcumu(IN-1,IZ+1,1) = NZIcumu(IN-1,IZ+1,1) + Radd
            R_an = R_an + Radd
            If Print_an Then U_Print_an(IZ,IN,Radd,"1st isomer, beta_m")
            ' beta decay
            Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_beta 
            NZIcumu(IN-1,IZ+1,0) = NZIcumu(IN-1,IZ+1,0) + Radd
            R_an = R_an + Radd
            If Print_an Then U_Print_an(IZ,IN,Radd,"1st isomer, beta")
            ' beta_n_m decay
            Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_beta_n_m  
            NZIcumu(IN-2,IZ+1,1) = NZIcumu(IN-2,IZ+1,1) + Radd
            If Radd > 0 Then
              R_nu_delayed = R_nu_delayed + Radd
              Print #f,Radd,IZ,IZ+IN,"1st isomer - beta_n_m"
              R_an = R_an + Radd
            End If  
            If Print_an Then U_Print_an(IZ,IN,Radd,"1st isomer, beta_n_m")
            ' beta_n decay    
            Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_beta_n
            NZIcumu(IN-2,IZ+1,0) = NZIcumu(IN-2,IZ+1,0) + Radd
            If Radd > 0 Then
              R_nu_delayed = R_nu_delayed + Radd
              Print #f,Radd,IZ,IZ+IN,"1st isomer - beta_n"
              R_an = R_an + Radd
            End If
            If Print_an Then U_Print_an(IZ,IN,Radd,"1st isomer, beta_n")
            ' beta_2n_m decay
            Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_beta_2n_m  
            NZIcumu(IN-3,IZ+1,1) = NZIcumu(IN-3,IZ+1,1) + Radd
            If Radd > 0 Then
              R_nu_delayed = R_nu_delayed + 2*Radd
              Print #f, Radd,IZ,IZ+IN,"1st isomer - beta_2n_m"
              R_an = R_an + Radd
            End If  
            If Print_an Then U_Print_an(IZ,IN,Radd,"1st isomer, beta_2n_m")
            ' beta_2n decay
            Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_beta_2n      
            NZIcumu(IN-3,IZ+1,0) = NZIcumu(IN-3,IZ+1,0) + Radd
            If Radd > 0 Then
              R_nu_delayed = R_nu_delayed + 2*Radd
              Print #f,2*Radd,IZ,IZ+IN,"1st isomer - beta_2n"
              R_an = R_an + Radd
            End If  
            If Print_an Then U_Print_an(IZ,IN,Radd,"1st isomer, beta_2n")
          End If         
        Else
          If Printcontrol Then
            Print "Missing in BranchData: 1st isomer of Z,A ";IZ;" ";IZ+IN;", IT assumed"
          End If  
          'IT
          Radd = NZIcumu(IN,IZ,1)
          NZIcumu(IN,IZ,0) = NZIcumu(IN,IZ,0) + Radd       
        End If  
      End If

    
      ' ground state
      If NZIcumu(IN,IZ,0) > 0 Then
        BrNmbr = Ibranch_for_ZAI(IZ,IZ+IN,0) 
        If BrNmbr > 0 Then
          If BranchData(BrNmbr).R_life < 3.15E13 Then
            If IN > INlast(IZ) Then
              'alpha_m decay
              Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_alpha_m
              NZIcumu(IN-2,IZ-2,1) = NZIcumu(IN-2,IZ-2,1) + Radd
              'alpha decay
              Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_alpha
              NZIcumu(IN-2,IZ-2,0) = NZIcumu(IN-2,IZ-2,0) + Radd
            End If
            ' beta_mm decay
            Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_beta_mm 
            NZIcumu(IN-1,IZ+1,2) = NZIcumu(IN-1,IZ+1,2) + Radd
            R_an = R_an + Radd
            If Print_an Then U_Print_an(IZ,IN,Radd,"gs, beta_mm")
            ' beta_m decay
            Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_beta_m 
            NZIcumu(IN-1,IZ+1,1) = NZIcumu(IN-1,IZ+1,1) + Radd
            R_an = R_an + Radd
            If Print_an Then U_Print_an(IZ,IN,Radd,"gs, beta_m")
            ' beta decay
            Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_beta
            NZIcumu(IN-1,IZ+1,0) = NZIcumu(IN-1,IZ+1,0) + Radd
            R_an = R_an + Radd
            If Print_an Then U_Print_an(IZ,IN,Radd,"gs, beta")
            ' beta_n_m decay
            Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_beta_n_m
            NZIcumu(IN-2,IZ+1,1) = NZIcumu(IN-2,IZ+1,1) + Radd
            If Radd > 0 Then
              R_nu_delayed = R_nu_delayed + Radd
              Print #f,Radd,IZ,IZ+IN,"ground state - beta_n_m"
              R_an = R_an + Radd
            End If  
            If Print_an Then U_Print_an(IZ,IN,Radd,"gs, beta_n_m")
            ' beta_n decay 
            Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_beta_n   
            NZIcumu(IN-2,IZ+1,0) = NZIcumu(IN-2,IZ+1,0) + Radd
            If Radd > 0 Then
              R_nu_delayed = R_nu_delayed + Radd
              Print #f,Radd,IZ,IZ+IN,"ground state - beta_n"
              R_an = R_an + Radd
            End If  
            If Print_an Then U_Print_an(IZ,IN,Radd,"gs, beta_n")
            ' beta_2n_m decay
            Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_beta_2n_m  
            NZIcumu(IN-3,IZ+1,1) = NZIcumu(IN-3,IZ+1,1) + Radd
            If Radd > 0 Then
              R_nu_delayed = R_nu_delayed + 2*Radd
              Print #f,2*Radd,IZ,IZ+IN,"ground state - beta_2n_m"
              R_an = R_an + Radd
            End If  
            If Print_an Then U_Print_an(IZ,IN,Radd,"gs, beta_2n_m")
            ' beta_2n decay
            Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_beta_2n 
            NZIcumu(IN-3,IZ+1,0) = NZIcumu(IN-3,IZ+1,0) + Radd
            If Radd > 0 Then
              R_nu_delayed = R_nu_delayed + 2*Radd
              Print #f,2*Radd,IZ,IZ+IN,"ground state - beta_2n"
              R_an = R_an + Radd
            End If
            If Print_an Then U_Print_an(IZ,IN,Radd,"gs, beta_2n")
          End If
        End If  
       

'       If BrNmbr = -2 Then  ' isotope is very neutron-rich -> beta-minus decay assumed
        If U_Q_beta_minus(IZ,IN+IZ) > 0 And BrNmbr = -2 Then
          If Printcontrol Then
            Print "blind beta-minus for ", IZ,IN+IZ
          End If       
          ' beta minus_decay
          Radd = NZIcumu(IN,IZ,0)
          NZIcumu(IN-1,IZ+1,0) = NZIcumu(IN-1,IZ+1,0) + Radd
          R_an = R_an + Radd
        End If     

      End If
      
      
    Next  ' IZ
  Next  ' NminusZ  

  If Printcontrol Then
    Print "*** Branchings 3"
    Print "Z=37, N=68 (105Rb) ind./cumu. ";NZPOST(68,37),NZIcumu(68,37,0),NZIcumu(68,37,1)
    Print "Z=38, N=67 (105Sr) ind./cumu. ";NZPOST(67,38),NZIcumu(67,38,0),NZIcumu(67,38,1)
    Print "Z=39, N=66 (105Y) ind./cumu. ";NZPOST(66,39),NZIcumu(66,39,0),NZIcumu(66,39,1)
    Print "Z=40, N=65 (105Zr) ind./cumu. ";NZPOST(65,40),NZIcumu(65,40,0),NZIcumu(65,40,1)
    Print "Z=41, N=64 (105Nb) ind./cumu. ";NZPOST(64,41),NZIcumu(64,41,0),NZIcumu(64,41,1)
    Print "Z=42, N=63 (105Mo) ind./cumu. ";NZPOST(63,42),NZIcumu(63,42,0),NZIcumu(63,42,1)
    Print "Z=43, N=62 (105Tc) ind./cumu. ";NZPOST(62,43),NZIcumu(62,43,0),NZIcumu(62,43,1)
    Print "Z=44, N=61 (105Ru) ind./cumu. ";NZPOST(61,44),NZIcumu(61,44,0),NZIcumu(61,44,1)
    Print "Z=45, N=60 (105Rb) ind./cumu. ";NZPOST(60,45),NZIcumu(60,45,0),NZIcumu(60,45,1)
    Print "Z=46, N=59 (105Pd) ind./cumu. ";NZPOST(59,46),NZIcumu(59,46,0),NZIcumu(59,46,1)
    Print "Z=47, N=58 (105Ag) ind./cumu. ";NZPOST(58,47),NZIcumu(58,47,0),NZIcumu(58,47,1)
    Print "Z=48, N=57 (105Cd) ind./cumu. ";NZPOST(57,48),NZIcumu(57,48,0),NZIcumu(57,48,1)
  End If


  For NminusZ = 0 To 100 Step 1
    For IZ = 90 To 10 Step -1
      IN = IZ + NminusZ
    
      
      ' 2. isomeric state
      If NZIcumu(IN,IZ,2) > 0 Then
        BrNmbr = Ibranch_for_ZAI(IZ,IZ+IN,2) 
        If BrNmbr > 0 Then
          If BranchData(BrNmbr).R_life < 3.15E13 Then
            If IN <= INLast(IZ) Then
              'alpha_m decay
              Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_alpha_m
              NZIcumu(IN-2,IZ-2,1) = NZIcumu(IN-2,IZ-2,1) + Radd
              'alpha decay
              Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_alpha
              NZIcumu(IN-2,IZ-2,0) = NZIcumu(IN-2,IZ-2,0) + Radd
              'IT_m decay
              Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_IT_m 
              NZIcumu(IN,IZ,1) = NZIcumu(IN,IZ,1) + Radd
              'IT decay
              Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_IT
              NZIcumu(IN,IZ,0) = NZIcumu(IN,IZ,0) + Radd
            End If
            ' beta_plus_mm decay
            Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_beta_plus_mm 
            NZIcumu(IN+1,IZ-1,2) = NZIcumu(IN+1,IZ-1,2) + Radd
            ' beta_plus_m decay
            Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_beta_plus_m 
            NZIcumu(IN+1,IZ-1,1) = NZIcumu(IN+1,IZ-1,1) + Radd
            ' beta plus_decay
            Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_beta_plus 
            NZIcumu(IN+1,IZ-1,0) = NZIcumu(IN+1,IZ-1,0) + Radd
            ' beta_p_m decay
            Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_beta_p_m 
            NZIcumu(IN+1,IZ-2,1) = NZIcumu(IN+1,IZ-2,1) + Radd
            ' beta_p decay    
            Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_beta_p  
            NZIcumu(IN+1,IZ-2,0) = NZIcumu(IN+1,IZ-2,0) + Radd
            ' beta_2p_m decay
            Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_beta_2p_m 
            NZIcumu(IN+1,IZ-3,1) = NZIcumu(IN+1,IZ-3,1) + Radd
            ' beta_2p decay    
            Radd = NZIcumu(IN,IZ,2) * BranchData(BrNmbr).R_beta_2p
            NZIcumu(IN+1,IZ-3,0) = NZIcumu(IN+1,IZ-3,0) + Radd
          End If
        End If
      End If        
    
      ' 1. isomeric state
      If NZIcumu(IN,IZ,1) > 0 Then
        BrNmbr = Ibranch_for_ZAI(IZ,IZ+IN,1) 
        If BrNmbr > 0 Then
          If BranchData(BrNmbr).R_life < 3.15E13 Then
            If IN <= INlast(IZ) Then
              'alpha_m decay
              Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_alpha_m
              NZIcumu(IN-2,IZ-2,1) = NZIcumu(IN-2,IZ-2,1) + Radd
              'alpha decay
              Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_alpha
              NZIcumu(IN-2,IZ-2,0) = NZIcumu(IN-2,IZ-2,0) + Radd
              ' IT decay
              Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_IT
              NZIcumu(IN,IZ,0) = NZIcumu(IN,IZ,0) + Radd
            End If
            ' beta_plus_mm decay
            Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_beta_plus_mm
            NZIcumu(IN+1,IZ-1,2) = NZIcumu(IN+1,IZ-1,2) + Radd
            ' beta_plus_m decay
            Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_beta_plus_m
            NZIcumu(IN+1,IZ-1,1) = NZIcumu(IN+1,IZ-1,1) + Radd
            ' beta plus_decay
            Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_beta_plus
            NZIcumu(IN+1,IZ-1,0) = NZIcumu(IN+1,IZ-1,0) + Radd
            ' beta_p_m decay
            Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_beta_p_m
            NZIcumu(IN+1,IZ-2,1) = NZIcumu(IN+1,IZ-2,1) + Radd
            ' beta_p decay    
            Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_beta_p            
            NZIcumu(IN+1,IZ-2,0) = NZIcumu(IN+1,IZ-2,0) + Radd
            ' beta_2p_m decay
            Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_beta_2p_m
            NZIcumu(IN+1,IZ-3,1) = NZIcumu(IN+1,IZ-3,1) + Radd
            ' beta_2p decay
            Radd = NZIcumu(IN,IZ,1) * BranchData(BrNmbr).R_beta_2p    
            NZIcumu(IN+1,IZ-3,0) = NZIcumu(IN+1,IZ-3,0) + Radd
          End If
        End If
      End If        
    
      ' ground state 
      If NZIcumu(IN,IZ,0) > 0 Then
        BrNmbr = Ibranch_for_ZAI(IZ,IZ+IN,0) 
        If BrNmbr > 0 Then
          If BranchData(BrNmbr).R_life < 3.15E13 Then
            If IN <= INlast(IZ) Then
              'alpha_m decay
              Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_alpha_m
              NZIcumu(IN-2,IZ-2,1) = NZIcumu(IN-2,IZ-2,1) + Radd
              'alpha decay
              Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_alpha
              NZIcumu(IN-2,IZ-2,0) = NZIcumu(IN-2,IZ-2,0) + Radd
            End If               
            ' beta_plus_mm decay
            Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_beta_plus_mm
            NZIcumu(IN+1,IZ-1,2) = NZIcumu(IN+1,IZ-1,2) + Radd
            ' beta_plus_m decay
            Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_beta_plus_m
            NZIcumu(IN+1,IZ-1,1) = NZIcumu(IN+1,IZ-1,1) + Radd
            ' beta plus_decay
            Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_beta_plus
            NZIcumu(IN+1,IZ-1,0) = NZIcumu(IN+1,IZ-1,0) + Radd
            ' beta_p_m decay
            Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_beta_p_m
            NZIcumu(IN+1,IZ-2,1) = NZIcumu(IN+1,IZ-2,1) + Radd
            ' beta_p decay
            Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_beta_p    
            NZIcumu(IN+1,IZ-2,0) = NZIcumu(IN+1,IZ-2,0) + Radd
            ' beta_2p_m decay
            Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_beta_2p_m
            NZIcumu(IN+1,IZ-3,1) = NZIcumu(IN+1,IZ-3,1) + Radd
            ' beta_2p decay    
            Radd = NZIcumu(IN,IZ,0) * BranchData(BrNmbr).R_beta_2p
            NZIcumu(IN+1,IZ-3,0) = NZIcumu(IN+1,IZ-3,0) + Radd
          End If
        End If
        If BrNmbr = -1 Then  ' isotope is very neutron-deficient -> beta-plus decay assumed
          If Printcontrol Then
            Print "blind beta-plus for ", IZ,IN+IZ
          End If       
          ' beta plus_decay
          Radd = NZIcumu(IN,IZ,0)
          NZIcumu(IN+1,IZ-1,0) = NZIcumu(IN+1,IZ-1,0) + Radd
        End If
      End If        
    
    Next IZ
  Next NminusZ  
  

  If Printcontrol Then
    Print "*** Branchings 4"
    Print "Z=37, N=68 (105Rb) ind./cumu. ";NZPOST(68,37),NZIcumu(68,37,0),NZIcumu(68,37,1)
    Print "Z=38, N=67 (105Sr) ind./cumu. ";NZPOST(67,38),NZIcumu(67,38,0),NZIcumu(67,38,1)
    Print "Z=39, N=66 (105Y) ind./cumu. ";NZPOST(66,39),NZIcumu(66,39,0),NZIcumu(66,39,1)
    Print "Z=40, N=65 (105Zr) ind./cumu. ";NZPOST(65,40),NZIcumu(65,40,0),NZIcumu(65,40,1)
    Print "Z=41, N=64 (105Nb) ind./cumu. ";NZPOST(64,41),NZIcumu(64,41,0),NZIcumu(64,41,1)
    Print "Z=42, N=63 (105Mo) ind./cumu. ";NZPOST(63,42),NZIcumu(63,42,0),NZIcumu(63,42,1)
    Print "Z=43, N=62 (105Tc) ind./cumu. ";NZPOST(62,43),NZIcumu(62,43,0),NZIcumu(62,43,1)
    Print "Z=44, N=61 (105Ru) ind./cumu. ";NZPOST(61,44),NZIcumu(61,44,0),NZIcumu(61,44,1)
    Print "Z=45, N=60 (105Rb) ind./cumu. ";NZPOST(60,45),NZIcumu(60,45,0),NZIcumu(60,45,1)
    Print "Z=46, N=59 (105Pd) ind./cumu. ";NZPOST(59,46),NZIcumu(59,46,0),NZIcumu(59,46,1)
    Print "Z=47, N=58 (105Ag) ind./cumu. ";NZPOST(58,47),NZIcumu(58,47,0),NZIcumu(58,47,1)
    Print "Z=48, N=57 (105Cd) ind./cumu. ";NZPOST(57,48),NZIcumu(57,48,0),NZIcumu(57,48,1)
  End If
End Scope
 
  Scope
    Dim As Integer IN,IZ,Iori
    For IN = 10 To 190
      For IZ = 10 To 90
        For Iori = 0 To 2
          d_NZIcumu(1,IN,IZ,Iori) = d_NZIcumu(1,IN,IZ,Iori) + NZIcumu(IN,IZ,Iori)
          d_NZIcumu(2,IN,IZ,Iori) = d_NZIcumu(2,IN,IZ,Iori) + NZIcumu(IN,IZ,Iori)^2
        Next Iori
      Next IZ
    Next IN    
    d_R_nu_delayed(1) = d_R_nu_delayed(1) + R_nu_delayed
    d_R_nu_delayed(2) = d_R_nu_delayed(2) + R_nu_delayed^2
  End Scope 
 
 
If B_Error_Analysis = 1 And I_Error + 1 = N_Error_Max Then
  ' Last passage of perturbed calculations

  Scope
    Dim As Integer IN,IZ,Iori
    For IN = 10 To 190
      For IZ = 10 To 90
        For Iori = 0 To 2
        
     '   Print NZIcumu(IN,IZ,Iori),d_NZIcumu(1,IN,IZ,Iori),d_NZIcumu(2,IN,IZ,Iori)
        
           If d_NZIcumu(1,IN,IZ,Iori) > 0 Then
             d_NZIcumu(0,IN,IZ,Iori) = sqr ( (d_NZIcumu(2,IN,IZ,Iori) - _
                                  d_NZIcumu(1,IN,IZ,Iori)^2/N_Error_Max ) / (N_Error_Max-1.0) )
           Else
             d_NZIcumu(0,IN,IZ,Iori) = NZIcumu(IN,IZ,Iori)                       
           End If
           If d_NZIcumu(0,IN,IZ,Iori) > NZIcumu(IN,IZ,Iori) Or d_NZIcumu(0,IN,IZ,Iori) = 0 Then 
              d_NZIcumu(0,IN,IZ,Iori) = NZIcumu(IN,IZ,Iori)
           End If           
        Next Iori
      Next IZ
    Next IN  
    If d_R_nu_delayed(1) > 0 Then
      d_R_nu_delayed(0) = sqr ( (d_R_nu_delayed(2) - _
                             d_R_nu_delayed(1)^2/N_Error_Max ) / (N_Error_Max-1.0) )
    Else
      d_R_nu_delayed(0) = R_nu_delayed                       
    End If
    
  End Scope

End If  


Scope
  Dim As Integer IN,IZ,IA,IA_last,Iori
 
  Print #f,"    </dn_emitters>"
  Print #f,"    <nu_delayed>"
  Print #f," "
    

  If B_Error_On = 1 And B_Error_Analysis = 0 Then
    Print #f,"Multiplicity of delayed neutrons per fission: "; Csng(R_nu_delayed * 0.01);" +-";_
           Csng(d_R_nu_delayed(0) * 0.01)
    For I = 0 To 2
     d_R_nu_delayed(I) = 0
    Next I
    Print #f,"(The given uncertainty does not include uncertainties of decay data.)"       
  Else
    Print #f,"Multiplicity of delayed neutrons per fission: ";Csng(R_nu_delayed * 0.01)
  End If
  
  Print #f," "
  Print #f,"    </nu_delayed>"

  Print #f,"    <anti_neutrinos>"
  Print #f,"------------------------------------"
  Print #f,"--- Production of anti-neutrinos ---"
  Print #f,"------------------------------------"
  Print #f," "
  Print #f,"Multiplicity of anti-neutrinos: "; Csng(R_an * 0.01); " per fission"  ' from percent to number
  Print #f," "
  Print #f," Z  A   N       Number          Q value       Decay"
  Print #f," "
  For I = 1 To I_out_an
    Print #f, C_out_an(I)
  Next I  
  Redim C_out_an(1)
  I_out_an = 0
  Print #f,"    </anti_neutrinos>"
  
  Print #f,"    <Cumu>"
  Print #f,"      <Yields>"
  Print #f,"-------------------------"
  Print #f,"--- Cumulative yields ---" 
  Print #f,"-------------------------"
  Print #f," "
  Print #f,"Isomers are taken from ";Isosource;"."
  Print #f,"(See definition of isomer numbers in the corresponding"
  Print #f," file Nucpropxxx.bas.)"
  If B_Error_On = 1 And B_Error_Analysis = 0 Then
    Print #f," A"," Z"," Isomer"," Yield"," Uncertainty (+-)"
  Else
    Print #f," A"," Z"," Isomer"," Yield"
  End If  
  For IA = 20 To P_A_CN - 20
    For IZ = 10 To P_Z_CN - 10
      IN = IA - IZ
      If IN > 10 And IN < I_N_CN - 10 Then
        For Iori = 0 To 2
          If NZIcumu(IN,IZ,Iori) > 0 Then
            If IA <> IA_last Then
              Print #f, " "
              IA_last = IA
            End If
            If B_Error_On = 1 And B_Error_Analysis = 0 Then
              If d_NZIcumu(0,IA-IZ,IZ,Iori) > NZIcumu(IA-IZ,IZ,Iori) Then
                d_NZIcumu(0,IA-IZ,IZ,Iori) = NZIcumu(IA-IZ,IZ,Iori)
              End If
              If d_NZIcumu(0,IA-IZ,IZ,Iori) = 0 Then
                d_NZIcumu(0,IA-IZ,IZ,Iori) = NZIcumu(IA-IZ,IZ,Iori)
              End If
              Print #f, IA, IZ, Iori, NZIcumu(IA-IZ,IZ,Iori), Csng(d_NZIcumu(0,IA-IZ,IZ,Iori))
            Else
              Print #f, IA, IZ, Iori, NZIcumu(IA-IZ,IZ,Iori)
            End If
          End If
        Next Iori
      End If
    Next IZ
  Next IA
    
  Print #f," "
  Print #f,"      </Yields>"
  
  #Include "CovarCUMU.bas"
  
  Print #f,"    </Cumu>"
  Print #f,"  </Delayed> " 
  
  If B_Error_Analysis = 1 Then
    fmvd_single = Freefile
    Open Cfilemvd_single For Append As #fmvd_single
    
    Print #fmvd_single,"*"
    Print #fmvd_single,"* Set          A             Z            Isomer       Ycumu(A,Z,I)"  
    Print #fmvd_single,"*AZIcumu*"
    For IA = 20 To P_A_CN - 20
      For IZ = 10 To P_Z_CN - 10
        IN = IA - IZ
        If IN > 10 And IN < I_N_CN - 10 Then
          For Iori = 0 To 2
            If NZIcumu(IN,IZ,Iori) > 0 Then
              If IA <> IA_last Then
                Print #fmvd_single, "* "
                IA_last = IA
              End If
              Print #fmvd_single, I_Error+1, IA, IZ, Iori, NZIcumu(IA-IZ,IZ,Iori)
            End If
          Next Iori
        End If
      Next
    Next
    Close #fmvd_single
  End If  
 
End Scope
