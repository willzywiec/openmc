 /' Plot of mass distribution (Plotting.bas) '/

' If I_thread < 2 Then  ' Plotting with multiple GEF jobs does not work (program crashes).
                       ' Therefore, plotting is not allowed for I_thread > 1.
' A condition on B_graphics (that depends on I_thread) is inserted below and 
' in the plotting subroutines in DCLplotting.bas (5.Dec.2018,KHS).
' This makes it possible to calculate chi-square values without using graphics.

If I_thread < 2 And B_Print_Chisquare = 0 Then 
   ' B_Print_Chisquare is 1 when Chisqr is printed in a list to the general output file
  B_graphics = 1
Else
  B_graphics = 0
 ' If I_thread > 1 Then Print "Display is supressed, because I_thread > 1."
End If    

' B_graphics = 0     ' Graphics output totally suppressed, but chi-square calculation still performed.                       
           
If B_graphics = 1 Then    
  If B_Fit = 1 Then B_gfx = 0 Else B_gfx = -1 End If                 
  Scope
    If B_gfx Then
       ' set window title
      WinTitle = "GEF "+C_GEF_Version+": Mass yields for Z="+Str(P_Z_CN)+", A="+Str(P_A_CN)
      Select Case Emode
        Case 0
            WinTitle = WinTitle+", E* over Eb = "+Str(P_E_EXC)+" MeV"
        Case 1
            WinTitle = WinTitle+", E* = "+Str(P_E_EXC)+" MeV"
        Case 2
            WinTitle = WinTItle+" (CN), En = "+Str(P_E_EXC)+" MeV"
      End Select

    ' create a window with given resolution and 32-bit colours
    'Screenres 500,350,32
      Screenres 500,350,32
      WindowTitle WinTitle 
    End If  

    ' Open a file for a copy of the GFX file in GRAF format
    F_GRAF = Freefile
    Open "GRAF/"+Csystem+"_Apost.grf" For Output As #F_GRAF
    Print #F_GRAF,WinTitle
    Print #f_GRAF,"C: ";Format( Rdatetime, "dd.mm.yyyy, hh:mm:ss")
    Print #F_GRAF,"X: Post-neutron mass"
    Print #F_GRAF,"Y: Yield / %"
    Print #F_GRAF, "P: SCALING(0.6) SYMBOL(2)"

  End Scope

  If B_gfx Then
    ' set foreground and background colours
    Color RGB(0,0,0), RGB(255,255,255)
    ' draw background
    Cls
  End If

  Print " "
  If B_supp Then
    Print "    nu-bar = ";Round(Nmean,4) ' "Bf = ";B_F;" EB = ";E_B
  Else 
    Print "    nu-bar = ";Round(Nmean,4) ;"            GEF: no suppression" 
  End If

  Dim As Single Xmin, Xmax, Ymin, Ymax
  Xmin = 70
  Xmax = 180
  Xmin = ((Cint(P_A_CN/2.0))\10) * 10 - 50
  Xmax = (((Cint(P_A_CN/2.0))\10) + 1) * 10 + 50
  'Print Xmin,Xmax
  Dim As Single Xtic, Ytic

  If P_ylog = 1 Then
    If Nevtused <0.9E6 Then
      Ymin = -2.3
    Else
      Ymin = -3.3
    End If  
    Ymax = 1.3
  Else
    Ymin = 0
    Ymax = 14
  End If

  If B_gfx Then
   ' write numbers on axes
    If P_Ylog = 1 Then
      If ymin > -2.4 And ymin < -2.2 Then
        Draw String (30,40), "10"
        Draw String (38,118), "1"
        Draw String (22,196), "0.1"
        Draw String (14,274), "0.01"
     '   Draw String (6,352), "0.001"
      End If
      If ymin > -3.4 And ymin < -3.2 Then
        Draw String (30,31), "10"
        Draw String (38,92), "1"
        Draw String (22,149), "0.1"
        Draw String (14,214), "0.01"
        Draw String (6,275), "0.001"
      End If 
    Else
      Draw String (38,295), "0"
      Draw String (38,255), "2"
      Draw String (38,215), "4"
      Draw String (38,175), "6"
      Draw String (38,135), "8"
      Draw String (30,95), "10"
      Draw String (30,55), "12"
    End If 
    Ytic = 308 
    For I = 20 To 200 Step 20
      If I > Xmin And I < Xmax Then
        Xtic = 3.92 * (110 / (Xmax - Xmin)) * (I - Xmin + 70) - 236.1
        If I < 100 Then Xtic = Xtic + 5
        Draw String (Xtic,Ytic), Trim(Str(I))
      End If  
    Next I  
    /'  
    Draw String (81,308), "80"
    Draw String (156,308), "100"
    Draw String (234,308), "120"
    Draw String (313,308), "140"
    Draw String (391,308), "160"
    '/
    Draw String (200,330), "Post-neutron mass"


    ' define a viewport (clipping region)
    View (50,20) - (480,300), RGB(255,255,150), RGB(0,0,0)

  ' define new coordinate system on viewport region
    Window (Xmin,Ymin) - (Xmax, Ymax)

  ' Draw grid
  ' Draw horizontal grid lines:
    If P_ylog = 1 Then
      For Ytic = -5 To 5 Step 1
        Line (Xmin,Ytic) - (Xmax,Ytic)
      Next
    Else
      For Ytic = 0 To 20 Step 2
        Line (Xmin,Ytic) - (Xmax,Ytic)
      Next
    End If
    ' Draw vertical grid lines:
    For Xtic = Xmin + 10 To Xmax - 10 Step 10
      Line (Xtic,Ymin) - (Xtic,Ymax)
    Next
  End If

  ' draw a line with red colour
  ' Line (90,-2) - (100,0), RGB(255,0,0)


  ' draw mass distribution
  ' Logcircle (100,0.1)

  Print #F_GRAF, "H: X Y(GEF),NTR11 DY+-"

  If B_gfx Then
    Scope
      Dim As Single Dplus,Dminus
      Dim As Ubyte Bdraw
      For I = 20 To 190
        Bdraw = 0
        If P_Ylog = 1 Then
          If APost(I) > 10^Ymin Then Bdraw = -1
        Else
          If APost(I) > 0 Then Bdraw = -1
        End If  
   	    If Bdraw Then
   	      If P_Ylog = 1 Then 
   	        Logcircle (I,APost(I),0.6)
   	      Else
   	        Lincircle (I,APost(I),0.6)
   	      End If  
   	      If d_APost(0,I) > 0 Then
            Dplus = APost(I) + d_APost(0,I)  
            Dminus = APost(I) - d_APost(0,I) 
            If Dminus < 0.1*APost(I) Then Dminus = 0.1 * APost(I)
            If P_Ylog = 1 Then
              Logline3(I,Dplus,I,Dminus)
            Else
              LinLine3(I,Dplus,I,Dminus)
            End If    
          End If 
          Print #F_GRAF,I,Csng(APost(I)),Csng(d_APost(0,I))  ' Copy to GRAF file  	  
      	End If  
      Next  
    End Scope
  End If

  ' draw contributions of fission channels
  If B_gfx Then
    Scope
      Dim As Single IFirst
      Dim As Ubyte Bdraw
      For I = 0 To 7
        Print #F_GRAF, "H: X Y(GEF),LTG0"       ' Copy to GRAF file
        IFirst = 0
        For J = 20 To 190
'If J = 155 Then Print I,J,AMpost(I,J)        
          Bdraw = 0
          If P_Ylog = 1 Then
            If AMPost(I,J) > 10^Ymin Then Bdraw = -1
          Else 
            If AMPOst(I,J) > 0 Then Bdraw = -1
          End If  
          If Bdraw Then
            IFirst = IFirst + 1
            If IFirst = 2 Then
              If P_Ylog = 1 Then
                Logline1(J-1,AMpost(I,J-1),J,AMpost(I,J))
              Else
                Linline1(J-1,AMpost(I,J-1),J,AMpost(I,J))
              End If  
            End If
            If IFirst > 2 Then
              If P_Ylog = 1 Then 
                Logline2(J,AMpost(I,J))
              Else
                Linline2(J,AMpost(I,J))
              End If  
            End If
            Print #F_GRAF,J,Csng(AMpost(I,J))   ' Copy to GRAF file
          Else
            IFirst = 0
          End If
        Next
      Next
    End Scope
  End If
End If  ' If B_graphics

If B_Fit Then
  Fitlog = Freefile
  Open "tmp/Fitlog"+Trim(Str(I_thread)) +".dat" For Append As #Fitlog

  If B_New_Fit_Parameters = 1 Then
    Print #Fitlog, " " 
    If I_Fitloop = 1 Then
      Print #Fitlog,"'********************************************"
      Print #Fitlog,"' Calculation started on ";
      Print #Fitlog,Format( Rdatetime, "dd.mm.yyyy, hh:mm:ss")
      Print #Fitlog,"'********************************************"
      If Chisqr_Fit_min <> 1.E10 Then
        Print #Fitlog,"Start value of Chisqr_Fit_min: ";Csng(Chisqr_Fit_min)
        Print #Fitlog,"from Fitpar.dat (best value of previous fit)."
      End If
    End If
    If I_Fitloop = 2 Then
      If Chisqr_Fit_min = 1.E10 Then
        Chisqr_Fit_min = Chisqr_Fit_present
        Print #Fitlog,"Start value of Chisqr_Fit_min: ";Csng(Chisqr_Fit_min)
        Print #Fitlog,"from first calculation of present fit."
      End If  
    End If 
 /' If I_Fitloop > 2 Then
      Print #Fitlog,"Total Chisqr value: ";Chisqr_Fit_present
      If Chisqr_Fit_present < Chisqr_Fit_min And Chisqr_Fit_present > 0 Then
        Chisqr_Fit_min = Chisqr_Fit_present  ' store new "best" chisqr value
        Print #Fitlog, "New improved set of fit parameters found and stored in Fitpar.dat."
        #Include "FitparWrite.bas"    ' write new parameter values to file
        D_Par_Fac = D_Par_Fac / sqr(2) ' reduce amplitude of variations
        Print #Fitlog, "Amplitude of parameter variation is reduced by factor 1/sqr(2)."
      End If
    End If '/ 
    Print #Fitlog,"New set of fit parameters #";I_Fitloop;", D_Par_Fac = ";D_Par_Fac
    Print #Fitlog,Format( Rdatetime, "dd.mm.yyyy, hh:mm:ss")
    B_New_Fit_Parameters = 0  
    Chisqr_Fit_present = 0
  End If
End If

Chilin = 0
Chilog = 0
ChiGEFlin = 0
ChiGEFlog = 0
' Dim As Single Chilin,Chilog,ChiGEFlin,ChiGEFlog

'Print "Plotting.bas(277):P_Z_CN,P_A_CN,P_E_exc";P_Z_CN;P_A_CN;P_E_Exc

' pre-neutron mass distributions from kinematical experiments
If EMODE = 1 And P_E_Exc >= 0.5 And P_E_Exc <= 1.5 Then
  If P_A_CN = 180 And P_Z_CN = 80 Then
    IF Instr(C_Fitoption,"APRE") > 0 Then
      Restore Apre_Hg180
      Ploteval("Hg180","Apre(Elseviers)",-1)
      Scope 
        Dim As Single Chisqr_single
        Dim As Integer IA, IAfirst, IAlast
        Restore Apre_Hg180
        Read IAfirst, IAlast
        Redim As Single Ayield(IAfirst To IAlast)
        Redim As Single dAyield(IAfirst To IAlast)
        For IA = IAfirst To IAlast Step 2
          Read Ayield(IA)
        Next IA
        For IA = IAfirst To IAlast Step 2
          Read dAyield(IA)
          dAyield(IA) = Max(dAyield(IA),0.2)
        Next IA
        If Fitloglevel > 2 Then Print #Fitlog, " A"; "  Yield(exp)  d_exp"," Yield(GEF)"," Chisqr"        
        Chisqr_Fit = 0
        For IA = IAfirst to IAlast Step 2
          If dAyield(IA) > 0 Then
            Chisqr_single =_
             ( (Ayield(IA) - Apre(IA) )/dAyield(IA))^2
            If Fitloglevel > 2 Then Print #Fitlog, IA;Ayield(IA),dAyield(IA),Csng(Apre(IA)),Chisqr_Single
            Chisqr_Fit = Chisqr_Fit + Chisqr_single 
          End If     
        Next IA
        If B_graphics = 1 Then
          Close #F_GRAF
          Open "GRAF/"+Csystem+"_Apre.grf" For Output As #F_GRAF
          Print #F_GRAF,WinTitle
          Print #F_GRAF,"X: Apre"
          Print #F_GRAF,"Y: Yield / %"
          Print #F_GRAF, "P: SCALING(0.6) SYMBOL(2)"
          Print #F_GRAF,"H: X  Y(Data),LT7  DY  Y(GEF),LRT11  "
          For IA = IAfirst to IAlast Step 2
            Print #F_GRAF,IA,Ayield(IA),dAyield(IA),Apre(IA)
          Next IA          
'          Close #F_GRAF
'          Open "GRAF/"+Csystem+"_Apre.grf" For Output As #F_GRAF          
        End If
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit 
        Print #Fitlog, "Hg180 (Apre,Elseviers): Chisqr = ";Csng(Chisqr_Fit)      
      End Scope  
    End If
  End If
End If
If EMODE = 0 And P_E_Exc >= 10 And P_E_Exc <= 11 Then
  If P_A_CN = 213 And P_Z_CN = 85 Then
    IF Instr(C_Fitoption,"APRE") > 0 Then
      Restore Apre_At213
      Ploteval("At213","Apre(Itkis)",-1)
      Scope 
        Dim As Single Chisqr_single
        Dim As Integer IA, IAfirst, IAlast
        Restore Apre_At213
        Read IAfirst, IAlast
        Redim As Single Ayield(IAfirst To IAlast)
        Redim As Single dAyield(IAfirst To IAlast)
        For IA = IAfirst To IAlast
          Read Ayield(IA)
        Next IA
        For IA = IAfirst To IAlast
          Read dAyield(IA)
          dAyield(IA) = Max(dAyield(IA),0.2)
        Next IA
        If Fitloglevel > 2 Then Print #Fitlog, " A"; "  Yield(exp)  d_exp"," Yield(GEF)"," Chisqr"        
        Chisqr_Fit = 0
        For IA = IAfirst to IAlast
          If dAyield(IA) > 0 Then
            Chisqr_single =_
             ( (Ayield(IA) - Apre(IA) )/dAyield(IA))^2
            If Fitloglevel > 2 Then Print #Fitlog, IA;Ayield(IA),dAyield(IA),Csng(Apre(IA)),Chisqr_Single
            Chisqr_Fit = Chisqr_Fit + Chisqr_single 
          End If     
        Next IA
        If B_graphics = 1 Then
          Close #F_GRAF
          Open "GRAF/"+Csystem+"_Apre.grf" For Output As #F_GRAF
          Print #F_GRAF,WinTitle
          Print #F_GRAF,"X: Apre"
          Print #F_GRAF,"Y: Yield / %"
          Print #F_GRAF, "P: SCALING(0.6) SYMBOL(2)"
          Print #F_GRAF,"H: X  Y(Data),LT7  DY  Y(GEF),LRT11  "
          For IA = IAfirst to IAlast
            Print #F_GRAF,IA,Ayield(IA),dAyield(IA),Apre(IA)
          Next IA          
'          Close #F_GRAF
'          Open "GRAF/"+Csystem+"_Apre.grf" For Output As #F_GRAF          
        End If
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit 
        Print #Fitlog, "At213 (Apre,Itkis): Chisqr = ";Csng(Chisqr_Fit)            
      End Scope      
    End If
  End If
  If P_A_CN = 187 And P_Z_CN = 77 Then
    IF Instr(C_Fitoption,"APRE") > 0 Then
      Restore Apre_Ir187
      Ploteval("Ir187","Apre(Itkis)",-1)
      Scope 
        Dim As Single Chisqr_single
        Dim As Integer IA, IAfirst, IAlast
        Restore Apre_Ir187
        Read IAfirst, IAlast
        Redim As Single Ayield(IAfirst To IAlast)
        Redim As Single dAyield(IAfirst To IAlast)
        For IA = IAfirst To IAlast
          Read Ayield(IA)
        Next IA
        For IA = IAfirst To IAlast
          Read dAyield(IA)
          dAyield(IA) = Max(dAyield(IA),0.2)
        Next IA
        If Fitloglevel > 2 Then Print #Fitlog, " A"; "  Yield(exp)  d_exp"," Yield(GEF)"," Chisqr"        
        Chisqr_Fit = 0
        For IA = IAfirst to IAlast
          If dAyield(IA) > 0 Then
            Chisqr_single =_
               ( (Ayield(IA) - Apre(IA) )/dAyield(IA))^2
            If Fitloglevel > 2 Then Print #Fitlog, IA;Ayield(IA),dAyield(IA),Csng(Apre(IA)),Chisqr_Single
            Chisqr_Fit = Chisqr_Fit + Chisqr_single
          End If     
        Next IA
        If B_graphics = 1 Then
          Close #F_GRAF
          Open "GRAF/"+Csystem+"_Apre.grf" For Output As #F_GRAF
          Print #F_GRAF,WinTitle
          Print #F_GRAF,"X: Apre"
          Print #F_GRAF,"Y: Yield / %"
          Print #F_GRAF, "P: SCALING(0.6) SYMBOL(2)"
          Print #F_GRAF,"H: X  Y(Data),LT7  DY  Y(GEF),LRT11  "
          For IA = IAfirst to IAlast
            Print #F_GRAF,IA,Ayield(IA),dAyield(IA),Apre(IA)
          Next IA          
'          Close #F_GRAF
'          Open "GRAF/"+Csystem+"_Apre.grf" For Output As #F_GRAF
        End If
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit 
        Print #Fitlog, "Ir187 (Apre,Itkis): Chisqr = ";Csng(Chisqr_Fit)            
      End Scope      
    End If
  End If
  If P_A_CN = 201 And P_Z_CN = 81 Then
    IF Instr(C_Fitoption,"APRE") > 0 Then
      Restore Apre_Tl201
      Ploteval("Tl201","Apre(Itkis)",-1)
      Scope 
        Dim As Single Chisqr_single
        Dim As Integer IA, IAfirst, IAlast
        Restore Apre_Tl201
        Read IAfirst, IAlast
        Redim As Single Ayield(IAfirst To IAlast)
        Redim As SIngle dAyield(IAfirst To IAlast)
        For IA = IAfirst To IAlast
          Read Ayield(IA)
        Next IA
        For IA = IAfirst To IAlast
          Read dAyield(IA)
          dAyield(IA) = Max(dAyield(IA),0.2)
        Next IA
        If Fitloglevel > 2 Then Print #Fitlog, " A"; "  Yield(exp)  d_exp"," Yield(GEF)"," Chisqr"        
        Chisqr_Fit = 0
        For IA = IAfirst to IAlast
          If dAyield(IA) > 0 Then
            Chisqr_single =_
               ( (Ayield(IA) - Apre(IA) )/dAyield(IA))^2
            If Fitloglevel > 2 Then Print #Fitlog, IA;Ayield(IA),dAyield(IA),Csng(Apre(IA)),Chisqr_Single
            Chisqr_Fit = Chisqr_Fit + Chisqr_single 
          End If    
        Next IA
        If B_graphics = 1 Then
          Close #F_GRAF
          Open "GRAF/"+Csystem+"_Apre.grf" For Output As #F_GRAF
          Print #F_GRAF,WinTitle
          Print #F_GRAF,"X: Apre"
          Print #F_GRAF,"Y: Yield / %"
          Print #F_GRAF, "P: SCALING(0.6) SYMBOL(2)"
          Print #F_GRAF,"H: X  Y(Data),LT7  DY  Y(GEF),LRT11  "
          For Ia = IAfirst to IAlast
            Print #F_GRAF,IA,Ayield(IA),dAyield(IA),Apre(IA)
          Next IA          
'          Close #F_GRAF
'          Open "GRAF/"+Csystem+"_Apre.grf" For Output As #F_GRAF
        End If
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit 
        Print #Fitlog, "Tl201 (Apre,Itkis): Chisqr = ";Csng(Chisqr_Fit)            
      End Scope      
    End If
  End If
End If

If EMODE = 12 And P_E_Exc >= 27.5 And P_E_Exc <= 28.5 Then
  If P_A_CN = 233 And P_Z_CN = 91 Then
    IF Instr(C_Fitoption,"APRE") > 0 Then
      Restore Apre_Th232p_28MeV:
      Ploteval("Pa233","Apre(Berriman)",-1)
      Scope 
        Dim As Single Chisqr_single
        Dim As Integer IA, IAfirst, IAlast
        Restore Apre_Tl201
        Read IAfirst, IAlast
        Redim As Single Ayield(IAfirst To IAlast)
        Redim As SIngle dAyield(IAfirst To IAlast)
        For IA = IAfirst To IAlast
          Read Ayield(IA)
        Next IA
        For IA = IAfirst To IAlast
          Read dAyield(IA)
          dAyield(IA) = Max(dAyield(IA),0.2)
        Next IA
        If Fitloglevel > 2 Then Print #Fitlog, " A"; "  Yield(exp)  d_exp"," Yield(GEF)"," Chisqr"        
        Chisqr_Fit = 0
        For IA = IAfirst to IAlast
          If dAyield(IA) > 0 Then
            Chisqr_single =_
               ( (Ayield(IA) - Apre(IA) )/dAyield(IA))^2
            If Fitloglevel > 2 Then Print #Fitlog, IA;Ayield(IA),dAyield(IA),Csng(Apre(IA)),Chisqr_Single
            Chisqr_Fit = Chisqr_Fit + Chisqr_single 
          End If    
        Next IA
        If B_graphics = 1 Then
          Close #F_GRAF
          Open "GRAF/"+Csystem+"_Apre.grf" For Output As #F_GRAF
          Print #F_GRAF,WinTitle
          Print #F_GRAF,"X: Apre"
          Print #F_GRAF,"Y: Yield / %"
          Print #F_GRAF, "P: SCALING(0.6) SYMBOL(2)"
          Print #F_GRAF,"H: X  Y(Data),LT7  DY  Y(GEF),LRT11  "
          For IA = IAfirst to IAlast
            Print #F_GRAF,IA,Ayield(IA),dAyield(IA),Apre(IA)
          Next IA          
'          Close #F_GRAF
'          Open "GRAF/"+Csystem+"_Apre.grf" For Output As #F_GRAF
        End If
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit / 10
        Print #Fitlog, "Th232+p, Ep=28MeV (Apre,Berriman): Chisqr = ";Csng(Chisqr_Fit/10);"(*10)"             
      End Scope      
    End If  
  End If
End If

' Spontaneous fission
If EMODE = 1 And P_E_EXC = 0 Then
  If P_A_CN = 252 And P_Z_CN = 98 Then
    Restore CF252S
    Ploteval("CF252S","ENDF B VII",-1)
    Restore CF252S
    Chisqr_Apost("CF252S",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
    PrintChisqr(Chilin,"ENDF")
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin * 100   
                    ' Put high weight to force yield of S3
      Print #Fitlog, "CF252S (APOST,ENDF): Chisqr = ";Chilin * 100;" ( / 100)"      
    End If
    IF Instr(C_Fitoption,"NUBAR") > 0 Then
      Restore nubar_CF252S
      Read nubar_exp
      Read d_nubar_exp
      Chisqr_Fit = ( (Nmean - nubar_exp)/ d_nubar_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "CF252S (NUBAR): Chisqr = ";Csng(Chisqr_Fit),"exp:";nubar_exp,"GEF:";Nmean   
    End If
  End If
  If P_A_CN = 250 And P_Z_CN = 98 Then
    Restore CF250S
    Ploteval("CF250S","ENDF B VII",-1)
    Restore CF250S
    Chisqr_Apost("CF250S",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
    PrintChisqr(Chilin,"ENDF")
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "CF250S (APOST,ENDF): Chisqr = ";Chilin
    End If        
  End If
  If P_A_CN = 242 And P_Z_CN = 96 Then
    IF Instr(C_Fitoption,"NUBAR") > 0 Then
      Restore nubar_CM242S
      Read nubar_exp
      Read d_nubar_exp
      Chisqr_Fit = ( (Nmean - nubar_exp)/ d_nubar_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "CM242S (NUBAR): Chisqr = ";Csng(Chisqr_Fit),"exp:";nubar_exp,"GEF:";Nmean     
    End If
  End If
  If P_A_CN = 244 And P_Z_CN = 96 Then
    Restore CM244S
    Ploteval("CM244S","ENDF B VII",-1)
    Restore CM244S
    Chisqr_Apost("CM244S",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
    PrintChisqr(Chilin,"ENDF")
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "CM244S (APOST,ENDF): Chisqr = ";Chilin      
    End If  
    IF Instr(C_Fitoption,"NUBAR") > 0 Then
      Restore nubar_CM244S
      Read nubar_exp
      Read d_nubar_exp
      Chisqr_Fit = ( (Nmean - nubar_exp)/ d_nubar_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "CM244S (NUBAR): Chisqr = ";Csng(Chisqr_Fit),"exp:";nubar_exp,"GEF:";Nmean      
    End If
  End If
  If P_A_CN = 246 And P_Z_CN = 96 Then
    Restore CM246S
    Ploteval("CM246S","ENDF B VII",-1)
    Restore CM246S
    Chisqr_Apost("CM246S",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
    PrintChisqr(Chilin,"ENDF")
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "CM246S (APOST,ENDF): Chisqr = ";Chilin      
    End If  
  End If
  If P_A_CN = 248 And P_Z_CN = 96 Then
    Restore CM248S
    Ploteval("CM248S","ENDF B VII",-1)
    Restore CM248S
    Chisqr_Apost("CM248S",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
    PrintChisqr(Chilin,"ENDF")
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "CM248S (APOST,ENDF): Chisqr = ";Chilin      
    End If  
  End If
  If P_A_CN = 253 And P_Z_CN = 99 Then
    Restore ES253S
    Ploteval("ES253S","ENDF B VII",-1)
    Restore ES253S
    Chisqr_Apost("ES253S",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
    PrintChisqr(Chilin,"ENDF")
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "ES253S (APOST,ENDF): Chisqr = ";Chilin      
    End If  
  End If
  If P_A_CN = 254 And P_Z_CN = 100 Then
    Restore FM254S
    Ploteval("FM254S","ENDF B VII",-1)
    Restore FM254S
    Chisqr_Apost("FM254S",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
    PrintChisqr(Chilin,"ENDF")
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "FM254S (APOST,ENDF): Chisqr = ";Chilin      
    End If  
  End If  
  If P_A_CN = 256 And P_Z_CN = 100 Then
    Restore FM256S
    Ploteval("FM256S","ENDF B VII",-1)
    Restore FM256S
    Chisqr_Apost("FM256S",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
    PrintChisqr(Chilin,"ENDF")
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "FM256S (APOST,ENDF): Chisqr = ";Chilin      
    End If  
  End If  
  If P_A_CN = 238 And P_Z_CN = 94 THen
    If Instr(C_Fitoption,"MODES") > 0 Then
      Scope
        Dim As Single Chisqr_single
        Dim As Single Yield_GEF
        Dim As Integer IMode, IModefirst, IModelast
        Restore Modes_PU238S
        Read IModefirst,IModelast
        ReDim As Single Yield(IModefirst To IModelast)
        ReDim As Single dYield(IModefirst To IMODElast)
        For IMode = IModefirst To IModelast
          Read Yield(IMode)
        Next IMode
        For IMode = IModefirst To IModelast
          Read dYield(IMode)
        Next IMode
        Chisqr_Fit = 0
        If Fitloglevel > 1 Then Print #Fitlog, "Mode", "Yield_exp ","d_Yield_exp","Yield_GEF","Chisqr"
        For IMode = IModefirst to IModelast
          If IMode = 0 Then Yield_GEF = Yield_Mode_0
          If IMode = 1 Then Yield_GEF = Yield_Mode_1
          If IMode = 2 Then Yield_GEF = Yield_Mode_2
          If IMode = 3 Then Yield_GEF = Yield_Mode_3
          If IMode = 4 Then Yield_GEF = Yield_Mode_4
          Chisqr_single =_
             ( (Yield(IMode) - Yield_GEF)/dYield(IMode))^2
            ' If Fitloglevel > 1 Then 
             Print #Fitlog, IMode,Yield(IMode),dYield(IMode),Yield_GEF,Chisqr_Single
          Chisqr_Fit = Chisqr_Fit + Chisqr_single   
        Next IMode
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
        Print #Fitlog, "Pu238S (Modes): Chisqr = ";Csng(Chisqr_Fit)  
      End Scope  
    End If  
  End If
  If P_A_CN = 240 And P_Z_CN = 94 THen
    If Instr(C_Fitoption,"MODES") > 0 Then
      Scope
        Dim As Single Chisqr_single
        Dim As Single Yield_GEF
        Dim As Integer IMode, IModefirst, IModelast
        Restore Modes_PU240S
        Read IModefirst,IModelast
        ReDim As Single Yield(IModefirst To IModelast)
        ReDim As Single dYield(IModefirst To IMODElast)
        For IMode = IModefirst To IModelast
          Read Yield(IMode)
        Next IMode
        For IMode = IModefirst To IModelast
          Read dYield(IMode)
        Next IMOde
        Chisqr_Fit = 0
        If Fitloglevel > 1 Then Print #Fitlog, "Mode", " Yield_exp","d_Yield_exp","Yield_GEF","Chisqr"
        For IMode = IModefirst to IModelast
          If IMode = 0 Then Yield_GEF = Yield_Mode_0
          If IMode = 1 Then Yield_GEF = Yield_Mode_1
          If IMode = 2 Then Yield_GEF = Yield_Mode_2
          If IMode = 3 Then Yield_GEF = Yield_Mode_3
          If IMode = 4 Then Yield_GEF = Yield_Mode_4
          Chisqr_single =_
             ( (Yield(IMode) - Yield_GEF)/dYield(IMode))^2
            ' If Fitloglevel > 1 Then 
             Print #Fitlog, IMode,Yield(IMode),dYield(IMode),Yield_GEF,Chisqr_Single
          Chisqr_Fit = Chisqr_Fit + Chisqr_single   
        Next IMode
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
        Print #Fitlog, "Pu240S (Modes): Chisqr = ";Csng(Chisqr_Fit)  
      End Scope  
    End If  
  End If
  If P_A_CN = 244 And P_Z_CN = 94 Then
    If Instr(C_Fitoption,"MODES") > 0 Then
      Scope
        Dim As Single Chisqr_single
        Dim As Single Yield_GEF
        Dim As Integer IMode, IModefirst, IModelast
        Restore Modes_PU244S
        Read IModefirst,IModelast
        ReDim As Single Yield(IModefirst To IModelast)
        ReDim As Single dYield(IModefirst To IMODElast)
        For IMode = IModefirst To IModelast
          Read Yield(IMode)
        Next IMode
        For IMode = IModefirst To IModelast
          Read dYield(IMode)
        Next IMOde
        Chisqr_Fit = 0
        If Fitloglevel > 1 Then Print #Fitlog, "Mode", "Yield_exp ","d_Yield_exp","Yield_GEF","Chisqr"
        For IMode = IModefirst to IModelast
          If IMode = 0 Then Yield_GEF = Yield_Mode_0
          If IMode = 1 Then Yield_GEF = Yield_Mode_1
          If IMode = 2 Then Yield_GEF = Yield_Mode_2
          If IMode = 3 Then Yield_GEF = Yield_Mode_3
          If IMode = 4 Then Yield_GEF = Yield_Mode_4
          Chisqr_single =_
             ( (Yield(IMode) - Yield_GEF)/dYield(IMode))^2
            ' If Fitloglevel > 1 Then 
             Print #Fitlog, IMode,Yield(IMode),dYield(IMode),Yield_GEF,Chisqr_Single
          Chisqr_Fit = Chisqr_Fit + Chisqr_single   
        Next IMode
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
        Print #Fitlog, "Pu244S (Modes): Chisqr = ";Csng(Chisqr_Fit)  
      End Scope  
    End If  
  End If
  If P_A_CN = 238 And P_Z_CN = 92 Then
    Restore U238S
    Ploteval("U238S","ENDF B VII",-1)
    Restore U238S
    Chisqr_Apost("U238S",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
    PrintChisqr(Chilin,"ENDF B VII")
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "U238S (APOST,ENDF): Chisqr = ";Chilin      
    End If  
  End If  
End If

' Thermal-neutron-induced fission
If EMODE = 2 And (P_E_EXC >= 0 And P_E_EXC <= 0.05) Then
  If P_A_CN = 242 And P_Z_CN = 95 Then
    If IENDFall = 0 Then
      Restore AM241T
      Ploteval("AM241T","ENDF B VII",-1)
      Restore AM241T
      Chisqr_Apost("AM241T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore AM241TJEFF311
      Ploteval("AM241T","JEFF 3.1.1",-1)
      Restore AM241TJEFF311
      Chisqr_Apost("AM241T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore AM241TJEFF33
      Ploteval("AM241T","JEFF 3.3",-1)
      Restore AM241TJEFF33
      Chisqr_Apost("AM241T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore AM241TJEFF33
      Ploteval("AM241T","JEFF 3.3",0)
      Restore AM241TJEFF33
      Chisqr_Apost("AM241T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)    
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "AM241T (APOST,JEFF 3.3): Chisqr = ";Chilin      
    End If
    IF Instr(C_Fitoption,"NUBAR") > 0 Then
      Restore nubar_AM241T
      Read nubar_exp
      Read d_nubar_exp
      Chisqr_Fit = ( (Nmean - nubar_exp)/ d_nubar_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "AM241T (NUBAR): Chisqr = ";Csng(Chisqr_Fit),"exp:";nubar_exp,"GEF:";Nmean     
    End If
  End If
  If P_A_CN = 243 And P_Z_CN = 95 Then
    If IENDFall = 0 Then
      Restore AM242T
      Ploteval("AM242T","ENDF B VII",-1)
      Restore AM242T
      Chisqr_Apost("AM242T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore AM242MTJEFF311
      Ploteval("AM242mT","JEFF 3.1.1",-1)
      Restore AM242MTJEFF311
      Chisqr_Apost("AM242mT",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If  
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore AM241TJEFF33
      Chisqr_Apost("AM242mT",Chilin,Chilog,ChiGEFlin,ChiGEFlog)    
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "AM242mT (APOST,JEFF 3.3): Chisqr = ";Chilin      
    End If
  End If
  If P_A_CN = 244 And P_Z_CN = 95 Then
    If IENDFall = 1 Then
      Restore AM243TJEFF311
      Ploteval("AM243T","JEFF 3.1.1",-1)
      Restore AM243TJEFF311
      Chisqr_Apost("AM243T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore AM243TJEFF33
      Ploteval("AM243T","JEFF 3.3",-1)
      Restore AM243TJEFF33
      Chisqr_Apost("AM243T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If  
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore AM243TJEFF33
      Ploteval("AM243T","JEFF 3.3",0)
      Restore AM243TJEFF33
      Chisqr_Apost("AM243T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)    
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "AM243T (APOST,JEFF 3.3): Chisqr = ";Chilin      
    End If
  End If
  If P_A_CN = 250 And P_Z_CN = 98 Then
    If IENDFall = 0 Then
      Restore CF249T
      Ploteval("CF249T","ENDF B VII",-1)
      Restore CF249T
      Chisqr_Apost("CF249T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 3 Then
      Restore CF249TLOHENGRIN
      Ploteval("CF249T","LOHENGRIN",-1)
      Restore CF249TLOHENGRIN
      Chisqr_Apost("CF249T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"LOHENGRIN")  
    End If 
    If Instr(C_Fitoption,"APOST") > 0 Then
      Restore CF249TLOHENGRIN
      Ploteval("CF249T","LOHENGRIN",0)
      Restore CF249TLOHENGRIN
      Chisqr_Apost("CF249T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "CF249T (APOST,LOHENGRIN): Chisqr = ";Chilin     
    End If  
    If Instr(C_Fitoption,"ZEO") > 0 Then
      Scope
        Dim As Single ZEO_exp, d_ZEO_exp
        Restore Zeo_CF249T
        Read ZEO_exp
        Read d_ZEO_exp
        Chisqr_Fit = ((ZEO_exp - ZEO_GEF) / d_ZEO_exp)^2
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
        Print #Fitlog, "CF249T (Zeo, Lohengrin): Chisqr = ";Csng(Chisqr_Fit),"exp:";ZEO_exp,"GEF:";ZEO_GEF           
      End Scope
    End If
  End If
  If P_A_CN = 252 And P_Z_CN = 98 Then
    If IENDFall = 0 Then
      Restore CF251T
      Ploteval("CF251T","ENDF B VII",-1)
      Restore CF251T
      Chisqr_Apost("CF251T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 3 Then
      Restore CF251TLOHENGRIN
      Ploteval("CF251T","LOHENGRIN",-1)
      Restore CF251TLOHENGRIN
      Chisqr_Apost("CF251T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"LOHENGRIN")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then
      Restore CF251TLOHENGRIN
      Ploteval("CF251T","LOHENGRIN",0)
      Restore CF251TLOHENGRIN
      Chisqr_Apost("CF251T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "CF249T (APOST.LOHENGRIN): Chisqr = ";Chilin     
    End If  
  End If
  If P_A_CN = 244 And P_Z_CN = 96 Then
    IF IENDFall = 0 Then
      Restore CM243T
      Ploteval("CM243T","ENDF B VII",-1)
      Restore CM243T
      Chisqr_Apost("CM243T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If  
    If IENDFall = 1 Then
      Restore CM243TJEFF311
      Ploteval("CM243T","JEFF 3.1.1",-1)
      Restore CM243TJEFF311
      Chisqr_Apost("CM243T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore CM243TJEFF33
      Ploteval("CM243T","JEFF 3.3",-1)
      Restore CM243TJEFF33
      Chisqr_Apost("CM243T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore CM243FJEFF33
      Ploteval("CM243T","JEFF 3.3",0)
      Restore CM243FJEFF33
      Chisqr_Apost("CM243T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)    
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "CM243T (APOST,JEFF 3.3): Chisqr = ";Chilin      
    End If
    IF Instr(C_Fitoption,"NUBAR") > 0 Then
      Restore nubar_CM243T
      Read nubar_exp
      Read d_nubar_exp
      Chisqr_Fit = ( (Nmean - nubar_exp)/ d_nubar_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "CM243T (NUBAR): Chisqr = ";Csng(Chisqr_Fit),"exp:";nubar_exp,"GEF:";Nmean     
    End If
  End If
  If P_A_CN = 245 And P_Z_CN = 96 Then
    If IENDFall = 1 Then
      Restore CM244TJEFF311
      Ploteval("CM244T","JEFF 3.1.1",-1)
      Restore CM244TJEFF311
      Chisqr_Apost("CM244T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrinTChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore CM244TJEFF33
      Ploteval("CM244T","JEFF 3.3",-1)
      Restore CM244TJEFF33
      Chisqr_Apost("CM244T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrinTChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore CM244TJEFF33
      Ploteval("CM244T","JEFF 3.3",0)
      Restore CM244TJEFF33
      Chisqr_Apost("CM244T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)    
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "CM244T (APOST,JEFF 3.3): Chisqr = ";Chilin      
    End If
    IF Instr(C_Fitoption,"NUBAR") > 0 Then
      Restore nubar_CM244T
      Read nubar_exp
      Read d_nubar_exp
      Chisqr_Fit = ( (Nmean - nubar_exp)/ d_nubar_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "CM244T (NUBAR): Chisqr = ";Csng(Chisqr_Fit),"exp:";nubar_exp,"GEF:";Nmean     
    End If
  End If
  If P_A_CN = 246 And P_Z_CN = 96 Then
    If IENDFall = 0 Then
      Restore CM245T
      Ploteval("CM245T","ENDF B VII",-1)
      Restore CM245T
      Chisqr_Apost("CM245T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore CM245TJEFF311
      Ploteval("CM245T","JEFF 3.1.1",-1)
      Restore CM245TJEFF311
      Chisqr_Apost("CM245T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore CM245TJEFF33
      Ploteval("CM245T","JEFF 3.3",-1)
      Restore CM245TJEFF33
      Chisqr_Apost("CM245T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore CM245TJEFF33
      Ploteval("CM245T","JEFF 3.3",0)
      Restore CM245TJEFF33
      Chisqr_Apost("CM245T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)    
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "CM245T (APOST,JEFF 3.3): Chisqr = ";Chilin      
    End If
    IF Instr(C_Fitoption,"NUBAR") > 0 Then
      Restore nubar_CM245T
      Read nubar_exp
      Read d_nubar_exp
      Chisqr_Fit = ( (Nmean - nubar_exp)/ d_nubar_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "CM245T (NUBAR): Chisqr = ";Csng(Chisqr_Fit),"exp:";nubar_exp,"GEF:";Nmean     
    End If
  End If
  If P_A_CN = 255 And P_Z_CN = 99 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore ES254T
      Ploteval("ES254T","ENDF B VII",-1)
      Restore ES254T
      Chisqr_Apost("ES254T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore ES254T
      Chisqr_Apost("ES254T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "CM245T (APOST,ENDF): Chisqr = ";Chilin   
    End If  
  End If
  If P_A_CN = 256 And P_Z_CN = 100 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore FM255T
      Ploteval("FM255T","ENDF B VII",-1)
      Restore FM255T
      Chisqr_Apost("FM255T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore FM255T
      Chisqr_Apost("FM255T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "FM255T (APOST,ENDF): Chisqr = ";Chilin   
    End If  
  End If
  If P_A_CN = 238 And P_Z_CN = 93 Then
    IF IENDFall = 0 Then
      Restore NP237T
      Ploteval("NP237T","ENDF B VII",-1)
      Restore NP237T
      Chisqr_Apost("NP237T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore NP237TJEFF311
      Ploteval("NP237T","JEFF 3.1.1",-1)
      Restore NP237TJEFF311
      Chisqr_Apost("NP237T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore NP237TJEFF33
      Ploteval("NP237T","JEFF 3.3",-1)
      Restore NP237TJEFF33
      Chisqr_Apost("NP237T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore NP237TJEFF33
      Ploteval("NP237T","JEFF 3.3",0)
      Restore NP237TJEFF33
      Chisqr_Apost("NP237T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)    
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "NP237T (APOST,JEFF 3.3): Chisqr = ";Chilin      
    End If
    IF Instr(C_Fitoption,"NUBAR") > 0 Then
      Restore nubar_NP237T
      Read nubar_exp
      Read d_nubar_exp
      Chisqr_Fit = ( (Nmean - nubar_exp)/ d_nubar_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "NP237T (NUBAR): Chisqr = ";Csng(Chisqr_Fit),"exp:";nubar_exp,"GEF:";Nmean     
    End If
  End If  
  If P_A_CN = 239 And P_Z_CN = 93 Then
    IF IENDFall = 1 Then
      Restore NP238TJEFF311
      Ploteval("NP238T","JEFF 3.1.1",-1)
      Restore NP238TJEFF311
      Chisqr_Apost("NP238T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If  
    IF IENDFall = 2 Then
      Restore NP238TJEFF33
      Ploteval("NP238T","JEFF 3.3",-1)
      Restore NP238TJEFF33
      Chisqr_Apost("NP238T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If  
    If IENDFall = 3 Then   ' LOHENGRIN data
      Restore NP238TLOHENGRIN
      Ploteval("NP238T","LOHENGRIN",-1)
      Restore NP238TLOHENGRIN
      Chisqr_Apost("NP238T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"LOHENGRIN")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then
      Restore NP238TLOHENGRIN
      Ploteval("NP238T","LOHENGRIN",0)
      Restore NP238TLOHENGRIN
      Chisqr_Apost("NP238T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "NP238T (APOST,LOHENGRIN): Chisqr = ";Csng(Chisqr_Fit)     
    End If  
    IF Instr(C_Fitoption,"NUBAR") > 0 Then
      Restore nubar_NP238T
      Read nubar_exp
      Read d_nubar_exp
      Chisqr_Fit = ( (Nmean - nubar_exp)/ d_nubar_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "NP238T (NUBAR): Chisqr = ";Csng(Chisqr_Fit),"exp:";nubar_exp,"GEF:";Nmean     
    End If
  End If
  If P_A_CN = 239 And P_Z_CN = 94 Then
    If IENDFall = 1 Then
      Restore PU238TJEFF311
      Ploteval("PU238T","JEFF 3.1.1",-1)
      Restore PU238TJEFF311
      Chisqr_Apost("PU238T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If  
    If IENDFall = 2 Then
      Restore PU238TJEFF33
      Ploteval("PU238T","JEFF 3.3",-1)
      Restore PU238TJEFF33
      Chisqr_Apost("PU238T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If  
  End If

  If P_A_CN = 240 And P_Z_CN = 94 Then
    IF IENDFall = 0 Then
      Restore PU239T
      Ploteval("PU239T","ENDF B VII",-1)
      Restore PU239T
      Chisqr_Apost("PU239T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If  
    If IENDFall = 1 Then
      Restore PU239TJEFF311
      Ploteval("PU239T","JEFF 3.1.1",-1)
      Restore PU239TJEFF311
      Chisqr_Apost("PU239T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore PU239TJEFF33
      Ploteval("PU239T","JEFF 3.3",-1)
      Restore PU239TJEFF33
      Chisqr_Apost("PU239T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 3 Then
      Restore PU239TLOHENGRIN
      Ploteval("PU239T","LOHENGRIN",-1)
      Restore PU239TLOHENGRIN
      Chisqr_Apost("PU239T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"LOHENGRIN")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then
      Restore PU239TJEFF33
      Ploteval("PU239T","JEFF 3.3",0)
      Restore PU239TJEFF33
      Chisqr_Apost("PU239T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "PU239T (APOST,JEFF3.3): Chisqr = ";Chilin     
      Restore PU239TLOHENGRIN
      Ploteval("PU239T","LOHENGRIN",0)
      Restore PU239TLOHENGRIN
      Chisqr_Apost("PU239T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "PU239T (APOST,LOHENGRIN): Chisqr = ";Chilin     
    End If  
    If Instr(C_Fitoption,"ZEO") > 0 Then
      Scope
        Dim As Single ZEO_exp, d_ZEO_exp
        Restore Zeo_PU239T
        Read ZEO_exp
        Read d_ZEO_exp
        Chisqr_Fit = ((ZEO_exp - ZEO_GEF) / d_ZEO_exp)^2
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
        Print #Fitlog, "PU239T (Zeo, Lohengrin): Chisqr = ";Csng(Chisqr_Fit),"exp:";ZEO_exp,"GEF:";ZEO_GEF           
      End Scope
    End If
    IF Instr(C_Fitoption,"NUBAR") > 0 Then
      Restore nubar_PU239T
      Read nubar_exp
      Read d_nubar_exp
      Chisqr_Fit = ( (Nmean - nubar_exp)/ d_nubar_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit * 10
      Print #Fitlog, "Pu239T (NUBAR): Chisqr = ";Csng(Chisqr_Fit);"(/10)","exp:";nubar_exp,"GEF:";Nmean  
    End If    
    If Instr(C_Fitoption,"NUDEL") > 0 Then
      Restore nudel_PU239T
      Read nudel_exp
      Read d_nudel_exp
      Chisqr_Fit = ( (R_nu_delayed * 0.01 - nudel_exp)/ d_nudel_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "PU239T (nudel): Chisqr = ";Csng(Chisqr_Fit),"exp:";nudel_exp*100,"GEF:";R_nu_delayed 
    End If
  End If  

  If P_A_CN = 241 And P_Z_CN = 94 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore PU240T
      Ploteval("PU240T","ENDF B VII",-1)
      Restore PU240T
      Chisqr_Apost("PU240T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore PU240T
      Chisqr_Apost("PU240T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "PU240T (APOST,ENDF): Chisqr = ";Chilin   
    End If  
  End If  
  If P_A_CN = 242 And P_Z_CN = 94 Then
    IF IENDFall = 0 Then
      Restore PU241T
      Ploteval("PU241T","ENDF B VII",-1)
      Restore PU241T
      Chisqr_Apost("PU241T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore PU241TJEFF311
      Ploteval("PU241T","JEFF 3.1.1",-1)
      Restore PU241TJEFF311
      Chisqr_Apost("PU241T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If  
    If IENDFall = 2 Then
      Restore PU241TJEFF33
      Ploteval("PU241T","JEFF 3.3",-1)
      Restore PU241TJEFF33
      Chisqr_Apost("PU241T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore PU241TJEFF33
      Ploteval("PU241T","JEFF 3.3",0)
      Restore PU241TJEFF33
      Chisqr_Apost("PU241T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)    
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "PU241T (APOST,JEFF 3.3): Chisqr = ";Chilin      
    End If
    IF Instr(C_Fitoption,"NUBAR") > 0 Then
      Restore nubar_PU241T
      Read nubar_exp
      Read d_nubar_exp
      Chisqr_Fit = ( (Nmean - nubar_exp)/ d_nubar_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "PU241T (NUBAR): Chisqr = ";Csng(Chisqr_Fit),"exp:";nubar_exp,"GEF:";Nmean    
    End If
  End If  
  If P_A_CN = 243 And P_Z_CN = 94 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore PU242T
      Ploteval("PU242T","ENDF B VII",-1)
      Restore PU242T
      Chisqr_Apost("PU242T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore PU242T
      Chisqr_Apost("PU242T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "PU242T (APOST,ENDF): Chisqr = ";Chilin   
    End If  
  End If  
  If P_A_CN = 228 And P_Z_CN = 90 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore TH227T
      Ploteval("TH227T","ENDF B VII",-1)
      Restore TH227T
      Chisqr_Apost("TH227T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore TH227T
      Chisqr_Apost("TH227T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "TH227T (APOST,ENDF): Chisqr = ";Chilin   
    End If  
  End If  
  If P_A_CN = 230 And P_Z_CN = 90 Then
    IF IENDFall = 0 Then
      Restore TH229T
      Ploteval("TH229T","ENDF B VII",-1)
      Restore TH229T
      Chisqr_Apost("TH229T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 3 Then
      Restore TH229TLOHENGRIN
      Ploteval("TH229T","LOHENGRIN",-1)
      Restore TH229TLOHENGRIN
      Chisqr_Apost("TH229T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"LOHENGRIN")
    End If  
    If Instr(C_Fitoption,"APOST") > 0 Then
      Restore TH229TLOHENGRIN
      Ploteval("TH229T","LOHENGRIN",0)
      Restore TH229TLOHENGRIN
      Chisqr_Apost("TH229T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "TH229T (APOST,LOHENGRIN): Chisqr = ";Chilin     
    End If  
    If Instr(C_Fitoption,"ZEO") > 0 Then
      Scope
        Dim As Single ZEO_exp, d_ZEO_exp
        Restore Zeo_TH229T
        Read ZEO_exp
        Read d_ZEO_exp
        Chisqr_Fit = ((ZEO_exp - ZEO_GEF) / d_ZEO_exp)^2
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
        Print #Fitlog, "TH229T (Zeo,LOHENGRIN): Chisqr = ";Csng(Chisqr_Fit),"exp:";ZEO_exp,"GEF:";ZEO_GEF           
      End Scope
    End If
    
  End If  
  If P_A_CN = 233 And P_Z_CN = 92 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore U232T
      Ploteval("U232T","ENDF B VII",-1)
      Restore U232T
      Chisqr_Apost("U232T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore U232T
      Chisqr_Apost("U232T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "U232T (APOST,ENDF): Chisqr = ";Chilin   
    End If  
  End If  
  If P_A_CN = 234 And P_Z_CN = 92 Then
    If IENDFall = 0 Then
      Restore U233T
      Ploteval("U233T","ENDF B VII",-1)
      Restore U233T
      Chisqr_Apost("U233T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If 
    If IENDFall = 1 Then
      Restore U233TJEFF311
      Ploteval("U233T","JEFF 3.1.1",-1)
      Restore U233TJEFF311
      Chisqr_Apost("U233T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
     If IENDFall = 2 Then
      Restore U233TJEFF33
      Ploteval("U233T","JEFF 3.3",-1)
      Restore U233TJEFF33
      Chisqr_Apost("U233T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 3 Then
      Restore U233TLOHENGRIN
      Ploteval("U233T","LOHENGRIN",-1)
      Restore U233TLOHENGRIN
      Chisqr_Apost("U233T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"LOHENGRIN")
    End If
    IF Instr(C_Fitoption,"NUBAR") > 0 Then
      Restore nubar_U233T
      Read nubar_exp
      Read d_nubar_exp
      Chisqr_Fit = ( (Nmean - nubar_exp)/ d_nubar_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "U233T (NUBAR): Chisqr = ";Csng(Chisqr_Fit),"exp:";nubar_exp,"GEF:";Nmean     
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then
      Restore U233TLOHENGRIN
      Ploteval("U233T","LOHENGRIN",0)
      Restore U233TLOHENGRIN
      Chisqr_Apost("U233T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "U233T (APOST,LOHENGRIN): Chisqr = ";Chilin    
    End If  
    If Instr(C_Fitoption,"TKEPRE") > 0 Then
      Restore TKEPRE_U233T
      Read TKE_exp
      Read d_TKE_exp
      Chisqr_Fit = ( (TKEmean_pre - TKE_exp)/ d_TKE_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "U233T (TKEpre): Chisqr = ";Csng(Chisqr_Fit),"exp:";TKE_exp,"GEF:";TKEmean_pre    
    End If
    If Instr(C_Fitoption,"TKEPOST") > 0 Then
      Restore TKEPOST_U233T
      Read TKE_exp
      Read d_TKE_exp
      Chisqr_Fit = ( (TKEmean_post - TKE_exp)/ d_TKE_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "U233T (TKEpost): Chisqr = ";Csng(Chisqr_Fit),"exp:";TKE_exp,"GEF:";TKEmean_post    
    End If
  End If  
  If P_A_CN = 236 And P_Z_CN = 92 Then
    If IENDFall = 0 Then
      Restore U235T
      Ploteval("U235T","ENDF B VII",-1)
      Restore U235T
      Chisqr_Apost("U235T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If  
    If IENDFall = 1 Then
      Restore U235TJEFF311
      Ploteval("U235T","JEFF 3.1.1",-1)
      Restore U235TJEFF311
      Chisqr_Apost("U235T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF") 
    End If
    If IENDFall = 2 Then  
      Restore U235TJEFF33
      Ploteval("U235T","JEFF 3.3",-1)
      Restore U235TJEFF33
      Chisqr_Apost("U235T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")  
    End If  
    If IENDFall = 3 Then
      Restore U235TLOHENGRIN
      Ploteval("U235T","LOHENGRIN",-1)
      Restore U235TLOHENGRIN
      Chisqr_Apost("U235T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"LOHENGRIN")  
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then
      Restore U235TJEFF33
      Ploteval("U235T","JEFF 3.3",0)
      Restore U235TJEFF33
      Chisqr_Apost("U235T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin * 10
      Print #Fitlog, "U235T (APOST,JEFF 3.3): Chisqr = ";Chilin * 10;"(/10)"    
      Restore U235TLOHENGRIN
      Ploteval("U235T","LOHENGRIN",0)
      Restore U235TLOHENGRIN
      Chisqr_Apost("U235T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin * 10
      Print #Fitlog, "U235T (APOST,LOHENGRIN): Chisqr = ";Chilin * 10;"(/10)"    
    End If
    If Instr(C_Fitoption,"ZEO") > 0 Then
      Scope
        Dim As Single ZEO_exp, d_ZEO_exp
        Restore Zeo_U235T
        Read ZEO_exp
        Read d_ZEO_exp
        Chisqr_Fit = ((ZEO_exp - ZEO_GEF) / d_ZEO_exp)^2
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
        Print #Fitlog, "U235T (Zeo, Lohengrin): Chisqr = ";Csng(Chisqr_Fit),"exp:";ZEO_exp,"GEF:";ZEO_GEF           
      End Scope
    End If
    If Instr(C_Fitoption,"ZPOST") > 0 Then
      Scope 
        Dim As Single Chisqr_single
        Dim As Integer IZ, IZfirst, IZlast
        Restore Z_U235T
        Read IZfirst, IZlast
        Redim As Single Zyield(IZfirst To IZlast)
        Redim As SIngle dZyield(IZfirst To IZlast)
        For IZ = IZfirst To IZlast
          Read Zyield(IZ)
        Next IZ
        For IZ = IZfirst To IZlast
          Read dZyield(IZ)
        Next IZ
        If Fitloglevel > 1 Then Print #Fitlog, " Z"; "  Yield(exp)  d_exp"," Yield(GEF)"," Chisqr"        
        For IZ = IZfirst + 1 to IZlast - 1  ' exp. border values may be cut!
          Chisqr_single =_
             ( (Zyield(IZ) - ZPOST(IZ) )/dZyield(IZ))^2
          If Fitloglevel > 1 Then Print #Fitlog, IZ;Zyield(IZ),dZyield(IZ),Csng(ZPOST(IZ)),Chisqr_Single
          Chisqr_Fit = Chisqr_Fit + Chisqr_single   
        Next IZ
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
        Print #Fitlog, "U235T (Zyield, Lohengrin): Chisqr = ";Csng(Chisqr_Fit)           
       End Scope    
    End If
    If Instr(C_Fitoption,"ZVSAPOST") > 0 Then
      Scope
        Dim As Single Chisqr_single
        Dim As Integer IA, IAfirst, IAlast
        Restore ZvsApost_U235T
        Read IAfirst, IAlast
        ReDim As Single ZovAmean(IAfirst To IAlast)
        ReDim As Single dZovAmean(IAfirst To IAlast)
        For IA = IAfirst To IAlast
          Read ZovAmean(IA)
        Next IA
        For IA = IAfirst To IAlast
          Read dZovAmean(IA)
        Next IA
        Chisqr_Fit = 0
        If Fitloglevel > 1 Then Print #Fitlog, " A"; "  <Z>exp "," d_exp"," <Z>GEF",," Chisqr"
        For IA = IAfirst to IAlast
          Chisqr_single =_
             ( (ZovAmean(IA) - (ZPOLARPOST(IA)+IA*P_Z_CN/P_A_CN) )/dZovAmean(IA))^2
             If Fitloglevel > 1 Then Print #Fitlog, IA;ZovAmean(IA),dZovAmean(IA),ZPOLARPOST(IA)+IA*P_Z_CN/P_A_CN,Chisqr_Single
          Chisqr_Fit = Chisqr_Fit + Chisqr_single   
        Next IA
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
        Print #Fitlog, "U235T (ZvsApost): Chisqr = ";Csng(Chisqr_Fit)  
      End Scope
    End If
    IF Instr(C_Fitoption,"NUBAR") > 0 Then
      Restore nubar_U235T
      Read nubar_exp
      Read d_nubar_exp
      Chisqr_Fit = ( (Nmean - nubar_exp)/ d_nubar_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit * 10
      Print #Fitlog, "U235T (NUBAR): Chisqr = ";Csng(Chisqr_Fit*10);"(/10)","exp:";nubar_exp,"GEF:";Nmean  
    End If
    IF Instr(C_Fitoption,"TKEPRE") > 0 Then
      Restore TKEPRE_U235T
      Read TKE_exp
      Read d_TKE_exp
      Chisqr_Fit = ( (TKEmean_pre - TKE_exp)/ d_TKE_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "U235T (TKEpre): Chisqr = ";Csng(Chisqr_Fit),"exp:";TKE_exp,"GEF:";TKEmean_pre    
    End If
    If Instr(C_Fitoption,"NUDEL") > 0 Then
      Restore nudel_U235T
      Read nudel_exp
      Read d_nudel_exp
      Chisqr_Fit = ( (R_nu_delayed * 0.01 - nudel_exp)/ d_nudel_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "U235T (nudel): Chisqr = ";Csng(Chisqr_Fit),"exp:";nudel_exp*100,"GEF:";R_nu_delayed     
    End If
  End If
  If P_A_CN = 237 And P_Z_CN = 92 Then
    If (B_Print_Chisquare = 1  And IENDFall = 2) Or B_Print_Chisquare = 0 Then
      Restore U236TJEFF33
      Ploteval("U236T","JEFF 3.3",-1)
      Restore U236TJEFF33
      Chisqr_Apost("U236T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")  
    End If  
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore U236TJEFF33
      Chisqr_Apost("U236T",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "U236T (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If  
  End If
End If

' Fast-neutron-induced fission
If (EMODE = 2 And (P_E_Exc >= 0.4 And P_E_Exc <= 2) ) Or _
   ( EMODE Mod 10 = 3 And Instr(C_Espectrum,"F") > 0 ) Then  ' Distribution of E*
  If P_A_CN = 242 And P_Z_CN = 95 Then
    If IENDFall = 0 Then
      Restore AM241F
      Ploteval("AM241F","ENDF B VII",-1)
      Restore AM241F
      Chisqr_Apost("AM241F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore AM241FJEFF311
      Ploteval("AM241F","JEFF 3.1.1",-1)
      Restore AM241FJEFF311
      Chisqr_Apost("AM241F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If  
    If IENDFall = 2 Then
      Restore AM241FJEFF33
      Ploteval("AM241F","JEFF 3.3",-1)
      Restore AM241FJEFF33
      Chisqr_Apost("AM241F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If  
    If Instr(C_Fitoption,"APOST") > 0 Then
      Restore AM241FJEFF33
      Ploteval("AM241F","JEFF 3.3",0)
      Restore AM241FJEFF33
      Chisqr_Apost("AM241F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "AM241F (APOST,JEFF 3.3): Chisqr = ";Chilin    
    End If    
  End If
  If P_A_CN = 243 And P_Z_CN = 95 Then
    If (B_Print_Chisquare = 1  And IENDFall = 1) Or B_Print_Chisquare = 0 Then
      Restore AM242MFJEFF311
      Ploteval("AM242F","JEFF 3.1.1",-1)
      Restore AM242MFJEFF311
      Chisqr_Apost("AM242F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore AM242MFJEFF311
      Chisqr_Apost("AM242F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "AM242F (APOST,JEFF 3.1.1): Chisqr = ";Chilin   
    End If 
  End If
  If P_A_CN = 244 And P_Z_CN = 95 Then
    If IENDFall = 0 Then
      Restore AM243F
      Ploteval("AM243F","ENDF B VII",-1)
      Restore AM243F
      Chisqr_Apost("AM243F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore AM243FJEFF311
      Ploteval("AM243F","JEFF 3.1.1",-1)
      Restore AM243FJEFF311
      Chisqr_Apost("AM243F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore AM243FJEFF33
      Ploteval("AM243F","JEFF 3.3",-1)
      Restore AM243FJEFF33
      Chisqr_Apost("AM243F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
 /' If Instr(C_Fitoption,"APOST") > 0 Then
      Restore AM243FJEFF33      ' These data are probably wrong!!!
      Ploteval("AM243F","JEFF 3.3",0)
      Restore AM243FJEFF33
      Chisqr_Apost("AM243F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "AM243F (APOST,JEFF 3.3): Chisqr = ";Chilin    
    End If '/    
    If Instr(C_Fitoption,"APOST") > 0 Then
      Restore AM243FJEFF311     
      Ploteval("AM243F","JEFF 3.1.1",0)
      Restore AM243FJEFF311
      Chisqr_Apost("AM243F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "AM243F (APOST,JEFF 3.1.1): Chisqr = ";Chilin    
    End If    
  End If
  If P_A_CN = 243 And P_Z_CN = 96 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore CM242F
      Ploteval("CM242F","ENDF B VII",-1)
      Restore CM242F
      Chisqr_Apost("CM242F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore CM242F
      Chisqr_Apost("CM242F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "CM242F (APOST,JEFF 3.1.1): Chisqr = ";Chilin   
    End If 
  End If
  If P_A_CN = 244 And P_Z_CN = 96 Then
    IF IENDFall = 0 Then
      Restore CM243F
      Ploteval("CM243F","ENDF B VII",-1)
      Restore CM243F
      Chisqr_Apost("CM243F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore CM243FJEFF311
      Ploteval("CM243F","JEFF 3.1.1",-1)
      Restore CM243FJEFF311
      Chisqr_Apost("CM243F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If  
    If IENDFall = 2 Then
      Restore CM243FJEFF33
      Ploteval("CM243F","JEFF 3.3",-1)
      Restore CM243FJEFF33
      Chisqr_Apost("CM243F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If  
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore CM243FJEFF33
      Ploteval("CM243F","JEFF 3.3",0)
      Restore CM243FJEFF33
      Chisqr_Apost("CM243F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "CM243F (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If 
  End If
  If P_A_CN = 245 And P_Z_CN = 96 Then
    If IENDFall = 0 Then
      Restore CM244F
      Ploteval("CM244F","ENDF B VII",-1)
      Restore CM244F
      Chisqr_Apost("CM244F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore CM244FJEFF311
      Ploteval("CM244F","JEFF 3.1.1",-1)
      Restore CM244FJEFF311
      Chisqr_Apost("CM244F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore CM244FJEFF33
      Ploteval("CM244F","JEFF 3.3",-1)
      Restore CM244FJEFF33
      Chisqr_Apost("CM244F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore CM244FJEFF33
      Ploteval("CM244F","JEFF 3.3",0)
      Restore CM244FJEFF33
      Chisqr_Apost("CM244F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "CM244F (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If 
  End If
  If P_A_CN = 246 And P_Z_CN = 96 Then
    If IENDFall = 1 Then
      Restore CM245FJEFF311
      Ploteval("CM245F","JEFF 3.1.1",-1)
      Restore CM245FJEFF311
      Chisqr_Apost("CM245F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore CM245FJEFF33
      Ploteval("CM245F","JEFF 3.3",-1)
      Restore CM245FJEFF33
      Chisqr_Apost("CM245F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If  
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore CM245FJEFF33
      Ploteval("CM245F","JEFF 3.3",0)
      Restore CM245FJEFF33
      Chisqr_Apost("CM245F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "CM245F (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If 
  End If
  If P_A_CN = 247 And P_Z_CN = 96 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore CM246F
      Ploteval("CM246F","ENDF B VII",-1)
      Restore CM246F
      Chisqr_Apost("CM246F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If  
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore CM246F
      Chisqr_Apost("CM246F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "CM246F (APOST,ENDF): Chisqr = ";Chilin   
    End If 
  End If
  If P_A_CN = 249 And P_Z_CN = 96 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore CM248F
      Ploteval("CM248F","ENDF B VI",-1)
      Restore CM248F
      Chisqr_Apost("CM248F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore CM248F
      Chisqr_Apost("CM248F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "CM248F (APOST,ENDF): Chisqr = ";Chilin   
    End If 
  End If  
  If P_A_CN = 238 And P_Z_CN = 93 Then
    If IENDFall = 0 Then
      Restore NP237F
      Ploteval("NP237F","ENDF B VII",-1)
      Restore NP237F
      Chisqr_Apost("NP237F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore NP237FJEFF311
      Ploteval("NP237F","JEFF 3.1.1",-1)
      Restore NP237FJEFF311
      Chisqr_Apost("NP237F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore NP237FJEFF33
      Ploteval("NP237F","JEFF 3.3",-1)
      Restore NP237FJEFF33
      Chisqr_Apost("NP237F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore NP237FJEFF33
      Ploteval("NP237F","JEFF 3.3",0)
      Restore NP237FJEFF33
      Chisqr_Apost("NP237F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "NP237F (APOST,ENDF): Chisqr = ";Chilin   
    End If 
  End If
  If P_A_CN = 239 And P_Z_CN = 93 Then
    If IENDFall = 0 Then
      Restore NP238F
      Ploteval("NP238F","ENDF B VII",-1)
      Restore NP238F
      Chisqr_Apost("NP238F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore NP238FJEFF311
      Ploteval("NP238F","JEFF 3.1,1",-1)
      Restore NP238FJEFF311
      Chisqr_Apost("NP238F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore NP238FJEFF33
      Ploteval("NP238F","JEFF 3.3",-1)
      Restore NP238FJEFF33
      Chisqr_Apost("NP238F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore NP238FJEFF33
      Ploteval("NP238F","JEFF 3.3",0)
      Restore NP238FJEFF33
      Chisqr_Apost("NP238F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "NP238F (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If 
  End If  
  If P_A_CN = 232 And P_Z_CN = 91 Then
    Restore PA231F
    Ploteval("PA231F","ENDF B VII",-1)
    Restore PA231F
    Chisqr_Apost("PA231F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
    PrintChisqr(Chilin,"ENDF")
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "PA231F (APOST,ENDF): Chisqr = ";Chilin   
    End If
  End If
  If P_A_CN = 239 And P_Z_CN = 94 Then
    If IENDFall = 0 Then
      Restore PU238F
      Ploteval("PU238F","ENDF B VII",-1)
      Restore PU238F
      Chisqr_Apost("PU238F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore PU238FJEFF311
      Ploteval("PU238F","JEFF 3.1.1",-1)
      Restore PU238FJEFF311
      Chisqr_Apost("PU238F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore PU238FJEFF33
      Ploteval("PU238F","JEFF 3.3",-1)
      Restore PU238FJEFF33
      Chisqr_Apost("PU238F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore PU238FJEFF33
      Ploteval("PU238F","JEFF 3.3",0)
      Restore PU238FJEFF33
      Chisqr_Apost("PU238F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "PU238F (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If   
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore PU238FJEFF33
      Chisqr_Apost("PU238F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "PU238F (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If  
  End If  
  If P_A_CN = 240 And P_Z_CN = 94 Then
    IF IENDFall = 0 Then
      Restore PU239F
      Ploteval("PU239F","ENDF B VII",-1)
      Restore PU239F
      Chisqr_Apost("PU239F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore PU239FJEFF311
      Ploteval("PU239F","JEFF 3.1.1",-1)
      Restore PU239FJEFF311
      Chisqr_Apost("PU239F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore PU239FJEFF33
      Ploteval("PU239F","JEFF 3.3",-1)
      Restore PU239FJEFF33
      Chisqr_Apost("PU239F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore PU239FJEFF33
      Ploteval("PU239F","JEFF 3.3",0)
      Restore PU239FJEFF33
      Chisqr_Apost("PU239F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "PU239F (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If  
    IF Instr(C_Fitoption,"TKEPRE") > 0 Then
      Restore TKEPRE_PU239F
      Read TKE_exp
      Read d_TKE_exp
      Chisqr_Fit = ( (TKEmean_pre - TKE_exp)/ d_TKE_exp )^2 
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "PU239F (TKEpre): Chisqr = ";Csng(Chisqr_Fit),"exp:";TKE_exp,"GEF:";TKEmean_pre   
    End If
  End If       
  If P_A_CN = 241 And P_Z_CN = 94 Then
    If IENDFall = 0 Then
      Restore PU240F
      Ploteval("PU240F","ENDF B VII",-1)
      Restore PU240F
      Chisqr_Apost("PU240F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore PU240FJEFF311
      Ploteval("PU240F","JEFF 3.1.1",-1)
      Restore PU240FJEFF311
      Chisqr_Apost("PU240F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore PU240FJEFF33
      Ploteval("PU240F","JEFF 3.3",-1)
      Restore PU240FJEFF33
      Chisqr_Apost("PU240F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore PU240FJEFF33
      Ploteval("PU240F","JEFF 3.3",0)
      Restore PU240FJEFF33
      Chisqr_Apost("PU240F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "PU240F (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If  
    IF Instr(C_Fitoption,"TKEPRE") > 0 Then
      Restore TKEPRE_PU240F
      Read TKE_exp
      Read d_TKE_exp
      Chisqr_Fit = ( (TKEmean_pre - TKE_exp)/ d_TKE_exp )^2 
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "PU240F (TKEpre): Chisqr = ";Csng(Chisqr_Fit),"exp:";TKE_exp,"GEF:";TKEmean_pre  
    End If         
    IF Instr(C_Fitoption,"TKEPOST") > 0 Then
      Restore TKEPOST_PU240F
      Read TKE_exp
      Read d_TKE_exp
      Chisqr_Fit = ( (TKEmean_post - TKE_exp)/ d_TKE_exp )^2 
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "PU240F (TKEpost: Chisqr = ";Csng(Chisqr_Fit),"exp:";TKE_exp,"GEF:";TKEmean_post   
    End If   
  End If    
  If P_A_CN = 242 And P_Z_CN = 94 Then
    IF IENDFall = 0 Then
      Restore PU241F
      Ploteval("PU241F","ENDF B VII",-1)
      Restore PU241F
      Chisqr_Apost("PU241F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore PU241FJEFF311
      Ploteval("PU241F","JEFF 3.1.1",-1)
      Restore PU241FJEFF311
      Chisqr_Apost("PU241F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If 
    If IENDFall = 2 Then
      Restore PU241FJEFF33
      Ploteval("PU241F","JEFF 3.3",-1)
      Restore PU241FJEFF33
      Chisqr_Apost("PU241F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If 
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore PU241FJEFF33
      Ploteval("PU241F","JEFF 3.3",0)
      Restore PU241FJEFF33
      Chisqr_Apost("PU241F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "PU241F (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If  
  End If        
  If P_A_CN = 243 And P_Z_CN = 94 Then
    If IENDFall = 0 Then
      Restore PU242F
      Ploteval("PU242F","ENDF B VII",-1)
      Restore PU242F
      Chisqr_Apost("PU242F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 2 Then
      Restore PU242FJEFF33
      Ploteval("PU242F","JEFF 3.3",-1)
      Restore PU242FJEFF33
      Chisqr_Apost("PU242F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore PU242FJEFF33
      Ploteval("PU242F","JEFF 3.3",0)
      Restore PU242FJEFF33
      Chisqr_Apost("PU242F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "PU242F (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If  
    IF Instr(C_Fitoption,"TKEPRE") > 0 Then
      Restore TKEPRE_PU242F
      Read TKE_exp
      Read d_TKE_exp
      Chisqr_Fit = ( (TKEmean_pre - TKE_exp)/ d_TKE_exp )^2 
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "PU242F (TKEpre): Chisqr = ";Csng(Chisqr_Fit),"exp:";TKE_exp,"GEF:";TKEmean_pre   
    End If        
    IF Instr(C_Fitoption,"TKEPOST") > 0 Then
      Restore TKEPOST_PU242F
      Read TKE_exp
      Read d_TKE_exp
      Chisqr_Fit = ( (TKEmean_post - TKE_exp)/ d_TKE_exp )^2 
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "PU242F (TKEpost: Chisqr = ";Csng(Chisqr_Fit),"exp:";TKE_exp,"GEF:";TKEmean_post  
    End If         
  End If    
  If P_A_CN = 233 And P_Z_CN = 90 Then
    If IENDFall = 0 Then
      Restore TH232F
      Ploteval("TH232F","ENDF B VII",-1)
      Restore TH232F
      Chisqr_Apost("TH232F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore TH232FJEFF311
      Ploteval("TH232F","JEFF 3.1.1",-1)
      Restore TH232FJEFF311
      Chisqr_Apost("TH232F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore TH232FJEFF33
      Ploteval("TH232F","JEFF 3.3",-1)
      Restore TH232FJEFF33
      Chisqr_Apost("TH232F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore TH232FJEFF33
      Ploteval("TH232F","JEFF 3.3",0)
      Restore TH232FJEFF33
      Chisqr_Apost("TH232F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "TH232F (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If  
  End If      
  If P_A_CN = 234 And P_Z_CN = 92 Then
    IF IENDFall = 0 Then
      Restore U233F
      Ploteval("U233F","ENDF B VII",-1)
      Restore U233F
      Chisqr_Apost("U233F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore U233FJEFF311
      Ploteval("U233F","JEFF 3.1.1",-1)
      Restore U233FJEFF311
      Chisqr_Apost("U233F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore U233FJEFF33
      Ploteval("U233F","JEFF 3.3",-1)
      Restore U233FJEFF33
      Chisqr_Apost("U233F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore U233FJEFF33
      Ploteval("U233F","JEFF 3.3",0)
      Restore U233FJEFF33
      Chisqr_Apost("U233F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "U233F (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If  
  End If        
  If P_A_CN = 235 And P_Z_CN = 92 Then
    If IENDFall = 0 Then
      Restore U234F
      Ploteval("U234F","ENDF B VII",-1)
      Restore U234F
      Chisqr_Apost("U234F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore U234FJEFF311
      Ploteval("U234F","JEFF 3.1.1",-1)
      Restore U234FJEFF311
      Chisqr_Apost("U234F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore U234FJEFF33
      Ploteval("U234F","JEFF 3.3",-1)
      Restore U234FJEFF33
      Chisqr_Apost("U234F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore U234FJEFF33
      Ploteval("U234F","JEFF 3.3",0)
      Restore U234FJEFF33
      Chisqr_Apost("U234F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "U234F (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If  
  End If        
  If P_A_CN = 236 And P_Z_CN = 92 Then
    IF IENDFall = 0 Then
      Restore U235F
      Ploteval("U235F","ENDF B VII",-1)
      Restore U235F
      Chisqr_Apost("U235F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore U235FJEFF311
      Ploteval("U235F","JEFF 3.1.1",-1)
      Restore U235FJEFF311
      Chisqr_Apost("U235F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore U235FJEFF33
      Ploteval("U235F","JEFF 3.3",-1)
      Restore U235FJEFF33
      Chisqr_Apost("U235F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore U235FJEFF33
      Ploteval("U235F","JEFF 3.3",-1)
      Restore U235FJEFF33
      Chisqr_Apost("U235F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "U235F (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If  
  End If       
  If P_A_CN = 237 And P_Z_CN = 92 Then
    If IENDFall = 0 Then
      Restore U236F
      Ploteval("U236F","ENDF B VII",-1)
      Restore U236F
      Chisqr_Apost("U236F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore U236FJEFF311
      Ploteval("U236F","JEFF 3.1.1",-1)
      Restore U236FJEFF311
      Chisqr_Apost("U236F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If  
    If IENDFall = 2 Then
      Restore U236FJEFF33
      Ploteval("U236F","JEFF 3.3",-1)
      Restore U236FJEFF33
      Chisqr_Apost("U236F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If  
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore U236FJEFF33
      Ploteval("U236F","JEFF 3.3",0)
      Restore U236FJEFF33
      Chisqr_Apost("U236F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "U236F (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If 
  End If      
  If P_A_CN = 238 And P_Z_CN = 92 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore U237F
      Ploteval("U237F","ENDF B VII",-1)
      Restore U237F
      Chisqr_Apost("U237F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore U237F
      Chisqr_Apost("U237F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "U237F (APOST,ENDF): Chisqr = ";Chilin   
    End If 
  End If     
  If P_A_CN = 239 And P_Z_CN = 92 Then
    If IENDFall = 0 Then
      Restore U238F
      Ploteval("U238F","ENDF B VII",-1)
      Restore U238F
      Chisqr_Apost("U238F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If  
    If IENDFall = 1 Then
      Restore U238FJEFF311
      Ploteval("U238F","JEFF 3.1.1",-1)
      Restore U238FJEFF311
      Chisqr_Apost("U238F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If  
    If IENDFall = 2 Then
      Restore U238FJEFF33
      Ploteval("U238F","JEFF 3.3",-1)
      Restore U238FJEFF33
      Chisqr_Apost("U238F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore U238FJEFF33
      Ploteval("U238F","JEFF 3.3",0)
      Restore U238FJEFF33
      Chisqr_Apost("U238F",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "U238F (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If 
  End If      
End If

' HE (14 MeV) -neutron-induced fission
If EMODE = 2 And (P_E_EXC >= 13.5 And P_E_Exc <= 14.5) Then
  If P_A_CN = 233 And P_Z_CN = 90 Then
    If IENDFall = 0 Then
      Restore TH232HE
      Ploteval("TH232HE","ENDF B VII",-1)
      Restore TH232HE
      Chisqr_Apost("TH232HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore TH232HJEFF311
      Ploteval("TH232HE","JEFF 3.1.1",-1)
      Restore TH232HJEFF311
      Chisqr_Apost("TH232HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore TH232HJEFF33
      Ploteval("TH232HE","JEFF 3.3",-1)
      Restore TH232HJEFF33
      Chisqr_Apost("TH232HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore TH232HJEFF33
      Ploteval("TH232HE","JEFF 3.3",0)
      Restore TH232HJEFF33
      Chisqr_Apost("TH232HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "TH232H (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If
  End If
  If P_A_CN = 234 And P_Z_CN = 92 Then
    If IENDFall = 0 Then
      Restore U233HE
      Ploteval("U233HE","ENDF B VII",-1)
      Restore U233HE
      Chisqr_Apost("U233HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore U233HJEFF311
      Ploteval("U233HE","JEFF 3.1.1",-1)
      Restore U233HJEFF311
      Chisqr_Apost("U233HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore U233HJEFF33
      Ploteval("U233HE","JEFF 3.3",-1)
      Restore U233HJEFF33
      Chisqr_Apost("U233HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore U233HJEFF33
      Ploteval("U233HE","JEFF 3.3",0)
      Restore U233HJEFF33
      Chisqr_Apost("U233HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "U233H (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If 
  End If
  If P_A_CN = 235 And P_Z_CN = 92 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore U234HE
      Ploteval("U234HE","ENDF B VII",-1)
      Restore U234HE
      Chisqr_Apost("U234HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore U234HE
      Chisqr_Apost("U234HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "U234H (APOST,ENDF): Chisqr = ";Chilin   
    End If 
  End If
  If P_A_CN = 236 And P_Z_CN = 92 Then
    If IENDFall = 0 Then
      Restore U235HE
      Ploteval("U235HE","ENDF B VII",-1)
      Restore U235HE
      Chisqr_Apost("U235HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 1 Then
      Restore U235HJEFF311
      Ploteval("U235HE","JEFF 3.1.1",-1)
      Restore U235HJEFF311
      Chisqr_Apost("U235HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 2 Then
      Restore U235HJEFF33
      Ploteval("U235HE","JEFF 3.3",-1)
      Restore U235HJEFF33
      Chisqr_Apost("U235HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore U235HJEFF33
      Ploteval("U235HE","JEFF 3.3",-1)
      Restore U235HJEFF33
      Chisqr_Apost("U235HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "U235H (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If 
    IF Instr(C_Fitoption,"TKEPOST") > 0 Then
      Restore TKEPOST_U235H
      Read TKE_exp
      Read d_TKE_exp
      Chisqr_Fit = ( (TKEmean_pre - TKE_exp)/ d_TKE_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "U235H (TKEpre): Chisqr = ";Csng(Chisqr_Fit),"exp:";TKE_exp,"GEF:";TKEmean_pre  
    End If      
    
  End If 
  If P_A_CN = 237 And P_Z_CN = 92 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore U236HE
      Ploteval("U236HE","ENDF B VII",-1)
      Restore U236HE
      Chisqr_Apost("U236HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore U236HE
      Chisqr_Apost("U236HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "U236H (APOST,JEFF 3.3): Chisqr = ";Chilin   
    End If 
  End If
  If P_A_CN = 239 And P_Z_CN = 92 Then
    IF IENDFall = 0 Then
      Restore U238HE
      Ploteval("U238HE","ENDF B VII",-1)
      Restore U238HE
      Chisqr_Apost("U238HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If IENDFall = 2 Then
      Restore U238HJEFF33
      Ploteval("U238HE","JEFF 3.3",-1)
      Restore U238HJEFF33
      Chisqr_Apost("U238HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If IENDFall = 1 Then
      Restore U238HJEFF311
      Ploteval("U238HE","JEFF 3.1.1",-1)
      Restore U238HJEFF311
      Chisqr_Apost("U238HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"JEFF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore U238HJEFF33
      Ploteval("U238HE","JEFF 3.1.1",0)
      Restore U238HJEFF33
      Chisqr_Apost("U238HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "U238H (APOST,ENDF): Chisqr = ";Chilin   
    End If 
  End If
  If P_A_CN = 238 And P_Z_CN = 93 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore NP237HE
      Ploteval("NP237HE","ENDF B VII",-1)
      Restore NP237HE
      Chisqr_Apost("NP237HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore NP237HE
      Chisqr_Apost("NP237HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "NP237H (APOST,ENDF): Chisqr = ";Chilin   
    End If 
  End If
  If P_A_CN = 240 And P_Z_CN = 94 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore PU239HE
      Ploteval("PU239HE","ENDF B VII",-1)
      Restore PU239HE
      Chisqr_Apost("PU239HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore PU239HE
      Chisqr_Apost("PU239HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "PU239H (APOST,ENDF): Chisqr = ";Chilin   
    End If 
    IF Instr(C_Fitoption,"TKEPRE") > 0 Then
      Restore TKEPRE_PU239H
      Read TKE_exp
      Read d_TKE_exp
      Chisqr_Fit = ( (TKEmean_pre - TKE_exp)/ d_TKE_exp )^2
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "PU239H (TKEpre): Chisqr = ";Csng(Chisqr_Fit),"exp:";TKE_exp,"GEF:";TKEmean_pre  
    End If      
    IF Instr(C_Fitoption,"TKEPOST") > 0 Then
      Restore TKEPOST_PU239H
      Read TKE_exp
      Read d_TKE_exp
      Chisqr_Fit = ( (TKEmean_post - TKE_exp)/ d_TKE_exp )^2 
      Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
      Print #Fitlog, "PU239H (TKEpost): Chisqr = ";Csng(Chisqr_Fit),"exp:";TKE_exp,"GEF:";TKEmean_post 
    End If      
  End If
  If P_A_CN = 241 And P_Z_CN = 94 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore PU240HE
      Ploteval("PU240HE","ENDF B VII",-1)
      Restore PU240HE
      Chisqr_Apost("PU240HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore PU240HE
      Chisqr_Apost("PU240HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "PU240H (APOST,ENDF): Chisqr = ";Chilin   
    End If 
  End If
  If P_A_CN = 243 And P_Z_CN = 94 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore PU242HE
      Ploteval("PU242HE","ENDF B VII",-1)
      Restore PU242HE
      Chisqr_Apost("PU242HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore PU242HE
      Chisqr_Apost("PU242HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin
      Print #Fitlog, "PU242H (APOST,ENDF): Chisqr = ";Chilin   
    End If 
  End If
  If P_A_CN = 242 And P_Z_CN = 95 Then
    If (B_Print_Chisquare = 1  And IENDFall = 0) Or B_Print_Chisquare = 0 Then
      Restore AM241HE
      Ploteval("AM241HE","ENDF B VII",-1)
      Restore AM241HE
      Chisqr_Apost("AM241HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      PrintChisqr(Chilin,"ENDF")
    End If
    If Instr(C_Fitoption,"APOST") > 0 Then 
      Restore AM241HE
      Chisqr_Apost("AM242HE",Chilin,Chilog,ChiGEFlin,ChiGEFlog)
      Chisqr_Fit_present = Chisqr_Fit_present + Chilin 
      Print #Fitlog, "AM241H (APOST,ENDF): Chisqr = ";Chilin 
    End If 
  End If
End If

If EMode = 1 And Abs(P_E_EXC - 14) < 3 Then  ' e.-m. excitation at FRS
  If P_A_CN = 222 And P_Z_CN = 90 Then
    IF Instr(C_Fitoption,"ZEMFRS") > 0 Then
      Scope 
        Dim As Single Chisqr_single
        Dim As Integer IZ, IZfirst, IZlast
        Restore Z_TH222em_FRS2000
        Read IZfirst, IZlast
        Redim As Single Zyield(IZfirst To IZlast)
        Redim As SIngle dZyield(IZfirst To IZlast)
        For IZ = IZfirst To IZlast
          Read Zyield(IZ)
        Next IZ
        For IZ = IZfirst To IZlast
          Read dZyield(IZ)
        Next IZ
        If Fitloglevel > 2 Then Print #Fitlog, " Z"; "  Yield(exp)  d_exp"," Yield(GEF)"," Chisqr"        
        For IZ = IZfirst to IZlast
          Chisqr_single =_
             ( (Zyield(IZ) - ZPOST(IZ) )/dZyield(IZ))^2 
          If Fitloglevel > 2 Then Print #Fitlog, IZ;Zyield(IZ),dZyield(IZ),Csng(ZPOST(IZ)),Chisqr_Single
          Chisqr_Fit = Chisqr_Fit + Chisqr_single  
        Next IZ
        If B_graphics = 1 Then
          Close #F_GRAF
          Open "GRAF/"+Csystem+"_Zpost.grf" For Output As #F_GRAF
          Print #F_GRAF,WinTitle
          Print #F_GRAF,"X: Fragment Z"
          Print #F_GRAF,"Y: Yield / %"
          Print #F_GRAF, "P: SCALING(0.6) SYMBOL(2)"
          Print #F_GRAF,"H: X  Y(Data),LT7  DY  Y(GEF),LRT11  "
          For IZ = IZfirst to IZlast
            Print #F_GRAF,IZ,Zyield(IZ),dZyield(IZ),ZPOST(IZ)
          Next IZ          
'          Close #F_GRAF
'          Open "GRAF/"+Csystem+"_Apost.grf" For Append As #F_GRAF 
        End If
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit / 100  
               ' division by 100 to avoid dominating influence on fit
        Print #Fitlog, "TH222em (Zyield): Chisqr = ";Csng(Chisqr_Fit / 100);" ( * 100)"           
       End Scope
     End If
  End If
  If P_A_CN = 226 And P_Z_CN = 90 Then
     IF Instr(C_Fitoption,"ZEMFRS") > 0 Then
      Scope 
        Dim As Single Chisqr_single
        Dim As Integer IZ, IZfirst, IZlast
        Restore Z_TH226em_FRS2000
        Read IZfirst, IZlast
        Redim As Single Zyield(IZfirst To IZlast)
        Redim As SIngle dZyield(IZfirst To IZlast)
        For IZ = IZfirst To IZlast
          Read Zyield(IZ)
        Next IZ
        For IZ = IZfirst To IZlast
          Read dZyield(IZ)
        Next IZ
        If Fitloglevel > 2 Then Print #Fitlog, " Z"; "  Yield(exp)  d_exp"," Yield(GEF)"," Chisqr"        
        For IZ = IZfirst to IZlast
          Chisqr_single =_
             ( (Zyield(IZ) - ZPOST(IZ) )/dZyield(IZ))^2
          If Fitloglevel > 2 Then Print #Fitlog, IZ;Zyield(IZ),dZyield(IZ),Csng(ZPOST(IZ)),Chisqr_Single
          Chisqr_Fit = Chisqr_Fit + Chisqr_single   
        Next IZ
        If B_graphics = 1 Then
          Close #F_GRAF
          Open "GRAF/"+Csystem+"_Zpost.grf" For Output As #F_GRAF
          Print #F_GRAF,WinTitle
          Print #F_GRAF,"X: Fragment Z"
          Print #F_GRAF,"Y: Yield / %"
          Print #F_GRAF, "P: SCALING(0.6) SYMBOL(2)"
          Print #F_GRAF,"H: X  Y(Data),LT7  DY  Y(GEF),LRT11  "
          For IZ = IZfirst to IZlast
            Print #F_GRAF,IZ,Zyield(IZ),dZyield(IZ),ZPOST(IZ)
          Next IZ          
'          Close #F_GRAF
'          Open "GRAF/"+Csystem+"_Apost.grf" For Append As #F_GRAF 
        End If
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit / 100
        Print #Fitlog, "TH226em (Zyield): Chisqr = ";Csng(Chisqr_Fit / 100);" ( * 100)"           
       End Scope
     End If
  End If
  If P_A_CN = 229 And P_Z_CN = 90 Then
     IF Instr(C_Fitoption,"ZEMFRS") > 0 Then
      Scope 
        Dim As Single Chisqr_single
        Dim As Integer IZ, IZfirst, IZlast
        Restore Z_TH229em_FRS2000
        Read IZfirst, IZlast
        Redim As Single Zyield(IZfirst To IZlast)
        Redim As SIngle dZyield(IZfirst To IZlast)
        For IZ = IZfirst To IZlast
          Read Zyield(IZ)
        Next IZ
        For IZ = IZfirst To IZlast
          Read dZyield(IZ)
        Next IZ
        If Fitloglevel > 2 Then Print #Fitlog, " Z"; "  Yield(exp)  d_exp"," Yield(GEF)"," Chisqr"        
        For IZ = IZfirst to IZlast
          Chisqr_single =_
             ( (Zyield(IZ) - ZPOST(IZ) )/dZyield(IZ))^2
          If Fitloglevel > 2 Then Print #Fitlog, IZ;Zyield(IZ),dZyield(IZ),Csng(ZPOST(IZ)),Chisqr_Single
          Chisqr_Fit = Chisqr_Fit + Chisqr_single   
        Next IZ
        If B_graphics = 1 Then
          Close #F_GRAF
          Open "GRAF/"+Csystem+"_Zpost.grf" For Output As #F_GRAF
          Print #F_GRAF,WinTitle
          Print #F_GRAF,"X: Fragment Z"
          Print #F_GRAF,"Y: Yield / %"
          Print #F_GRAF, "P: SCALING(0.6) SYMBOL(2)"
          Print #F_GRAF,"H: X  Y(Data),LT7  DY  Y(GEF),LRT11  "
          For IZ = IZfirst to IZlast
            Print #F_GRAF,IZ,Zyield(IZ),dZyield(IZ),ZPOST(IZ)
          Next IZ          
'          Close #F_GRAF
'          Open "GRAF/"+Csystem+"_Apost.grf" For Append As #F_GRAF 
        End If
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit / 100
        Print #Fitlog, "TH229em (Zyield): Chisqr = ";Csng(Chisqr_Fit / 100);" ( * 100)"            
       End Scope
     End If
  End If
  If P_A_CN = 232 And P_Z_CN = 92 Then
     IF Instr(C_Fitoption,"EMFRS") > 0 Then
      Scope 
        Dim As Single Chisqr_single
        Dim As Integer IZ, IZfirst, IZlast
        Restore Z_U232em_FRS2000
        Read IZfirst, IZlast
        Redim As Single Zyield(IZfirst To IZlast)
        Redim As SIngle dZyield(IZfirst To IZlast)
        For IZ = IZfirst To IZlast
          Read Zyield(IZ)
        Next IZ
        For IZ = IZfirst To IZlast
          Read dZyield(IZ)
        Next IZ
        If Fitloglevel > 2 Then Print #Fitlog, " Z"; "  Yield(exp)  d_exp"," Yield(GEF)"," Chisqr"        
        For IZ = IZfirst to IZlast
          Chisqr_single =_
             ( (Zyield(IZ) - ZPOST(IZ) )/dZyield(IZ))^2
          If Fitloglevel > 2 Then Print #Fitlog, IZ;Zyield(IZ),dZyield(IZ),Csng(ZPOST(IZ)),Chisqr_Single
          Chisqr_Fit = Chisqr_Fit + Chisqr_single   
        Next IZ
        If B_graphics = 1 Then
          Close #F_GRAF
          Open "GRAF/"+Csystem+"_Zpost.grf" For Output As #F_GRAF
          Print #F_GRAF,WinTitle
          Print #F_GRAF,"X: Fragment Z"
          Print #F_GRAF,"Y: Yield / %"
          Print #F_GRAF, "P: SCALING(0.6) SYMBOL(2)"
          Print #F_GRAF,"H: X  Y(Data),LT7  DY  Y(GEF),LRT11  "
          For IZ = IZfirst to IZlast
            Print #F_GRAF,IZ,Zyield(IZ),dZyield(IZ),ZPOST(IZ)
          Next IZ          
'          Close #F_GRAF
'          Open "GRAF/"+Csystem+"_Apost.grf" For Append As #F_GRAF 
        End If
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit / 100
        Print #Fitlog, "U232em (Zyield): Chisqr = ";Csng(Chisqr_Fit / 100);" ( * 100)"            
       End Scope
     End If
  End If
End If  

If Emode = 1 Then  
  If P_A_CN = 205 And P_Z_CN = 83 And Abs(P_E_EXC - 22) < 2 Then 
    If Instr(C_Fitoption,"MODES") > 0 Then
      Scope
        Dim As Single Chisqr_single
        Dim As Single Yield_GEF
        Dim As Integer IMode, IModefirst, IModelast
        Restore Modes_BI205_22MeV
        Read IModefirst,IModelast
        ReDim As Single Yield(IModefirst To IModelast)
        ReDim As Single dYield(IModefirst To IMODElast)
        For IMode = IModefirst To IModelast
          Read Yield(IMode)
        Next IMode
        For IMode = IModefirst To IModelast
          Read dYield(IMode)
        Next IMode
        Chisqr_Fit = 0
        If Fitloglevel > 1 Then Print #Fitlog, "Mode", "Yield_exp ","d_Yield_exp","Yield_GEF","Chisqr"
        For IMode = IModefirst to IModelast
          If IMode = 0 Then Yield_GEF = Yield_Mode_0
          If IMode = 1 Then Yield_GEF = Yield_Mode_1
          If IMode = 2 Then Yield_GEF = Yield_Mode_2
          If IMode = 3 Then Yield_GEF = Yield_Mode_3
          If IMode = 4 Then Yield_GEF = Yield_Mode_4
          If IMode = 5 Then Yield_GEF = Yield_Mode_5
          Chisqr_single =_
             ( (Yield(IMode) - Yield_GEF)/dYield(IMode))^2
            ' If Fitloglevel > 1 Then 
             Print #Fitlog, IMode,Yield(IMode),dYield(IMode),Yield_GEF,Chisqr_Single
          Chisqr_Fit = Chisqr_Fit + Chisqr_single   
        Next IMode
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
        Print #Fitlog, "BI205_22 MeV (Modes): Chisqr = ";Csng(Chisqr_Fit)  
      End Scope  
    End If  
  End If
  If P_A_CN = 205 And P_Z_CN = 83 And Abs(P_E_EXC - 26) < 2 Then 
    If Instr(C_Fitoption,"MODES") > 0 Then
      Scope
        Dim As Single Chisqr_single
        Dim As Single Yield_GEF
        Dim As Integer IMode, IModefirst, IModelast
        Restore Modes_BI205_26MeV
        Read IModefirst,IModelast
        ReDim As Single Yield(IModefirst To IModelast)
        ReDim As Single dYield(IModefirst To IMODElast)
        For IMode = IModefirst To IModelast
          Read Yield(IMode)
        Next IMode
        For IMode = IModefirst To IModelast
          Read dYield(IMode)
        Next IMode
        Chisqr_Fit = 0
        If Fitloglevel > 1 Then Print #Fitlog, "Mode", "Yield_exp ","d_Yield_exp","Yield_GEF","Chisqr"
        For IMode = IModefirst to IModelast
          If IMode = 0 Then Yield_GEF = Yield_Mode_0
          If IMode = 1 Then Yield_GEF = Yield_Mode_1
          If IMode = 2 Then Yield_GEF = Yield_Mode_2
          If IMode = 3 Then Yield_GEF = Yield_Mode_3
          If IMode = 4 Then Yield_GEF = Yield_Mode_4
          If IMode = 5 Then Yield_GEF = Yield_Mode_5
          Chisqr_single =_
             ( (Yield(IMode) - Yield_GEF)/dYield(IMode))^2
            ' If Fitloglevel > 1 Then 
             Print #Fitlog, IMode,Yield(IMode),dYield(IMode),Yield_GEF,Chisqr_Single
          Chisqr_Fit = Chisqr_Fit + Chisqr_single   
        Next IMode
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
        Print #Fitlog, "BI205_26 MeV (Modes): Chisqr = ";Csng(Chisqr_Fit)  
      End Scope  
    End If  
  End If
  If P_A_CN = 205 And P_Z_CN = 83 And Abs(P_E_EXC - 31) < 2 Then 
    If Instr(C_Fitoption,"MODES") > 0 Then
      Scope
        Dim As Single Chisqr_single
        Dim As Single Yield_GEF
        Dim As Integer IMode, IModefirst, IModelast
        Restore Modes_BI205_31MeV
        Read IModefirst,IModelast
        ReDim As Single Yield(IModefirst To IModelast)
        ReDim As Single dYield(IModefirst To IMODElast)
        For IMode = IModefirst To IModelast
          Read Yield(IMode)
        Next IMode
        For IMode = IModefirst To IModelast
          Read dYield(IMode)
        Next IMode
        Chisqr_Fit = 0
        If Fitloglevel > 1 Then Print #Fitlog, "Mode", "Yield_exp ","d_Yield_exp","Yield_GEF","Chisqr"
        For IMode = IModefirst to IModelast
          If IMode = 0 Then Yield_GEF = Yield_Mode_0
          If IMode = 1 Then Yield_GEF = Yield_Mode_1
          If IMode = 2 Then Yield_GEF = Yield_Mode_2
          If IMode = 3 Then Yield_GEF = Yield_Mode_3
          If IMode = 4 Then Yield_GEF = Yield_Mode_4
          If IMode = 5 Then Yield_GEF = Yield_Mode_5
          Chisqr_single =_
             ( (Yield(IMode) - Yield_GEF)/dYield(IMode))^2
            ' If Fitloglevel > 1 Then 
             Print #Fitlog, IMode,Yield(IMode),dYield(IMode),Yield_GEF,Chisqr_Single
          Chisqr_Fit = Chisqr_Fit + Chisqr_single   
        Next IMode
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
        Print #Fitlog, "BI205_31 MeV (Modes): Chisqr = ";Csng(Chisqr_Fit)  
      End Scope  
    End If  
  End If
  If P_A_CN = 209 And P_Z_CN = 83 And Abs(P_E_EXC - 28.5) < 2 Then 
    If Instr(C_Fitoption,"MODES") > 0 Then
      Scope
        Dim As Single Chisqr_single
        Dim As Single Yield_GEF
        Dim As Integer IMode, IModefirst, IModelast
        Restore Modes_BI209_28MeV5
        Read IModefirst,IModelast
        ReDim As Single Yield(IModefirst To IModelast)
        ReDim As Single dYield(IModefirst To IMODElast)
        For IMode = IModefirst To IModelast
          Read Yield(IMode)
        Next IMode
        For IMode = IModefirst To IModelast
          Read dYield(IMode)
        Next IMode
        Chisqr_Fit = 0
        If Fitloglevel > 1 Then Print #Fitlog, "Mode", "Yield_exp ","d_Yield_exp","Yield_GEF","Chisqr"
        For IMode = IModefirst to IModelast
          If IMode = 0 Then Yield_GEF = Yield_Mode_0
          If IMode = 1 Then Yield_GEF = Yield_Mode_1
          If IMode = 2 Then Yield_GEF = Yield_Mode_2
          If IMode = 3 Then Yield_GEF = Yield_Mode_3
          If IMode = 4 Then Yield_GEF = Yield_Mode_4
          If IMode = 5 Then Yield_GEF = Yield_Mode_5
          Chisqr_single =_
             ( (Yield(IMode) - Yield_GEF)/dYield(IMode))^2
            ' If Fitloglevel > 1 Then 
             Print #Fitlog, IMode,Yield(IMode),dYield(IMode),Yield_GEF,Chisqr_Single
          Chisqr_Fit = Chisqr_Fit + Chisqr_single   
        Next IMode
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
        Print #Fitlog, "BI209_28.5 MeV (Modes): Chisqr = ";Csng(Chisqr_Fit)  
      End Scope  
    End If  
  End If
  If P_A_CN = 209 And P_Z_CN = 83 And Abs(P_E_EXC - 31.7) < 2 Then 
    If Instr(C_Fitoption,"MODES") > 0 Then
      Scope
        Dim As Single Chisqr_single
        Dim As Single Yield_GEF
        Dim As Integer IMode, IModefirst, IModelast
        Restore Modes_BI209_31MeV7
        Read IModefirst,IModelast
        ReDim As Single Yield(IModefirst To IModelast)
        ReDim As Single dYield(IModefirst To IMODElast)
        For IMode = IModefirst To IModelast
          Read Yield(IMode)
        Next IMode
        For IMode = IModefirst To IModelast
          Read dYield(IMode)
        Next IMode
        Chisqr_Fit = 0
        If Fitloglevel > 1 Then Print #Fitlog, "Mode", "Yield_exp ","d_Yield_exp","Yield_GEF","Chisqr"
        For IMode = IModefirst to IModelast
          If IMode = 0 Then Yield_GEF = Yield_Mode_0
          If IMode = 1 Then Yield_GEF = Yield_Mode_1
          If IMode = 2 Then Yield_GEF = Yield_Mode_2
          If IMode = 3 Then Yield_GEF = Yield_Mode_3
          If IMode = 4 Then Yield_GEF = Yield_Mode_4
          If IMode = 5 Then Yield_GEF = Yield_Mode_5
          Chisqr_single =_
             ( (Yield(IMode) - Yield_GEF)/dYield(IMode))^2
            ' If Fitloglevel > 1 Then 
             Print #Fitlog, IMode,Yield(IMode),dYield(IMode),Yield_GEF,Chisqr_Single
          Chisqr_Fit = Chisqr_Fit + Chisqr_single   
        Next IMode
        Chisqr_Fit_present = Chisqr_Fit_present + Chisqr_Fit
        Print #Fitlog, "BI209_31.7 MeV (Modes): Chisqr = ";Csng(Chisqr_Fit)  
      End Scope  
    End If  
  End If
End If  


If B_graphics = 1 Then  
  Scope
    Dim As Integer I_Res
    Close #F_GRAF            ' Close GRAF copy file
    #ifdef __FB_WIN32__
    #else
      If B_fit Then I_Res = Shell("cd GRAF/ ; todos *")
  '    If I_Res = 0 Then Print ".grf files in GRAF folder converted to Windows format."
    #endif
  End Scope 
  Locate 45
End If

If B_fit Then  
  Close #Fitlog
End If
