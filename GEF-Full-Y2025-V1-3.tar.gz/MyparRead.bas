' Reading optimum parameter values from MyParameters.dat
    
If B_MyParameters Then
  If Fileexists("MyParameters.dat") Then  ' Read parameters from user-supplied file
    Scope 
      Dim As String Cline
      Dim As Integer Ileft,Iright
      Dim As Integer Ndiv,N
      Dim As String Cdiv(2)
      Dim As String Cpar
      Dim As Single Valpar
      Dim As Byte B_found
     
      Print "File MyParameters.dat found."
      Print "Parameter values from file 'MyParameters.dat' are used."
      ' Reading user-supplied parameter values from MyParameters.dat
      Dim As Integer F_Mypar 
      F_Mypar = Freefile
      Open "MyParameters.dat" for Input as #F_Mypar
      DO Until EOF(F_Mypar)
        Line Input #F_Mypar,Cline 
' Print "FitparRead.bas: Line Input("+Cline
        #Include "ReadParameters.mac"
      Loop
      CLose F_Mypar
    End Scope
  Else
    Print "File MyParameters.dat not found."  
  End If
End If
