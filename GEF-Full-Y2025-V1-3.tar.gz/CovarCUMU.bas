   /' Analysis of uncertainties and covariances of cumulative yields '/
 '  Static As Integer fmvd_single, fmvd  'files
   Dim As Integer NZAcumuptb
      
   Redim SZAcumuCovar(1,1,1,1) As OCovar
   Redim SZAcumuCorr(1,1,1,1) As Ocorr
   
   Dim As Integer Zcumumin,Zcumumax
   Dim As Integer Acumumin,Acumumax
   Dim As Integer dAcumumax
   Redim VAcumulim(1,2) As Integer   ' Amin, Amax for different Z values
   Dim As Integer L

   Redim SZAcumu_Double_Covar(1,1,1,1) As OCovar
   Redim SZAcumu_Double_Corr(1,1,1,1) As OCorr
   Dim As Integer Zcumu_Double_min,Zcumu_Double_max
   Dim As Integer Acumu_Double_min,Acumu_Double_max
   Dim As Integer dAcumu_Double_max
   Redim VAcumu_Double_lim(1,2) As Integer   ' Amin, Amax
   Redim rms_Double(1,2) As Double
   Redim rms_ZAcumu_Double(1,1,2) As Double
   Dim As Integer Zmincumu, Zmaxcumu
   Dim As Integer Z_double_min_cumu, Z_double_max_cumu

' Fill NZcumu and ZISOcumu with data from NZIcumu
   Dim As Double Rhelp
   For I = Lbound(NZIcumu,1) To Ubound(NZIcumu,1)  ' Loop over N
     For J = Lbound(NZIcumu,2) To Ubound(NZIcumu,2)  ' Loop over Z
       Rhelp = 0 
       For K = Lbound(NZIcumu,3) To Ubound(NZIcumu,3) ' sum over states
         Rhelp = Rhelp + NZIcumu(I,J,K)
       Next K
       NZcumu(I,J) = Rhelp
       If I+J >= Lbound(ZISOcumu,1) And I+J <= Ubound(ZISOcumu,1) And _  I+J = N+Z = A
          J >= Lbound(ZISOcumu,2) and J <= Ubound(ZISOcumu,2) Then ' J = Z
           ZISOcumu(I+J,J) = Rhelp 
       End If   
       Next J
   Next I

   If B_Error_On = 1 Then
     If B_Error_Analysis = 1 Then

       ' Nuclide yields
'       For I = 20 To P_A_CN - 20
'         For J = 10 To P_Z_CN - 10
'           If ZISOcumu(I,J) > 0 Then
'             d_ZISOcumu(1,I,J) = d_ZISOcumu(1,I,J) + ZISOcumu(I,J)
'       	     d_ZISOcumu(2,I,J) = d_ZISOcumu(2,I,J) + (ZISOcumu(I,J))^2
'           End If
'         Next
'       Next
       
'       Cfilemvd_single = "tmp\"+Csystem+"_Single.mvd"
       fmvd_single = freefile
       Open Cfilemvd_single For Append As #fmvd_single
       Print #fmvd_single,"*"
'       Dim As Double Rdatetime
'       Rdatetime = Now
'       Print #fmvd_single,"* Output written on ";
'       Print #fmvd_single, Format( Rdatetime, "dd.mm.yyyy, hh:mm:ss")
'       Print #fmvd_single,"* "
'       Print #fmvd_single, Using "& ### & ###";"* Calculation for the nucleus Z = ";P_Z_CN;", A = ";P_A_CN

       Print #fmvd_single,"*"
       Print #fmvd_single,"* Perturbed parameter set #"+Str(I_Error+1)
       Print #fmvd_single,"*"
   	   Print #fmvd_single,"*"
       Print #fmvd_single,"* Set          A             Z            Ycumu(A,Z) "  
       Print #fmvd_single,"*AZcumu*"
       For I = 20 To P_A_CN - 20
         For J = 10 To P_Z_CN - 10
           If ZISOcumu(I,J) > 0 Then
       	     Print #fmvd_single,I_Error+1,I,J,Csng(ZISOcumu(I,J))
       	   End If   
         Next
       Next
       If I_Error + 1 = N_Error_Max Then
     '    Print #fmvd_single,"***********************END****************************"
       End If  
       Close #fmvd_single
       
       
       For I = 10 To P_A_CN - P_Z_CN - 10
         For J = 10 To P_Z_CN -10
           If NZcumu(I,J) > 0 Then
             d_NZcumu(1,I,J) = d_NZcumu(1,I,J) + NZcumu(I,J) ' simple sum
             d_NZcumu(2,I,J) = d_NZcumu(2,I,J) + (NZcumu(I,J))^2 ' quadratic sum
           End If
         Next
       Next
       
     Else  ' Last passage, calculate final uncertainties and covariances
     
       ' Open file for values needed for covariances between different fissioning systems     
'       If B_Double_Covar = 1 Then
'         Cfilemvd = "tmp\"+Cfileout+".mvd"
'         fmvd = freefile
'         If I_Double_Covar = 1 Then
'           Open Cfilemvd For Output As #fmvd
'         Else
'           Open Cfilemvd For Append As #fmvd
'         End If
'       End If

     
       ' --- Covariances and uncertainties for single systems ---

       ' Covariances
       
       Dim As String Coption
       Dim As String Cread
       
       /' First step: Read and count event data from file '/
       fmvd_single = freefile       
       Open Cfilemvd_single For Input As #fmvd_single
       Coption = "None"
       NZAptb = 0
       
       Do Until EOF(fmvd_single)
         Line Input #fmvd_single, Cread
         If Left(Cread,1) = "*" Then Coption = "None"
         If Cread = "*AZcumu*" Then 
           Coption = "AZcumu"
           Line Input #fmvd_single, Cread
         End If  
         Select Case Coption
           Case "AZcumu" 
             NZAptb = NZAptb + 1  ' number of nuclides in mvd file
           Case Else
         End Select
       Loop
       Close #fmvd_single    
       
       Redim VZAcumuptb(NZAptb) As OCovarEvt2d
       
       Dim As Integer IcntA,IcntZ,IcntZA
       Dim CVsplit(5) As String
       Dim Nsplit As Integer
       IcntZA=0


       /' Calculation of covariance matrices '/
       
       /' Second step: Read event data from file '/
       Zmincumu = 1000
       Zmaxcumu = 0
       fmvd_single = freefile       
       Open Cfilemvd_single For Input As #fmvd_single
       Coption = "None"
       Do Until EOF(fmvd_single)
         Line Input #fmvd_single, Cread
         If Left(Cread,1) = "*" Then Coption = "None"
         If Cread = "*AZcumu*" Then 
           Coption = "AZcumu"
           Line Input #fmvd_single, Cread
         End If  
         Select Case Coption
           Case "AZcumu" 
             CC_cut Cread," ",CVsplit(),Nsplit
             IcntZA = IcntZA + 1  
             VZAcumuptb(IcntZA).IParameter = Cast(Integer,CVsplit(1))
             VZAcumuptb(IcntZA).ICoordinate1 = Cast(Integer,CVsplit(2))
             VZAcumuptb(IcntZA).ICoordinate2 = Cast(Integer,CVsplit(3)) 
             VZAcumuptb(IcntZA).Ryield = Cast(Single,CVsplit(4))
             Zmaxcumu = Max(Zmaxcumu,VZAcumuptb(IcntZA).ICoordinate2)
             Zmincumu = Min(Zmincumu,VZAcumuptb(IcntZA).ICoordinate2)
           Case Else
         End Select
       Loop
       Close #fmvd_single
         
       /' Step 3, calculate covariances '/  
       Dim As Integer IParset, IMatrix

       Dim Bfound As Byte
       Dim As Integer Nsum
       Dim As Double Rsum,Rsquare
  

       ' Covariance for cumulative nuclide distribution 
       ' Determine dimension of covariance matrix
       Redim VAcumulim(Zmincumu to Zmaxcumu ,2) As Integer
       Dim As Integer A1full,A1red,A2full,A2red,Z1,Z2
       For I = Zmincumu to Zmaxcumu
         VAcumulim(I,1) = 1000
         VAcumulim(I,2) = 0
       Next
       dAcumumax = 0
       For I = 1 To IcntZA
         If I <= Ubound(VZAcumuptb) Then
           Z1 = VZAcumuptb(I).Icoordinate2
           If Z1 >= Zmincumu And Z1 <= Zmaxcumu Then
             VAcumulim(Z1,1) = Min(VAcumulim(Z1,1),VZAcumuptb(I).Icoordinate1)
             VAcumulim(Z1,2) = Max(VAcumulim(Z1,2),VZAcumuptb(I).Icoordinate1)
           Else ' this should not happen
             Print "CovarCUMU: Z1 =";Z1;", yield = ";VZAcumuptb(I).Ryield
           End If  
         Else   
           Print "Internal error 1: I,IcntZA",I,IcntZA
           Input "Press Enter key to leave GEF!",kin
           End
         End If 
       Next
       For I = Zmincumu to Zmaxcumu
         dAcumumax = Max(dAcumumax, VAcumulim(I,2) - VAcumulim(I,1))
       Next
       dAcumumax = dAcumumax + 1
       Redim VZAcumumean(Zmincumu to Zmaxcumu,1 to dAcumumax) As Single
       Redim VZAcumurms(Zmincumu to Zmaxcumu,1 to dAcumumax) As Single       
       Redim SZAcumuCovar(Zmincumu to Zmaxcumu,1 to dAcumumax, _
                          Zmincumu to Zmaxcumu,1 to dAcumumax) As OCovar 
       Redim SZAcumuCorr(Zmincumu to Zmaxcumu,1 to dAcumumax, _
                          Zmincumu to Zmaxcumu,1 to dAcumumax) As OCorr 
                          
       ' Determine mean values and variances
       For I = Zmincumu To Zmaxcumu
         For J = VAcumulim(I,1) To VAcumulim(I,2) 
           Rsum = 0
           Rsquare = 0
           Nsum = 0
           For K = 1 To IcntZA
             If K <= Ubound(VZAcumuptb) Then
               If VZAcumuptb(K).ICoordinate2 = I And _
                  VZAcumuptb(K).ICoordinate1 = J Then
                 RSum = RSum + VZAcumuptb(K).Ryield
                 Rsquare = Rsquare + (VZAcumuptb(K).Ryield)^2
                 Nsum = Nsum + 1
               End If
             Else
               Print "Internal error 2: I,J,K,IcntZA=",I,J,K,IcntZA
               Input "Press Enter key to leave GEF!",kin
               End
             End If
           Next  
           A1red = J-VAcumulim(I,1)+1
           If Nsum > 0 Then
             VZAcumumean(I,A1red) = RSum / Nsum
             VZAcumurms(I,A1red) = sqr((Rsquare - Rsum^2/Nsum)/(Nsum-1))
           Else
             VZAcumumean(I,A1red) = 0
             VZAcumurms(I,A1red) = 0
           End If       
         Next 
       Next
       
       'Determine covariance matrix
       For I = 1 To IcntZA
         If I <= Ubound(VZAcumuptb) Then
           Z1 = VZAcumuptb(I).ICoordinate2
           A1full = VZAcumuptb(I).ICoordinate1
           A1red = A1full - VAcumulim(Z1,1) + 1
           For J = 1 To IcntZA
             If J <= Ubound(VZAcumuptb) Then
               Z2 = VZAcumuptb(J).ICoordinate2
               A2full = VZAcumuptb(J).ICoordinate1
               A2red = A2full - VAcumulim(Z2,1) + 1
               If VZAcumuptb(I).IParameter = VZAcumuptb(J).IParameter Then 
                 SZAcumuCovar(Z1,A1red,Z2,A2red).Rval = SZAcumuCovar(Z1,A1red,Z2,A2red).Rval + _
                   (VZAcumuptb(I).Ryield - VZAcumumean(Z1,A1red)) * _
                   (VZAcumuptb(J).Ryield - VZAcumumean(Z2,A2red)) 
                 SZAcumuCovar(Z1,A1red,Z2,A2red).Nval = SZAcumuCovar(Z1,A1red,Z2,A2red).Nval + 1                       
               End If       
             Else
               Print "Internal error 3: I,J,IcntZA=",I,J,IcntZA
               Input "Press Enter key to leave GEF!",kin
               End
             End If    
           Next
         Else
           Print "Internal error 4: I,IcountZA=",I,IcntZA
           Input "Press Enter key to leave GEF!",kin
           End
         End If
       Next      
       
       For I = Zmincumu To Zmaxcumu
         For J = VAcumulim(I,1) To VAcumulim(I,2) 
           A1red = J - VAcumulim(I,1) + 1
           For K = Zmincumu To Zmaxcumu
             For L = VAcumulim(K,1) To VAcumulim(K,2)
               A2red = L - VAcumulim(K,1) + 1 
               If SZAcumuCovar(I,A1red,K,A2red).Nval = N_Error_Max Then
                 SZAcumuCovar(I,A1red,K,A2red).Rval = SZAcumuCovar(I,A1red,K,A2red).Rval / _
                                          (SZAcumuCovar(I,A1red,K,A2red).Nval-1)
                 If VZAcumurms(I,A1red) <> 0 And VZAcumurms(K,A2red) <> 0 Then
                   SZAcumuCorr(I,A1red,K,A2red).Rval = SZAcumuCovar(I,A1red,K,A2red).Rval / _
                          (VZAcumurms(I,A1red) * VZAcumurms(K,A2red))                   
                 End If                         
               Else
                 SZAcumuCovar(I,A1red,K,A2red).Rval = 0
               End If                           
             Next
           Next
         Next
       Next       
       
       
       
       If B_Double_Covar = 1 Then  ' Store values for covariances between different systems

       ' Open file for values needed for covariances between different fissioning systems     
         Cfilemvd = "tmp\"+Cfileout+".mvd"
         fmvd = freefile
         Open Cfilemvd For Append As #fmvd

         Print #fmvd, "* System Nr.   Parameterset  Observable     Number (1. 2. dim)        Deviation"
         For I = 1 To IcntZA
           Print #fmvd, I_Double_Covar, VZAcumuptb(I).IParameter, "ZAcumu", _ 
                        VZAcumuptb(I).ICoordinate1, _
                        VZAcumuptb(I).ICoordinate2, _
                        VZAcumuptb(I).Ryield  - _
                            VZAcumumean(VZAcumuptb(I).ICoordinate2,VZAcumuptb(I).ICoordinate1 + 1 - _ 
                            VAcumulim(VZAcumuptb(I).ICoordinate2,1)) 
         Next I
         Close #fmvd
       End If


     ' Uncertainties

'       For I = 20 To 190
'         If d_APost(1,I) > 0 Then
'           d_APost(0,I) = sqr ( (d_APost(2,I) - _
'                                 d_APost(1,I)^2/N_Error_Max ) /(N_Error_Max-1.0) )
'         Else
'           d_APost(0,I) = APost(I)                       
'         End If
'         If d_APost(0,I) > APost(I) Or d_APost(0,I) = 0 Then 
'            d_APost(0,I) = APost(I)
'         End If   
'       Next            

'       For I = 20 To 70
'         If d_ZPost(1,I) > 0 Then
'           d_ZPost(0,I) = sqr ( (d_ZPost(2,I) - _
'                                 d_ZPost(1,I)^2/N_Error_Max ) /(N_Error_Max-1.0) )
'         Else
'           d_ZPost(0,I) = ZPost(I)                       
'         End If
'         If d_ZPost(0,I) > ZPost(I) Or d_ZPost(0,I) = 0 Then 
'           d_ZPost(0,I) = ZPost(I)
'         End If        
'       Next I

'       For I = 20 To P_A_CN - 20
'         For J = 10 To P_Z_CN - 10
'           If ZISOPOST(I,J) > 0 Then
'             d_ZISOPOST(0,I,J) = sqr ( (d_ZISOPOST(2,I,J) - _
'                                        d_ZISOPOST(1,I,J)^2/N_Error_Max ) /(N_Error_Max-1.0) )
'           Else
'             d_ZISOPOST(0,I,J) = ZISOPOST(I,J)      
'       	   End If
'       	   If d_ZISOPOST(0,I,J) > ZISOPOST(I,J) or d_ZISOPOST(0,I,J) = 0 Then
'       	                d_ZISOPOST(0,I,J) = ZISOPOST(I,J)
'       	   End If             
'         Next
'       Next
'       For I = 10 To P_A_CN - P_Z_CN -10
'         For J = 10 To P_Z_CN - 10
'           If NZPost(I,J) > 0 Then
'             d_NZPOST(0,I,J) = sqr ( (d_NZPOST(2,I,J) - _
'                                      d_NZPOST(1,I,J)^2/N_Error_Max ) /(N_Error_Max-1.0) )
'           Else
'             d_NZPost(0,I,J) = NZPost(I,J)
'                   ' relative error set to 100%
'           End If
'           If d_NZPost(0,I,J) > NZPost(I,J) Or d_NZPost(0,I,J) = 0 Then 
'                    d_NZPost(0,I,J) = NZPost(I,J) 
                   ' relative error limited to 100% 
'           End If         
'         Next
'       Next
''       d_NCN(0) = sqr( (d_NCN(2) - d_NCN(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
 '      d_Nsci(0) = sqr( (d_Nsci(2) - d_Nsci(1)^2/N_Error_Max) / (N_Error_Max - 1.0) ) 
 '      d_Nfr(0) = sqr( (d_Nfr(2) - d_Nfr(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
 '      d_Nlight(0) = sqr( (d_Nlight(2) - d_Nlight(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
 '      d_Nheavy(0) = sqr( (d_Nheavy(2) - d_Nheavy(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
 '      d_Ntot(0) = sqr( (d_Ntot(2) - d_Ntot(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
 '      d_ENfr(0) = sqr( (d_ENfr(2) - d_ENfr(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
 '      
 '      d_Ng(0) = sqr( (d_Ng(2) - d_Ng(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
 '      d_Eg(0) = sqr( (d_Eg(2) - d_Eg(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
 '      d_Egtot(0) = sqr( (d_Egtot(2) - d_Egtot(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
 '      d_Q(0) = sqr( (d_Q(2) - d_Q(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
 '      d_TKEpre(0) = sqr( (d_TKEpre(2) - d_TKEpre(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
 '      d_TKEpost(0) = sqr( (d_TKEpost(2) - d_TKEpost(1)^2/N_Error_Max) / (N_Error_max - 1.0) )
 '      d_TotXE(0) = sqr( (d_TotXE(2) - d_TotXE(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
    
    
       ' --- Covariances between the yields of two fissioning systems ---
       
       If B_Double_Covar = 1 And I_Double_Covar = 2 Then
         Dim As String C_dummy
         Redim As String C_part(1) 
         Dim As Integer Nstored, Istored, Nvalues
         fmvd = freefile       
         Open Cfilemvd For Input As #fmvd
         Nstored = 0
         Do 
           Line Input #fmvd, C_dummy
           If Left(Ltrim(C_dummy),1) <> "*" Then Nstored = Nstored + 1
         Loop Until EOF(fmvd)
         Close #fmvd

         Redim As Integer VIstored(4,Nstored)
           ' 1: System, 2: Parset, 3: Dim. 1, 4: Dim. 2
         Redim As Single VRstored(Nstored)  
         Redim As String VCstored(Nstored) 

         fmvd = freefile       
         Open Cfilemvd For Input As #fmvd
         Istored = 0
         Z_Double_min_cumu = 1000
         Z_Double_max_cumu = 0
         Do 
           Line Input #fmvd, C_dummy
           If Left(Ltrim(C_dummy),1) <> "*" Then 
             Istored = Istored + 1
             Nvalues = CC_Count(C_dummy," ")
             Redim C_part(Nvalues)
             CC_Cut(C_dummy," ",C_part(),Nvalues)
             VIstored(1,Istored) = Val(C_part(1))  ' Fissioning system (1 or 2)
             VIstored(2,Istored) = Val(C_part(2))  ' Parameter set (1 To N_Error_Max)
             VIstored(3,Istored) = Val(C_part(4))  ' Dimension 1 (e.g. Z or A)
             VIstored(4,Istored) = Val(C_part(5))  ' Dimension 2 (e.g. Z)
             VRstored(Istored) = Val(C_part(6))    ' Deviation from mean value
             VCstored(Istored) = C_part(3)         ' Kind of data (Z, Apre, Apost, ZApre, ZApost, ZAcumu)
             If VCstored(Istored) = "ZAcumu" Then
               Z_Double_min_cumu = Min(Z_Double_min_cumu,VIstored(4,Istored))
               Z_Double_max_cumu = Max(Z_Double_max_cumu,VIstored(4,Istored))
             End If
           End If  
         Loop Until EOF(fmvd) 
         Close #fmvd                  
         

         ' Covariance between the cumulative nuclide distributions of the two systems 
         ' Determine dimension of covariance matrix
         Redim VAcumu_Double_lim(Z_Double_min_cumu to Z_Double_max_cumu,2) As Integer
         Dim As Integer M
         For I = Z_Double_min_cumu To Z_Double_max_cumu
           VAcumu_Double_lim(I,1) = 1000
           VAcumu_Double_lim(I,2) = 0
         Next I
         dAcumu_Double_max = 0 
         For I = 1 To Nstored
           If VCstored(I) = "ZAcumu" Then
             Z1 = VIstored(4,I)
             VAcumu_Double_lim(Z1,1) = Min(VAcumu_Double_lim(Z1,1),VIstored(3,I))
             VAcumu_Double_lim(Z1,2) = Max(VAcumu_Double_lim(Z1,2),VIstored(3,I))
           End If         
         Next I
         For I = Z_Double_min_cumu To Z_Double_max_cumu
           If VAcumu_Double_lim(I,1) = 1000 Then 
             VAcumu_Double_lim(I,1) = 0
           Else 
             dAcumu_Double_max = Max(dAcumu_Double_max, VAcumu_Double_lim(I,2) - VAcumu_Double_lim(I,1) + 1) 
           End If  
         Next I
         
         ' Reorder deviations for faster access
         Redim As Single VRZAcumu_Double(2,N_Error_Max,Z_Double_min_cumu To Z_Double_max_cumu,dAcumu_Double_max)
         For I = 1 To Nstored
           If VCstored(I) = "ZAcumu" Then
             Z1 = VIstored(4,I)
             A1 = VIstored(3,I)
             A1red = A1 - VAcumu_Double_lim(Z1,1) + 1
             VRZAcumu_Double(VIstored(1,I),VIstored(2,I),Z1,A1red) = _
                     VRstored(I)
           End If
         Next I
         
         
         ' Calculate covariances
         Redim SZAcumu_Double_Covar(Z_Double_min_cumu to Z_Double_max_cumu, 1 to dAcumu_Double_max,_
                                   Z_Double_min_cumu to Z_Double_max_cumu, 1 to dAcumu_Double_max) As OCovar
         Redim SZAcumu_Double_Corr(Z_Double_min_cumu to Z_Double_max_cumu, 1 to dAcumu_Double_max,_
                                   Z_Double_min_cumu to Z_Double_max_cumu, 1 to dAcumu_Double_max) As OCorr
         For I = Z_Double_min_cumu to Z_Double_max_cumu
           For J = VAcumu_Double_lim(I,1) To VAcumu_Double_lim(I,2)
             A1full = J
             A1red = J - VAcumu_Double_lim(I,1) + 1
             For K = Z_Double_min_cumu To Z_Double_max_cumu
               For L = VAcumu_Double_lim(K,1) To VAcumu_Double_lim(K,2)
                 A2full = L
                 A2red = L - VAcumu_Double_lim(K,1) + 1
                 For M = 1 To N_Error_Max
                   If VRZAcumu_Double(1,M,I,A1red) <> 0 And VRZAcumu_Double(2,M,K,A2red) <> 0 Then    
 '  Print M,I,J,VRZApre_Double(1,M,I,A1red),VRZApre_Double(2,M,K,A2red)                              
                     SZAcumu_Double_Covar(I,A1red,K,A2red).Rval = _
                                SZAcumu_Double_Covar(I,A1red,K,A2red).Rval _ 
                                + VRZAcumu_Double(1,M,I,A1red) * VRZAcumu_Double(2,M,K,A2red) 
                     SZAcumu_Double_Covar(I,A1red,K,A2red).Nval = _
                                SZAcumu_Double_Covar(I,A1red,K,A2red).Nval + 1
                   End If              
                 Next M       
               Next L
             Next K
           Next J    
         Next I          
         
         ' Normalize and remove incomplete results   
         For I = Z_Double_min_cumu to Z_Double_max_cumu
           For J = 1 To dAcumu_Double_max
             For K = Z_Double_min_cumu To Z_Double_max_cumu
               For L = 1 To dAcumu_Double_max
                 If SZAcumu_Double_Covar(I,J,K,L).Nval = N_Error_Max Then 
                   SZAcumu_Double_Covar(I,J,K,L).Rval = SZAcumu_Double_Covar(I,J,K,L).Rval / _
                                  (SZAcumu_Double_Covar(I,J,K,L).Nval - 1) 
                 Else
                   SZAcumu_Double_Covar(I,J,K,L).Rval = 0
                 End If  
               Next L
             Next K
           Next J
         Next I       
         
         Redim rms_ZA_Double(Z_Double_min_cumu to Z_Double_max_cumu, 1 to dAcumu_Double_max,2)
         For I = Z_Double_min_cumu to Z_Double_max_cumu
           For J = 1 To dAcumu_Double_max
             For K = 1 To N_Error_Max 
               rms_ZA_Double(I,J,1) = rms_ZA_Double(I,J,1) + VRZAcumu_Double(1,K,I,J)^2
               rms_ZA_Double(I,J,2) = rms_ZA_Double(I,J,2) + VRZAcumu_Double(2,K,I,J)^2   
             Next K     
           Next J
         Next I
         For I = Z_Double_min_cumu to Z_Double_max_cumu
           For J = 1 To dAcumu_Double_max
             rms_ZA_Double(I,J,1) = sqr(rms_ZA_Double(I,J,1) / (N_Error_Max - 1))
             rms_ZA_Double(I,J,2) = sqr(rms_ZA_Double(I,J,2) / (N_Error_Max - 1))
           Next J
         Next I
         For I = Z_Double_min_cumu to Z_Double_max_cumu
           For J = 1 To dAcumu_Double_max
             For K = Z_Double_min_cumu to Z_Double_max_cumu
               For L = 1 To dAcumu_Double_max
                 If rms_ZA_Double(I,J,1) <> 0 And rms_ZA_Double(K,L,2) <> 0 Then
                   SZAcumu_Double_Corr(I,J,K,L).Rval = SZAcumu_Double_Covar(I,J,K,L).Rval / _
                     (rms_ZA_Double(I,J,1) * rms_ZA_Double(K,L,2))
                 End If
               Next L
             Next K
           Next J
         Next I
         Erase VRZAcumu_Double
         
         Erase rms_ZA_Double
         
       End If  ' If B_Double_Covar ...
                
     End If
            
   End If
   
      Dim As Integer Inewline 
   Inewline = 0
   Dim As Single Rout
   If B_Error_On = 1 And B_Error_Analysis = 0 Then    
     If Bcov = 1 Then
       Print #f,"      <ZAcumu_covariances>"
       Print #f,"--- Covariance matrix of cumulative yields ---"
       Print #f," "
       Print #f,"  Key table of Amin and Amax values: (Z,Amin(Z),Amax(Z))"                                     
       For I = Zmincumu to Zmaxcumu
         If VAcumulim(I,2) > 0 Then _
          Print #f, I;" ";VAcumulim(I,1);" ";VAcumulim(I,2)
       Next                                     
       Print #f," "                                      
       Print #f,"  Header for loop structure: (For Z1 =";Zmincumu;" to";Zmaxcumu; _
                                            ") (For A1 = Amin(Z1) to Amax(Z1)"; _
                                            ") (For Z2 =";Zmincumu;" to";Zmaxcumu; _
                                            ") (For A2 = Amin(Z2) to Amax(Z2))"
       Print #f," "
       Print #f,"The data are written according to the loop structure specified above."
       Print #f,"The last loop is the inner-most one."
       Print #f,"A line break is inserted with a new Z2 value."
       Print #f," "
       Inewline = 0
       For I = Zmincumu To Zmaxcumu 
         For J = VAcumulim(I,1) To VAcumulim(I,2)
           For K = Zmincumu To Zmaxcumu
             For L = VAcumulim(K,1) To VAcumulim(K,2)
               Rout = SZAcumuCovar(I,J-VAcumulim(I,1)+1,K,L-VAcumulim(K,1)+1).Rval
            /' Inewline = Inewline + Len(Str(Round(Rout,4))) + 1
               If Inewline >= 500 Then
                 Print #f, " "
                 Inewline = 0
               End If '/
               Print #f,Trim(Str(Round(Rout,4)));" ";
             Next
           Next    
           Print #f, " "
         Next
       Next
       Print #f," "
       Print #f,"      </ZAcumu_covariances>"
     End If
     If Bcor = 1 Then
       Print #f,"      <ZAcumu_correlations>"
       Print #f,"--- Correlation matrix of cumulative yields ---"
       Print #f," "
       Print #f,"  Key table of Amin and Amax values: (Z,Amin(Z),Amax(Z))"                                     
       For I = Zmincumu to Zmaxcumu
         If VAcumulim(I,2) > 0 Then _
          Print #f, I;" ";VAcumulim(I,1);" ";VAcumulim(I,2)
       Next                                     
       Print #f," "                                      
       Print #f,"  Header for loop structure: (For Z1 =";Zmincumu;" to";Zmaxcumu; _
                                            ") (For A1 = Amin(Z1) to Amax(Z1)"; _
                                            ") (For Z2 =";Zmincumu;" to";Zmaxcumu; _
                                            ") (For A2 = Amin(Z2) to Amax(Z2))"
       Print #f," "
       Print #f,"The data are written according to the loop structure specified above."
       Print #f,"The last loop is the inner-most one."
       Print #f,"A line break is inserted with a new Z2 value."
       Print #f," "
       Inewline = 0
       For I = Zmincumu To Zmaxcumu 
         For J = VAcumulim(I,1) To VAcumulim(I,2)
           For K = Zmincumu To Zmaxcumu
             For L = VAcumulim(K,1) To VAcumulim(K,2)
               Rout = SZAcumuCorr(I,J-VAcumulim(I,1)+1,K,L-VAcumulim(K,1)+1).Rval
            /' Inewline = Inewline + Len(Str(Round(Rout,4))) + 1
               If Inewline >= 500 Then
                 Print #f, " "
                 Inewline = 0
               End If '/
               Print #f,Trim(Str(Round(Rout,4)));" ";
             Next
           Next    
           Print #f, " "
         Next
       Next
       Print #f," "
       Print #f,"      </ZAcumu_correlations>"
     End If
     
     If B_Double_Covar = 1 And I_Double_Covar = 2 Then
       If Bcov = 1 Then
         Print #f,"      <ZAcumu_covariances_2_systems>"
         Print #f,"--- Covariance matrix of the nuclide cumulative yields for the two fissioning systems ---"
         Print #f," "     
         Print #f,"  Key table of Amin and Amax values: (Z,Amin(Z),Amax(Z))"                                     
         For I = Z_Double_min_cumu to Z_Double_max_cumu
           If VAcumu_Double_lim(I,2) > 0 Then _
            Print #f, I;" ";VAcumu_Double_lim(I,1);" ";VAcumu_Double_lim(I,2)
         Next                                     
         Print #f," "                                      
         Print #f,"  Header for loop structure: (For Z1 =";Z_Double_min_cumu;" to";Z_Double_max_cumu; _
                                              ") (For A1 = Amin(Z1) to Amax(Z1)"; _
                                              ") (For Z2 =";Z_Double_min_cumu;" to";Z_Double_max_cumu; _
                                              ") (For A2 = Amin(Z2) to Amax(Z2))"
         Print #f," "
         Print #f,"The data are written according to the loop structure specified above."
         Print #f,"The last loop is the inner-most one."
         Print #f,"A line break is inserted with a new Z2 value."
         Print #f," "
         Inewline = 0
         For I = Z_Double_min_cumu To Z_Double_max_cumu 
           For J = VAcumu_Double_lim(I,1) To VAcumu_Double_lim(I,2)
             For K = Z_Double_min_cumu To Z_Double_max_cumu
               For L = VAcumu_Double_lim(K,1) To VAcumu_Double_lim(K,2)
                 Rout = SZAcumu_Double_Covar(I,J-VAcumu_Double_lim(I,1)+1,K,L-VAcumu_Double_lim(K,1)+1).Rval
              /' Inewline = Inewline + Len(Str(Round(Rout,4))) + 1
                 If Inewline >= 500 Then
                   Print #f, " "
                   Inewline = 0
                 End If '/
                 Print #f,Trim(Str(Round(Rout,4)));" ";
               Next
             Next    
             Print #f, " "
           Next
         Next 
         Print #f," "
         Print #f,"      </ZAcumu_covariances_2_systems>"
       End If
       If Bcor = 1 Then  
         Print #f,"      <ZAcumu_correlations_2_systems>"
         Print #f,"--- Correlation matrix of the nuclide cumulative yields for the two fissioning systems ---"
         Print #f," "     
         Print #f,"  Key table of Amin and Amax values: (Z,Amin(Z),Amax(Z))"                                     
         For I = Z_Double_min_cumu to Z_Double_max_cumu
           If VAcumu_Double_lim(I,2) > 0 Then _
            Print #f, I;" ";VAcumu_Double_lim(I,1);" ";VAcumu_Double_lim(I,2)
         Next                                     
         Print #f," "                                      
         Print #f,"  Header for loop structure: (For Z1 =";Z_Double_min_cumu;" to";Z_Double_max_cumu; _
                                              ") (For A1 = Amin(Z1) to Amax(Z1)"; _
                                              ") (For Z2 =";Z_Double_min_cumu;" to";Z_Double_max_cumu; _
                                              ") (For A2 = Amin(Z2) to Amax(Z2))"
         Print #f," "
         Print #f,"The data are written according to the loop structure specified above."
         Print #f,"The last loop is the inner-most one."
         Print #f,"A line break is inserted with a new Z2 value."
         Print #f," "
         Inewline = 0
         For I = Z_Double_min_cumu To Z_Double_max_cumu 
           For J = VAcumu_Double_lim(I,1) To VAcumu_Double_lim(I,2)
             For K = Z_Double_min_cumu To Z_Double_max_cumu
               For L = VAcumu_Double_lim(K,1) To VAcumu_Double_lim(K,2)
                 Rout = SZAcumu_Double_Corr(I,J-VAcumu_Double_lim(I,1)+1,K,L-VAcumu_Double_lim(K,1)+1).Rval
              /' Inewline = Inewline + Len(Str(Round(Rout,4))) + 1
                 If Inewline >= 500 Then
                   Print #f, " "
                   Inewline = 0
                 End If '/
                 Print #f,Trim(Str(Round(Rout,4)));" ";
               Next
             Next    
             Print #f, " "
           Next
         Next 
         Print #f," "
         Print #f,"      </ZAcumu_correlations_2_systems>"
       End If
     End If     
     
   End If  

