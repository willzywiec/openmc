#!/bin/bash

echo "************************************************************"
echo This shell starts 16 batch jobs of GEF for input from file.
echo The delay is necessary for the multi-thread organisation.
echo Reset the thread variable before, e.g. by deleting the .ctl folder!
echo "Chose 'Preferences/Title and command/Keep the terminal open'"
echo "on a GNOM terminal to keep the terminal open when GEF stops."
echo "************************************************************"

gnome-terminal --title="GEF 1" --zoom=0.65 -- "./GEF"
sleep 1
gnome-terminal --title="GEF 2" --zoom=0.65 -- "./GEF"
sleep 1
gnome-terminal --title="GEF 3" --zoom=0.65 -- "./GEF"
sleep 1
gnome-terminal --title="GEF 4" --zoom=0.65 -- "./GEF"
sleep 1
gnome-terminal --title="GEF 5" --zoom=0.65 -- "./GEF"
sleep 1
gnome-terminal --title="GEF 6" --zoom=0.65 -- "./GEF"
sleep 1
gnome-terminal --title="GEF 7" --zoom=0.65 -- "./GEF"
sleep 1
gnome-terminal --title="GEF 8" --zoom=0.65 -- "./GEF"
sleep 1
gnome-terminal --title="GEF 9" --zoom=0.65 -- "./GEF"
sleep 1
gnome-terminal --title="GEF 10" --zoom=0.65 -- "./GEF"
sleep 1
gnome-terminal --title="GEF 11" --zoom=0.65 -- "./GEF"
sleep 1
gnome-terminal --title="GEF 12" --zoom=0.65 -- "./GEF"
sleep 1
gnome-terminal --title="GEF 13" --zoom=0.65 -- "./GEF"
sleep 1
gnome-terminal --title="GEF 14" --zoom=0.65 -- "./GEF"
sleep 1
gnome-terminal --title="GEF 15" --zoom=0.65 -- "./GEF"
sleep 1
gnome-terminal --title="GEF 16" --zoom=0.65 -- "./GEF"
