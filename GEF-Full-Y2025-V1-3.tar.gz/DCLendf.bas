If CHDIR("ENDF") Then
  MKDIR("ENDF") 
  Print "Subfolder /ENDF created for output of GEF."
Else
  CHDIR("..")
End If    

Dim Shared As Integer fENDF 
Dim Shared As Integer fCUMU
Static As String CGEFY_part,CGEFY  ' name of output file
Static As String CGEFY_last  ' name of last output file
Static As String CGEFY_new ' new output file
Static As String CGEFY_random  ' name of random file

Dim As Single E_ev   ' Energy in units of eV

Declare Sub Testprint(Byref C_in As String,C_trail As String,Byref I_Line As Integer)
Declare Sub TestprintC(Byref C_in As String,C_trail As String,Byref I_Line As Integer)
Declare Function CDouble(R_in As Double) As String
Declare Function CInteger(I_in as Integer,N_digits As Integer) As String 
Declare Function CTrailer(I_MAT As Integer,I_MF As Integer,I_MT As Integer, _
                          I_NS As Integer) As String

'*** Functions and soubroutines *** 

Sub Testprint(Byref C_in As String,C_trail As String,Byref I_Line As Integer)
  If Len(C_in) >= 66 Then
    Print #fENDF, C_in + C_trail
    C_in = ""
    I_Line = I_Line + 1
  End If 
End Sub

Sub TestprintC(Byref C_in As String,C_trail As String,Byref I_Line As Integer)
  If Len(C_in) >= 66 Then
    Print #fCUMU, C_in + C_trail
    C_in = ""
    I_Line = I_Line + 1
  End If 
End Sub

Function CTrailer(I_MAT As Integer,I_MF As Integer,I_MT As Integer, I_NS As Integer) As String
   Dim As String C_Out
   C_Out = CInteger(I_Mat,4)+CInteger(I_MF,2)+CInteger(I_MT,3)+ CInteger(I_NS,5)
   CTrailer = C_Out      
End Function         


Function CDouble(R_in As Double) As String
  ' ENDF single format with 1-digit or 2-digit exponent
   Dim As String C_out
   Dim As Integer Icomma
 
 Repair:  
   If R_in = 0 Then 
     C_out = " 0.000000+0"
   Else
     If (R_in >= 1.E-9 And R_in < 1.E10) Then
       C_out = Format(R_in,"-0.000000E+0")
     Else
       C_out = Format(R_in,"-0.00000E+00")
     End If     
     Icomma = Instr(C_out,",")
     If Icomma > 0 Then
        C_out = Mid(C_out,1,Icomma-1)+"."+Mid(C_out,Icomma+1)
     End If
     If Mid(C_out,1,1) <> "-" Then C_out = " " + C_out
     C_out = Mid(C_out,1,Instr(C_out,"E")-1) + Mid(C_out,Instr(C_out,"E")+1,Len(C_out))
   End If

   If Instr(C_out,"10.00") > 0 Then 
     R_in = R_in * 1.0001
     Goto Repair
   End If

   CDouble = C_out
End Function


Function CInteger(I_in as Integer,N_digits As Integer) As String
   Dim As String C_out
     C_out = Format(I_in,"#####")
     If N_digits <= 5 Then
       C_out = String(N_digits," ") + C_out
       C_out = Right(C_out,N_digits)
     Else
       C_out = String(N_digits," ") + C_out
       C_out = Right(C_out,N_digits)
     End If  
     CInteger = C_out
End Function




 ' heaviest isotopes with information in ENSDF:
HighA:
  Data 7,10,12,16,19,22,25,28,31,34,37,40,43,44,46,49,51,53,55,57,60,_
  63,65,67,69,72,75,78,80,83,86,89,92,94,97,100,101,105,108,110,113,_
  115,118,120,122,124,130,132,135,137,139,142,144,147,151,153,155,_
  157,159,161,163,165,167,169,171,173,175,177,179,181,184,188,190,_
  192,194,200,202,203,205,210


