
  Static Shared As String C_GEF_Version  
  C_GEF_Version = "2025/1.3"
  ' example:      "2012/3.1"  (must have the same length)   
  

  Print " "
  Print "   **************************************************************************"
  Print "   *       Model code for a general description of fission observables      *"
  Print "   *                                 G E F                                  *"
  Print "   *                           Version "+C_GEF_Version+"                             *"
  Print "   *    Copyright 2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,   *"
  Print "   *              2020,2021,2022,2023,2024,2025,2026                                 *"      
  Print "   *                      K.-H. Schmidt and B. Jurado                       *"
  Print "   **************************************************************************"
  Print " "
    
    #Define Compilationstamp __DATE_ISO__ + " at " __TIME__
    Print "   GEF " + C_GEF_Version + " compiled on " + Compilationstamp + "."
    Print
  
'   Dim As String cyes
'   Print " I accept using this code under the GNU General Public License conditions."
'   Print " (See Readme.txt and License.txt, which are provided with this code or"
'   Print "  <http://www.gnu.org/licenses/> .)" 
'   Input " Enter YES if you agree: ",cyes
'   If UCASE(cyes) <> "YES" Then End
'   Print " "
/'<'/

'
'    Copyright 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 
'              2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026 
'       Dr. Karl-Heinz Schmidt, Rheinstrasse 4, 64390 Erzhausen, Germany
'       and 
'       Dr. Beatriz Jurado, Centre d'Etudes Nucleaires de Bordeaux-Gradignan,
'       Chemin du Solarium, Le Haut Vigneau, BP 120, 33175 Gradignan, Cedex,
'       France 
'
'    This program is free software: you can redistribute it and/or modify
'    it under the terms of the GNU General Public License as published by
'    the Free Software Foundation, either version 3 of the License, or
'    (at your option) any later version.
'
'    This program is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'    GNU General Public License for more details.
'
'    You should have received a copy of the GNU General Public License
'    along with this program.  If not, see <http://www.gnu.org/licenses/>.


  /' Documentation: '/
  /' (1) K.-H. Schmidt and B. Jurado, Contribution to '/
  /'     ESNT Workshop "The scission process", Saclay (France), April 12-16, 2010 '/
  /' (2) B. Jurado and K.-H. Schmidt, Contribution to '/
  /'     Seminar an fission, Gent (Belgium), May 17-20, 2010 '/
  /' (3) B. Jurado and K.-H. Schmidt, Contribution to '/
  /'     EFNUDAT Workshop, Paris (France), May 25-27, 2010 '/
  /' (4) K.-H. Schmidt and B. Jurado, Contribution to '/
  /'     EFNUDAT Workshop, Paris (France), May 25-27, 2010 '/
  /' (5) K.-H. Schmidt and B. Jurado, '/
  /'     Final Report to EFNUDAT, October, 2010 '/
  /' (6) K.-H. Schmidt and B. Jurado, Phys. Rev. Lett. 104 (2010) 21250 '/
  /' (7) K.-H. Schmidt and B. Jurado, Phys. Rev. C 82 (2011) 014607 '/
  /' (8) K.-H. Schmidt and B. Jurado, Phys. Rev. C 83 (2011) 061601 '/
  /' (9) K.-H. Schmidt and B. Jurado, arXiv:1007.0741v1[nucl-th] (2010) '/
  /' (10) K.-H. Schmidt and B. Jurado, JEF/DOC 1423, NEA of OECD, 2012 '/  
  /' (11) K.-H. Schmidt and B. Jurado, Phys. Rev. C 86 (2012) 044322 '/
  /' (12) K.-H. Schmidt, B. Jurado, Ch. Amouroux, JEFF-Report 24, NEA of OECD, 2014 '/
  /' (13) B. Jurado, K.-H. Schmidt, J. Phys. G: Nucl. Part. Phys. 42 (2015) 055101 '/
  /' (14) K.-H. Schmidt, B. Jurado, Eur. Phys. J. A 51 (2015) 176 '/
  /' (15) K.-H. Schmidt, B. Jurado, C. Amouroux, C. Schmitt, Nucl. Data Sheets 131 (2016) 107 '/
  /' (16) K.-H. Schmidt, B. Jurado, Rep. Progr. Phys. 81 (2018) 106301 '/
  /' (17) K.-H. Schmidt et al., Nucl. Data Sheets 173 (2021) 54 '/

  /' Further documentation and the newest version of the GEF code are '/
  /' available from                                                   '/
  /' http://www.cenbg.in2p3.fr/GEF and http://www.khschmidts-nuclear-web.eu/ . '/

  
'    The development of the GEF code has been supported by the European Union,
'    EURATOM 6 in the Framework Program "European Facilities for Nuclear Data
'    Measurements" (EFNUDAT), contract number FP6-036434, the Framework
'    Program "European Research Infrastructure for Nuclear Data Applications
'    (ERINDA), contract number FP7-269499, by the OECD Nuclear Energy Agency
'    (from 2010 to 2016), and by the University Nantes (2018).


' Technical remark: The code contains commented sections with 
' control-character sequences (/'<'/ and /'>'/) that serve to automatically 
' produce a deterministic version of the GEF code as a subroutine from this 
' source with a dedicated pre-processor, named ExtractSub.bas. 
' Sections starting with the sequence /'<'/ and ending with the sequence /'>'/
' are used in the deterministic GEF version.
' ExtractSub.bas produces the deterministic code GEFSUB.bas in FreeBASIC.
' The translator FBtoFO.bas can be used to translate this code into FORTRAN99.
' In order to enable this translation, GEF.bas contains already some additional
' statements ( e.g.  /'<FO REAL*4 GAUSSINTEGRAL FO>'/ )   
' that are only used by the translator to provide some specific 
' FORTRAN statements that cannot be produced automatically. 
   

  /' K.-H. Schmidt / B. Jurado, 07/Feb./2009 '/
  /' SEFI9 is taken as a basis and extended by new features in SEFI14 (May 2010), KHS '/
  /' Several improvements (even-odd effect, charge polarization etc. (June 2010), KHS '/
  /' SEFI15 converted from PL/I to FreeBASIC on 04/July/2010, KHS '/
  /' Error in LyPair corrected (26/July/2010) KHS '/
  /' Indices corrected in U_Shell inside Eva (1/Aug/2010) KHS '/
  /' Major developments, sigma_E*(scission), sigma_Z(A) etc. (14/Aug/2010) KHS '/
  /' Macroscopic masses from Thomas-Fermi model (Myers & Swiatecki) (17/Aug/2010) KHS '/
  /' 3 reference options for energy input (4/Sept/2010) KHS '/
  /' Graphic output of mass distribution added (if there are problems with the X11 
      installation on LINUX, the graphics may be suppressed by simply commenting 
      the line  -> #Include Once "DCLPlotting.bas" <- )  (5/Sept/2010) KHS '/
  /' Comparison with ENDF compilation in graphic output (12/Sept/2010) KHS '/
  /' Super-long fission channel included (14/Sept/2010) KHS '/
  /' Overlap of S1 and S2 fission channels in both fragments included (18/Oct/2010) KHS '/
  /' Output of neutron multiplicity distribution added (20/Oct/2010) KHS '/
  /' Decreasing curvature of shells with increasing E* (24/Oct/2010) KHS '/
  /' Angular momenta of fission fragments added (18/Dec/2010) KHS '/
  /' CN angular momentum considered (14/Jan/2011) KHS '/
  /' Numerical stability improved (28/Jan/2011) KHS '/
  /' Output in ENDF format (optional) (4/Feb/2011) KHS '/
  /' Input list from file supported (31/Jan/2011) KHS '/
  /' Multiprocessing supported (5/Feb/2011) KHS '/
  /' Polarization for symmetric fission channel improved (12/Feb/2011) KHS '/
  /' GUI for input (23/Feb/2011) KHS '/
  /' Calculation of fission-fragment angular momentum refined (5/May/2011) KHS '/
  /' Neutron inverse cross section modified (5/August/2011) KHS '/
  /' Even-odd staggering in neutron emission improved (5/August/2011) KHS '/
  /' Slight modifications in angular-momentum distributions (19/October/2011) KHS '/
  /' Gamma emission added (23/November/2011) KHS '/
  /' TKE added (24/November/2011) KHS '/
  /' Neutron spectrum added (25/November/2011) KHS '/
  /' Neutron-gamma competition added (4/December/2011) KHS '/
  /' Composite level density (Egidy + Ignatyuk) refined (31/January/2012) KHS '/
  /' Treatment of GDR refined (14/February/2012) KHS '/
  /' Deformation of S3 channel changed (27/February/2012) KHS '/
  /' Z=44 deformed shell added (supports S1 around Pu) (27/February/2012) KHS '/
  /' Uncertainties from perturbed fission yields (3/March/2012) KHS '/
  /' Validity range extended to Z=120 (with a warning message) (8/March/2012) KHS '/
  /' Neutron emission during fragment acceleration (18/March/2012) KHS '/
  /' Several optimizations (15/April/2012) KHS '/
  /' TF masses of Myers & Swiatecki corrected (pairing shift) (29/May/2012) KHS '/
  /' Correction on intrinsic excitation energy (05/June/2012) KHS '/
  /' Correction on gamma emission (25/September/2012) KHS '/
  /' Free choice of listmode values (13/October/2012) KHS '/
  /' Excitation-energy distribution from file (14/October/2012) KHS '/
  /' Transfer of input from GUI corrected (02/November/2012) KHS '/
  /' Parameters of perturbed calculations modified (02/November/2012) KHS '/
  /' Model parameters je-adjusted (08/November/2012) KHS '/
  /' Input options for isomeric target nuclei (09/November/2012) KHS '/
  /' Random initialisation of the random generator (26/November/2012) KHS '/
  /' Covariance matrix for Z, Apre, Apost, ZApre, ZApost (06/December/2012) KHS '/
  /' Output file in XML format (06/December/2012) KHS '/
  /' Multi-chance fission supported (13/December/2012) KHS '/
  /' Pre-compound emission for (n,f) included (13/December/2012) KHS '/
  /' Some technical corrections and modifications (17/December/2012) KHS '/
  /' Transition from asymmetric to symmetric fission around Fm improved (19/December/2012) KHS '/
  /' Influence of S2 channel on S1 channel in the other fragment included (20/December/2012) KHS'/
  /' List-mode output of pre-fission neutron energies (21/December/2012) KHS '/
  /' Parameterisation for EB-EA from fit to data in Dahlinger et al. (21/December/2012) KHS '/
  /' Fission channel at Z=42 added (seen around Pu in light fragment and around Hg) (23/Dec./2012) KHS '/
  /' Gamma-n / Gamma-f according to Moretto (IAEA Rochester) (23/December/2012) KHS '/
  /' Pre-compound neutron energies modified (24/December/2012) KHS '/
  /' Some technical revisions to avoid crashes in covariances (26/December/2012) KHS '/
  /' Influence of shells on yrast line from Deleplanque et al. (26/December/2012) KHS '/
  /' Fission threshold in multi-chance fission modified (30/December/2012) KHS '/
  /' Output of energies at fission for multi-chance fission (30/December/2012) KHS '/
  /' Several revisions (15/January/2013) KHS '/
  /' New optical model fit (3/February/2013) KHS '/
  /' Gamma-f / Gamma-n modified (3/February/2013) KHS '/
  /' Handling for reading input from file corrected (5/February/2013) KHS '/ 
  /' Data transfer from GUI corrected (6/February/2013) KHS '/
  /' Input dialog re-organized (6/February/2013) KHS '/  
  /' Mass-dependent deformation and charge polarization revised (9/February/2013) KHS '/
  /' Calculation of combined fission channels S12, S22 revised (10/February/2013) KHS '/
  /' Extension of validity range to heavier nuclei (10/February/2013) KHS '/
  /' Improved description of prompt-neutron spectra (21/February/2013) KHS '/
  /' Several technical corrections and developments (April-May/2013) KHS '/
  /' Pre-fission emission of protons considered (14/Mai,2013) KHS '/
  /' Structure of energy list in input file modified (26/May/2013) KHS '/
  /' Option "local fit" added (26/May/2013) KHS '/
  /' Neutron evaporation corrected (more realistic even-odd effect in isotonic distr.) (21/June(2013) KHS '/
  /' Even-odd effect in TKE added (23/June/2013) KHS '/
  /' Calculation of Z-A-covariance matrix corrected (16/July/2013) KHS '/ 
  /' Output of multi-variate distributions corrected for input from file (24/July/2013) KHS '/
  /' New global fit (most important: Energy gain from saddle to scission reduced) (15/September/2013) KHS '/
  /' Even-odd effect in neutron number of fragments modified (17/September/2013) KHS '/
  /' Curvatures of fission valleys adjusted to experimental shells around 132Sn (18/September/2013) KHS '/
  /' Width of S0 corrected: Fit of Rusanov (18/September/2013) KHS '/
  /' Random generator Box with asymmetric diffuseness for S2 (18/September/2013) KHS '/
  /' Gaussian random generator revised (20/September/2013) KHS '/
  /' Mass shift of fission channels with E* modified (22/September/2013) KHS '/
  /' Energy dependence of S1 position corrected, slightly modified parameters (25/September/2013) KHS '/
  /' Initial angular momentum introduced as an input parameter (02/October/2013) KHS '/
  /' Calculation of prompt-neutron emission improved, some model parameters modified (12/October/2013) KHS '/
  /' Technical error, causing incomplete covariance matrices on output corrected  (17/October/2013) KHS '/
  /' Washing of shell effects considerd in shape fluctuations (26/October/2013) KHS '/
  /' Post-scission neutrons added to list-mode output (8/November/2013) KHS '/
  /' Fission-gamma competition refined (10/November/2013) KHS '/
  /' New global fit of model parameters (18/November/2013) KHS '/
  /' Multi-chance fission modified (18/November/2013) KHS '/
  /' A numerical instability removed (20/November/2013) KHS '/
  /' Calculation of multi-chance fission: corrected and modified (28/November/2013) KHS '/
  /' Spurious even-odd effect in fission probabilities (from Moeller's shells) removed (4/December/2013) KHS '/
  /' More precise calculation of E* in n-induced fission (6/December/2013) KHS '/
  /' Pre-fission gamma strength increased (adjusted to Pf(E*) of 238U (22/December/2013) KHS '/
  /' Kinetic energy of prompt neutrons in cm system (fragment-neutron) (10/Janurary/2014) KHS '/
  /' Binnig of prompt-neutron spectra corrected (shift by 50 keV) (10/January/2014) KHS '/
  /' Description of fission barriers modified (15/January/2014) KHS '/
  /' Description of energy-dependent fission probability modified (17/January/2014) KHS '/
  /' E* at scission modified for fission below Bf (4/February/2014) KHS '/
  /' Influence of Z=44 shell on deformation of light fragment (4/February/2014) KHS '/
  /' Tunneling for S1 enhanced (16/February/2014) KHS '/
  /' New global fit of fission channels (strength and position) (19/March/2014) KHS '/
  /' Normalization of distributions for deterministic version corrected (23/May/2014) KHS '/
  /' Calculation of "corrected sample variance" revised (05/September/2014) KHS '/
  /' Uncertainties calculated with "corrected sample variance" (05/September/2014) KHS '/
  /' Shape of "S22" fission channel modified (08/December/2014) KHS '/
  /' Binsize for prompt neutrons set to 1 keV (09/December/2014) KHS '/
  /' Binsize for prompt gammas set to 1 keV (09/December/2014) KHS '/
  /' Fragment excitation energies in listmode (10/December/2014) KHS '/
  /' Shell in symmetric fission channel included in GEFSUB (12/December/2014) KHS '/
  /' Ground-state spin of fragments is taken into account (22/January/2015) KHS '/
  /' Pre-fission gamma emission included (20/February/2015) KHS '/
  /' VMI model for E2 gammas developed and implemented (15/March/2015) KHS '/
  /' Binning of spectrum EN corrected (28/March/2015) KHS '/ 
  /' Energetics of symmetric fission channel revised (5/April/2015) KHS '/
  /' Output of isomeric yields extended (# of events added) (10/April/2015) KHS '/
  /' Control-output for progress of calculation (17/April/2015) KHS '/
  /' Angular-momentum dependence of pairing gap in eva (7/May/2015) KHS '/
  /' Angular-momentum dependent Gf: influence of fissility and temperature (13/May/2015) KHS '/
  /' Influence of angular momentum on mass width by increasing fissiliy (14/May/2015) KHS '/
  /' Mass distribution truncated at zero and A_CN (14/May/2015) KHS '/
  /' Yields of fission modes also for multi-chance fission (7/August/2015) KHS '/
  /' Tentative description of structure in FF distributions around A_CN = 180-200 (8/August/2015) KHS '/
  /' Improved description of asymmetric fission in light nuclei (A_CN < 220) (9/August/2015) KHS '/
  /' Extension of the validity range to lighter nuclei (9/August/2015) KHS '/
  /' Adaptions of ERF function to new FreeBASIC compiler (12/Sept(2015) KHS '/
  /' Allowance for calculations with very large number of events (15/Sept(2015) KHS '/
  /' Slight adjustement of parameters to "repair" deterioation for low E* (21/Sept/2015) KHS '/
  /' Correction of some formatting issues (03/Oct/2015) KHS '/
  /' Calculation of covariances for independent yields corrected (6/Nov/2015) KHS '/
  /' Calculation of covariances between two systems corrected (6/Nov/2015) KHS '/
  /' Output of correlations matrices added (6/Nov/2015) KHS '/
  /' Espectrum.in can now also provide the CN spin (13/Nov/2015) KHS '/
  /' Output for parallel computing better protected (1/March/2016) KHS '/
  /' Output of random files provided (4/March/2016) KHS '/
  /' Prompt-neutron spectrum with variable bin size added (6/April/2016) KHS '/
  /' Overflow problem in tanh and coth corrected (11/April/2016) KHS '/
  /' Experimental masses in evaporation routine (not yet finished) (23/April/2016) KHS '/
  /' Subscriptrange problem in output of neutron energies corrected (29/April/2016) KHS '/  
  /' Gamma spectra with conditions on pre-neutron mass (29/Mai/2016) KHS '/
  /' Relation between energies: experimental masses used (07/Sept/2016) KHS '/
  /' Partial support of p-induced fission (up to Ep = 30 MeV)
       (pre-equilibrium emission not yet implemented, preliminary l-distribution) (07/Sept/2016) KHS '/
  /' Model parameters of fission channels optimized (20/Sept/2016) KHS '/
  /' Neutrons emitted between outer saddle and scission added (21/Sept/2016) KHS '/  
  /' Output of delayed-neutron multiplicities added (25/Sept/2016) KHS '/
  /' New adjustment of model parameters (13/Oct/2016) KHS '/  
  /' Output of delayed-neutron emitters added (13/Oct/2016) KHS '/ 
  /' Uncertainty range of angular momentum added (24/Oct/2016) KHS '/
  /' Uncertainties of prompt-gamma and prompt-neutron characteristics added (24/Oct/2016) KHS '/
  /' Uncertainty of TKE (pre and post) added (06/Nov/2016) KHS '/
  /' Normalization of Maxwell distribution corrected (07/Nov/2016) KHS '/
  /' Declaration of some variables changed to prevent overflow (24/Nov/2016) KHS '/
  /' Energy dependence of shape fluctuations modified (26/Nov/2016) KHS '/
  /' Formatting of output slightly modified (15/Dec/2016,15/May/2017) KHS '/
  /' Fission probabilities added to output (01/Jul/2017) KHS '/
  /' Calculation of correlations between two systems allowed from input file (25/Jul/2017) KHS '/
  /' Input options from file implemented (27/July/2017) KHS '/
  /' Fluctuation of E_intr modified (only E* over Bf considered) (22/Sept/2017) KHS '/
  /' Fluctuation of neck distance introduced (22/Sept/2017) KHS '/
  /' New adjustment of fit parameters with special care for 235U(nth,f), 
        data point for A=129 from ENDF replaced by other measurement (23/Sept/2017) KHS '/
  /' Adjustment of mass-dependent prompt-neutron multiplicities, new general fit (27/Sept./2017) KHS '/
  /' Extension of energy range for energy sorting (27/Sept/2017) KHS '/  
  /' New fit with shape of S2 closer to a Gaussian (3/Oct/2017) KHS '/    
  /' Symmetric fission channel at low energies revised (7/Oct/2017) KHS '/
  /' New comprehensive fit of model parameters (18-31/Oct/2017) KHS '/
  /' Spurious structure at symmetry in pre-neutron yields removed (30/Oct/2017) KHS '/
  /' Odd-even effect on Pf modified (31/Oct/2017) KHS '/
  /' Numerical problem in odd-even effect in Z and A of light nuclei corrected (16/Nov/2017) KHS '/
  /' Minimum collective temperature reduced (16/Nov/2017) KHS '/
  /' Improved parameters of the Z=38 shell (16-22/Nov/2017) KHS '/
  /' Sequence of energy values from file allowed for options "GS" and "EB" (24/Nov/2017) KHS '/
  /' Shell effect in fission probability revised (27/Nov/2017) KHS '/
  /' Calculation of fission probabilities modified (5-20/Dec/2017) KHS '/
  /' Scaling factor for variation of perturbed parameters introduced (20/Jan/2018) KHS '/   
  /' Hbar-Omeaga of charge polarization modified (better agreement with radiochemical data) (24/Jan/2018) KHS '/
  /' Model parameters better adjusted to independent yields of 235U(nth,f) (28/Jan/2018) KHS '/
  /' Calculation of covariances/correlations between 2 systems corrected (29/Jan/2018) KHS '/
  /' New optimization of model parameters (27/Mar/2018) KHS '/
  /' Several simultaneous calculations of the same systems with different energies enabled (27/Mar/2018) KHS '/
  /' Several systems from JEFF 3.1.1 and JEFF 3.3 added to DCLPlotting.bas (28/Mar/2018) KHS '/
  /' Energies and spins for calculation of isomeric yields from NUBASE-2016 (31/Mar/2018) KHS '/
  /' Input dialog (Linux) revised (10/Apr/2018) KHS '/
  /' New optimization of model parameters (28/Apr/2018) KHS '/
  /' Assumed uncertainties of parameter values reduced by a factor of 0.6 (28/Apr/2018) KHS '/
  /' Neutron emission between saddle and scission corrected (10/June/2018) KHS '/
  /' Overflow problem in calculation of fission chances solved (09/July/2018) KHS '/
  /' Shell effect at symmetry is washed out in Getyield with increasing E* (9/Aug/2018) KHS '/
  /' More flexible handling of plotting (15/Dec/2018) KHS '/
  /' More options for calculations from file (e.g. energy spectrum) (15/Dec/2018) KHS '/
  /' NucpropNUBASE2016.bas: estimated data included (16/Dec/2018) KHS '/
  /' Windows version: Technical problem with GUI corrected (18/Dec/2018) KHS '/
  /' File name for energy spectrum on input can be freely chosen in dialog and batch mode (17/Dec/2018) KHS '/
  /' Output of prompt-neutron mean energies extended (30/Dec/2018) KHS '/
  /' Protection of validity range softened (28/Jan/2019) KHS '/
  /' Influence of N=50 shell on charge polarisation introduced (30/Jan/2019) KHS '/  
  /' Spread of gamma energy due to spin of statistical photons introduced (03/Feb/2019) KHS '/
  /' Calculation of fission probability revised (04/Feb/2019) KHS '/
  /' Options "delayed processes" and "ENDF output" separated (09/Feb/2019) KHS '/
  /' Option E* distribution from file with multi-chance fission introduced (17/Feb/2019) KHS '/
  /' Mass-dependent modification of symmetric fission valley around 229Th introduced (05/Mar/2019) KHS '/
  /' Parametrization of the S3 fission channel modified (11/Mar/2019) KHS '/
  /' Delta_S0 parameter values revised (15/Mar/2019) KHS '/
  /' Output of E*-dependent Pfis for option "EM" (15/Apr/2019) KHS '/ 
  /' Momentum of incident particle: effect on pre-fission particle emission and fragments 
                                   (17/Apr/2019) KHS '/ 
  /' Direction in space of pre-scission particles and fragments included in
     list-mode output (17/Apr/2019) KHS '/  
  /' List-mode output of particle kinematics extended (06/May/2019) KHS '/    
  /' Option PnCN in GUI corrected (05/June/2019) KHS '/
  /' Excitation energy used for fission from multi-chance section corrected (06/June/2019) KHS '/   
  /' Emission angle for prompt neutrons with very low E_kin revised (06/June/2019) KHS '/   
  /' P_fis revised: energy-dependent collective enhancement (04/September/2019) KHS '/
  /' Error in calculation of kinematics (causing subscript-range violation) corrected (12/September/2019) KHS '/
  /' Deformation of heavy fragment in fission of nuclei around mercury like
     deformation of light fragments in S1 and S2 in the actinides.
     Deformation of light fragment in fission of nuclei around mercury = 0  
    (From new experimental data of Christelle Schmitt et al., 2019)   (preliminary: 20/December/2019) KHS '/
  /' Data structure for correlation/covariance matrices simplified (02/February/2020) KHS '/  
  /' Initial energy added to name of lmd file in batch mode (02/February/2020) KHS '/  
  /' Option: locally adjusted (=default) or global model parameters in batch mode added (27/February/2020) KHS '/ 
  /' Calculation and output of Chi-square vs. different evaluations and LOHENGRIN data (06/April/2020) KHS '/
  /' List-mode output of state after prompt-gamma emission added (27/April/2020) KHS '/
  /' Correlations and covariances of cumulative yields, also for 2 different systems, implemented (30/April/2020) KHS '/
  /' Filter on specific fission modes introduced (18/July/2020) KHS '/
  /' Nuclear properties for NucProp and DCLbranching extracted from JEFF-3.3 decay file (20/March/2020) Kilian Kern '/
  /' Nuclear properties from JEFF-3.3 included in GEF (26/July/2020) KHS '/
  /' Technical correction: Clearing of spectra for particles and gammas from CN shifted before multi-chance block (09/August/2020) KHS '/ 
  /' More elaborate calculation of threshold for switching on the calculation of multi-chance fission (01/September/2020) KHS '/
  /' Re-organization of the reading of spectroscopic and decay data in DCLbranchingxxx.bas and Nucpropxxx.bas (05/September/2020) KHS '/
  /' Revision of the S4 fission channel (energy dependence from C 102, 054611 (2020)) (04/December/2020) KHS '/
  /' Error messages revised (03/January/2021) KHS '/
  /' Composed level-density formula (const. temp - Fermi gas) exactly matched by adjusted shell in FG regime (20/April/2021) KHS '/
  /' Cumulation process starting from external post-neutron fission yields implemented (16/May/2021) KHS '/
  /' Output of A-dependent gamma multiplicities: extended to N=0 (19/May/2021) KHS '/
  /' More consistent description of S4 (Z around 38) for pre-actinides 
      (dE_Defo_S4 adjusted to mass yields ad low E*) (01/June/2021) KHS '/
  /' T_Rusanov limited in pairing regime (24/Sept/2021) KHS '/
  /' Output of potential energy near outer fission barrier in mode-pockets in /dmp folder (16/January/2022) KHS '/
  /' Option for input of average angular momentum for batch mode (CN fission) added (07/April/2022) KHS '/
  /' Z and A at saddle added to list-mode output (23/May/2022) KHS '/
  /' alpha-induced fission introduced (05/June/2022) KHS '/
  /' User-defined parameters from data file introduced (17/June/2022) KHS '/
  /' Treatment of angular momentum revised (20/June/2022) KHS '/
  /' Comprehensive Monte-Carlo fit implemented (21/December/2022) KHS '/
  /' Value of HOMPOL increased, adjusted to delayed-neutron yields (21/December/2022) KHS '/
  /' Parameter values determined by comprehensive fit (8/January/2023) KHS '/
  /' Nuclear masses updated to AME2020 (30/January/2023) KHS '/
  /' FitparRead added to Parameters.bas (1/February/2023) KHS '/
  /' Option lmd+ added in batch mode (8/February/2023) KHS '/
  /' Energy conservation checked (16/February/2023) KHS '/
  /' Masscurv (Rusanov, Mulgin) assumed to be A dependent (27/February/2023) KHS '/
  /' Bug in MyParameters option removed (7/March/2023) KHS '/
  /' Calculation of Pfis at energies around Bf revised (10/March/2023) KHS '/
  /' Discontinuity in pre-equilibrium emission removed (14/March/2023) KHS '/
  /' Shell near 208Pb introduced (31/March/2023) KHS '/
  /' Z correction in BF-mac removed (not good for SHE) (31/March/2023) KHS '/
  /' Extension to N<=200, Z<=120 (31/March/2023) KHS '/
  /' Erot of CN removed from FF intrinsic energy (09/April/2023) KHS '/
  /' Upper wing of Masscurv1 (curvature of asym. macr. potential) doubled, 
         improvements for yields of n-deficient nuclei (6/July/2023) KHS '/
  /' Z correction in BF-mac re-installed in standard version (6/July/2023) KHS '/       
  /' Dependence from SNmac-SPmac introduced in Masscurv1 (11/July/2023) KHS '/      
  /' New automatic fit of model parameters (11/July/2023) KHS '/       
  /' Suppression of SNmac-SPmac dependence for fission channel around Z = 36 
           (just phenomenological) (22/July/2023) KHS '/
  /' Fission barriers consistently set to those of the NDS paper from 2016 (24/July/2023) KHS '/   
  /' h-bar-omega for P_fis set to the value of 1 MeV as determined already in GEF 2023/1.2 (26/July/2023) KHS '/ 
  /' Erot included in fission probability (04/August/2023) KHS '/ 
  /' Treatment of Emode = 3 and Emode = 13 checked (12/August/2023) KHS '/   
  /' Management of parallel computing in batch mode modified (time step of await reduced to100 ms) (4/September/2023) KHS '/
  /' Cutting extremely small elongations at small E* (by 3rd barrier?) (20/September/2023) KHS '/
  /' Partition between fragment and orbital angular momentum modified (13/November(2023) KHS '/
  /' Neck length at scission adjusted to TKE of the pre-actinides (e.g. 202Pb) (13/November/2023) KHS '/
  /' Handling of MAT numbers modified (unique value for each nucleus) (18/November/2023) KHS '/
  /' Technical problems in treatment of CN spin solved (14/December/2023) KHS ') '/
  /' New tentative description of the suppression of compact shapes (15/December/2023) KHS '/
  /' Organization of parallel computing revised (15/December/2023) KHS '/ 
  /' Allocated memory reduced by more efficient organization (26/December/2023) KHS '/
  /' Odd-even effect in TKE modified (12/January/2024) KHS '/
  /' Level of S11 fission channel decreased by 100 keV (14/January/2024) KHS '/
  /' Peak in contr. of Z=50 shell to S2 mode flattened (to improve U238F) (1/August/2024) KHS '/
  /' Onset of S1 suppression smoothed out (to improve U238F) (1/August/2024) KHS'/
  /' S1: slight deformation (by neck) in heavy fragment introduced (1/August/2024) KHS '/
  /' Transition from const. temp. to Fermi-gas level density in EVA corrected (2/August/2024) KHS '/ 
  /' Code modified to be compatible with the 64-bit compiler (9/September/2024) KHS '/
  /' Neutron emission below pairing gap in even-even nuclei suppressed (21/October/2024) KHS '/
  /' Table of nuclear properties updated (NuProbNUBASE2020) (22/October/2024) KHS '/
  /' Tables DCLbranchingJEFF33, NucPropNUBASE2020 and DCLbranchingNUBASE20 revised (12/November/2024) J. Collin, KHS '/
  /' Calculation of isobaric independent and cumulative yields revised (12/November/2024) KHS '/
  /' Variation of momentum of inertia at barrier as a function of Z^2/A modified (9/December/2024) KHS '/
  /' Indentation of source file GEF.bas revised (18/December/2024) KHS '/
  /' Slightly modified description of the suppression effects in the light actinides 
       and the deformation energy of very heavy fragments in S2 and S3 (1/January/2025) KHS '/
  /' Gradually lowered 3rd barrier above U (6/March/2025) KHS '/    
  /' Influence of shell effects on T_Egidy adjusted to 235U(n,f), En = 14 MeV (23/June/2025) KHS '/ 
  /' Increase of macroscopic potential for very large asymmetry (25/June/2025) KHS '/
  /' Lower curvature of the potential at the saddles (05/July/2025) KHS '/
  /' Probabilities of nucleon emission w/o fission added (06/July/2025 KHS '/
  /' Typo in the filling of spectrum EdefoA corrected (07/September/2025) KHS '/
  /' Deformation of light fragment from S3 modified (set equal to S2) (07/September/2025) KHS '/
  /' Technical problem in GUI treatment solved (08/September/2025) KHS '/
  /' Stand-alone version checked against Monte-Carlo version, GEFSUB.FOR updated (18/October/2025) KHS '/
  /' Parallel computing with different energy distributions enabled (23/November/2025) KHS '/
  /' Calculation of fragment deformation for SL optimized (gain in speed of GEF around 40%) (13/February/2026) KHS '/
  /' Yield and beta of S1 adopted to xxxPu(sf) (3 modifications), only SF changed from Y2025/1.2) (18-19/February/2026) KHS '/ 
  /' Upper limmit of Shell_S1 removed (18/February/2026) KHS '/
  /' beta_S1 of heavy fragment reduced (19/February/2026) KHS '/
  /' T_low_S1: Z dependence changed (19/February/2026) KHS '/
  /' Multiprocessing with energy distribution of CN revised (3/March/2026) KHS '/   
  /' T_low_S1 for Z<94: using the value for Z=94 (for 238U(sf) ) (23/March/2026) KHS '/  


  /' FreeBASIC is available from http://www.freebasic.net/ '/
  /' FreeBASIC runs on Windows, Linux, and DOS. '/
  /' FreeBASIC runs also under Wine on MAC OS. '/
  /' FreeBASIC compiles a binary code that uses the C run-time library. '/
 
     
  
/'>'/

  /'*** Important compilation options: ***'/
  #define B_delayed  ' Comment this line, when delayed processes are not needed.
                      ' This option is also required for output in ENDF format.    
'  #define B_EgammaA  ' Comment this line, when output of mass-dependent gammas is not needed.
  /'**************************************'/
  Dim As UBYTE B_ENDF = 0
  #If defined(B_delayed) 
    B_ENDF = 1
  #Endif  

  #Include Once "file.bi"
  #Include "vbcompat.bi"  
/'<'/  
  #Include "utilities.bi"
/'>'/
  #ifdef __FB_WIN32__
    #include "Mutex.bas"
    ' Declaration of Waitsynch_GUI
  #endif
  

  
   ' Check and create subfolders for output of GEF
  If CHDIR("ctl") Then
    MKDIR("ctl")
    Print "Subfolder /ctl created for output of GEF."
  Else
    CHDIR("..")
  End If  
   
  If CHDIR("out") Then
    MKDIR("out")
    Print "Subfolder /out created for output of GEF."
  Else
   CHDIR("..")
  End If  
   
  If CHDIR("tmp") Then
    MKDIR("tmp") 
    Print "Subfolder /tmp created for output of GEF."
  Else
    CHDIR("..")
  End If    

  If CHDIR("dmp") Then
    MKDIR("dmp") 
    Print "Subfolder /dmp created for output of GEF."
  Else
    CHDIR("..")
  End If    
   
  If CHDIR("GRAF") Then
    MKDIR("GRAF") 
    Print "Subfolder /GRAF created for output of GEF."
  Else
    CHDIR("..")
  End If    

  If CHDIR("BestFit") Then
    MKDIR("BestFit") 
    Print "Subfolder /BestFit created for output of GEF."
  Else
    CHDIR("..")
  End If    

 /'  CHDIR("GRAF")
   If CHDIR("BestFit") Then
     MKDIR("BestFit") 
     Print "Subfolder /GRAF/BestFit created for output of GEF."
   Else
     CHDIR("..")
   End If
   CHDIR("..")  '/

  If CHDIR("External") Then
    MKDIR("External") 
    Print "Subfolder /External created for evtl. input of external yields into GEF."
    Print "See README.txt file for details!"
  Else
    CHDIR("..")
  End If    
   

/'<'/


  /' Functions and subroutines '/
  
  Declare Function _ 
      Getyield(E_rel As Single,E As Single,E_shell As Single, dE_defo As Single, _
                  T_low As Single,T_high As Single,T_high_mac As Single,Imode As Integer) As Single
     	
  Declare Function F1(Z_S_A As Single) As Single
  Declare Function F2(Z_S_A As Single) As Single
  Declare Function Masscurv(Z As Single, A As Single, RL As Single, _
                  kappa As Single, kappa4 As Single) As Single
  Declare Function Masscurv1(Z As Single, A As Single, RL As Single, _
                  kappa As Single, kappa4 As Single) As Single

  Declare Function Masscurv2(Z As Single, A As Single, RL As Single, _
                  kappa As Single, kappa4 As Single) As Single

  Declare Function De_Saddle_Scission(Z_CN_in As Single, A_CN_in As Single, _
                  ESHIFTSASCI As Single) As Single
           
  Declare Function TKE_Viola(Z_CN As Single, A_CN As Single) As Single

  Declare Function TEgidy(A As Single,DU As Single,Fred As Single) As Single
   
  Declare Function TRusanov(E As Single, A As Single) As Single

  Declare Function LyMass(Z As Single,A As Single,beta As Single) As Single

  Declare Function LyPair(Z As Integer,A As Integer) As Single

  Declare Function TFPair(Z As Integer,A As Integer) As Single

  Declare Function Pmass(Z As Single,A As Single,beta As Single) As Single

  Declare Function FEDEFOLys(Z As Single,A As Single,beta As Single) As Single
   
  Declare Function FEDEFOP(Z As Single,A As Single,beta As Single) As Single

  Declare Function LDMass(Z As Single,A As Single,beta As Single) As Single
   
  Declare Function AME2020(Z As Integer,A As Integer) As Single

  Declare Function U_SHELL(Z As Integer,A As Integer) As Single
   
  Declare Function U_SHELL_exp(Z As Integer, A As Integer) As Single   
   
  Declare Function U_SHELL_EO_exp(Z As Integer, A As Integer) As Single

  Declare Function U_MASS(Z As Single,A As Single) As Single

  Declare Function ECOUL( _
	        Z1 As Single,A1 As Single,beta1 As Single,Z2 As Single,A2 As Single, _
           beta2 As Single,d As Single) As Single

  Declare Function beta_light(Z As Integer,betaL0 As Single,betaL1 As Single) As Single

  Declare Function beta_heavy(Z As Integer,betaH0 As Single,betaH1 As Single) As Single

  Declare Function _
           Z_equi(ZCN As Integer,A1 As Integer,A2 As Integer, _
           beta1 As Single,beta2 As Single,d As Single, Imode As Integer) _
           As Single

  Declare Sub Beta_opt_light(A1 As Single,A2 As Single,Z1 As Single,Z2 As Single, _
           d As Single,beta2_imposed As Single,ByRef beta1_opt As Single)

  Declare Sub Beta_Equi( _
           A1 As Single,A2 As Single,Z1 As Single,Z2 As Single,d As Single, _
          beta1prev As Single,beta2prev As Single, _
          ByRef beta1opt As Single,ByRef beta2opt As Single)
/'>'/
  Declare Sub Eva(Ilh As Integer, _
          Z_CN As Single,A_CN As Single,E_INIT As Single,T As Single, J_frag As Single, _
          ByRef Z_RES As Single,ByRef A_RES As Single, ByRef E_FINAL As Single, _
          Array_En() As Single, Array_Tn() As Single, Array_Eg0() As Single)
   
  Declare Function u_accel(A1 As Single,Z1 As Single,A2 As Single,Z2 As Single, _
          TKE As Single,E0 As Single,Tn As Single) As Single 
   
  Declare Function P_Egamma_high(Zi as Single, Ai As Single, Ei As Single) As Single

  Declare Function P_Egamma_low(Zi as Single, Ai As Single, Ei As Single) As Single
/'<'/      

  Declare Function U_Ired(Z As Single,A As Single) As Single

  Declare Function U_IredFF(Z As Single,A As Single) As Single
   
  Declare Function U_I_Shell(Z As Single, A As Single) As Single
   
  Declare Function U_alev_ld(Z As Single, A As Single) As Single
   
  Declare Function U_Temp(Z As Single, A As Single, E As Single, Ishell As Integer, _
             Ipair As Integer, Tscale As Single,Econd As Single, Etrans As Single) As Single
/'>'/  
  Declare Function U_levdens_Egidy(Z As Integer, A As Integer, E As Single, Ishell As Integer, _
             Ipair As Integer, Tscale As Single, Econd As Single, Etrans As Single, af_an As Single) As Double

  Declare Function U_levdens_FG(Z As Integer, A As Integer, E As Single, Ishell As Integer, _
             Ipair As Integer, Tscale As Single, Econd As Single, Etrans As Single, af_an As Single) As Double

  Declare Function U_levdens_old(Z As Integer, A As Integer, E As Single, Ishell As Integer, _
             Ipair As Integer, Tscale As Single, Econd As Single, Etrams As Single, af_an As Single) As Double

  Declare Function U_levdens(Z As Integer, A As Integer, E As Single, Ishell As Integer, _
             Ipair As Integer, Tscale As Single, Econd As Single, Etrans As Single, af_an As Single) As Double

  Declare Function U_Temp2(Z As Single, A As Single, E As Single, Rshell As Single, _
             Rpair As Single, Tscale As Single,Econd As Single,Etrans As Single) As Single

  Declare Function E0_GDR(Z As Single, A As Single) As Single
   
  Declare Function Width_GDR(E0 As Single) As Single
   
  Declare Function Sigma_GDR(Z As Single,A As Single,E As Single,E0 As Single, _
             WidthK As Single) As Single
              
  Declare Function Efac_def_GDR(Beta As Single,Gamma As Single,K As Single) As Single
   
  Declare Function TK_GDR(Z As Single,A As Single,E As Single) As Single   
   
  Declare Function GgGtot(Z As Single, A As Single, E As Single, Egamma As Single) As Single
   
  Declare Function E_next(T1 As Single,T2 As Single,E1 As Single,E2 As Single,A1 As Single,A2 As Single) _
             As Single
  Declare Function EVEN_ODD(R_ORIGIN As Single,R_EVEN_ODD As Single) As Integer
/'<'/

  Declare Function U_Even_Odd(I_Channel As Integer,PEO As Single) As Single
   
  Declare Function BFTF(RZ As Single,RA As Single,I_Switch As Integer) As Single
  Declare Function BFTFA(RZ As Single,RA As Single,I_Switch As Integer) As Single
  Declare Function BFTFB(RZ As Single,RA As Single,I_Switch As Integer) As Single
   
  Declare Function Acentral(Z As Single) As Single

  Declare Function Gaussintegral(R_x As Single,R_sigma As Single) As Single
/'>'/

  Declare Sub Printcomments
   

/'<'/

   /' Utility functions '/


  Declare Function U_Box(x As Single,sigma As Single, _ 
                  width As Single) As Single
  Declare Function U_Box2(x As Single,sigma1 As Single, sigma2 As Single, _ 
                  width As Single, slope As Single) As Single
  Declare Function U_Gauss(x As Single,sigma As Single) As Single
  Declare Function U_Gauss_abs(x As Single,sigma As Single) As Single
  Declare Function U_Gauss_mod(x As Single,sigma As Single) As Single
  Declare Function U_LinGauss(x As Single,R_Sigma As Single) As Single
  Declare Function Bell(xpos As Single, xleft As Single, xright As Single) As Single
/'>'/
  Declare Function Round(R As Single, N As Integer) As Single        
  Declare Function Pexplim(R_lambda As Single,xmin As Single,xmax As Single) As Single
  Declare Function PBox(Mean As Single,Sigma As Single,Width As Single) As Single 
  Declare Function PBox2(Mean As Single,Sigma1 As Single,Sigma2 As Single, _
              Bottom As Single,Rslope As Single) As Single
  Declare Function PPower(Order As Integer, Rmin As Single, Rmax As Single) As Single    
  Declare Function PPower_Griffin_v(Order As Integer, Rmin As Single, Rmax As Single) As Single    
  Declare Function PPower_Griffin_E(Order As Integer, Rmin As Single, Rmax As Single) As Single    
  Declare Function PGauss(Mean As Single,Sigma As Single) As Single
  Declare Function PLinGauss(Sigma As Single) As Single
  Declare Function PExp(Tau As Single) As Single
  Declare Function PMaxwell(R_T As Single) As Single
  Declare Function PMaxwellMod(R_T As Single,R_A As Single) As Single
  Declare Function PMaxwellv(R_T As Single) As Single
  Declare Function Floor(R As Single) As Single
  Declare Function Ceil(R As Single) As Single
  Declare Function Modulo(I As ULongint, J As ULongint) As Longint  
  Declare Function PLoss(IL As Ulongint) As Integer
  #Ifdef B_EgammaA 
    Declare Sub StoreEgammaA(Egamma1keV As Integer, Apre As Integer)
  #EndIf 
/'<'/

  Declare Function U_Valid(I_Z As Integer,I_A As Integer) As Ubyte
  Declare Function U_Delta_S0(I_Z As Integer,I_A As Integer) As Single 

/'>'/   

  Dim Shared As Double Timeoffset = 0
  Declare Sub await (Ithread As Integer,Ithreadmax As Integer) 
  Sub await(Ithread As Integer,Ithreadmax As Integer)
    ' The thread waits for its time window for writing 
    ' to a common file (start time defined by the clock, duration 100 millisecond)
    Dim As Integer isec
    Do
      sleep 10
      Isec = Int( (Timer - Timeoffset)*10 ) Mod (Ithreadmax + 1)
      '  isec = second(now) mod (Ithreadmax + 1)
    Loop Until isec = Ithread  
  End Sub
   
   
  Dim As Integer I_Anl = 0
  Dim Shared As Integer N_Anl
   
       ' UDT for analyzer attributes
  Type Analyzer_Attributes
    As String*128 C_Name
    As String*128 C_Title
    As String*128 C_xaxis
    As String*128 C_yaxis
    As String*128 C_Linesymbol
    As String*20 C_Type
    As Single R_ALim(1 to 4,1 to 3) 
    As Integer I_Dim
    Declare Constructor
    Declare Destructor
  End Type
  Constructor Analyzer_Attributes
    R_ALim(1,1) = 0  ' first bin (or element of array)
    R_ALim(1,3) = 1  ' binsize
    R_ALim(2,1) = 0  ' first bin (or element of array)
    R_ALim(2,3) = 1  ' binsize
    R_Alim(3,1) = 0  ' first bin (or element of array)
    R_ALim(3,3) = 1  ' binsize
    R_Alim(4,1) = 0  ' first bin (or element of array)
    R_ALim(4,3) = 1  ' binsize
    I_Dim = 1        ' dimension of analyzer
    C_xaxis = "Channel"
    C_yaxis = "Counts"
    C_Linesymbol = "HT0"
    C_Type = "analog"
  End Constructor
  Destructor Analyzer_Attributes
  End Destructor
   
  Declare Function Find_IAnl(CAnl As String) As Integer
  Declare Sub U_DMP_1D(Array() As Double,CName As String,Ccmt As String)  
  Declare Sub U_DMP_1D_S(Array() As Single,CName As String,Ccmt As String)  '/


  Dim Shared As String CdmpFolder
  Dim Shared As Integer DMPFile

      
  Dim Shared As Ubyte Bsub = 0  ' For extracting the subroutine version of GEF.

/'<'/


/' Internal variables '/
  Dim As Double Rdatetime
  Const As Single pi = 3.14159
  Dim Shared As Integer I_N_CN /' Neutron number of fissioning nucleus '/
  Dim Shared As Longint I,J,K
  Dim Shared As Single T_coll_Mode_1,T_coll_Mode_2,T_coll_Mode_3,T_coll_Mode_4,T_coll_Mode_5
  Dim Shared As Single T_asym_Mode_1,T_asym_Mode_2,T_asym_Mode_3,T_asym_Mode_4,T_asym_Mode_5,T_asym_Mode_0
  Dim Shared As Single Sigpol_Mode_1,Sigpol_Mode_2,Sigpol_Mode_3,Sigpol_Mode_4,Sigpol_Mode_5
  Dim Shared As Single R_Z_Curv_S0,R_Z_Curv1_S0,R_A_Curv1_S0,R_Z_Curv2_S0,R_A_Curv2_S0
  Dim Shared As Single ZC_Mode_0,ZC_Mode_1,ZC_Mode_2,ZC_Mode_3,ZC_Mode_4,ZC_Mode_5
  Dim Shared As Single DZ_asym
  Dim Shared As Single ZC_Mode_3_shift
  Dim Shared As Single SigZ_Mode_0,SigZ_Mode_1,SigZ_Mode_2,SigZ_Mode_3,SigZ_Mode_4,SigZ_Mode_5
  Dim Shared As Single SigZ_SL5
  Dim Shared As Single SN,Sprot,Salpha,Balpha,Bprot
  Dim Shared As Single E_exc_S0_prov,E_exc_S1_prov,E_exc_S2_prov,E_exc_S3_prov,E_exc_S4_prov,E_exc_S5_prov
  Dim Shared As Single E_exc_S11_prov,E_exc_S22_prov
  Dim Shared As Single E_exc_Barr
  Dim Shared As Single E_LD_S1,E_LD_S2,E_LD_S3,E_LD_S4,E_LD_S5
  Dim Shared As Single R_Shell_S1_eff,R_Shell_S2_eff,R_Shell_S3_eff,R_Shell_S4_eff,R_Shell_S5_eff
  Dim Shared As Single Yield_Norm
  Dim Shared As Single R_E_exc_eff
  Dim Shared As Single R_Z_Heavy,R_Z_Light
  Dim Shared As Integer I_Mode
  Dim Shared As Single P_selected
  Dim Shared As Integer I_Mode_selected = -1
  Dim Shared As Single T_Pol_Mode_0,T_Pol_Mode_1,T_Pol_Mode_2,T_Pol_Mode_3,T_Pol_Mode_4,T_Pol_Mode_5
  Dim Shared As Single E_Min_Barr
  Dim Shared As Single RI
  Dim Shared As Single rbeta, beta1, beta2
  Dim Shared As Single rbeta_ld, rbeta_shell
  Dim Shared As Single ZUCD
  Dim Shared As Single Z
  Dim Shared As Single E_tunn, E_tunn_S1, E_tunn_S2, E_tunn_S3, E_tunn_S4
  Dim Shared As Single EsciS0, EsciS1, EsciS2, EsciS3, EsciS4, EsciS5 
  Dim Shared As Ubyte B_supp = 1 ' suppression of compact scission configurations
  Dim Shared As Single R_slope_S2, R_supp_S0,R_supp_S1, R_supp_S2, R_Supp_S3
  Dim Shared As Single DEsupp 
  Dim Shared As Single beta1_opt,beta2_opt,beta1_prev,beta2_prev
  Dim Shared As Integer I_Z_CN_last, I_A_CN_last                ' avoid multiple calculation of betax_opt
  Dim Shared As Ubyte B_keep                                    '  "  
  Dim Shared As Single Z1,Z2
  Dim Shared As Integer IZ1,IN1,IZ2,IN2
  Dim Shared As Single A1,A2
  Dim Shared As Integer IA1,IA2
  Dim Shared As Single E_defo
  Dim Shared As Single R_Pol_Curv_S0, R_Pol_Curv_S1, R_Pol_Curv_S2,R_Pol_Curv_S3,R_Pol_Curv_S4,R_Pol_Curv_S5
  Dim Shared As Single RA,RZ
  Dim Shared As Single SigA_Mode_0, SigA_Mode_1, SigA_Mode_2,SigA_Mode_3,SigA_Mode_4,SigA_Mode_5
  Dim Shared As Single AC_Mode_0, AC_Mode_1, AC_Mode_2, AC_Mode_3, AC_Mode_4,AC_Mode_5
  Dim Shared As Single R_A_heavy, R_A_light
  Dim Shared As Single RZpol
  Dim Shared As Single B_nopot  ' no potential pockets calculated
 '   Dim Shared As Single B_nosort = 0 ' switch to couple pre-fission and fission directly
  Dim Shared As Single ZEO_GEF
/'>'/    
  Dim As Single Eexc_light,Eexc_heavy
                  
  Dim As String C_pfis   ' file name for decay widths and probabilities 
  Dim As String C_pfis2  ' file name for decay widths and probabilities

/'<'/    
  Dim Shared As Single T_intr_Mode_0,T_intr_Mode_1_heavy,T_intr_Mode_1_light
  Dim Shared As Single T_intr_Mode_2_heavy,T_intr_Mode_2_light
  Dim Shared As Single T_intr_Mode_3_heavy,T_intr_Mode_3_light
  Dim Shared As Single T_intr_Mode_4_heavy,T_intr_Mode_4_light
  Dim Shared As Single T_intr_Mode_5_heavy,T_intr_Mode_5_light
  Dim Shared As Single T
  Dim Shared As Single DU0,DU1,DU2,DU3,DU4,DU5
/'>'/    
  Dim Shared As Single E_intr,E_intr_light,E_intr_heavy
  Dim Shared As Single E_intr_light_S0_mac,E_intr_heavy_S0_mac,RW_mac  
  Dim Shared As Single E_intr_light_S0_mic,E_intr_heavy_S0_mic   
  Dim Shared As Single E_intr_light_mean,E_intr_heavy_mean
  Dim Shared As Single Eexc_heavy_mean, Eexc_light_mean
  Dim Shared As Single Ecoll,Ecoll_mean,Ecoll_heavy,Ecoll_light
  Static As Single E_EXC_TRUE,E_EXC_ISO  ' Excitation energy of isomeric state
  Dim Shared As Single Qvalue_sad,Qvalue_sci,TKEmin
  Dim Shared As Single Rtest
  Dim Shared As Single Theavy,Tlight
    
  Dim Shared As Single Edef1,Edef2,Erot1,Erot2,Eintr1,Eintr2 ' for list-mode output
  Dim Shared As Single Edef1_mean,Edef2_mean
/'<'/    
  Dim Shared As Single T_low_S1_used
  Dim Shared As Single SigA_Mode_11,SigA_Mode_22
  Dim Shared As Integer Ngtot = 0
  Dim Shared As Integer Nglight = 0
  Dim Shared As Integer Ngheavy = 0
  Dim Shared As Single Egtot1000 = 0
  Dim Shared As Single S1_enhance, S2_enhance, S1_enhance_S2
  Dim Shared As Single DZ_S2_lowE = 0    
  Dim Shared As Integer I_A_CN,I_Z_CN
/'>'/  
  Dim Shared As Single TKE, TKE_post, Ekinlight, Ekinheavy, Ekinlight_post, Ekinheavy_post
  Dim Shared As Single Ekinlight_sci, Ekinheavy_sci
  Dim Shared As Single vkinlight,vkinheavy
    
  /' Input parameters: '/
  Dim As String kin   ' Key input
  Dim As String Cyesno
  Static Shared As Integer I_thread = 0  ' Thread number of this process
  Dim Shared As integer I_thread_last = 0
  Dim Shared As Integer I_thread_first = 0
    
  Dim Shared As UByte B_Error_On = 0        /' Error analysis required '/
  Dim As UByte B_Error_Analysis
  Dim As Integer N_Error_Max = 10    /' Number of different random parameter sets '/    
  Dim As Integer I_Error = 0         /' Counts the parameter sets '/
    ' I_Error runs from 0 to N_Error_Max - 1!
  Dim Shared As Integer B_Print_Chisquare  /' Output of Chisqr values to general out put file '/
        
  Dim As UByte B_Fit = 0     /' Fit option '/
  Dim As String C_Fitoption    /' Quantity used for Fit option '/
  Dim As LongInt I_Fitloop   /' Counts the fit loops '/
  Dim As UByte B_New_Fit_Parameters
  Dim As Integer N_iter = 0   /' Number of fit iterations '/
    
  Dim As UByte B_Random_on = 0       /' Write ENDF random files '/
    
  Dim As Integer I_DelGam = 0

  Dim Shared As Integer P_Z_CN = 92           /'`Z of fissioning nucleus '/
  Dim Shared As Integer P_A_CN = 236          /' A of fissioning nucleus '/
  Dim As Single P_E_exc = 2                   /' Energy above lowest outer barrier EB '/
    
  Dim As UByte B_Double_Covar = 0    /' Option: covariances for yields of 2 fragments '/
  Dim As Integer I_Double_Covar      /' Sequence of calculations for 2 fragments '/
  Dim As Integer N_Double_Covar
  Dim As Integer P_Z_CN_Double 
  Dim As Integer P_A_CN_Double
  Dim As Single P_E_exc_Double
    
/'<'/
  Dim Shared As Single P_I_rms_CN = 0                  /' rms initial angular momentum '/

    ' Model parameters of GEF

  Dim Shared As Single  Emax_valid = 100      /' Maximum allowed excitation energy '/
  Dim As Single Eexc_min_multi = 3            /' Threshold for calc. of multi-chance fission '/
  Dim Shared As Single _Delta_S0 = 0         /' Shell effect for SL, for individual systems '/
  Dim Shared As Single EOscale = 1.0         /' Scaling factor for even-odd structure in yields '/
  Dim Shared As Integer Emode = 1      /' 0: E over BF_B; 1: E over gs; 2: E_neutron; 12: E_proton '/
  Dim Shared As Single D_Par_Fac = 1          /' Scales the variation of perturbed parameters '/
 
  Dim Shared As Single Chisqr_Fit_min

  Dim Shared As Single _P_DZ_Mean_S1
  Dim Shared As Single _P_corr_S1
  Dim Shared As Single _P_DZ_Mean_S2
  Dim Shared As Single _P_DZ_Mean_S3     /' Shift of mean Z of Mode 3 '/
  Dim Shared As Single _P_DZ_Mean_S4     /' Shift of mean Z of Mode around Z=82 '/
  Dim Shared As Single _P_DZ_Mean_SL5     /' Shift of mean Z of Mode around Z=36 for around Pu '/
  Dim Shared As Single _P_DZ_Mean_S5     /' Shift of mean Z of Mode around Z=36 '/
  Dim Shared As Single  ZC_Mode_SL5  ' enhances S1 near Pu
  Dim Shared As Single _P_Z_Curv_S1
  Dim Shared As Single P_Z_Curvmod_S1    /' Scales energy-dependent shift '/ 
  Dim Shared As Single _P_Z_CurV_S2      
  Dim Shared As Single _S2leftmod     /' Asymmetry in diffuseness of S2 mass peak '/ 
  Dim Shared As Single P_Z_Curvmod_S2    /' Scales energy-dependent shift '/
  Dim Shared As Single _P_A_Width_S2   /' A width of Mode 2 (box) '/
  Dim Shared As Single P_Cut_S2        /' Divide S2 into two modes, S2a and S2b '/
  Dim Shared As Single Fmod_slope_S2  /' Slope modification of linear part of potential '/
  Dim Shared As Single _P_Z_Curv_S3 
  Dim Shared As Single P_Z_Curvmod_S3    /' Scales energy-dependent shift '/
  Dim Shared As Single _P_Z_Curv_S4
  Dim Shared As Single _P_Z_Curv_SL5
'    Dim Shared As Single P_Z_Sigma_SL5 
  Dim Shared As Single _P_Z_Curv_S5
  Dim Shared As Single P_Z_Curvmod_S4   /' Scales energy-dependent shift '/
  Dim Shared As Single P_Z_Curvmod_S5   /' Scales energy-dependent shift '/
  Dim Shared As Single _P_Shell_S1     /' Shell effect for Mode 1 (S1) '/
  Dim Shared As Single _P_Shell_S2     /' Shell effect for Mode 2 (S2) '/
  Dim Shared As Single _P_Shell_S3     /' Shell effect for Mode 3 (SA) '/
  Dim Shared As Single _P_Shell_S4    /' Shell effect for Mode 4  (Z=82) '/
  Dim Shared As Single _P_Shell_SL5    /' Shell enhancing S1 '/
  Dim Shared As Single _P_Shell_S5    /' Shell effect for Mode 5  (Z=36) '/
  Dim Shared As Single P_S5_mod     /' Variation of S5 shell with N_CN (reference: 205Bi) '/
  Dim Shared As Single _PZ_S3_olap_pos     /' Pos. of S3 shell in light fragment (in Z) '/
  Dim Shared As Single _PZ_S3_olap_curv 
  Dim Shared As Single ETHRESHSUPPS1    
  Dim Shared As Single ESIGSUPPS1      
  Dim Shared As Single Level_S11         /' Level for mode S11 '/
  Dim Shared As Single Shell_fading    /' fading of shell effect with E* '/
  Dim Shared As Single _T_low_S1  
  Dim Shared As Single _T_low_S2       /' Slope parameter for tunneling '/
  Dim Shared As Single _T_low_S3       /' Slope parameter for tunneling '/
  Dim Shared As Single _T_low_S4       /' Slope parameter for tunneling '/
  Dim Shared As Single _T_low_S5       /' Slope parameter for tunneling '/
  Dim Shared As Single _T_low_SL       /' Slope parameter for tunneling '/
  Dim Shared As Single T_low_S11      /' Slope parameter for tunneling '/
  Dim Shared As Single T_low_S22
  Dim Shared As Single _P_att_pol      /' Attenuation length of 132Sn shell '/
  Dim Shared As Single P_att_pol2  
  Dim Shared As Single P_att_pol3 
  Dim Shared As Single _P_att_rel     /' Relative portion of attenuation '/
  Dim Shared As Single _dE_Defo_S1     /' Deformation energy expense for Mode 1 '/
  Dim Shared As Single _dE_Defo_S2     /' Deformation energy expense for Mode 2 '/
  Dim Shared As Single _dE_Defo_S3     /' Deformation energy expense for Mode 3 '/
  Dim Shared As Single _dE_Defo_S4     /' Deformation energy expense for Mode 4 '/
  Dim Shared As Single _dE_Defo_S5     /' Deformation energy expense for Mode 5 '/    
  Dim Shared As Single _betaL0 
  Dim Shared As Single _betaL1 
  Dim Shared As Single _betaH0        /' Offset for deformation of heavy fragment '/
  Dim Shared As Single _betaH1 
  Dim Shared As Single _dbeta_S3
  Dim Shared As Single kappa         /' N/Z dedendence of A-asym. potential '/
  Dim Shared As Single kappa4        /' Dahlinger appoach '/
  Dim Shared As Single BFC           /' third saddle '/
  Dim Shared As Single TCOLLFRAC     /' Tcoll per energy gain from saddle to scission '/
  Dim Shared As Single _ECOLLFRAC      
  Dim Shared As Single TFCOLL   
  Dim Shared As Single TCOLLMIN 
  Dim Shared As Single ESHIFTSASCI_intr   /' Shift of saddle-scission energy '/ 
  Dim Shared As Single ESHIFTSASCI_coll    /' Shift of saddle-scission energy '/
  Dim Shared As Single _EDISSFRAC 
  Dim Shared As Single Epot_shift        /' shift of potential at scission '/
  Dim Shared As Single SIGDEFO   
  Dim Shared As Single SIGDEFO_0 
  Dim Shared As Single SIGDEFO_slope 
  Dim Shared As Single SIGENECK        /' Width of TXE by fluctuation of neck length '/
  Dim Shared As Single EexcSIGrel 
  Dim Shared As Single DNECK             /' Tip distance at scission / fm '/
  Dim Shared As Single FTRUNC50          /' Truncation near Z = 50 '/
  Dim Shared As Single ZTRUNC50          /' Z value for truncation '/
  Dim Shared As Single FTRUNC28          /' Truncation near Z = 28 '/
  Dim Shared As Single ZTRUNC28          /' Z value for truncation '/
  Dim Shared As Single ZMAX_S2           /' Maximum Z of S2 channel in light fragment '/
  Dim Shared As Single NTRANSFEREO       /' Steps for E sorting for even-odd effect '/
  Dim Shared As Single NTRANSFERE        /' Steps for E sorting for energy division '/
  Dim Shared As Single Csort             /' Smoothing of energy sorting '/
  Dim Shared As Single PZ_EO_symm        /' Even-odd effect in Z at symmetry '/
  Dim Shared As Single PN_EO_Symm        /' Even-odd effect in N at symmetry '/
  Dim Shared As Single R_EO_THRESH       /' Threshold for asymmetry-driven even-odd effect'/
  Dim Shared As Single R_EO_SIGMA 
  Dim Shared As Single R_EO_MAX          /' Maximum even-odd effect '/
  Dim Shared As Single _POLARadd         /' Offset for enhanced polarization '/
  Dim Shared As Single POLARfac          /' Enhancement of polarization of ligu. drop '/
  Dim Shared As Single T_POL_RED         /' Reduction of temperature for sigma(Z) '/
  Dim Shared As Single _HOMPOL           /' hbar omega of polarization oscillation '/
  Dim Shared As Single ZPOL1             /' Extra charge polarization of S1 '/
  Dim Shared As Single P_n_x             /' Enhanced inverse neutron x section '/
  Dim Shared As Single Tscale 
  Dim Shared As Single Econd    
  Dim Shared As Single Etrans
  Dim Shared As Single T_orbital         /' From orbital ang. momentum '/
  Dim Shared As Single _Jscaling         /' General scaling of fragment angular momenta '/
  Dim Shared As Single Spin_odd          /' RMS Spin enhancement for odd Z '/ 
                                         /' Value of 0.4 adjusted to data. In conflict with Naik! '/
  Dim Shared As Single Esort_extend      /' Extension of energy range for E-sorting '/
  Dim Shared As Single Esort_slope       /' Onset of E-sorting around symmetry '/     
  Dim Shared As Single Esort_slope_S0    /' Onset of E-sorting around symmetry for S0 channel '/     

/'>'/
  Dim As Byte B_MyParameters = 0

   
/'<'/
    
  #include "Parameters.bas"              /' Initialize parameter values '/ 
/'>'/
  #include "ParameterManipulation.mac"   /' Manipulate parameters, copy, replace, update etc. '/

                                  

'  There is a variety of files that provide nuclear properties:
'  "NucPropJEFF311.bas", "NucPropJEFF33.bas", "NucPropNUBASE2016", and "NucProbNUBASE2020".
'  The following files, based on JEFF-3.1.1 are dedicated for special use, only:
'  "NucPropf.bas" extended by shape isomers
'                 only suited for spont. fission of shape isomers,
'  "NucPropmf.bas" contains more isomers of fissioning nuclei,
'  "NucPropx.bas"  contains extensions for all nuclei.

' The file NucPropxxx.bas is used for the calculation of isomeric yields.
' Different versions are provided.
' JEFF-3.1.1 and JEFF-3.3 contain only relatively long-lived isomers, which
' are considered to be relevant for technical applications.
' NUBASE-2016 and NUBASE-2020 contain all known isomers, also short-lived ones, without a limit
' on the half-life.

' B_delayed: In case B_delayed is defined, beta-delayed processes and cumulative 
'   yields are calculated. 
'   The decay properties for beta-delayed processes are provided by the file
'   DCLbranchingsxxx.bas.
'   Only two files are provided: DCLbranchingsJEFF311.bas and DLCbranchingsJEFF33.bas.
'   Consistency is only assured when NucPropxxx.bas and DCLbranchingsxxx.bas
'   from the same source are used. 
'   However, the combination NucPropNUBASExxx.bas - DCLbranchingsJEFF33.bas
'   may also be used, if there is special interest in the population of
'   short-lived isomers. In this case, GEF assumes that short-lived isomers,
'   which do not appear in JEFF-3.1.1 or JEFF-3.3 decay by gamma decay to the
'   ground state. This is reasonable in most cases.
'   One of the two options in the next statements may be chosen accordingly.

' 1. This is the recommended option, when consistency is required:
'    #Include Once "NucPropJEFF311.bas"  ' JEFF 3.1.1 is not recommended any more.
     #Include Once "NucPropJEFF33.bas"   ' Uses nuclear properties from JEFF-3.3.
  
' 2. This is the recommended option, when short-lived isomers should be included
'    in any case:   

'    #Include once "NucPropNUBASE2016.bas"   ' NUBASE 2016
'    #Include once "NucPropNUBASE2020.bas"   ' NUBASE 2020

' 3. This is the recommended option, when consistency is only required, when
'    delayed processes are included:        
 /' #If defined(B_delayed)
  '   #Include Once "NucPropJEFF311.bas"  ' Uses nuclear properties from JEFF-3.1.1. (JEFF-3.1.1 is not recommended any more.)
      #Include Once "NucPropJEFF33.bas"   ' Uses nuclear properties from JEFF-3.3.
    #Else
      #Include Once "NucPropNUBASE2016.bas"  ' NUBASE 2016
      #Include Once "NucProbNUBASE2020.bas"  ' NUBASE 2020
    #Endif '/ 

  
StartAgain:  
'Print 922,"StartAgain"

  B_supp = 1    ' Initialize

  Redim Shared Anl_Par(1000) As Analyzer_Attributes
  I_Anl = 0
   

/'<'/

  /' I. Properties of nuclide distributions '/

  ReDim Shared Beta(-1 To 7,1 To 2,150) As Single 
       ' -1: microscopic; 0: macroscopic for S0 fission channel
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "Beta"
  Anl_Par(I_Anl).C_Title = "Mean fragment deformation at scission"
  Anl_Par(I_Anl).C_xaxis = "Atomic number"
  Anl_Par(I_Anl).C_yaxis = "beta"
  Anl_Par(I_Anl).C_Linesymbol = "LT0"  
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).R_ALim(2,1) = 1   ' first bin (light/heavy fragment)
/'<'/

  ReDim Shared Edefo(-1 To 5,1 To 2,150) As Single
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "Edefo"
  Anl_Par(I_Anl).C_Title = "Fragment deformation energy at scission"
  Anl_Par(I_Anl).C_xaxis = "Atomic number"
  Anl_Par(I_Anl).C_yaxis = "E / MeV"
  Anl_Par(I_Anl).C_Linesymbol = "LT0"  
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).R_ALim(2,1) = 1   ' first bin (light/heavy fragment)
/'<'/

  ReDim Shared Zmean(0 To 5,1 To 2,350) As Single
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "Zmean"
  Anl_Par(I_Anl).C_Title = "Mean Z at scission"
  Anl_Par(I_Anl).C_xaxis = "Mass number"
  Anl_Par(I_Anl).C_yaxis = "Zm$e$a$n$"
  Anl_Par(I_Anl).C_Linesymbol = "LT0"  
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).R_ALim(2,1) = 1   ' first bin (light/heavy fragment)
/'<'/

  ReDim Shared Zshift(0 To 5,1 To 2,350) As Single
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "Zshift"
  Anl_Par(I_Anl).C_Title = "Z polarisation at scission"
  Anl_Par(I_Anl).C_xaxis = "Mass number"
  Anl_Par(I_Anl).C_yaxis = "Zm$e$a$n$ - ZU$C$D$"
  Anl_Par(I_Anl).C_Linesymbol = "LT0"  
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).R_ALim(2,1) = 1   ' first bin (light/heavy fragment)
/'<'/

  ReDim Shared Temp(0 To 5,1 To 2,350) As Single
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "Temp"
  Anl_Par(I_Anl).C_Title = "Nuclear temperature (level-density parameter)"
  Anl_Par(I_Anl).C_xaxis = "Mass number"
  Anl_Par(I_Anl).C_yaxis = "T / MeV"
  Anl_Par(I_Anl).C_Linesymbol = "LT0"  
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).R_ALim(2,1) = 1   ' first bin (light/heavy fragment)
/'<'/

  ReDim Shared TempFF(0 To 5,1 To 2,350) As Single
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "TempFF"
  Anl_Par(I_Anl).C_Title = "Nuclear temperature (level-density parameter) of FF"
  Anl_Par(I_Anl).C_xaxis = "Mass number"
  Anl_Par(I_Anl).C_yaxis = "T / MeV"
  Anl_Par(I_Anl).C_Linesymbol = "LT0"  
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).R_ALim(2,1) = 1   ' first bin (light/heavy fragment)
/'<'/

  ReDim Shared Eshell(0 To 5,1 To 2,350) As Single
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "Eshell"
  Anl_Par(I_Anl).C_Title = "Local shell effect over pre-neutron mass"
  Anl_Par(I_Anl).C_xaxis = "Mass number"
  Anl_Par(I_Anl).C_yaxis = "de^U / MeV"
  Anl_Par(I_Anl).C_Linesymbol = "LT0"  
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).R_ALim(2,1) = 1   ' first bin (light/heavy fragment)
/'<'/

  ReDim Shared PEOZ(0 To 7,1 To 2,350) As Single
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "PEOZ"
  Anl_Par(I_Anl).C_Title = "Local even-odd effect in Z"
  Anl_Par(I_Anl).C_xaxis = "Mass number"
  Anl_Par(I_Anl).C_yaxis = "de^P"
  Anl_Par(I_Anl).C_Linesymbol = "LT0"  
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).R_ALim(2,1) = 1   ' first bin (light/heavy fragment)
/'<'/

  ReDim Shared PEON(0 To 7,1 To 2,350) As Single   ' pre-neutron evaporation
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "PEON"
  Anl_Par(I_Anl).C_Title = "Local even-odd effect in N"
  Anl_Par(I_Anl).C_xaxis = "Mass number"
  Anl_Par(I_Anl).C_yaxis = "de^N"
  Anl_Par(I_Anl).C_Linesymbol = "LT0"  
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).R_ALim(2,1) = 1   ' first bin (light/heavy fragment)
/'<'/

  ReDim Shared EPART(0 To 7,1 To 2,350) As Single
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "EPART"
  Anl_Par(I_Anl).C_Title = "Energy partition"
  Anl_Par(I_Anl).C_xaxis = "Mass number"
  Anl_Par(I_Anl).C_yaxis = "Mean fragment intrinsic excitation energy at scission / MeV"
  Anl_Par(I_Anl).C_Linesymbol = "LT0"  
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).R_ALim(2,1) = 1   ' first bin (light/heavy fragment)
/'<'/
                               
  Redim Shared SpinRMSNZ(0 To 7,1 To 2,1 To 200,1 To 150) As Single
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "SpinRMSNZ"
  Anl_Par(I_Anl).C_Title = "RMS spin of fragments"
  Anl_Par(I_Anl).C_xaxis = "Neutron number"
  Anl_Par(I_Anl).C_yaxis = "Atomic number"
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).I_Dim = 2
  Anl_Par(I_Anl).R_ALim(2,1) = 1   ' first bin (light/heavy fragment)
  Anl_Par(I_Anl).R_ALim(3,1) = 1   ' first bin (neutron number)
  Anl_Par(I_Anl).R_ALim(4,1) = 1   ' first bin (atomic number)
/'<'/
                               

  /' Masses etc. '/
                               
  ReDim Shared BEldmTF(0 To 203,0 To 136) As Single
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "BEldmTF"
  Anl_Par(I_Anl).C_Title = "Liquid-drop mass (-BE)"
  Anl_Par(I_Anl).C_xaxis = "Neutron number"
  Anl_Par(I_Anl).C_yaxis = "Atomic number"
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).I_Dim = 2
/'<'/

  ReDim Shared BEexp(0 To 203,0 To 136) As Single
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "BEexp"
  Anl_Par(I_Anl).C_Title = "Experimental mass (-BE)"
  Anl_Par(I_Anl).C_xaxis = "Neutron number"
  Anl_Par(I_Anl).C_yaxis = "Atomic number"
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).I_Dim = 2
/'<'/

    Redim Shared DEFOtab(0 To 236,0 To 136) As Single
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "be^g$s$ (Moeller)"
  Anl_Par(I_Anl).C_Title = "Nuclear deformations (Moeller)"
  Anl_Par(I_Anl).C_xaxis = "Neutron number"
  Anl_Par(I_Anl).C_yaxis = "Atomic number"
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).I_Dim = 2
/'<'/    
                               
  ReDim Shared ShellMO(0 To 203,0 To 136) As Single
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "ShellMO"
  Anl_Par(I_Anl).C_Title = "Shell effect"
  Anl_Par(I_Anl).C_xaxis = "Neutron number"
  Anl_Par(I_Anl).C_yaxis = "Atomic number"
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).I_Dim = 2
/'<'/

  ReDim Shared EVOD(0 To 203,0 To 136) As Single
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "EVOD"
  Anl_Par(I_Anl).C_Title = "Even-odd fluctuating binding energy"
  Anl_Par(I_Anl).C_xaxis = "Neutron number"
  Anl_Par(I_Anl).C_yaxis = "Atomic number"
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).I_Dim = 2
/'<'/

/'>'/
  #include "Spectra.bas" 

  #include once "DCLplotting.bas"   ' For plotting and Chi-square  
  #ifdef B_delayed   ' include files for the calculation of cumulative yields etc. 
    #include once "DCLendf.bas"       
 '  #include once "DCLbranchingJEFF311.bas" ' JEFF-3.1.1 is not recommended any more.
    #include once "DCLbranchingJEFF33.bas"
 '  #include once "DCLbranchingNUBASE20.bas"  ' contains more short-lived isomers
  #endif     

/'<'/

  ReDim Shared NZPRE(0 to 200,0 to 150) As Single 
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "NZPRE"
  Anl_Par(I_Anl).C_Title = "Nuclide distribution, pre-neutron"
  Anl_Par(I_Anl).C_xaxis = "Neutron number"
  Anl_Par(I_Anl).C_yaxis = "Atomic number"
  Anl_Par(I_Anl).C_Type = "digital"
  Anl_Par(I_Anl).I_Dim = 2
/'<'/
                               
  ReDim Shared NZMPRE(0 To 7,0 to 200,0 to 150) As Single 
/'>'/
  I_Anl = I_Anl + 1
  Anl_Par(I_Anl).C_Name = "NZMPRE"
  Anl_Par(I_Anl).C_Title = "Nuclide distribution of modes, pre-neutron"
  Anl_Par(I_Anl).C_xaxis = "Neutron number"
  Anl_Par(I_Anl).C_yaxis = "Atomic number"
  Anl_Par(I_Anl).C_Type = "analog"
  Anl_Par(I_Anl).I_Dim = 2
    
  N_Anl = I_Anl   ' Total number of analyzers

    ' Input/Return parameters of subroutine Eva:
  ReDim Shared As Single Array_E_n1_frag1(50)  ' neutron energy array in fragment frame
  Redim Shared As Single Array_v_n1_frag1(50)
  ReDim Shared As Single Array_vlong_n1_frag1(50)  ' neutron velocity array longitudinal
  ReDim Shared As Single Array_vperp_n1_frag1(50)  ' neutron velocity array perpendicular
  ReDim Shared As Single Array_E_n2_frag2(50)  ' neutron energy array in fragment frame
  Redim Shared As Single Array_v_n2_frag2(50)
  ReDim Shared As Single Array_vlong_n2_frag2(50)  ' neutron velocity array longitudinal
  ReDim Shared As Single Array_vperp_n2_frag2(50)  ' neutron velocity array perpendicular
  ReDim Shared As Single Array_Tn(50)  ' neutron decay times after scission
  ReDim Shared As Single Array_Eg0_light(100)  ' statistical gamma energy array
  ReDim Shared As Single Array_Eg0_heavy(100)  ' statistical gamma energy array
    
    ' For list-mode output:
  ReDim Shared As Single Array_v_f1_CN(50)
  ReDim Shared As Single Array_v_f2_CN(50)
  ReDim Shared As Single Array_En_sci(200)   ' En (between saddle and scission)
  Dim As String C_pattern_sci
  ReDim Shared As Single Array_E_nall_CN(200)  ' neutron energy array in CN system
  Redim Shared As Single Array_E_n1_CN(50)
  Redim Shared As Single Array_E_n2_CN(50)
  Redim Shared As Single Array_cosalpha_n1_frag1(50)
  Redim Shared As Single Array_cosalpha_n2_frag2(50)  
  Redim Shared As Single Array_phi_n1_frag1(50)
  Redim Shared As Single Array_phi_n2_frag2(50)  
  Dim As Integer In_post 
  ReDim Shared As Single Array_Eg1_light(100) ' statistical gamma energy array
  ReDim Shared As Single Array_Eg1_heavy(100) ' statistical gamma energy array
  Dim As Integer Ig1_light, Ig1_heavy         ' after prompt-neutron emission
  ReDim Shared As Single Array_Eg2_light(100) ' collective gamma energy array
  ReDim Shared As Single Array_Eg2_heavy(100) ' collective gamma energy array
  Dim As Integer Ig2_light, Ig2_heavy    
    

 /' Uncertainties for error analysis (definition of variables): '/
  Dim As Single Fred_par = 0.5
  Dim As Single Var_P_DZ_Mean_S1 = 0.06 * Fred_par
  Dim As Single Var_P_Corr_S1 = 0.01 * Fred_par
  Dim As Single Var_P_DZ_Mean_S2 = 0.06 * Fred_par
  Dim As Single Var_P_A_Width_S2 = _P_A_Width_S2 * 0.03 * Fred_par
  Dim As Single Var_P_DZ_Mean_S3 = 0.06 * Fred_par
  Dim As Single Var_P_DZ_Mean_S4 = 0.06 * Fred_par
  Dim As Single Var_P_DZ_Mean_SL5 = 0.06 * Fred_par
  Dim As Single Var_P_DZ_Mean_S5 = 0 * Fred_par
  Dim As Single Var_Delta_S0 = 0.06 * Fred_par
  Dim As Single Var_P_Shell_S1 = 0.06 * Fred_par
  Dim As Single Var_P_Shell_S2 = 0.06 * Fred_par
  Dim As Single Var_P_Shell_S3 = 0.3 * Fred_par
  Dim As Single Var_P_Shell_S4 = 0.06 * Fred_par
  Dim As Single Var_P_Shell_SL5 = 0.06 * Fred_par
  Dim As Single Var_P_Shell_S5 = 0.03 * Fred_par
  Dim As Single Var_P_Z_Curv_S1 = _P_Z_Curv_S1 * 0.03 * Fred_par
  Dim As Single Var_P_Z_Curv_S2 = _P_Z_Curv_S2 * 0.03 * Fred_par
  Dim As Single Var_S2leftmod = _S2leftmod * 0.03 * Fred_par
  Dim As Single Var_P_Z_Curv_S3 = _P_Z_Curv_S3 * 0.03 * Fred_par
  Dim As Single Var_P_Z_Curv_S4 = _P_Z_Curv_S4 * 0.03 * Fred_par
  Dim As Single Var_P_Z_Curv_SL5 = _P_Z_Curv_SL5 * 0.03 * Fred_par
  Dim As Single Var_P_Z_Curv_S5 = _P_Z_Curv_S5 * 0.03 * Fred_par
  Dim As Single Var_PZ_S3_olap_pos = 0.1 * Fred_par
  Dim As Single Var_PZ_S3_olap_curv = 0.0002 * Fred_par
  Dim As Single Var_dE_Defo_S1 = 0.25 * Fred_par
  Dim As Single Var_dE_Defo_S2 = 0.25 * Fred_par
  Dim As Single Var_dE_Defo_S3 = 0.25 * Fred_par
  Dim As Single Var_dE_Defo_S4 = 0.25 * Fred_par
  Dim As Single Var_dE_Defo_S5 = 0.25 * Fred_par
  Dim As Single Var_betaL0 = 2.0 * Fred_par
  Dim As Single Var_betaL1 = 0.02 * Fred_par
  Dim As Single Var_betaH0 = 2.0 * Fred_par
  Dim As Single Var_betaH1 = 0.02 * Fred_par
  Dim As Single Var_dbeta_S3 = 0.1 * Fred_par
  Dim As Single Var_T_low_S1 = 0.006 * Fred_par
  Dim As Single Var_T_low_S2 = 0.006 * Fred_par
  Dim As Single Var_T_low_S3 = 0.006 * Fred_par
  Dim As Single Var_T_low_S4 = 0.006 * Fred_par
  Dim As Single Var_T_low_S5 = 0.006 * Fred_par
  Dim As Single Var_T_low_SL = 0.006 * Fred_par
  Dim As Single Var_ECOLLFRAC = 0.05 * Fred_par
  Dim As Single Var_EDISSFRAC = 0.05 * Fred_par
  Dim As Single Var_P_att_pol = _P_att_pol * 0.12 * Fred_par
  Dim As Single Var_HOMPOL = _HOMPOL * 0.06 * Fred_par
  Dim As Single Var_POLARadd = 0.06 * Fred_par
  Dim As Single Var_Jscaling = _Jscaling * 0.0 * Fred_par

    
/'<'/    
 /' Internal parameters for error analysis: '/
  Dim Shared As Single P_DZ_Mean_S1
  Dim Shared As Single P_corr_S1
  Dim Shared As Single P_DZ_Mean_S2
  Dim Shared As Single P_DZ_Mean_S3
  Dim Shared As Single P_DZ_Mean_S4
  Dim Shared As Single P_DZ_Mean_SL5
  Dim Shared As Single P_DZ_Mean_S5
  Dim Shared As Single P_Z_Curv_S1
  Dim Shared As Single P_Z_Curv_S2
  Dim Shared As Single S2leftmod
  Dim Shared As Single P_A_Width_S2
  Dim Shared As Single P_Z_Curv_S3
  Dim Shared As Single P_Z_Curv_S4
  Dim Shared As Single P_Z_Curv_SL5
  Dim Shared As Single P_Z_Curv_S5
  Dim Shared As Single PZ_S3_olap_pos
  Dim Shared As Single PZ_S3_olap_curv
  Dim Shared As Single Delta_S0
  Dim Shared As Single P_Shell_S1
  Dim Shared As Single P_Shell_S2
  Dim Shared As Single P_Shell_S3
  Dim Shared As Single P_Shell_S4
  Dim Shared As Single P_Shell_SL5
  Dim Shared As Single P_Shell_S5
  Dim Shared As Single dE_Defo_S1
  Dim Shared As Single dE_Defo_S2
  Dim Shared As Single dE_Defo_S3
  Dim Shared As Single dE_Defo_S4
  Dim Shared As Single dE_Defo_S5
  Dim Shared As Single betaL0
  Dim Shared As Single betaL1
  Dim Shared As Single betaH0
  Dim Shared As Single betaH1
  Dim Shared As Single dbeta_S3
  Dim Shared As Single T_low_S1
  Dim Shared As Single T_low_S2
  Dim Shared As Single T_low_S3
  Dim Shared As Single T_low_S4
  Dim Shared As Single T_low_S5
  Dim Shared As Single T_low_SL
  Dim Shared As Single ECOLLFRAC
  Dim Shared As Single EDISSFRAC
  Dim Shared As Single P_att_pol
  Dim Shared As Single P_att_rel
  Dim Shared As Single HOMPOL
  Dim Shared As Single POLARadd  
  Dim Shared As Single Jscaling
    
/'>'/    
 /' Memory for perturbed parameter values '/   
  ReDim Shared As Single Double_P_DZ_Mean_S1(1)
  ReDim Shared As Single Double_P_corr_S1(1)
  ReDim Shared As Single Double_P_DZ_Mean_S2(1)
  ReDim Shared As Single Double_P_DZ_Mean_S3(1)
  ReDim Shared As Single Double_P_DZ_Mean_S4(1)
  ReDim Shared As Single Double_P_DZ_Mean_SL5(1)
  ReDim Shared As Single Double_P_DZ_Mean_S5(1)
  ReDim Shared As Single Double_P_Z_Curv_S1(1)
  ReDim Shared As Single Double_P_Z_Curv_S2(1)
  Redim Shared As Single Double_S2Leftmod(1)
  ReDim Shared As Single Double_P_A_Width_S2(1)
  ReDim Shared As Single Double_P_Z_Curv_S3(1)
  ReDim Shared As Single Double_P_Z_Curv_S4(1)
  ReDim Shared As Single Double_P_Z_Curv_SL5(1)
  ReDim Shared As Single Double_P_Z_Curv_S5(1)
  Redim Shared As Single Double_PZ_S3_olap_pos(1)
  Redim Shared As Single Double_PZ_S3_olap_curv(1)
  ReDim Shared As Single Double_Delta_S0(1)
  ReDim Shared As Single Double_P_Shell_S1(1)
  ReDim Shared As Single Double_P_Shell_S2(1)
  ReDim Shared As Single Double_P_Shell_S3(1)
  ReDim Shared As Single Double_P_Shell_S4(1)
  ReDim Shared As Single Double_P_Shell_SL5(1)
  ReDim Shared As Single Double_P_Shell_S5(1)
  ReDim Shared As Single Double_dE_Defo_S1(1)
  ReDim Shared As Single Double_dE_Defo_S2(1)
  ReDim Shared As Single Double_dE_Defo_S3(1)
  ReDim Shared As Single Double_dE_Defo_S4(1)
  ReDim Shared As Single Double_dE_Defo_S5(1)
  ReDim Shared As Single Double_betaL0(1)
  ReDim Shared As Single Double_betaL1(1)
  ReDim Shared As Single Double_betaH0(1)
  ReDim Shared As Single Double_betaH1(1)
  ReDim Shared As Single Double_dbeta_S3(1)
  ReDim Shared As Single Double_T_low_S1(1)
  ReDim Shared As Single Double_T_low_S2(1)
  ReDim Shared As Single Double_T_low_S3(1)
  ReDim Shared As Single Double_T_low_S4(1)
  ReDim Shared As Single Double_T_low_S5(1)
  ReDim Shared As Single Double_T_low_SL(1)
  ReDim Shared As Single Double_ECOLLFRAC(1)
  ReDim Shared As Single Double_EDISSFRAC(1)
  ReDim Shared As Single Double_P_att_pol(1)
  ReDim Shared As Single Double_HOMPOL(1)
  ReDim Shared As Single Double_POLARadd(1)  
  Redim Shared As Single Double_Jscaling(1)
/'<'/

     
 /' Control parameters: '/
  Dim Shared As Single B_F = 0              /' Fission barrier '/
  Dim Shared As Single B_F_ld = 0           /' Fission barrier, liquid drop '/
  Dim Shared As Single E_A = 0              /' Inner fission barrier '/
  Dim Shared As Single E_B = 0              /' Outer fission barrier '/
  Dim Shared As Single DE_AB = 0
  Dim Shared As Single E_B_ld = 0           /' Outer fission barrier, liquid drop '/
  Dim Shared As Single R_E_exc_Eb = 0       /' Energy above outer barrier '/
  Dim Shared As Single R_E_exc_GS = 0       /' Energy above ground state '/
  Dim Shared As Single P_Z_Mean_S0 = 0      /' Mean Z of Mode 1 '/
  Dim Shared As Single P_Z_Mean_S1 = 52.8   /' Mean Z of Mode 1 '/
  Dim Shared As Single P_Z_Mean_S2 = 55     /' Mean Z of Mode 2 '/
  Dim Shared As Single P_Z_Mean_S3 = 65     /' Mean Z of Mode 3 '/
  Dim Shared As Single P_Z_Mean_S4 = 84     /' Mean Z of Mode 4 '/
  Dim Shared As Single P_Z_Mean_S5 = 38     /' Mean Z of Mode 4 '/
  Dim Shared As Single NC_Mode_0 = 0        /' Mean N of symm. Mode '/
  Dim Shared As Single NC_Mode_1 = 0        /' Mean N of Mode 1 '/
  Dim Shared As Single NC_Mode_2 = 0        /' Mean N of Mode 2 '/
  Dim Shared As Single NC_Mode_3 = 0        /' Mean N of Mode 3 '/
  Dim Shared As Single NC_Mode_4 = 0
  Dim Shared As Single NC_Mode_5 = 0
  Dim Shared As Single B_S1 = 0             /' Barrier S1, relative to SL '/
  Dim Shared As Single B_S2 = 0             /' Barrier S2, relative to SL '/
  Dim Shared As Single B_S3 = 0             /' Barrier S3, relative to SL '/
  Dim Shared As Single B_S4 = 0
  Dim Shared As Single B_S5 = 0
  Dim Shared As Single B_S11 = 0            /' Barrier S11, relative to SL '/
  Dim Shared As Single B_S22 = 0            /' Barrier S22, relative to SL '/
  Dim Shared As Single DES11ZPM = 0         /' Mod. of eff. barrier due to ZPM in overlap '/
  Dim Shared As Single Delta_NZ_Pol = 0      /' Polarization for 132Sn '/
  Dim Shared As Single Yield_Mode_0 = 0     /' Relative yield of SL '/
  Dim Shared As Single Yield_Mode_1 = 0     /' Relative yield of S1 '/
  Dim Shared As Single Yield_Mode_2 = 0     /' Relative yield of S2 '/
  Dim Shared As Single Yield_Mode_3 = 0     /' Relative yield of S3 '/
  Dim Shared As Single Yield_Mode_4 = 0     /' Relative yield of S4 '/
  Dim Shared As Single Yield_Mode_5 = 0     /' Relative yield of S5 '/
  Dim Shared As Single Yield_Mode_11 = 0    /' Relative yield of S11 '/
  Dim Shared As Single Yield_Mode_22 = 0    /' Relative yield of S22 '/
  Dim Shared As Single P_POL_CURV_S0 = 0    /' Stiffnes in N/Z '/
  Dim Shared As Single T_Coll_Mode_0 = 0    /' Effective collective temperature '/
  Dim Shared As Single E_Exc_S0 = 0         /' Energy over barrier of symmetric channel '/
  Dim Shared As Single E_Exc_S1 = 0         /' Energy over barrier of S1 channel '/
  Dim Shared As Single E_Exc_S2 = 0         /' Energy over barrier of S2 channel '/
  Dim Shared As Single E_Exc_S3 = 0         /' Energy over barrier of S3 channel '/
  Dim Shared As Single E_Exc_S4 = 0         /' Energy over barrier of S4 channel '/
  Dim Shared As Single E_Exc_S5 = 0         /' Energy over barrier of S5 channel '/
  Dim Shared As Single E_Exc_S11 = 0        /' Energy over barrier of S11 channel '/
  Dim Shared As Single E_Exc_S22 = 0        /' Energy over barrier of S22 channel '/
  Dim Shared As Single E_POT_SCISSION = 0   /' Potential-energy gain saddle-scission '/
  Dim Shared As Single E_diss_Scission = 0  /' Dissipated energy between saddle and scission '/
  Dim Shared As Single EINTR_SCISSION = 0   /' Intrinsic excitation energy at scission '/
  Dim Shared As Single EeffS1 = 0           /' Governs S1 reduction '/
  Dim Shared As Single Sigpol_Mode_0 = 0    /' Width of isobaric Z distribution '/
/'>'/

  Randomize,3   ' Random initialisation of the random generator


                               
/'<'/

  #Include Once "BEldmTF.bas"
  
  #Include Once "BEexp.bas"
  
  #Include Once "DEFO.bas"

  #Include Once "ShellMO.bas"
  

/'>'/
  Static Shared CElement(1 To 120)   As String   ' Chemical element names
  #Include Once "ElmtNames.bas"

/'
'**************************************************************************
  Dim As Integer IN,IZ,IA,IZmem=73
  Scope
 'Print list of fission barriers
    For IZ = 73 to 120
      For IN = 70 to 200
        IA = IZ + IN
        If IA / IZ > 160.E0 / 76.E0 _
          And IA / IZ < 289.E0/90.E0  Then
          If IZmem <> IZ Then Print " "
          If IN >= 130 Then
            If BFTFB(IZ,IA,1) > 0 Then 
      '       Print U_Valid(IZ,IA);
              Print IZ;IA;BFTF(IZ,IA,1),BFTFA(IZ,IA,1),BFTFB(IZ,IA,1),BFTF(IZ,IA,4)
            Else 
      '       Print U_Valid(IZ,IA);
              Print IZ;IA;BFTF(IZ,IA,1),BFTFA(IZ,IA,1)," ---",BFTF(IZ,IA,4)
            End If
          Else
            Print IZ;IA;BFTF(IZ,IA,1)," ---"," ---",BFTF(IZ,IA,4)
          End If  
          IZmem = IZ
        End If
      Next IN
    Next IZ 
  End Scope   
  Sleep
'**************************************************************************   
'/
   

  
/'
  Scope
    Dim As Single Z,A,E
    Print "Z  A  E  U_temp  U_Rusanov"
    For Z = 80 To 90 Step 10
      For A = 180 To 240 Step 20
        For E = 5 To 125 Step 20
          Print Z,A,E,U_Temp(Z,A,E,0,0,1,3),TRusanov(E,A)
        Next E
      Next A
    Next Z 
  End Scope
  Sleep
'/

/' *********************** Only for GEFSUB *****************************
/'<'/

  Declare Sub GEFSUB(P_Z_CN As Integer, P_A_CN As Integer, P_E_EXC As Single, _
   P_J_CN As Single)
   
  GEFSUB(92,236,6.,0.0)

' The following section prints the results of GEFSUB.

/'

  Dim As Single Zsum

  Print
  Print "Z, A, Yield"
  For I = 10 To 190
    For J = 10 To 140
      If NZPRE(I,J) > 0.0001 Then
        Print J,I+J,NZPRE(I,J)*200
      End If
    Next
  Next 


  Print
  Print "Z yields"
  For J = 10 To 140
    Zsum = 0
    For I = 10 To 190
      Zsum = Zsum + NZpre(I,J)
    Next
    If Zsum > 0.0 Then
      Print J, Zsum * 200
    End If   
  Next '/ 


/'
  Dim As Single Asum
  Print
  Print "N yields"
  For I = 10 To 140
    Asum = 0
    For J = 10 To 190
      Asum = Asum + NZpre(I,J)
 '    If NZPRE(I,J) > 0.001 Then
 '      Print J,I+J,NZPRE(I,J)*200
 '    End If
    Next
    Print I, Asum * 200
  Next   '/

  End
  

  Sub GEFSUB(P_Z_CN As Integer, P_A_CN As Integer, P_E_EXC As Single, _
    P_J_CN As Single)
    /' Input parameters: '/
    /' Atomic number, mass number, excitation energy/MeV, spin/h_bar of CN '/
    /' Results are stored in external arrays. '/
   
/'<FO INCLUDE "GEFSUBdcl.FOR" FO>'/
/' This is the place for the statements of Parameters.FOR '/
/'<FO INCLUDE "Parameters.FOR" FO>'/
/'>'/   

    Bsub = 1
  
  End Sub 
' *********************** End Only for GEFSUB **************************                         
'/

  /'  EXCMD('AFETCH BElmdTF');  '/
  /'  EXCMD('AFETCH ShellMO');  '/


  /'  EXCMD('AFETCH EVOD');  '/
  
  
Prompting:  
  /' User prompting: Input values '/
  
   /'BGUI controls the function of the GEF GUI '/
  Dim As Integer iblock
  Dim As Integer fMutex,fTransfer
  Dim As String Cname
  Dim As String Cvalue
  Static As String Csystem
  Static As String Cfileout,Cfileout_single,Cfileout_full
  Static As String Cfileoutlmd,Cfileoutlmd_full
  Static As String Cfilemvd_single,Cfilemvd
  Dim As String CEref
  Dim As Double Fenhance = 0
  Const As LongInt Ten_to_five = 1.E5
' Const As LongInt Ten_to_five = 1.E4
  Dim As Byte BGUI  'true: -1, false: 0
  Static As String Cerr
  Static As String Clocal
  Static As String Clocal_file_option 
  Static As Integer Ilocal = 0
  Dim As String Crec
  Dim As Byte Brec = 0
  Dim As Byte Bcov = 0
  Dim As Byte Bcor = 0
  Dim As String Cplot
  Dim As Byte Bplot = -1
   
   ' List-mode parameter choice
  Dim As Byte PZ1, PZ2, PA1pre, PA2pre, PA1post, PA2post
  Dim As Byte PI1,PI2,Pn1,Pn2,PTKEpre,PTKEpost,PnCN,PEnpost
  Dim As Byte PEgpost
  Dim As Byte Pdir
  Dim As Byte PXE,PXEdetails
  Dim As Byte Pndel  ' delayed neutrons
   
  Static As Byte Bfilein = 0   ' Bfilein is set if file.in is found
  Dim As Integer I_Warning = 0
  Static As Integer Iline
  Static As Integer Iline_tot  ' number of lines in input file 
  Static As Integer N_E_steps = 0   ' number of energy steps for input file
  Static As Integer I_E_step 
  Static As Integer I_first_E_step = 1
  Dim As Single Eabsgs     ' Energy above ground state
  Dim As Single ICN   ' mom. of inertia of CN
   
/'<'/   
  Dim As Single E_rot_CN = 0  ' Rotational energy of CN
  Dim As Integer I_short
  Static As Integer I_E_iso  ' numbered in sequence of increasing energy
  Static As Single Spin_CN, Spin_target  
  Dim As Single Spin_gs_light
  Dim As Single Spin_gs_heavy
/'>'/
  
  Dim As Integer Ivalid   
   
  Static As Integer Ffilein
  Static As Double Fenhance_global
  Dim As Single R_NEVTspectrum
  Dim As Integer Fthread
' Static Shared As Integer I_thread=0  ' Thread number of this process
  Static Shared As Integer I_thread_max = 8 '16   ' Value must be adapted to maximun of allowed processes on the system.
  Static As Byte B_thread 
  Static As String CFthread 
  CFthread = "thread.ctl"   ' (fileexists does not work with subfolders.)
  Static As String CFdone
  CFdone = "done.ctl"       ' (fileexists does not work with subfolders.)
  Dim Shared As Integer foutlmd
  Dim Shared As Integer f 
  Dim Shared As Integer fsync, Isync
  Dim As String C_Espectrum ' Espectrum used in the calculation
  Dim As String C_Espectrum1, C_Espectrum2  ' Espectrum files for first and second system 

  Type OCovarEvt1d
    ISystem As Integer
    IParameter As Integer     ' # of parameter set
    ICoordinate As Integer    ' Index of cov. matrix
    RYield As Single          ' Yield value
    Declare Constructor
  End Type
  Constructor OCovarEvt1d
    This.ISystem = 1 
    This.IParameter = 0
    This.ICoordinate = 0
    This.RYield = 0
  End Constructor 

  Type OCovarEvt2d
    ISystem As Integer
    IParameter As Integer     ' # of parameter set
    ICoordinate1 As Integer   ' Parameter 1st dimension
    ICoordinate2 As Integer   ' Parameter 2st dimension
    RYield As Single          ' Yield value
    Declare Constructor
  End Type
  Constructor OCovarEvt2d
    This.ISystem = 1 
    This.IParameter = 0
    This.ICoordinate1 = 0
    This.ICoordinate2 = 0
    This.RYield = 0
  End Constructor 
   
  Type OCovar
    Rval As Single      ' Covariance value
    Nval As Integer     ' Number of original values for one matrix element
    Declare Constructor
  End Type    
  Constructor OCovar
    This.Rval = 0
    This.Nval = 0
  End Constructor
   
  Type OCorr
    Rval As Single
    Declare Constructor
  End Type
  Constructor OCorr
    This.Rval = 0
  End Constructor  

  If Fileexists("file.in") Then
    Bfilein = -1
     
    #ifdef __FB_WIN32__
      WaitSynch_GUI   ' Timing with GUI (wait for full second)
      fMutex = FreeFile
      Open "GUI\Mutex.ctl" For Output As #fMutex
      Print #fMutex, "-1"    ' Close GUI window
      Close #fMutex
    #endif
     
     ' Assign thread number to this process
    CHDIR("ctl")
    If Fileexists(CFthread) Then
      Fthread = Freefile
      Open CFthread For Input As #Fthread
      Input #Fthread, I_thread_first
      If I_thread_first = 0 Then
        I_thread = 1
      ElseIf I_thread_first = 1 Then
        I_thread_last = I_thread_first
        Input #Fthread, Timeoffset
        While Not (EOF(Fthread))
          Input #Fthread, I_thread_last 
        Wend 
        I_thread = I_thread_last + 1
      Else
        Print "<E> Error in sequence of threads. No valid basic process."
        Print "<H> Please delecte file /ctl/thread.clt and start GEF again!"
        Sleep
        End
      End If
      Close #Fthread
    Else
      I_thread = 1
    End If  
     
    If I_thread > I_thread_max Then
      Print "The maximum number of "+Str(I_thread_max)+" processes was reached."
      Print "Please consider the following hints:"
      Print "GEF supports parallel computing for a series of systems given in the"
      Print "file 'file.in'."
      Print "GEF keeps track of the number of GEF calculations that run in parallel and"
      Print "compares it with the maximum number of processes than can run in parallel"
      Print "on your copmuter." 
      Print "For a proper functioning of this feature, two conditinos must be met."
      Print "1. The tracking information of active processes in GEF must be correct."
      Print "   For this purpose, please delete /ctl/thread.ctl (and also /ctl/done.ctl,"
      Print "   where the systems are listed that have already been calculated, and"
      Print "   /ctl/sync.ctl that synchronizes the output of GEF)"
      Print "   before starting a new series of calculations."
      Print "2. The maximum number of processes that can run on your computer must be"
      Print "   correct. This number is stored in the variable I_thread_max in GEF.bas."
      Print "   Please check and eventually correct the value of I_thread_max."    
      Print "   For example, 8 processes can run in parallel on an Intel i7 processor."
      Print "   After changing the value of I_thread_max in GEF.bas,"
      Print "   recompilation of GEF.bas is necessary."
      Print 
      Print "   Press ENTER to leave GEF!"
      Sleep
      End 
    End If

    If I_thread = 1 Then
      Fthread = Freefile
      Open CFthread For Output As #Fthread
      Timeoffset = Timer
      Print #Fthread, I_thread, Timeoffset
      Print "<I> This is the basic process (thread number = 1)."
      Print "    It is necessary for the time management and the"
      Print "    proper organization of the parallel computing of"
      Print "    a series of GEF calculations in batch mode."         
      Close #Fthread
    Else
      Fthread = Freefile
      Open CFthread for Append As #Fthread
      Print #Fthread, I_thread
      Print "<I> The thread number ";I_thread;" is assigned to this process."
      Print "<H> Please note that a series of GEF calculations must start"
      Print "    with thread number 1!"
      Print "    This is assured if the folder /ctl is deleted, before"
      Print "    starting a series of GEF calculations in batch mode."       
      Close #Fthread
    End If  
    CHDIR("..") 
  End If  
   
  Ivalid = 1
RepeatInput:   
  P_I_rms_CN = 0 
   /'************************  Input by GUI  *************************'/

  #ifdef __FB_WIN32__
    fTransfer = FreeFile
    If Bfilein = -1 Then  /' De-activate GUI '/
      Open "GUI\Transfer.ctl" For Output As #Ftransfer
      Print #fTransfer, "Bfilein"
      Close #Ftransfer
   /' Do
        Waitsynch_GUI
        fMutex = FreeFile
        Open "GUI\Mutex.ctl" For Input as #fMutex
        Input #fMutex, iblock
        Close #fMutex
      Loop until iblock <> 0
      If iblock = -1 Then
        End  /' stop GEF '/
      End If '/
    Else
      Open "GUI\Transfer.ctl" For Output As #Ftransfer
      Print #fTransfer, "Nofilein"
      Close #Ftransfer
      BGUI = -1   
      Do 
        WaitSynch_GUI
        fMutex = FreeFile
        Open "GUI\Mutex.ctl" For Input as #fMutex
        Input #fMutex, iblock
        Close #fMutex
      Loop until iblock <> 0
      Screen 0
      If iblock = -1 Then 
        End  /' stop GEF '/
      End If
      fTransfer = FreeFile
      Open "GUI\Transfer.ctl" For Input as #fTransfer
      CFileoutlmd = ""
      Clocal = "localoff"
      B_supp = 1
      P_Z_CN_Double = 0
      P_A_CN_Double = 0
      P_E_exc_Double = 0
      Do
        Input #fTransfer, Cname,Cvalue
        If Cname = "P_Z_CN" Then P_Z_CN = Cast(Single,Cvalue)
        If Cname = "P_Z_CN_Double" Then P_Z_CN_Double = Cast(Single,Cvalue)
        If Cname = "P_A_CN" Then P_A_CN = Cast(Single,Cvalue)
        If Cname = "P_A_CN_Double" Then P_A_CN_Double = Cast(Single,Cvalue)
        If P_Z_CN_Double > 0 Or P_A_CN_Double > 0 Or P_E_Exc_Double <> 0 Then B_Double_Covar = 1
        If Cname = "P_I_rms" Then P_I_rms_CN = Cast(Single,Cvalue)
        If Cname = "Isomer" Then I_E_Iso = Cast(Integer,Cvalue)
        If Cname = "P_E_exc" Then P_E_exc = Cast(Single,Cvalue)
        If Cname = "P_E_exc_Double" Then P_E_Exc_Double = Cast(Single,Cvalue) 
        If Cname = "Emode" Then 
          CEref = Cvalue
          Select Case Left(CEref,2)
            Case "EB"   ' CN fission, energy above EB
              Emode = 0
            Case "GS"   ' CN fission, energy above ground state
              Emode = 1
            Case "FC"   ' CN fission, first chance only
              If Emode = 13 Then
                Emode = 3
              Else
               Emode = -1
              End If  
            Case "IS"   ' spontaneous fission from isomer
              Emode = 1
              I_E_iso = Val(Mid(CEref,3))
            Case "EN"   ' neutron-induced fission
              Emode = 2
              If Val(Mid(CEref,3)) > 0 Then
                I_E_iso = Val(Mid(CEref,3))
              End If
            Case "EP"   ' proton-induced fission
              Emode = 12
              If Val(Mid(CEref,3)) > 0 Then
                I_E_iso = Val(Mid(CEref,3))
              End If               
            Case "EA"   ' alpha-induced fission
              Emode = 22
              If Val(Mid(CEref,3)) > 0 Then
                I_E_iso = Val(Mid(CEref,3))
              End If               
            Case "ES"  ' energy spectrum from input file (only FC)    
               Emode = 3
              C_Espectrum1 = "in/Espectrum.in"
              If B_ENDF = 1 Then
         '      Print " "
         '      Print "Output of FY in ENDF format is not possible with option ES."
         '      Print "ENDF output is suspended."
         '      Print " "
                B_ENDF = 0
              End If
            Case "EM"  ' energy spectrum from input file (multi-chance)               
              Emode = 13 
              C_Espectrum1 = "in/Espectrum.in"
            Case Else
              Print "Option ";CEref;" is not valid."     
              Print "Press Enter key to leave GEF!"
              Sleep
              End
          End Select           
        End If
        If Cname = "Delta_S0" Then _Delta_S0 = Cast(Single,Cvalue)
        If Cname = "Clocal" Then Clocal = Cvalue
        If Cname = "Csupp" Then 
          Scope
            Dim As string Csupp
            Csupp = Cvalue
            If Csupp = "supp " Then B_supp = 1
            If Csupp = "nosupp" Then B_supp = 0
          End Scope  
        End If  
'       If Cname = "MyParameters" Then B_MyParameters = -1
        If Cname = "Fout" Then 
          CFileout_full = Cvalue
          If CFileout_full <> "" Then
            If Instr(CFileout_full,".") = 0 Then
              CFileout_full = CFileout_full+".dat"
            End If
            CFileout = Mid(CFileout_full,Instrrev(CFileout_full,"\")+1)
            CFileout = Mid(CFileout,1,Instr(CFileout,".")-1)
            CFileout_Single = CFileout+"_Single"
          End If
        End If  
        If Cname = "Foutlmd" Then 
          CFileoutlmd_full = Cvalue
          If CFileoutlmd_full <> "" Then
            If Instr(CFileoutlmd_full,".") = 0 Then
              CFileoutlmd_full = CFileoutlmd_full + ".lmd"
            End If
            CFileoutlmd = CFileoutlmd_full
            While Instr(CFileoutlmd,"\") > 0
             CFileoutlmd = Mid(CFileoutlmd,Instr(CFileoutlmd,"\")+1)
            Wend
            While Instr(CFileoutlmd,"/") > 0
             CFileoutlmd = Mid(CFileoutlmd,Instr(CFileoutlmd,"\")+1)
            Wend
            CFileoutlmd = Mid(CFileoutlmd,1,Instr(CFileoutlmd,".")-1)
          End If  
        End If
        If Cname = "Fenhance" Then Fenhance = Cast(Single,Cvalue)
        If Cname = "Cerr" Then 
          Cerr = Cvalue
          If Cerr = "eron" Then 
            B_Error_On = 1
          Else 
            B_Error_On = 0
          End If
        End If
        If Cname = "Dparfac" Then D_Par_Fac = Cast(Single,Cvalue)
        If Cname = "Ccov" Then 
          If Cvalue = "covon" Then 
            BCov = 1
          Else 
            BCov = 0
          End If
        End If
        If Cname = "Ccor" Then 
          If Cvalue = "coron" Then 
            BCor = 1
          Else 
            BCor = 0
          End If
        End If
        If Cname = "Crec" Then   ' record perturbed results
          Crec = Cvalue
          If Crec = "recon" Then 
            Brec = 1
            If B_ENDF = 1 Then 
              B_Random_On = 1
            End If
          Else 
            Brec = 0
            B_Random_On = 0
          End If    
        End If
        If Cname = "Cplot" Then
          Cplot = Cvalue
          if Cplot = "ploton" Then
            Bplot = -1
          Else
            Bplot = 0
          End If    
        End If  
        If Cname = "EOfac" Then EOscale = Val(Cvalue)       
        If Cname = "PZ1" Then PZ1 = Cast(Integer,Cvalue)
        If Cname = "PZ2" Then PZ2 = Cast(Integer,Cvalue)
        If Cname = "PA1pre" Then PA1pre = Cast(Integer,Cvalue)
        If Cname = "PA2pre" Then PA2pre = Cast(Integer,Cvalue)
        If Cname = "PA1post" Then PA1post = Cast(Integer,Cvalue)
        If Cname = "PA2post" Then PA2post = Cast(Integer,Cvalue)
        If Cname = "PI1" Then PI1 = Cast(Integer,Cvalue)
        If Cname = "PI2" Then PI2 = Cast(Integer,Cvalue)
        If Cname = "Pdir" Then Pdir = Cast(Integer,Cvalue)
        If Cname = "PXE" Then PXE = Cast(Integer,Cvalue)
        If Cname = "PXEdetails" Then PXEdetails = Cast(Integer,Cvalue)
        If Cname = "Pn1" Then Pn1 = Cast(Integer,Cvalue)
        If Cname = "Pn2" Then Pn2 = Cast(Integer,Cvalue)
        If Cname = "PTKEpre" Then PTKEpre = Cast(Integer,Cvalue)
        If Cname = "PTKEpost" Then PTKEpost = Cast(Integer,Cvalue)
        If Cname = "PPnCN" Then PnCN = Cast(Integer,Cvalue)
        If Cname = "PEnpost" Then PEnpost = Cast(Integer,Cvalue) 
        If Cname = "PEgpost" Then PEgpost = Cast(Integer,Cvalue)  
        If Cname = "Pndel" Then Pndel = Cast(Integer,Cvalue)   
      Loop Until EOF(fTransfer)          
      Close #fTransfer
      Ivalid = U_Valid(P_Z_CN,P_A_CN)
      If Ivalid = 0 Then
        Print "************************************************"
        Print "<W> Fissioning nucleus out of supported range!!!"
        Print "************************************************"
        Input "Do you want to start the calculation anyhow [y/n]? Default = <no> ",Cyesno
        Ivalid = Pyes(Cyesno,"NO")
        If Ivalid = 0 Then
          WaitSynch_GUI   ' Timing with GUI (wait for full second)
          fMutex = FreeFile
          Open "GUI\Mutex.ctl" For Output As #fMutex
          Print #fMutex, "0"    ' Allow input from GUI 
          Close #fMutex
          Goto RepeatInput
        End If  
      End If  
      If P_E_exc > 120 Then
        Dim As Integer IhighE
        Print "******************************************"
        Print "<W> Energy exceeds the supported range !!!"
        Print "******************************************"
        Input "Do you want to start the calculation anyhow [y/n]? Default = <no> ",Cyesno
        IhighE = Pyes(Cyesno,"NO")
        If IhighE = 0 Then 
          WaitSynch_GUI   ' Timing with GUI (wait for full second)
          fMutex = FreeFile
          Open "GUI\Mutex.ctl" For Output As #fMutex
          Print #fMutex, "0"    ' Allow input from GUI 
          Close #fMutex
          Goto RepeatInput
        End If  
      End If  
      If Fileexists("MyParameters.dat") Then
        Print "File MyParameters.dat found."
        Print "Values of Parameters found in MyParameters.dat are used."
        Print " "
        B_MyParameters = -1
      End If    
    End If
  #endif   ' If Windows system
   
   
   /'*******************  Input by dialogue  *************************'/
  If Bfilein = 0 And BGUI = 0 Then  ' Input by dialogue on Linux
   
RepeatNucleus:
    
    Print "   --------------------------- INPUT DIALOG ---------------------------------"
    Print
    Print "Questions marked by (*): Just press ENTER for a standard calculation."
    Print

    #If defined(B_delayed)  
      Input "Output of FY in ENDF format required? [y/n]? Default = <no> ",Cyesno
      B_ENDF = Pyes(Cyesno,"NO") 
      Print 
    #Endif
        
    Input "Enter Z and A of fissioning nucleus: ",P_Z_CN,P_A_CN
    Ivalid = U_Valid(P_Z_CN,P_A_CN)
    If Ivalid = 0 Then
      Print "************************************************"
      Print "<W> Fissioning nucleus out of supported range!!!"
      Print "************************************************"
      Input "Do you want to start the calculation anyhow [y/n]? Default = <no> ",Cyesno
      Ivalid = Pyes(Cyesno,"NO")
      If Ivalid = 0 Then Goto RepeatNucleus
    End If  
     
RepeatReference:  
    Print
    Print "Chose the input option for the energy:" 
    Print "  GS (energy above ground state),"
    Print "  FC (energy above ground state, only first-chance fission),"
    Print "  ISx (isomer x=1,2; energy above isomeric state x),"
    Print "  EN (neutron incident energy),"
    Print "  EP (proton incident energy),"
    Print "  EA (alpha incident energy),"
    Print "  ENx (x=1,2; neutron incident energy; target in isomeric state x),"
    Print "  EPx or EAx (in analogy to ENx),"
    Print "  EB (energy above outer fission barrier),"
    Print "  ES (excitation-energy spectrum from file, first-chance),"
    Input "  EM (excitation-energy spectrum from file, multi-chance): ",CEref
    CEref = Ucase(CEref)
    If CEref <> "EB" And CEref <> "GS" And Left(CEref,2) <> "IS" _
                     And Left(CEref,2) <> "EN" And Left(CEref,2) <> "EP" And Left(CEref,2) <> "EA" _ 
                     And CEref <> "ES" And CEref <> "EM" And CEref <> "FC" Then
      Print "Option ";CEref;" is not valid. Enter again!"  
      Goto RepeatReference
    End If
    If B_ENDF = 1 Then 
      If CEref = "ES" Then
        Print " "
        Print "***********************************************"
        Print "<I> ENDF output is not supported for ES option."
        Print "    No ENDF file will be produced."
        Print "***********************************************"
        Print " "
        B_ENDF = 0
      End If
    End If
         
    ' Selection of list-mode values (for LINUX version) (0 or 1)
    PZ1 = 1
    PZ2 = 1
    PA1pre = 1
    PA2pre = 1
    PA1post = 1
    PA2post = 1
    PI1 = 1
    PI2 = 1
    Pdir = 1
    PXE = 1
    Pn1 = 1
    Pn2 = 1
    PTKEpre = 1
    PTKEpost = 1    
    PnCN = 1
    Pndel = 1
 
    I_E_iso = 0
    Select Case Left(CEref,2)
      Case "EB"
        Emode = 0
        Print "Reference for energy input is the outer barrier."
      Case "GS"
        Emode = 1
        Print "Reference for energy input is the ground state."
      Case "FC"
        Emode = -1
        Print "Reference for energy input is the ground state."
      Case "IS"
        Emode = 1
        Print "Reference for energy input is the isomeric state."  
        I_E_iso = Val(Mid(CEREF,3))
      Case "EN"
        Emode = 2
        Print "(n,f) reaction assumed."
        Print "Energy input is the incident neutron energy."
        If Val(Mid(CEREF,3)) > 0 Then
          I_E_iso = Val(Mid(CEREF,3))
        End If
      Case "EP"
        Emode = 12
        Print "(p,f) reaction assumed."
        Print "Energy input is the incident proton energy."
        If Val(Mid(CEref,3)) > 0 Then
          I_E_iso = Val(Mid(CEref,3))
        End If         
      Case "EA"
        Emode = 22
        Print "(alpha,f) reaction assumed."
        Print "Energy input is the incident alpha energy."
        If Val(Mid(CEref,3)) > 0 Then
          I_E_iso = Val(Mid(CEref,3))
        End If         
      Case "ES"
        Emode = 3
        Print "Excitation-energy spectrum from input file."  
        Print "(Only first-chance fission is calculated.)"
      Case "EM"
        Emode = 13
        Print "Excitation-energy spectrum from input file."  
        Print "Multi-chance fission supported."   
      Case Else
        Print "Option ";CEref;" is not valid. Enter again!"
        Goto RepeatReference
    End Select
RepeatEnergy:  
    If Emode Mod 10 < 3 Then Input "Enter energy value (MeV): ",P_E_exc
    If Emode Mod 10 = 3 Then 
      Input "Enter file with energy spectrum (default = in/Espectrum.in): ",C_Espectrum1
      If C_Espectrum1 = "" Then C_Espectrum1 = "in/Espectrum.in"
      ' End GEF when file does not exist:
      If Not Fileexists(C_Espectrum1) Then
        Print "<S> File ";C_Espectrum1;" does not exist."
        Print "Press Enter to leave GEF!"  
        Sleep
        End
      End If
    End If  
/'  If Emode <> -1 And Emode <> 3 Then ' Not FC (one energy or distr. from table)
      Input "Avoid sorting events of pre-fission calculation",Cyesno  
      B_Nosort = Pyes(Cyesno,"NO") 
      If B_Nosort Then
        Print "Sequence of calculations will not be sorted by fission chances and energy of pre-fission emission." 
        Print "<W> Calculation time may be strongly increased!"
      End If  
      Print  
    End If  '/
    Print " "
    If P_E_exc > 120 Then
      Dim As Integer IhighE
      Print "******************************************"
      Print "<W> Energy exceeds the supported range !!!"
      Print "******************************************"
      Input "Do you want to start the calculation anyhow [y/n]? Default = <no> ",Cyesno
      IhighE = Pyes(Cyesno,"NO")
      If IhighE = 0 Then Goto RepeatEnergy
    End If
     
    If (Emode = 1 Or Emode = -1) And P_E_exc > 0 Then
      Input "Enter rms angular momentum of CN (0 for ground-state spin): ",P_I_rms_CN
      Print " "
    End If
    Input "(*) suppression of compact shapes at scission [y/n]? Default = <yes> ",Cyesno
    B_supp = Pyes(Cyesno,"YES")   
    print   
    Scope
      Dim As String C_eo
      Input "(*) Enter scaling factor for even-odd effect in Z and N yields (default = 1): ",C_eo
      If C_eo = "" Then 
        EOscale = 1
      Else
        EOscale = Val(C_eo)
      End If  
    End Scope  
    Print " "
/'<'/
    /' Shell effects for the symmetric fission channel '/
   _Delta_S0 = U_Delta_S0(P_Z_CN,P_A_CN)   ' default values
     
/'>'/     
    Scope
      Dim As Single Delta_S0_mod=0
      Dim As String Modi
      Print "Shell effect in the symmetric channel is assumed to be ";_Delta_S0;" MeV."
      Delta_S0_mod = _Delta_S0
      If Bfilein = 0 And BGUI = 0 Then
        Input "(*) You may enter another guess value if you want to change it: ",Modi
      End If  
      If Modi <> "" Then
        Delta_S0_mod = Val(Modi)
        _Delta_S0 = Delta_S0_mod
      End If
    End Scope  
    Print " "

    Scope
      If Fileexists("MyParameters.dat") Then
        Input "Read parameters from file MyParameters.dat [y/n]? Default = yes: ",Cyesno
        If Pyes (Cyesno,"YES") = 1 Then B_MyParameters = -1
        Print " "
      End If    
      Dim As Integer Ihelp = 0
      Clocal = "localoff"
'Print 2294,P_Z_CN,P_A_CN       
 /'   If (P_Z_CN = 92) And (P_A_CN = 234) Then
        Input "Use locally adjusted model parameters [y/n]? Default = yes: ",Cyesno
        Ihelp = Pyes(Cyesno,"YES")
        If Ihelp = 1 Then Clocal = "localon"
        Print " " 
      End If '/
    End Scope
     
    Dim As String C_mode_select
    Input "Select a specific fission channel: SL, S1(Sn), S2, S3(SA), S4(Pb), S5(Z=36):",C_mode_select
    Select Case C_mode_select
      Case "SL"
        I_Mode_selected = 0
        Print "Fission channel SL selected."
      Case "S1"
        I_Mode_selected = 1
        Print "Fission channel S1 (Sn shell) selected."
      Case "S2"
        I_Mode_selected = 2
        Print "Fission channel S2 selected."
      Case "S3"
        I_Mode_selected = 3
        Print "Fission channel S3 selected."
      Case "S4"
        I_Mode_selected = 4
        Print "Fission channel S4 (Pb shell) selected."
      Case "S5"
        I_Mode_selected = 5
        Print "Fission channel near Z=36 selected."
      Case Else
        Print "No fission channel selected."
    End Select
    Print " "

    if B_ENDF = 1 Then
      B_Error_On = 1   
      Print "Error analysis is on (required for ENDF output)."   
      If Emode = 2 Then Input "Write ENDF random files [y/n]? Default = no: ",Cyesno
      B_Random_On = Pyes(Cyesno,"NO")
    Else
      Input "Switch on error analysis by perturbed model parameters [y/n]? Default = no: ",Cyesno
      B_Error_On = Pyes(Cyesno,"NO")
    End If    
    Dim As String C_Par_Fac
    If B_Error_On = 1 Then
      Input "Factor for scaling the variation of perturbed parameters (default = 1): ",C_Par_Fac
        If C_Par_Fac = "" Then 
          D_Par_Fac = 1
        Else
          D_Par_Fac = Val(C_Par_Fac)
        End If  
      Input "Output of covariances [y/n]? Default = no: ",Cyesno
      Bcov = Pyes(Cyesno,"NO")
      Input "Output of correlation coefficients [y/n]? Default = no: ",Cyesno
      Bcor = Pyes(Cyesno,"NO")
    End If
    Print " " 
     
  ' If B_Error_On = 1 And (Bcov = 1 Or BCor = 1) And Emode Mod 10 < 3 Then
    If B_Error_On = 1 And Emode Mod 10 <= 3 Then
      Input "Include another system in the perturbed-parameter calculatinos [y\n]? Default = no: ",Cyesno
      B_Double_Covar = Pyes(Cyesno,"NO")
      If B_Double_Covar = 1 Then
RepeatDoubleNucleus:
        Input "Enter Z and A of the second fissioning nucleus: ",P_Z_CN_Double,P_A_CN_Double
        Ivalid = U_Valid(P_Z_CN_Double,P_A_CN_Double)
        If Ivalid = 0 Then
          Print "Fissioning nucleus out of supported range."
          Goto RepeatDoubleNucleus
        End If  
        If Emode Mod 10 < 3 Then
          Input "Enter energy value (MeV): ",P_E_exc_Double
        End If  
        If Emode Mod 10 = 3 Then
          Input "Enter file with energy spectrum (default = in/Espectrum.in): ",C_Espectrum2
          If C_Espectrum2 = "" Then C_Espectrum2 = "in/Espectrum.in"
          ' End GEF when file does not exist:
          If Not Fileexists(C_Espectrum2) Then
            Print "<S> File ";C_Espectrum2;" does not exist."
            Print "    GEF is terminated." 
            End
          End If
        End If
      End If
      Print " "
    End If
     
   '  Input "Include delayed gammas (de-exc. of isomers) in prompt-gamma results [y/n]? Default = no: ",Cyesno
   '  I_Delgam = Pyes(Cyesno,"NO")
   '  Print " "

    Input "You may specify an enhancement factor to increase the statistics (default = 1.E5 events): ",Fenhance  
    If Fenhance = 0 Then Fenhance = 1 
    If Fenhance < 1 Then
      Print "<W> The calculation with ";Csng(Fenhance*1.E5);" events will be subject"
       Print "    to grave statistical fluctuations!"
    End If   
    Print " "
     
    Input "Enter file for event-wise list-mode data output (if desired): ",Cfileoutlmd
    If Cfileoutlmd <> "" Then
      If Instr(Cfileoutlmd,".") = 0 Then
        Cfileoutlmd_full = "out\"+Cfileoutlmd + ".lmd"
      Else
        Cfileoutlmd_full = "out\"+Cfileoutlmd
      End If
      Input "List energies and angles of prompt post-scission neutrons [y/n]? Default = no: ",Cyesno
      PEnpost = Pyes(Cyesno,"NO")
      Input "List energies of post-scission prompt gammas [y/n]? Default = no: ",Cyesno
      PEgpost = Pyes(Cyesno,"NO")
      Input "List contributions to Eexc of fragments [y/n]? Default = no: ",Cyesno
      PXEdetails = Pyes(Cyesno,"NO")
      If PXEdetails = 1 Then
        Print "E_rotation, E_intrinsic(at scission) and ";  
        Print "E_deformation (converted to E_intrinsic after scission) ";
        Print "will be written to the lmd file."
      End If
    End If
    Print " "
     
    If B_Error_On = 1 Then
      Input "Extended output of perturbed calculations [y/n]? Default = no: ",Cyesno
      Brec = Pyes(Cyesno,"NO")
      print " "
      If Brec = 1 Then 
        print "- Full tables of all GEF results are written to /out/XXX.ptb."
        print "- Tables of FF yields (Y(Z), Y(Apre), Y(Apost), Y(Apre,Z), Y(Apost,Z)"
        print "  are written to /tmp/XXX.mvd."
        print "  These are the raw data for calculating the corresponding"
        print "  multivariant distributions of the GEF results and the"
        print "  covariance matrices."
        print "- List-mode data of all fission observables are written to /out/XXX.lmd."
        print "  (This option is only activated if list-mode output is enabled.)"
        print " "
      End If
    End If
    Input "Show display of mass distributions [y/n]? Default = yes: ";Cyesno
    Bplot = Pyes(Cyesno,"YES")
    If Bplot = 1 Then Bplot = -1
    If Bplot Then
      Input "If available, compare to ENDF/B-VII(0), JEFF3.1.1(1), JEFF3.3(2), LOHENGRIN(3): ",IENDFall
    '  Dim As Integer IJEFF311  
    '  IJEFF311 = Pyes(Cyesno,"YES")  ' IENDFall declared in DCLplotting.bas
    '  IENDFall = 1 - IJEFF311 
    End If  
    print " "
     
  End If  ' End input by dialogue    
 
  Chisqr_Fit_min = 1.E10  ' initialize value for sequence of fit loops
  I_Fitloop = 0
  Chisqr_Fit_present = 0
   
Nextfitloop:  
  Dim As Integer I_Res
   'The next two statements must stay before "If B_Fit = 1" !
  B_New_Fit_Parameters = 1  ' This variable is only used in fit mode.
                            ' Fit mode is set below by the input file in batch mode.
  If Bfilein Then await(I_thread,I_thread_max)  ' thread specific time window, duration 0.1 second  
                                                     ' (files #Fitlog) and #F_Fitpar)
  If B_Fit = 1 Then
    If I_Fitloop >= 1 Then
      Fitlog = Freefile
      Open "tmp/Fitlog"+Trim(Str(I_thread)) +".dat" For Append As #Fitlog
      Print #Fitlog,"Total Chisqr value: ";Csng(Chisqr_Fit_present)
      If Chisqr_Fit_present < Chisqr_Fit_min And Chisqr_Fit_present > 0 Then
        Chisqr_Fit_min = Chisqr_Fit_present  ' store new "best" chisqr value
        Print #Fitlog, "New improved set of fit parameters found and stored in Fitpar.dat."
        If D_Par_Fac > 0.03 Then 
          D_Par_Fac = D_Par_Fac * 0.9 ' reduce amplitude of variations
          Print #Fitlog, "Amplitude of parameter variation is reduced by factor 0.9."
        Else
          Print #Fitlog, "Amplitude of parameter variation reached lower limit."
        End If
        Print #Fitlog, "New value of D_Par_Fac: ";D_Par_Fac
        #Include "FitparWrite.bas"    ' write new parameter values to file
          ' Write updated Parameter list:
        #Include "ParameterUpdate.mac"             
        #ifdef __FB_WIN32__
        #else
          I_Res = Shell("cp -r GRAF BestFit")
          If I_Res = 0 Then Print ".grf files copied to BestFit/GRAF"
          If B_fit Then I_Res = Shell("cd BestFit/GRAF/ ; todos *")
          If I_Res = 0 Then Print ".grf files in BestFit/GRAF converted to Windows format."
        #endif 
      End If
      Close #Fitlog 
    End If
  End If
  #Include "FitparRead.bas"
         ' FitparRead looks for the file Fitpar.dat. If it exists, the parameter
         ' values are set to the values in Fitpar.dat. (Not only in fit mode!)
         ' If the parameter values from Parameters.bas should be taken, 
         ' the file Fitpar.dat must be renamed or deleted.
         ' Philosophy: At the beginning of a series of calculations in Fit mode,
         ' the file Fitpar.dat does not exist. In this case, the parameter values
         ' from Parameters.bas are taken. (Eventually, when MyParameters.dat exists,
         ' and the corresponding input option is chosen, they are overwritten 
         ' by the values in MyParameters.dat.)
         ' In the following calculations in Fit mode, Fitpar.dat may exist, and 
         ' the parameter values are overwritten by the last values in Fitpar.dat.
         ' These are the best values found until this moment. 
         ' FitparRead.bas sets also the value of Chisqr_Fit_min to the value
         ' of the last fit that is stored in fitpar.dat.
       I_Fitloop = I_Fitloop + 1

' Technische Bemerkung: 
' Hier klappt es noch! (Wenn es weiter unten steht, gibt es unsinnige Ergebnisse.)
         /' Uncertainties for error analysis (setting of values): '/
  Var_P_DZ_Mean_S1 = 0.06 * Fred_par * D_Par_Fac
  Var_P_Corr_S1 = 0.01 * Fred_par * D_Par_Fac
  Var_P_DZ_Mean_S2 = 0.06 * Fred_par * D_Par_Fac
  Var_P_A_Width_S2 =_P_A_Width_S2 * 0.03 * Fred_par * D_Par_Fac
  Var_P_DZ_Mean_S3 = 0.06 * Fred_par * D_Par_Fac
  Var_P_DZ_Mean_S4 = 0.06 * Fred_par * D_Par_Fac
  Var_P_DZ_Mean_SL5 = 0.06 * Fred_par * D_Par_Fac
  Var_P_DZ_Mean_S5 = 0.06 * Fred_par * D_Par_Fac
  Var_Delta_S0 = 0.06 * Fred_par * D_Par_Fac
  Var_P_Shell_S1 = 0.06 * Fred_par * D_Par_Fac
  Var_P_Shell_S2 = 0.06 * Fred_par * D_Par_Fac
  Var_P_Shell_S3 = 0.12 * Fred_par * D_Par_Fac
  Var_P_Shell_S4 = 0.06 * Fred_par * D_Par_Fac
  Var_P_Shell_SL5 = 0.03 * Fred_par * D_Par_Fac
  Var_P_Shell_S5 = 0.03 * Fred_par * D_Par_Fac
  Var_dE_Defo_S1 = 0.25 * Fred_par * D_Par_Fac
  Var_dE_Defo_S2 = 0.25 * Fred_par * D_Par_Fac
  Var_dE_Defo_S3 = 0.25 * Fred_par * D_Par_Fac
  Var_dE_Defo_S4 = 0.25 * Fred_par * D_Par_Fac
  Var_dE_Defo_S5 = 0.25 * Fred_par * D_Par_Fac
  Var_betaL0 = 2.0 * Fred_par * D_Par_Fac
  Var_betaL1 = 0.02 * Fred_par * D_Par_Fac
  Var_betaH0 = 2.0 * Fred_par * D_Par_Fac
  Var_betaH1 = 0.02 * Fred_par * D_Par_Fac
  Var_dbeta_S3 = 0.05 * Fred_par * D_Par_Fac
  Var_ECOLLFRAC = 0.05 * Fred_par * D_Par_Fac
  Var_EDISSFRAC = 0.05 * Fred_par * D_Par_Fac
  Var_P_Z_Curv_S1 = _P_Z_Curv_S1 * 0.03 * Fred_par * D_Par_Fac
  Var_P_Z_Curv_S2 = _P_Z_Curv_S2 * 0.03 * Fred_par * D_Par_Fac
  Var_S2leftmod = _S2leftmod * 0.03 * Fred_par * D_Par_Fac
  Var_P_Z_Curv_S3 = _P_Z_Curv_S3 * 0.03 * Fred_par * D_Par_Fac
  Var_P_Z_Curv_S4 = _P_Z_Curv_S4 * 0.03 * Fred_par * D_Par_Fac
  Var_P_Z_Curv_SL5 = _P_Z_Curv_SL5 * 0.03 * Fred_par * D_Par_Fac
  Var_P_Z_Curv_S5 = _P_Z_Curv_S5 * 0.03 * Fred_par * D_Par_Fac
  Var_PZ_S3_olap_pos = 0.1 * Fred_par * D_Par_Fac
  Var_PZ_S3_olap_curv = 0.03 * Fred_par * PZ_S3_olap_curv * D_Par_Fac
  Var_T_low_S1 = 0.006 * Fred_par * D_Par_Fac
  Var_T_low_S2 = 0.006 * Fred_par * D_Par_Fac
  Var_T_low_S3 = 0.006 * Fred_par * D_Par_Fac
  Var_T_low_S4 = 0.006 * Fred_par * D_Par_Fac
  Var_T_low_S5 = 0.006 * Fred_par * D_Par_Fac
  Var_T_low_SL = 0.006 * Fred_par * D_Par_Fac
  Var_P_att_pol = _P_att_pol * 0.12 * Fred_par * D_Par_Fac
  Var_HOMPOL = _HOMPOL * 0.06 * Fred_par * D_Par_Fac
  Var_POLARadd = 0.06 * Fred_par * D_Par_Fac 
  Var_Jscaling = _Jscaling * 0.06 * Fred_par * D_Par_Fac

  If Bfilein Then   
    Clocal = "localoff"
  End If  
        
  If Bfilein = 0 Then
    If B_Error_On = 1 Then
      If P_Z_CN > 106 And P_Z_CN <= 120 Then
        Print " "
        Print "***********************************************"
        Print " Uncertainty estimates are doubtful for Z>106! "
        Print "***********************************************"
        Print " "
      End If    
    End If   
  
    N_E_steps = 1
    Iline_tot = 1   
  End If
 
   
   /' Support of multiprocessing with task list from file '/    

   ' Notice: Before starting a new multiprocessing calculation, the
   ' files "ctl/thread.ctl" and "ctl/done.ctl" must be deleted!
   
  Dim As String C_Energy_Table
  Redim Energy_Table(1) As Single
  Redim Spin_Table(1) As Single
  Dim As Integer N_E_values = 1
  Dim As Integer I_first,I_last,I_step,N_values
  Static As Single En_min    ' excitation energy, for (n,f) neutron energy
  Static As Single En_max    ' excitation energy, for (n,f) neutron energy

  Type S_par_type          ' Case parameters
    Dim Z As Integer
    Dim A As Integer
    Dim Z_double As Integer
    Dim A_double As Integer
    Dim E_double As Single
    Dim CE As String          ' kind of entrance channel
  End Type
  Static N_par As Integer   ' Number of cases in input file
  Static S_par(5000) As S_par_type  ' List of case parameters
   
  Dim As Integer iexist

   ' Variables for calculation with energy distribution
  Redim As Single E_spectrum(1)
  Redim As Single L_spectrum(1)
  Redim As Single W_spectrum(1)
  Redim As Longint NE_all(1)
  Redim As Longint NE_fis(1)
  Dim As Longint I_Estep
  Dim As Single W_spectrum_max
  Dim As Single Ichannel


' Scope     
     
  Dim As String Chelp  
  Redim As String Cfilein(1000)
  Dim As Integer Ifilein 
  Dim As Integer Nfilein = 0
   
 '  N_E_steps = CInt(En_max) + 5
   ' Sequence of calculations:
   '     1    ,    2    ,    3    , 4 ,5,6,7,8,9,    ,N_E_steps-1,N_E_steps   
   '  En_min,    En_max,   En_min,0.4, 1,2,3,4,5 ... ,En_max,      En_min  
  

     
   ' Important note:  
   ' If the file "Input.dat" exists, the GEF program does not accept
   ' any input from the keybord and calculates the sequence of nuclei
   ' given in the file defined by "Input.dat" automatically!  

  /'*****************  Read task list from file  ********************'/
  If Bfilein Then
    Print "File 'file.in' found."
    Print "Manual input suspended, input will be taken from file."
   '  If B_ENDF = 1 Then     
   '    If B_Random_On = 1 Then
   '      Print "Random files in ENDF format will be produced."
   '    Else
   '      Print "No random files in ENDF format will be produced." 
   '    End If
   '  End If

    #ifdef __FB_WIN32__
      Print
      Print "*********************************"
      Print "*** GUI window is not active! ***"
      Print "*********************************"
      Print
    #endif
   
    Print "Number of running processes:";I_thread
    Print "Maximum number of parallel processes:";I_thread_max

    Bplot = 0
    Ffilein = Freefile
    Open "file.in" for input as #Ffilein
    Do Until EOF(Ffilein)
      Line Input #Ffilein,Chelp
      Chelp = Trim(Chelp)
      If Ucase(Chelp) = "FIT" Then
        Print "<I> Fit option specified in file.in."
        B_Fit = 1
        B_Error_On = 1
        BPlot = -1
   '    I_thread = 0
      ElseIf Ucase(Left(Chelp,6)) = "NITER(" And Right(Chelp,1) = ")" Then
        Print "<I> Input ";Chelp;" found on file.in."
        N_iter = Val(Mid(Chelp,7,Len(Chelp)-7))               
      Else
        Nfilein = Nfilein + 1
        If Nfilein >= 1000 Then
          Print "<E> Maximum number of input files reached."
          Nfilein = 1000
          Exit Do
        End If
        If Ucase(Chelp) = "END" Then
          Nfilein = Nfilein - 1 
          Exit Do
        End If  
        If Left(Chelp,1) <> "'" Then
          If Len(Chelp) > 2 Then
            If Instr(Chelp,"'") > 0 Then Chelp = Mid(Chelp,1,Instr(Chelp,"'")-1)
            Chelp = Rtrim(Chelp)
            If Left(Chelp,1) = """" And Right(Chelp,1) = """" Then
              Chelp = Mid(Chelp,2,Len(Chelp)-2)
            End If
          End If  
          Cfilein(Nfilein) = Chelp
        Else
          Nfilein = Nfilein - 1
          Print "Input ***";Chelp;"*** skipped."
        End If
      End If  
    Loop
    If Nfilein = 0 Then Print "No file with input data specified in file.in."
    Close #Ffilein
  End If
     
   /'*************** Loop for list of input files  ******************'/

  For Ifilein = 1 To Max(Nfilein,1)   
    If Nfilein > 0 Then
      Print " "
      Print "Sequence of nuclei given in ";Cfilein(Ifilein);" will be calculated!"
      Bfilein = -1
      Ffilein = Freefile
         
      If Fileexists(Cfilein(Ifilein)) Then
        Open Cfilein(Ifilein) for input as #Ffilein
        Input #Ffilein,Fenhance_global
        Line Input #Ffilein,C_Energy_Table
        C_Espectrum1 = ""
        If Left(C_Energy_Table,1) = """" Then
          C_Espectrum1 = Trim(C_Energy_Table,"""")  ' Filename for energy table of 1. system
          If Not Fileexists(C_Espectrum1) Then
            Print "<S> File ";C_Espectrum1;" does not exist."
            Print "Press Enter key to leave GEF!"
            Sleep
            End
          End If 
        Else
          If Instr(C_Energy_Table,":") > 0 Then
              ' This allows to set the first energy step number in random ENDF files
            I_first_E_step = Cint(Left(C_Energy_Table,Instr(C_Energy_Table,":")-1))
            C_Energy_Table = Mid(C_Energy_Table,Instr(C_Energy_Table,":")+1)
          End If      
          N_E_values = CC_Count(C_Energy_Table,",") 
          Redim Energy_Table(N_E_values) As Single
          Redim Spin_Table(N_E_values) As Single
          Redim Ccut(N_E_values) As String
          CC_Cut(C_Energy_Table,",",Ccut(),N_E_values)
          For I = 1 To N_E_values
            If Instr(Ccut(I),"/") > 0 Then  ' Read optional input of average angular momentum
              If Abs(Emode) > 1 And Emode <> 3 Then
                Print "<E> Error in input line:"
                Print C_Energy_Table
                Print "Input of average spin values are only supported for options 'CN fission' or 'ES'."
                Print "Press Enter key to leave GEF!"
                Sleep
                End
              EndIf
              Spin_Table(I) = Val(Mid(Ccut(I),Instr(Ccut(I),"/")+1))
              Ccut(I) = Left(Ccut(I),Instr(Ccut(I),"/")-1)
            End If
            Energy_Table(I) = Val(Ccut(I))
            If I > 1 Then 
              If Energy_Table(I) <= Energy_Table(I-1) Then
                Print "<E> Error in input line:"
                Print C_Energy_Table;"."
                Print "Energy values in input file must be ascending."
                Print "Press Enter key to leave GEF!"
                Sleep
                End
              End If
            End If
          Next I
          En_min = Energy_Table(1) 
          En_max = Energy_Table(N_E_values)
        End If
        Iline = 0
       ' Reset options from input file before reading the next input file:
        B_Error_On = 0
  '       If B_ENDF = 1 Then 
  '         B_Error_On = 1    ' necessary for ENDF files
  '         B_Random_On = 0
  '       End If
        Brec = 0
        Bcov = 0
        Bcor = 0
        B_supp = 1
        B_ENDF = 0
        B_Random_On = 0
        CFileoutlmd = ""
        Clocal_file_option = "localoff"   
        I_Mode_selected = -1
        Do Until EOF(Ffilein)
          Line Input #Ffilein,Chelp
          Chelp = Trim(Chelp)   
          If Left(Chelp,1) <> "'" And Chelp <> "" Then 
            Scope
              Dim As String Coptions,Cval
              If Ucase(Left(Chelp,8)) = "OPTIONS(" And Right(Chelp,1) = ")" Then
                Coptions = Mid(Chelp,9,Len(Chelp)-9)
                N_values = CC_Count(Coptions,",")
                Redim Ccut(N_values) As String
                CC_Cut(Coptions,",",Ccut(),N_values)
                For I = 1 To N_values
                  If Instr(Ccut(I),"(") > 0 And Instr(Ccut(I),")") > 0 Then
                    Cval = Mid(Ccut(I),Instr(Ccut(I),"(")+1,Instr(Ccut(I),")")-Instr(Ccut(I),"(")-1)
                    Ccut(I) = Mid(Ccut(I),1,Instr(Ccut(I),"("))
                  End If
                  Select Case Ucase(Ccut(I))
                    Case "PLOT"  ' Show plot of mass distribution
                      Bplot = -1
                      Print "      Plot of mass distribution will be shown." 
                    Case "MYPARAMETERS"    ' Read model parameters from file "MyParameters.dat"
                      Print "<I> Option 'MyParameters' found on input file"
                      If Fileexists("MyParameters.dat") Then
                        B_MyParameters = -1
                        Print "    User-defined parameter values will be used."
                      Else
                        Print "    File 'MyParameters.dat' not found."
                      End If  
                    Case "LOCAL"
                      Clocal_file_option = "localon"
                    Case "GLOBAL"
                      Clocal_file_option = "localoff" 
                    Case "NOSUPP"
                      B_supp = 0  
                    Case "ERR"
                      B_Error_On = 1  ' Calculation with perturbed parameters 
                      Print "<I> Option 'err' found on input file:"
                      Print "    Calculation with perturbed parameters enabled."
                      Print "    Uncertainties of several fission quantities will be determined,"
                      Print "    Correlations are calculated with the 'cor' option in addition."
                      Print "    Covariances are calculated with the 'cov' option in addition."
                      Print "    Output of perturbed calculations with the 'ptb' option in addition."
                      If B_ENDF = 1 Then 
                        Print "    Random files in ENDF format are produced with the 'random' option."
                      End If
                    Case "DPARFAC("
                      D_Par_Fac = Val(Cval)
                      Print "<I> Factor ";D_Par_Fac;" for scaling the variation of"
                      Print "    the perturbed parameters found on input file." 
                      Print "<W> Sorry, this option is not yet available!!!!!!!"
                    Case "PTB" 
                      Print "<I> Option 'ptb' found on input file:"
                      B_Error_On = 1
                      Brec = 1  ' detailed output of perturbed-parameter calculations
                      Print "    Extended output of perturbed-parameter calculations in /out/xxx.ptb file."
                    Case "RANDOM"  
                      Print "<I> Option 'random' found on input file:"
                      #Ifdef B_delayed
                        B_ENDF = 1  
                        B_Error_On = 1
                        B_Random_On = 1
                        Print "    Production of random files in ENDF format enabled."
                      #Else
                        Print "<E> Option 'random' not supported by this GEF version."  
                      #Endif   
                    Case "COV"
                      B_Error_On = 1
                      Bcov = 1  ' covariances on output
                      Print "<I> Option 'cov' found on input file:"
                      Print "    Covariances will be written to output file."
                    Case "COR"
                      B_Error_On = 1
                      Bcor = 1  ' correlation coefficients on output
                      Print "<I> Option 'cor' found on input file:"
                      Print "    Correlations coefficients will be written to output file."
                    Case "LMD" 
                      CFileoutlmd = "$Events.lmd" ' list-mode output
                      Cfileoutlmd_full = "out\"+Cfileoutlmd + ".lmd"
                      Print "<I> Option 'lmd' found on input file:"
                      Print "    List-mode output enabled."
                      PZ1 = 1
                      PZ2 = 1
                      PA1pre = 1
                      PA2pre = 1
                      PA1post = 1
                      PA2post = 1
                      PI1 = 1
                      PI2 = 1
                      Pdir = 1
                      PXE = 1
                      Pn1 = 1
                      Pn2 = 1
                      PTKEpre = 1
                      PTKEpost = 1    
                      PnCN = 1
                      Pndel = 1
                    Case "LMD+"
                      CFileoutlmd = "$Events.lmd" ' list-mode output
                      Cfileoutlmd_full = "out\"+Cfileoutlmd + ".lmd"
                      Print "<I> Option 'lmd+' found on input file:"
                      Print "    List-mode output, including prompt neutrons and gammas, enabled."
                      PZ1 = 1
                      PZ2 = 1
                      PA1pre = 1
                      PA2pre = 1
                      PA1post = 1
                      PA2post = 1
                      PI1 = 1
                      PI2 = 1
                      Pdir = 1
                      PXE = 1
                      PXEdetails = 1
                      Pn1 = 1
                      Pn2 = 1
                      PTKEpre = 1
                      PTKEpost = 1    
                      PnCN = 1
                      PEnpost = 1
                      PEgpost = 1
                      Pndel = 1
                    Case "NEO"
                      EOscale = 0
                      Print "<I> Even-odd effect in Z and N at scission suppressed."
         /'         Case "NOSORT"
                      B_Nosort = -1
                      Print "<I> Pre-fission emission will directly be coupled to the fission calculation."
                      Print "    This may considerably increase the computing time."  '/
                    Case "ENDF"
                      #if defined(B_delayed) 
                        B_ENDF = 1
                        B_Error_On = 1  ' Calculation with perturbed parameters 
                        Print "<I> Output files with FY in ENDF format will be produced."
                      #else 
                        Print "<I> Output of FY in ENDF format is not supported by this GEF version."
                      #endif  
                    Case Else  
                      Print "<E> Option ";Ccut(I);" found on input file is not supported."
                      Print "    Possible options are: local, global, err, dparfac(..), ptb, cov, cor, lmd, neo, ENDF, random."
                  End Select    
                Next I 
              ' For I = 1 To N_values
           '    Line Input #Ffilein,Chelp
           '    Chelp = Trim(Chelp)   
              ElseIf Ucase(Left(Chelp,4)) = "FIT(" And Right(Chelp,1) = ")" Then
                B_Fit = 1
                B_Error_On = 1
                BPlot = -1
                Print "<I> Input ";Chelp;" found on input file"
                C_Fitoption = Ucase(Mid(Chelp,5,Len(Chelp)-5))
              ElseIf Ucase(Left(Chelp,6)) = "NITER(" And Right(Chelp,1) = ")" Then
                Print "<I> Input ";Chelp;" found on input file."
                Coptions = Mid(Chelp,7,Len(Chelp)-7)
                N_iter = Val(Coptions)               
              ElseIf Ucase(Left(Chelp,5)) = "MODE(" And Right(Chelp,1) = ")" Then
                Print "<I> Input ";Chelp;" found on input file."
                Coptions = Mid(Chelp,6,Len(Chelp)-6)
                Select Case Coptions
                  Case "0","S0","L"
                    I_Mode_selected = 0
                    Print "   Calculation will be restricted to fission of the super-long mode."
                  Case "1","S1"
                    I_Mode_selected = 1
                    Print "   Calculation will be restricted to fission of the standard 1 mode."
                  Case "2","S2"
                    I_Mode_selected = 2
                    Print "   Calculation will be restricted to fission of the standard 2 mode."
                  Case "3","S3"
                    I_Mode_Selected = 3
                    Print "   Calculation will be restricted to fission of the standard 3 mode."
                  Case "4","S4"
                    I_Mode_Selected = 4
                    Print "   Calculation will be restricted to fission of Pb mode."
                  Case "5","S5"
                    I_Mode_Selected = 5
                    Print "   Calculation will be restricted to fission of the mode near Z=36."
                  Case "6","S11"
                    I_Mode_Selected = 6
                    Print "   Calculation will be restricted to fission of the S11 mode."
                  Case "7","S22"
                    I_Mode_Selected = 7
                    Print "   Calculation will be restricted to fission of the S22 mode."
                  Case Else
                    I_Mode_Selected = -1
                    Print "<E> Selected mode ";Coptions;" not defined."
                    Print "    Selection ignored."
                End Select
              ElseIf Ucase(Chelp) = "END" Then
                Print "Input after ***";Chelp;"*** skipped." 
                Exit Do
              Else   
                N_values = CC_Count(Chelp,",")  
                If N_values = 3 Then
                  Redim Ccut(3) As String
                  CC_Cut(Chelp,",",Ccut(),3)  
                  Ccut(3) = Trim(Ccut(3))
                  Ccut(3) = Trim(Ccut(3),"""")
                  If Instr(Ccut(2),"-") > 0 Then
                    I_first = Val(Mid(Ccut(2),1,Instr(Ccut(2),"-")-1))
                    If Instr(Ccut(2),"+") > 0 Then
                      I_last = Val(Mid(Ccut(2),Instr(Ccut(2),"-")+1,Instr(Ccut(2),"+") _
                         -Instr(Ccut(2),"-")-1))
                      I_step = Val(Mid(Ccut(2),Instr(Ccut(2),"+")+1))
                    Else
                      I_last = Val(Mid(Ccut(2),Instr(Ccut(2),"-")+1))
                      I_step = 1
                    End If
                    For I = I_first To I_last Step I_step
                      Iline = Iline + 1
                      S_par(Iline).Z = Val(Ccut(1))
                      S_par(Iline).A = I
                      S_par(Iline).Z_double = 0
                      S_par(Iline).CE = Ccut(3)
                    Next I
                  Else 
                    Iline = Iline + 1
                    S_par(Iline).Z = Val(Ccut(1))
                    S_Par(Iline).A = Val(Ccut(2))
                    S_Par(Iline).Z_double = 0
                    S_par(Iline).CE = Ccut(3)  
                  End If
                  If C_Espectrum1 <> "" Then
                    If Ccut(3) <> "ES" And Ccut(3) <> "EM" Then
                      Print "<E> Energy distribution from file only supported for options 'ES' and 'EM'."
                      Print "Press ENTER to leave GEF!"
                      Sleep
                      End
                    End If
                  End If
                ElseIf N_values = 6 Then  ' Correlations between two systems
                  If N_E_values > 1 Then
                    Print "<E> Calculation of correlations between two systems is supported"
                    Print "    for only one energy value (or E* spectrum) in the input file." 
                    Print "<H> As a work-around, you may provide several input files"
                    Print "    with only one energy (or spectrum) each and write the list" 
                    Print "    of input files into the file 'file.in'."
                    Print "Press Enter key to leave GEF!"
                    Sleep
                    End
                  End If
             
                  Redim Ccut(6) As String
                  CC_Cut(Chelp,",",Ccut(),6)  
                  Ccut(6) = Trim(Ccut(6))
                  Ccut(6) = Trim(Ccut(6),"""")
                  Iline = Iline + 1
                  S_par(Iline).Z = Val(Ccut(1))
                  S_Par(Iline).A = Val(Ccut(2))
                  S_par(Iline).Z_double = Val(Ccut(3))
                  S_par(Iline).A_double = Val(Ccut(4))
                  If Left(Ccut(5),1) = """" Then
                    C_Espectrum2 = Trim(Ccut(5),"""")
                    If Not Fileexists(C_Espectrum2) Then
                      Print "<S> File ";C_Espectrum2;" does not exist."
                      Print "Press ENTER key to leave GEF!"
                      Sleep
                      End
                    End If
                    If Ccut(6) <> "ES" And Ccut(6) <> "EM" Then
                      Print "<E> Energy distribution from file only supported for options 'ES' and 'EM'."
                      Print "Press Enter key to leave GEF!"
                      Sleep
                      End
                    End If 
                  Else
                    S_par(Iline).E_double = Val(Ccut(5))
                  End If  
                  S_par(Iline).CE = Ccut(6)
                Else
                  Print "<E> Number of data not matching in ";Chelp;"."
                End If
              End If
            End Scope  
          Else
            If Chelp <> "" Then Print "Input ***";Chelp;"*** skipped."
          End If  ' If Left(..
        Loop
        Close #Ffilein
        Iline_tot = Iline
      Else
        Print "<S> File ";Cfilein(Ifilein);" not found."
        Print "Press ENTER key to leave GEF!"
        Sleep
        End
      End If    
       
      Fenhance = Fenhance_global
    Else
      Bfilein = 0
      En_min = P_E_exc
      En_max = P_E_exc         
    End If
   
  
     /'*************** Loop for executing task list  ******************'/
     
    If Bfilein Then await(I_thread,I_thread_max)  ' thread specific time window, duration 0.1 second 
       ' Avoid collisions in reading and writing list of finished calculations (file  #Fdone),
     
    For Iline = 1 To Iline_tot   
      If Bfilein = -1 Then
        B_Double_Covar = 0
        P_Z_CN = S_par(Iline).Z
        P_A_CN = S_par(Iline).A
        If S_par(Iline).Z_double > 0 Then
          B_Double_Covar = 1
          P_Z_CN_Double = S_par(Iline).Z_double
          P_A_CN_Double = S_par(Iline).A_double
          P_E_exc_Double = S_par(Iline).E_double
           
          If N_E_values > 1 Then
            Print "<E> Calculation of correlations between two systems is supported"
            Print "    for only one energy value in the input file." 
            Print "<I> As a work-around, you may provide several input files"
            Print "    with only one energy each and write the list of input files" 
            Print "    into the file 'file.in'."
            Print "Press Enter key to leave GEF!"
            Sleep
            End
          End If
           
        End If
        CEref = Ucase(S_par(Iline).CE)
  
   '    If B_Fit = 0 Then _Delta_S0 = U_Delta_S0(P_Z_CN,P_A_CN)   
  
        If Bfilein Then await(I_thread,I_thread_max)
          ' Avoid collisions in reading and writing list of finished calculations  
          ' (file #Fdone).
        Dim As Integer Fdone,I,Ifound,Imode_done
        Dim As String C_Espectrum_done
        Dim As Single Zdone,Adone,Edone,Fenhance_done
        Ifound = 0
        If B_Fit = 0 Then  ' allow for repeated calculations of the same systems in Fit mode
          CHDIR("ctl")
          If Fileexists(CFdone) Then
            Fdone = Freefile
            Open CFdone For Input As #Fdone
            Do 
              Input #Fdone, Zdone,Adone,Edone,Fenhance_done,Imode_done,C_Espectrum_done
              If Zdone = P_Z_CN Then
   'Print "Z",Zdone,P_Z_CN
                If Adone = P_A_CN Then
   'Print "A",Adone,P_A_CN
                  If Edone = En_max Then
   'Print "E",Edone,En_max
                    If Fenhance_done = Fenhance Then
                      If Imode_done = I_Mode_selected Then
                        If C_Espectrum1 = C_Espectrum_done Or C_Espectrum_done = "none" Then
                          Ifound = 1
                          Print "Z = ";P_Z_CN;" A = ";P_A_CN;" E = ";En_max; _
                           " Fenhance = ";Fenhance;" I_Mode_selected = ";I_Mode_selected; _
                           " E_spectrum = ";C_Espectrum1;" skipped (already in done.ctl)."
'                         Print "Press ENTER key"
'                         sleep
                        End If
                      End If   
                    End If
                  End If
                End If      
              End If
            Loop Until EOF(Fdone)
            Close #Fdone
          End If   ' If Fileexist(CFdone)
          CHDIR("..")
        End If   ' If not B_Fit
           
        If U_valid(P_Z_CN,P_A_CN) = 0 Then
          Ifound = 1
          Print "Nucleus Z =";P_Z_CN;", A =";P_A_CN; _
              " out of supported range, will be skipped."
        End If
         
     '  sleep 100
           
        If Ifound = 0 Then     ' This block has been moved to this place
          Dim C_work1 As String 
          If C_Espectrum1 = "" Then C_work1 = "none" Else C_work1 = C_Espectrum1
          CHDIR("ctl")       
          Fdone = Freefile
          Open CFdone For Append As #Fdone
          Print #Fdone, P_Z_CN,P_A_CN,En_max,Fenhance,I_Mode_selected,C_work1  ' register new case in Fdone
          Close #Fdone
          CHDIR("..")
        End If
        If Ifound = 1 Then 
          Continue For
        End If           
        N_E_steps = 1      ' valid for most options
        P_E_exc = En_max   ' valid for most options
        I_E_iso = 0
        Select Case Left(CEref,2)
          Case "EB"   ' CN fission, energy above EB (outer barrier)
            Emode = 0 
            N_E_steps = N_E_Values
          Case "GS"   ' CN fission, energy above ground state
            Emode = 1
            N_E_steps = N_E_Values
          Case "FC"   ' CN fission, first chance only
            Emode = -1
          Case "IS"   ' spontaneous fission from isomer
            Emode = 1
            I_E_iso = Val(Mid(CEREF,3))
          Case "EN"
            Emode = 2
            If B_ENDF = 1 Then 
              If N_E_Values > 1 Then 
                N_E_steps = N_E_Values + 3   ' with ENDF output
              Else
                N_E_steps = 1
              End If  
              If B_random_on Then
                If N_E_Values = 1 Then N_E_steps = 2
              End If
            Else
              N_E_steps = N_E_Values   ' without ENDF output
            End If             
            If Val(Mid(CEref,3)) > 0 Then
              I_E_iso = Val(Mid(CEref,3))
            End If
          Case "EP"
            Emode = 12  
            If Val(Mid(CEref,3)) > 0 Then
              I_E_iso = Val(Mid(CEref,3))
            End If     
            N_E_steps = N_E_Values
          Case "EA"
            Emode = 22  
            If Val(Mid(CEref,3)) > 0 Then
              I_E_iso = Val(Mid(CEref,3))
            End If     
            N_E_steps = N_E_Values
          Case "ES"
            Emode = 3     
            If B_ENDF = 1 Then
              Print "<W> ENDF output not available for option 'ES'."
              Print "    ENDF output suspended."
              B_ENDF = 0
              B_random_on = 0
            End If 
          Case "EM"
            Emode = 13  '  energy spectrum from input file (multi-chance) 
          Case Else
            Print "<E> Option ";CEref;" is not valid."
            Print "Press Enter key to leave GEF!"
            Sleep
            End
        End Select
  
      End If
       
     /'****** Loop for double calculation of covariances between two systems ******'/ 
      If B_Double_Covar = 1 Then 
        N_Double_Covar = 2
      Else
        N_Double_Covar = 1
      End If
       
      For I_Double_Covar = 1 To N_Double_Covar  
        
        #ifdef B_plotting 
          If Bplot And I_Double_Covar = 2 Then
            SCREEN 0
          End If   
        #endif     
        If I_Double_Covar = 2 Then
          P_Z_CN = P_Z_CN_Double
          P_A_CN = P_A_CN_Double
          P_E_exc = P_E_exc_Double
        End If
      ' If Emode = 2 And B_Random_on = 1 And N_E_Values = 1 Then
      '   N_E_steps = 2            ' Additional calculation for ENDF limits
      ' End If
    
         
        '*** Insert locally adjusted model parameters *** 
          
        If Bfilein Then
          Clocal = Clocal_file_option
        End If  
       
        If B_Fit = 0 Then
            ' Reset global parameters values, and overwrite eventually
            ' by best fit values or user-defined parameters  
          #include "Parameters.bas"
        End If
            
        If Clocal = "localon" Then
          If B_Fit = 1 Then 
            Print "Local parameters not allowed for FIT option."
            Print "Global parameters are used."    
            Clocal = "localoff"
          End If
        End If 
       
     /' If Clocal = "localon" Then
         Clocal = "localoff"
         Print "Local parameters are not available."
        End If '/    
    
       ' Modify values according to local fits   
        If Clocal = "localon" Then
     /'     If P_Z_CN = 92 And P_A_CN = 234 Then
           '   Fmod_slope_S2 = 3.3
     Fmod_slope_S2 = 4
            Else '/
          Print "Local parameters are not available."
    '        End If
        End If    
       
        Print " "
        Print "Fission barrier of CN (Z =";P_Z_CN;", A =";P_A_CN;"):"
        Print "Macrosc. barrier (Thomas-Fermi) = ";Round(BFTF(P_Z_CN,P_A_CN,0),3);" MeV"
    '   If P_A_CN - P_Z_CN > 130 And BFTFB(P_Z_CN,P_A_CN,1) > 0 Then
        If BFTFA(P_Z_CN,P_A_CN,1) - BFTFB(P_Z_CN,P_A_CN,1) < 2 Then
          Print "Inner saddle =";Round(BFTFA(P_Z_CN,P_A_CN,1),3); _
             " MeV, second saddle =";Round(BFTFB(P_Z_CN,P_A_CN,1),3);" MeV"
          If P_Z_CN >= 90 And P_Z_CN <= 98 Then
            BFC = BFTFB(P_Z_CN,P_A_CN,1) + (BFTFB(P_Z_CN,P_A_CN,1) - BFTFA(P_Z_CN,P_A_CN,1) )
            If P_Z_CN >=92 Then BFC = BFC - 0.3 * (P_Z_CN - 92)^2  ' see _supp section
            Print "Third saddle (estimated) = ";Round(BFC,3)
          End If   
        Else
          Print "Fission-barrier height =";Round(BFTF(P_Z_CN,P_A_CN,1),3);" MeV"
        End If
        If BEexp(P_A_CN-P_Z_CN,P_Z_CN) > -1.E10 Then
          Print "exp. Mass = ";AME2020(P_Z_CN,P_A_CN);" MeV"
        Else
          Print "Mass = ";AME2020(P_Z_CN,P_A_CN);" MeV"
        End If    
        Print "Lymass    = ";Lymass(P_Z_CN,P_A_CN,0);" MeV"
        Print "G.S.Shell effect (Moeller) = ";Round(U_SHell(P_Z_CN,P_A_CN),3);" MeV, ";
        If BEexp(P_A_CN-P_Z_CN,P_Z_CN) > -1.E10 Then
          Print "G.S.Shell effect (exp,TF) = ";Round(U_Shell_exp(P_Z_CN,P_A_CN),3);" MeV"  
          Print "S_n(exp.) = ";AME2020(P_Z_CN,P_A_CN-1) - AME2020(P_Z_CN,P_A_CN);" MeV"      
        Else
          Print "G.S.Shell effect = ";Round(U_Shell_exp(P_Z_CN,P_A_CN),3);" MeV"  
          Print "S_n = ";AME2020(P_Z_CN,P_A_CN-1) - AME2020(P_Z_CN,P_A_CN);" MeV"      
        End If
        Print "S_n(Lymass) = ";Lymass(P_Z_CN,P_A_CN-1,0)-Lymass(P_Z_CN,P_A_CN,0);" MeV"
         
        If AME2020(P_Z_CN,P_A_CN-1) - AME2020(P_Z_CN,P_A_CN) < 0 Then
          Print
          Print "<W> Fissioning nucleus is not bound."
          Print "Calculation of this system is stopped."
          If Bfilein Then
            Print "Starting calculation of next system from input file."
            Print
            Goto Next_Iline_label
          Else
            Print "Please start input again!"
            Print
            Goto RepeatInput
          End If
        End If
       
         
       ' *** File name for large output file of calculation ***
     '  If BGUI = 0 Then
        CFileout_Single = "GEF_"+Trim(Str(P_Z_CN))+"_"+Trim(Str(P_A_CN))
        If I_Double_Covar = 1 Then  ' single system or first of the two fissioning systems
          If B_Double_Covar = 0 Then
            CFileout = "GEF_"+Trim(Str(P_Z_CN))+"_"+Trim(Str(P_A_CN))
      '     CFileout = Csystem
          Else
            CFileout = "GEF_"+Trim(Str(P_Z_CN))+"_"+Trim(Str(P_A_CN))+"+"+ _
                              Trim(Str(P_Z_CN_Double))+"_"+Trim(Str(P_A_CN_Double))
          End If
          If I_E_iso > 0 Then
            If Abs(Emode) = 1 Then CFileout = CFileout + "f" + Trim(Str(I_E_iso))
            If Emode Mod 10 = 2 Then CFileout = Cfileout + "m" + Trim(Str(I_E_iso))
          End If  
          If Emode = 0 Then CFileout = CFileout + "_EB"
          If Emode = 2 Then CFileout = CFileout + "_n" 
          If Emode = 12 Then CFileout = CFileout + "_p" 
          If Emode = 22 Then CFileout = CFileout + "_a" 
          If Abs(Emode) = 1 Then
            If P_E_exc = 0 Then  
              CFileout = Cfileout + "_sf"
            Else
              If Emode = -1 Then 
                CFileout = CFileout + "_fc"
              Else 
                CFileout = Cfileout + "_cf"
              End If  
            End If  
          End If  
          If Emode = 3 Then CFileout = Cfileout + "_ed"  ' energy distribution, 1st change 
          If Emode = 13 Then CFileout = Cfileout + "_em"  'energy distribution, multichance
          If I_Mode_selected > -1 Then
            CFileout = Cfileout + "_select"     ' selection for restricted calculation activated
          End If
        End If    
        CFileout_full = "out\"+CFileout + ".dat"
        If Bfilein = 0 then  ' Construct the name of the lmd output file, except in batch mode
          If Cfileoutlmd = "$Events.lmd" Then Cfileoutlmd = Cfileout+".lmd"
          If CFileoutlmd <> "" Then
            If Instr(CFileoutlmd,".") = 0 Then
              CFileoutlmd_full = "out\"+CFileoutlmd + ".lmd"
            Else
              CFileoutlmd_full = "out\"+CFileoutlmd
            End If
          End If    
        End If  
      ' End If       
    
        For I_E_step = 1 To N_E_steps 
    
          C_pfis = ""
          C_pfis2 = ""
          #include "CLEARerrors.bas"
          I_Error = 0
           
          If BFilein Then
            If Emode = 0 Then
              P_E_exc = Energy_Table(I_E_step)
              P_I_rms_CN = Spin_Table(I_E_step)
            End If
            If Emode = 1 Then  ' CN fission, energy above ground state
              P_E_exc = Energy_Table(I_E_step)        
              P_I_rms_CN = Spin_Table(I_E_step)
            End If
            If Emode = 2 Then  ' n-induced fission, neutron energy
              If B_ENDF = 1 Then
                If N_E_Steps = 1 Then
                  B_Error_On = 1
                  P_E_exc = Energy_table(1)
                ElseIf N_E_Steps = 2 Then
                  If B_Random_on Then  ' only one neutron energy on input
                    If I_E_step = 1 Then  ' calculation to determine common limits for ENDF random files
                      B_Error_On = 0
                      P_E_exc = Energy_table(1) 
                    ElseIf I_E_step = 2 Then  ' random calculations
                      B_Error_On = 1
                      P_E_exc = Energy_table(1)
                    End If  
                  Else 
                    B_Error_On = 1
                    P_E_exc = Energy_table(I)
                  End If 
                ElseIf N_E_Steps > 3 Then
                  If I_E_step = 1 Then   ' calculation with lowest energy for limits of nuclei in ENDF file
                    P_E_exc = En_min
                    B_Error_On = 0
                  ElseIf I_E_step = 2 Then   ' calculation with highest energy for limites of nuclei in ENDF file
                    P_E_exc = En_max
                    B_Error_On = 0
                  ElseIf I_E_step >= 3 and I_E_step < N_E_steps Then  ' calculations with perturbed parameters
                    P_E_exc = Energy_table(I_E_step-2)
                    B_Error_On = 1
                  ElseIf I_E_step = N_E_steps Then   ' final calculation
                    P_E_exc = En_min
                    B_Error_On = 0
                  End If  
                End If  
              Else
                P_E_exc = Energy_table(I_E_step)
              End If  
            Else 
              P_E_exc = Energy_table(I_E_step)                 
            End If
          End If  ' If Bfilein
           
         ' *** Name of system ***
          Csystem = "Z"+Trim(Str(P_Z_CN))+"_A"+Trim(Str(P_A_CN))
          If I_E_iso > 0 Then
            If Abs(Emode) = 1 Then Csystem = Csystem + "f" + Trim(Str(I_E_iso))
            If Emode Mod 10 = 2 Then Csystem = Csystem + "m" + Trim(Str(I_E_iso))
          End If  
          If Emode = 0 Then Csystem = Csystem + "_EB"       
          If Emode = 2 Then Csystem = Csystem + "_n" 
          If Emode = 12 Then Csystem = Csystem + "_p"     
          If Emode = 22 Then Csystem = Csystem + "_a"     
          If Abs(Emode) = 1 Then
            If P_E_exc = 0 Then  
              Csystem = Csystem + "_sf"
            Else
              If Emode = -1 Then
                Csystem = Csystem + "_fc"
              Else
                Csystem = Csystem + "_cf"
              End If  
            End If  
          End If  
          If Emode = 3 Then 
            Csystem = Csystem + "_ed"  ' energy distribution, first-chance
          ElseIf Emode = 13 Then
            Csystem = Csystem + "_em"  ' energy distribution, multi-chance   
          Else  
            Csystem = Csystem + "_E"+Trim(Str(P_E_exc))+"MeV"
          End If  
          If I_Mode_selected > -1 Then
            Csystem = Csystem + "_Mode" + Trim(Str(I_Mode_selected))
          End If
    
          If Bfilein = -1 then  ' Construct the name of the lmd output file in batch mode (including the initial energy)
            If Cfileoutlmd = "$Events.lmd" Then Cfileoutlmd = Csystem + ".lmd"
            If CFileoutlmd <> "" Then
              If Instr(CFileoutlmd,".") = 0 Then
                CFileoutlmd_full = "out\"+CFileoutlmd + ".lmd"
              Else
                CFileoutlmd_full = "out\"+CFileoutlmd
              End If
            End If    
          End If  
    
           /' Get data for isomer from table '/
          Scope
            Dim I_MAT As Integer
            Dim As Integer ZT,AT
            ZT = P_Z_CN
            AT = P_A_CN
            E_EXC_ISO = 0
            E_EXC_TRUE = P_E_exc
            If Emode = 2 Then AT = AT -1
            If Emode = 12 Then
              AT = AT - 1
              ZT = ZT - 1 
            End If         
            If Emode = 22 Then
              AT = AT - 4
              ZT = ZT - 2 
            End If         
            If I_E_iso > 0 Then 
              Print " "
              Print "isomer # ";I_E_iso
              I_MAT = I_MAT_ENDF(ZT,AT)
              IF N_ISO_MAT(I_MAT) < I_E_iso Then
                Print "The isomer is not in the table of nuclear properties."
                Print "Z, A, #iso ",ZT,AT,I_E_iso
                Print "Please stop GEF, complete table and restart GEF."
                Goto RepeatInput
              End If
              If I_MAT + I_E_iso >= Lbound(NucTab) And I_MAT + I_E_iso <= Ubound(NucTab) Then
                Print "spin = ";NucTab(I_MAT + I_E_iso).R_SPI
              Else
                Print "Spin not in NucTab (I_MAT = ";I_MAT;")"
              End If  
              If Abs(Emode) = 1 Then Print "Energy above ground state ->"
              If Emode = 2 Then Print "Fictive neutron energy for capt. in g.s. ->"
              If Emode = 12 Then Print "Fictive proton energy for capt. in g.s. ->"
              If Emode = 22 Then Print "Fictive alpha energy for capt. in g.s. ->"
              If I_MAT + I_E_iso >= Lbound(NucTab) And I_MAT + I_E_iso <= Ubound(NucTab) Then
                E_EXC_ISO = NucTab(I_MAT + I_E_iso).R_EXC
              Else
                Print "Excitation energy of isomer is not in table."
                Print "Value set to zero."
                E_EXC_ISO = 0
              End If  
              If Abs(Emode) = 1 Then P_E_exc = P_E_exc + E_EXC_ISO
              If Emode = 2 Then P_E_exc = P_E_exc + E_EXC_ISO
              If Emode = 12 Then P_E_exc = P_E_exc + E_EXC_ISO
              If Emode = 22 Then P_E_exc = P_E_exc + E_EXC_ISO
            End If  
          End Scope 
    'Print "Emode =";Emode       
     
          Print "CN: Z =";P_Z_CN;", A =";P_A_CN;
          If Emode Mod 10 < 3 Then
            Print ", E = ";P_E_exc;" MeV";
            If Emode = 1 Then
              Print ", Spin = ";P_I_rms_CN
            Else
              Print " "
            EndIf  
          Else
            If I_Double_Covar = 1 Then C_Espectrum = C_Espectrum1
            If I_Double_Covar = 2 Then C_Espectrum = C_Espectrum2
            Print ", E/MeV from file ";C_Espectrum;":"
          End If
    
          ' Read excitation-energy distribution from file
          Scope
            Dim As Integer FEspectrum
      '     Dim As Integer Ichannel=0
            Dim As Single Renergy,Rspin,Rweight,REmax
            Dim As Single Norm = 0
            Dim As String C_read
            Dim As Integer N_Count
            Dim As Integer I_skip, I_Elist_skip
            REmax = 0
            I_Elist_skip = 0
            If Emode = 3 Or Emode = 13 Then
              If Fileexists(C_Espectrum) Then 
                Redim Preserve E_spectrum(1)
                Redim Preserve L_spectrum(1)
                Redim Preserve W_spectrum(1)    
                Ichannel = 0       
                FEspectrum = Freefile
                Open C_Espectrum For Input As #FEspectrum  
                Line Input #FEspectrum, C_read
                Do While Left(Trim(C_read),1) = "'"
                  I_Elist_skip = I_Elist_skip + 1
                  Line Input #FEspectrum, C_read
                Loop
                N_Count = CC_Count(C_read, " ")
                Close #FEspectrum
                FEspectrum = Freefile
                Open C_Espectrum For Input As #FEspectrum  
                For I_skip = 1 To I_Elist_skip    ' skip the comment lines
                  Line Input #FEspectrum, C_read
                Next I_skip
                If N_Count = 2 Then
                  Do
                    Input #FEspectrum, Renergy,Rweight
                    REmax = Max(REmax,Renergy)
                    Ichannel = Ichannel + 1
                    If Ichannel > Ubound(W_spectrum,1) Then
                      Redim Preserve E_spectrum(Ichannel)
                      Redim Preserve L_spectrum(Ichannel)
                      Redim Preserve W_spectrum(Ichannel)
                    End If  
                    E_spectrum(Ichannel) = Renergy
                    L_spectrum(Ichannel) = 0
                    W_spectrum(Ichannel) = Rweight
                    Print E_spectrum(Ichannel),W_spectrum(Ichannel)            
                  Loop Until EOF(FEspectrum)       
                End If
                If N_Count = 3 Then
      /'          Dec. 2023: For Emode = 13, the angular momentum is 
                      taken into account in the pre-equilibrium calculation, only. '/        
                  Do
                    Input #FEspectrum, Renergy,Rspin,Rweight
                    REmax = Max(REmax,Renergy)
                    Ichannel = Ichannel + 1
                    If Ichannel > Ubound(W_spectrum,1) Then
                      Redim Preserve E_spectrum(Ichannel)
                      Redim Preserve L_spectrum(Ichannel)
                      Redim Preserve W_spectrum(Ichannel)
                    End If  
                    E_spectrum(Ichannel) = Renergy
                    L_spectrum(Ichannel) = Rspin
                    W_spectrum(Ichannel) = Rweight
                    Print E_spectrum(Ichannel),L_spectrum(Ichannel),W_spectrum(Ichannel)            
                  Loop Until EOF(FEspectrum)       
                End If
                Close #FEspectrum
              Else
                Print "<S> File ";C_Espectrum;" not found."
                Print "Press ENTER key to leave GEF!"
                Sleep
                End
              End If
              If REmax > 11 Then I_Warning = 1
            End If
            ' Normalize energy spectrum
            For I = 1 To Ubound(W_spectrum)
              Norm = Norm + W_spectrum(I)
            Next
            W_spectrum_max = 0
            For I = 1 To Ubound(W_spectrum)
              W_spectrum(I) = W_spectrum(I) / Norm
              W_spectrum_max = Max(W_spectrum_max,W_spectrum(I))
            Next
            Redim NE_all(Ichannel) ' for output of fission probability (option EM)
            Redim NE_fis(Ichannel) '  "
          End Scope
    
          If Bfilein = -1 Then
            Fenhance = Fenhance_global
          End If
    
          If Emode = 0 Then  ' energy on input above second barrier
            Spin_CN = P_I_rms_CN
          End If
           
          ' Set ground-state spin for spont. fission
          If Abs(Emode) = 1 Then
            If P_E_Exc = 0 Then  
              Scope
                Dim As Integer I_MAT
                I_MAT = I_MAT_ENDF(P_Z_CN,P_A_CN)
                If I_MAT >= LBound(NucTab) And I_MAT <= UBound(NucTab) Then
                  If I_E_Iso = 0 Then 
                    Spin_CN = NucTab(I_MAT).R_SPI
                    Print "Ground-state spin ";Spin_CN;" imposed."
                  Else
                    IF N_ISO_MAT(I_MAT) < I_E_iso Then
                      Print "The isomer is not in the table of nuclear properties."
                      Print "Z, A, #iso ",P_Z_CN,P_A_CN,I_E_iso;"."
                      Print "Spin value or isomer set to zero."
                      Spin_CN = 0
                    Else
                      Spin_CN = NucTab(I_MAT + I_E_iso).R_SPI
                      Print "Spin of isomer ";Spin_CN;" imposed."
                    End If
                  End If  
                Else  ' Nucleus is not in NucTab
                  Spin_CN = 0    
                  Print "The fissioning nucleus is not in the table of nuclear properties."
                  Print "Z, A ",P_Z_CN,P_A_CN;"."
                  Print "Spin value set to zero."
                End If
              End Scope
            Else
              Spin_CN = P_I_rms_CN
            End If    
          End If 'If Abs(Emode) = 1
           
          ' Spin of the target nucleus for fission induced by particles
          If Emode Mod 10 = 2 Then  ' neutron, proton or alpha paraticle
            Scope
              Dim As Integer ZT,AT         /' Z and A of target nucleus '/
              Dim As Single I_ISO          /' ISO number '/
              Dim As Integer I_MAT    
              If Emode = 2 Then  ' neutron-induced fission
                ZT = P_Z_CN
                AT = P_A_CN-1
              ElseIf Emode = 12 Then  ' proton-induced fission
                ZT = P_Z_CN-1
                AT = P_A_CN-1
              ElseIf Emode = 22 Then  ' alpha-induced fission
                ZT = P_Z_CN-2
                AT = P_A_CN-4
              End If                
              I_MAT = I_MAT_ENDF(ZT,AT)
              IF I_E_iso = 0 Then ' target in ground state
                If I_MAT = 0 Then
                  Print "The ground-state spin is not in the table of nuclear properties for the nucleus"
                  Print "Z, A ";ZT,AT;"."
                  Print "Spin value of targer nucleus set to zero."
                  Spin_target = 0
                Else  
                  If I_MAT >= Lbound(NucTab) And I_Mat <= Ubound(NucTab) Then
                    Spin_target =  NucTab(I_MAT).R_SPI
                  Else
                    Spin_target = 0
                  End If
                End If  
              Else ' fissioning nucleus or target in isomeric state
                If I_MAT >= Lbound(NucTab) And I_Mat <= Ubound(NucTab) Then
                  IF N_ISO_MAT(I_MAT) < I_E_iso Then
                    Print "The isomer is not in the table of nuclear properties."
                    Print "Z, A, #iso ",ZT,AT,I_E_iso;"."
                    Print "Spin value or isomer set to zero."
                    Spin_target = 0
                  Else
                    Spin_target = NucTab(I_MAT + I_E_iso).R_SPI
                  End If
                Else
                  Print "Spin of target set to zero."
                  Spin_target = 0
                End If
              End If          
            End Scope
          End If 'If Emode Mod 10 = 2
    
          ' Calculate excitation energy above ground state 
          ' and (in case of particle-induced fission) angular momentum of CN
          Select Case Emode
            Case 0  ' Energy above outer barrier is given on input
              Eabsgs = P_E_exc + BFTFB(P_Z_CN, P_A_CN, 1) 
            Case 1, -1 'Energy above ground state is given on input
              Eabsgs = P_E_exc
            Case 2  ' P_E_exc is the kinetic energy of the neutron
                   ' 2/3 * 1.16 * sqr(2 * 939.65) / 197.33 = 0.1699 
              If P_E_exc > 0 Then     
                Spin_CN = sqr(Spin_target^2 + _ 
                  0.5^2 + (0.1699 * (P_A_CN - 1)^0.333333 * sqr(P_E_exc))^2) _
                                  ' maximum impact parameter ,  velocity
              Else  ' This should not happen (negative kin. energy of neutron)
                Spin_CN = sqr(Spin_target^2 + 0.5^2)
              End If   
              Eabsgs = P_E_exc * ((P_A_CN-1) / P_A_CN) + AME2020(P_Z_CN,P_A_CN-1) - AME2020(P_Z_CN,P_A_CN)
                                                        '           target                      CN
            Case 12  ' P_E_exc is the kinetic energy of the proton
                   ' 2/3 * 1.16 * sqr(2 * 939.65) / 197.33 = 0.1699 
              Bprot = 1.14 * (P_Z_CN-1) / (1.16 * ( ( P_A_CN - 1)^0.33333 + 1) )      
              If P_E_exc > 0 Then 
                If P_E_exc * (P_A_CN-1) / P_A_CN > Bprot Then    
                  Spin_CN = sqr(Spin_target^2 + _ 
                    0.5^2 + (0.1699 * (P_A_CN - 1)^0.333333 * sqr(P_E_exc))^2)  _
                     _                ' maximum impact parameter ,  velocity
                    * sqr(1.0 - BProt / (P_E_exc * (P_A_CN-1) / P_A_CN) )  ' effect of Coulomb barrier
                Else
                  Spin_CN = sqr(Spin_target^2 + 0.5^2)  ' no contribution from proton kinetic energy 
                End If  
              Else ' This should not happen (negative kin. energy of proton)
                Spin_CN = sqr(Spin_target^2 + 0.5^2)
              End If            
              Eabsgs = P_E_exc * ((P_A_CN-1) / P_A_CN) + AME2020(P_Z_CN-1,P_A_CN-1) - AME2020(P_Z_CN,P_A_CN)
                                                         '           target                      CN
            Case 22  ' P_E_exc is the kinetic energy of the alpha particle
                   ' 2/3 * 1.16 * sqr(2 * 939.65) / 197.33 = 0.1699 
              If P_E_exc > 0 Then   
                Balpha = 1.14 * 2 * (P_Z_CN-2) / (1.16 * ( (P_A_CN - 4)^0.333333 + 4^0.333333) )   ' Coulomb barrier  
                If P_E_exc * ((P_A_CN-4) / P_A_CN) > Balpha Then
                  Spin_CN = sqr(Spin_target^2 + _ 
                    (0.1699 * ((P_A_CN - 4)^0.333333 + 4^0.333333) * 4 * sqr(P_E_exc/4))^2)_ 
                     _              ' maximum impact parameter      ,  velocity
                   * sqr(1.0 - Balpha / (P_E_exc * (P_A_CN-4) / P_A_CN) )   ' effect of Coulomb barrier
                Else 
                  Spin_CN = Spin_target  ' no contribution from alpha kinetic energy             
                End If                   
              Else  ' This should not happen (negative kin. energy of alpha particle)
                Spin_CN = Spin_target
              End If            
              Eabsgs = P_E_exc * ((P_A_CN-4) / P_A_CN) + AME2020(P_Z_CN-2,P_A_CN-4) - AME2020(P_Z_CN,P_A_CN) - 28.295
                                                         '           target                      CN
              If Eabsgs < 0 Then
                Print "<S> Alpha energy is too low. (E* of compound nucleus would be negativ.)"
                Print "    Press Enter key to leave GEF!"
                Sleep
                End
              End If
            Case 3  ' Energy values are set later (label Energy_loop:)
            Case 13 ' Energy values are set before the pre-equilibrium calculation
          End Select
          If Bfilein = 0 Then
            Print "Excitation energy above ground state: ";Eabsgs;" MeV"
            Print "Angular momentum: ";Spin_CN
            Print
          End If
          If Eabsgs > 100 Then
            If Bfilein Then
            Else
              If Eabsgs > 120 Then
                Print " "
                Print "*****************************************************************"
                Print "<E> Energy of CN > 120 MeV is not supported."
                Print "    Result may not be reliable and numerical problems may appear!"
                Print "*****************************************************************"
                Print " "
     '          Goto RepeatInput
              Else
                Print " "
                Print "**********************************************************************"
                Print "<W> Energy of CN beyond validity limit of 100 MeV. Result is doubtful." 
                Print "**********************************************************************"
                Print " "
              End If  
            End If
          End If
          If Eabsgs < 0 Then
            Print "<E> Input energy of the fissioning nucleus is below the ground state."
            Print "    Press Enter key to leave GEF!"
            Sleep
            End
          End If  
    
          Print " "
        ' Print "Calculation started at ";time
          Print " "
          Print "Please wait ... code is running."
          Print " "
    
      /'  *** Erase spectra of gammas and nucleons from CN here *** '/
      /'  They must be erased before the calculation of multi-chance fission, 
          because they are filled in that section. 
          (The other spectra are erased after the multi-chance block and before 
          the fission loop in CLEARspectra.bas.) 
          This is particularly important for the calculation with perturbed parameters,
          which loops only over the fission part and uses the same multi-chance results. '/
         
          For I = Lbound(_EgammaCN,1) To Ubound(_EgammaCN,1)
            _EgammaCN(I) = 0
          Next I 
          For I = Lbound(_EnCN,1) To Ubound(_EnCN,1)
            _EnCN(I) = 0
          Next I 
          For I = Lbound(_EpCN,1) To Ubound(_EpCN,1)
            _EpCN(I) = 0
          Next I   
          For I = Lbound(d_NCN,1) To Ubound(d_NCN,1)
            d_NCN(I) = 0
          Next I  
          For I = Lbound(NNCNtot,1) To Ubound(NNCNtot,1)
            NNCNtot(I) = 0
          Next I
          For I = Lbound(NPCNtot,1) To Ubound(NPCNtot,1)
            NPCNtot(I) = 0
          Next I
    
    
       /'*** Multi-chance fission ***'/
       
       '  Arrays for preliminary storage of pre-saddle emission:
    
          ReDim E_multi_chance(10,10,1000) As Single 
          Dim As Integer Emax_multi_chance 
          Dim As Integer Nmax_multi_chance
          Dim As Integer Pmax_multi_chance
          Dim As Integer Inofirst = 0      ' counts events > first-chance fission
          Dim As Longint Imulti = 0        ' counts the number of multi-chance fission events
          Dim As Integer Bmulti = 0        ' multi-chance possible
          Dim As Longint N_multi_sample 
          If Fenhance = 0 Then Fenhance = 1
     '    If B_Nosort Then
     '      N_multi_sample = 1
     '    Else   
          N_multi_sample = sqr(Fenhance) * Ten_to_five  ' number of events for pre-fission calculation
     '    End If  
      '   N_multi_sample = Ten_to_five 
          ReDim As Single W_chances(10,10)  ' neutron loss, proton loss
          ReDim As ULongint En_multi_1(0)   ' neutron energy for second-chance fission (100 keV bins)
          ReDim As ULongint En_multi_2(0)   ' neutron energy for third-chance fission (100 keV bins)
          ReDim As ULongint En_multi_3(0)   ' (neutron energies stored in 10 bits per neutron)
          ReDim As ULongint En_multi_4(0)
          ReDim As Ulongint En_multi_5(0)
          ReDim As Ulongint En_multi_6(0)
          ReDim As Integer J_multi_last(6) 
       
          Redim As UInteger I_emit_1(0)
          Redim As UInteger I_emit_2(0)
          Redim As UInteger I_emit_3(0)
          Redim As UInteger I_emit_4(0)
          Redim As UInteger I_emit_5(0)
          Redim As UInteger I_emit_6(0)
       
          Dim As Single DUF = 0   ' Shell effect at barrier
    
          Bmulti = 0
          If (EMode Mod 10 < 3 And EMode >= 0) Or Emode = 13 Then
            If Emode = 1 Then 
       /' The energy threshold is three MeV below Bf for CM fission for calculation of P_f '/
              Eexc_min_multi = Max(BFTF(P_Z_CN,P_A_CN,5)- 3,1)   
            Else
       /'     Enter only if Eabsgs) > Min(Sn,Bp) + Bf(daughter) - 3 MeV '/
              Eexc_min_multi = Min(AME2020(P_Z_CN,P_A_CN-1) - AME2020(P_Z_CN,P_A_CN) + BFTF(P_Z_CN,P_A_CN-1,1) - 3, _
                                 AME2020(P_Z_CN-1,P_A_CN-1) - AME2020(P_Z_CN,P_A_CN) + _             
                              1.44 * (P_Z_CN-1) / (2.0 * (1 + (P_A_CN-1)^0.333333)) + BFTF(P_Z_CN-1,P_A_CN-1,1) - 3)    
              Eexc_min_multi = Max(Eexc_min_multi,1)                     
    'Print 3282, U_Mass(P_Z_CN,P_A_CN-1) - U_Mass(P_Z_CN,P_A_CN), _ 
    'BFTF(P_Z_CN,P_A_CN-1,1),  _
    'AME2020(P_Z_CN-1,P_A_CN-1) - AME2020(P_Z_CN,P_A_CN), _
    '1.44 * (P_Z_CN-1) / (2.0 * (1 + (P_A_CN-1)^0.333333)), _
    'BFTF(P_Z_CN-1,P_A_CN-1,1), _ 
    'Eexc_min_multi
    'Sleep    
         
            End If  
            IF Eabsgs >= Eexc_min_multi Or Emode = 13 Then  
           ' Emode = 13 (energy distribution from file) must pass 
           ' by the calculation of fission chances, in order
           ' to make a consistent treatment for all events.
    
              Bmulti = 1
              Print "Calculation of fission chances and E*-dependent first-chance fission probability."
         
         /' Determine the weights of the different fission chances '/
         /' and the excitation-energy distributions at fission '/
    '     Print "Competition of neutron emission and fission is determined../"    
    '     Print 
    
              Scope
         
                Dim As Longint I,J,K
         
         ' Multi-chance fission-energy distribution
      '         Redim E_multi_chance(10,10,1000) As Single  ' Chance(n,p), E/100keV
                For I = 0 To 10  ' neutron loss
                  For J = 0 To 10  ' proton loss
                    For K = 0 To 1000  ' energy
                      E_multi_chance(I,J,K) = 0
                    Next  
                  Next
                Next    
                Emax_multi_chance = 0
                Nmax_multi_chance = 0
                Pmax_multi_chance = 0
           
    
                Dim As Integer A_f,Z_f,A_n,Z_n,A_p,Z_p
                Dim As Single T_f,T_f_low,T_f_eff
                Dim As Single T_n,T_n_low,T_n_eff
                Dim As Single T_p,T_p_low,T_p_eff
                Dim As Single T_mean
                Dim As Single Tm
           
    
                Dim As Single SN,SNTF,SNTFnopair,SNmean
                Dim As Single SP,SPTF,SPTFnopair,SPmean,BP,BPnopair,BPmean
                Dim As Single BF,BFLD,BFA,BFB,BFM,GNGF,TF
                Dim As Single BFAeff,BFBeff,BFMeff   ' With correction to fit empirical fission probabilities
                Dim As Single BFNP,BFANP,BFBNP,BFMNP
                Dim As Single SNpre,GNPref,GNpre,GPpre,GNPpre,GNPstat
                Dim As Single Smean
                Dim As Single GAmod,GBmod
                Dim As Single G,GN,GP,GF,GNPtot
                Dim As Single TNPtot
                Dim As Single Ggamma,Gtot,Grandom,Eg
                Dim As Single ypsilon,l_lim_2
                Dim As Single Frot     ' Enhanced fission due to angular momentum
                Dim As Single DUN,DU
                Dim As Single FredF = 1
                Dim As Single FredN = 1
                Dim As Single Tequi 
                Dim As SIngle Pfis,PN,Pgamma
                Dim As Single Etest,E_left,A_left,Z_left,E_left_pre
                Dim As Single A_loss,Z_loss,N_loss
                Dim As Single x,y
                Dim As Single Ftunn,FtunnA,FtunnB
                Dim As Single En_kin,Ep_kin
                Redim As ULongInt En_multi_mem(11)   ' 100 keV bins (used for neutrons and protons)
                Redim As Integer EnCN_mem(11)
                Redim As Integer EpCN_mem(11)
                Dim As Uinteger I_emit_mem
                Dim As Single P_precompound
                Dim As Ubyte B_pre  ' pre-equilibrium emission
                Dim As Integer I_pre_last
                Dim As Integer IPcnt,INcnt,IENtry,INPtot,IFIStot
           
                Dim As ULongint Ilong   
           
      '*********************************************************************     
      ' *** This section is just for testing ***
    
      ' Gamma_n and Gamma_f according to the statistical model
      ' using the analytical description of Smirenkin et al.
                Dim As Single Ework
     ' Print "First-chance fission without pre-equilibrium emission"
     ' Print "Aleft,Eleft,Shell,SN,BFld,BFM,SN-BFM,GN,GF,Pfis " 
      
      
     ' Parameters for multi-chance fission 
                Dim As Single GA = 0.41    ' From Sov. J. Nucl. Phys. 32 (1980) 184
                Dim As Single GB = 0.9     ' From Sov. J. Nucl. Phys. 32 (1980) 184
                Dim As Single F1_diss,Red_diss  ' dissipation-related
                Dim As Single dEf = 0.25        ' deviation from CT level density at low E*
                Dim As Single F1_coll  ' coefficient for energy dependence of coll. enhancement
                GA = (0.14 / sqr(pi/2))  ' triaxiality (compared to quadrupole deformation)
                GB = 0.5                 ' mass asymmetry (compared to quadrupole deformation)
                F1_diss = 20    ' increase of dissipation with energy (approx. Svirin Phys. Part. Nuclei 41 (2010) 285)
                F1_coll = 10    ' decrease of collective enhancement (for triaxial shapes at the inner barrier)
'                Dim As Single hbom = 0.9  ' effective curvature of fission barrier
                Dim As Single hbom = 0.8  ' effective curvature of fission barrier, modification by Pf of 239U around barrier (data of B. Jurado, 2025)
                Tequi = hbom /(2 * pi)  ' equivalent temperature parameter
                Dim As Single E100keV
                Dim As Single Tmax,Tfinal
                Dim As Single I_Exciton   ' For distribution of exciton configurations
                Dim As Single rho_CT,rho_FG
                Dim As Single af_an
                Dim As Single Ztrans = 86.0   ' used for paramatrization of af/an
                Dim As Single dZtrans = 2     ' "
                Dim As Double rho_CN,rho_B,rho_N,rho_N_mean
                Dim As Single Erot_gs,Erot_bf
      
    /'  
    '           Nur zum Testen von U_temp:
                Dim As Single E_test,tau1,tau2,tau3,T1,T2,T3,GN1,GN2,GN3
                Print "Z = 54, A = 140"
                Print "E    T (U_temp)"
                For E_test = 5 To 50 Step 0.1
                  T1 = U_Temp(54,140,E_test-2,1,0,Tscale,Econd)
                  T2 = U_Temp(54,140,E_test,1,0,Tscale,Econd)
                  T3 = U_Temp(54,140,E_test+2,1,0,Tscale,Econd)
                  GN1 = (140)^0.66667 * 0.13 * T1^2 / exp(6/T1)
                  GN2 = (140)^0.66667 * 0.13 * T2^2 / exp(6/T2)
                  GN3 = (140)^0.66667 * 0.13 * T3^2 / exp(6/T3)
                  tau1 = 0.658 / GN1
                  tau2 = 0.658 / GN2  
                  tau3 = 0.658 / GN3  
                  Print E_test,Round((T1*T2*T3)^0.333333,4),Round((GN1*GN2*GN3)^0.333333,4),Round((tau1*tau2*tau3)^0.333333,4)
                Next     
                sleep
     '/
     
    
    /'          Scope
                  Dim As Single E,rho 
    '             For E = 1 To 50 Step 1
    '               Print P_A_CN;" ";E;" ";U_levdens_Egidy(P_Z_CN,P_A_CN, E, 0, 0, 1, 2,1);" ";U_levdens_FG(P_Z_CN,P_A_CN,E,0,0,1,2,1);" ";_
    '               U_levdens_Egidy(P_Z_CN,P_A_CN, E,0, 0, 1, 2,1)/U_levdens_FG(P_Z_CN,P_A_CN,E,0,0,1,2,1)
    '             Next E
                  Print "************************"
                  For E = 1 To 50 Step 1
                    Print P_Z_CN; P_A_CN;" ";E;" ";U_levdens_Egidy(P_Z_CN,P_A_CN, E, 1, 1, 1, 2,1);" ";U_levdens_FG(P_Z_CN,P_A_CN,E,1,1,1,2,1);" ";_
                    U_levdens_Egidy(P_Z_CN,P_A_CN, E,1, 1, 1, 2,1)/U_levdens_FG(P_Z_CN,P_A_CN,E,1,1,1,2,1)
                  Next E
                End Scope
                Sleep '/     
    
    /'
                Scope
                  Dim As Single E,rho
                    For E = 4 To 20 Step 0.1
                    Print P_A_CN;" ";E;" ";U_levdens(P_Z_CN,P_A_CN, E, 1, 1, 1, 2,1);" ";U_levdens(P_Z_CN,P_A_CN,E,0,1,1,2,1);" ";_
                    U_levdens(P_Z_CN,P_A_CN, E,1, 1, 1, 2,1)/U_levdens(P_Z_CN,P_A_CN,E,0,1,1,2,1)
                  Next E
                End Scope
                Sleep 
    '/ 
     
     /'
                Scope
                  Dim AS Integer A,N,Z
                  N = 136
                  For Z = 88 To 94
                    A = N + Z
                    Print Z,A,U_Shell_exp(Z,A),U_Shell_EO_exp(Z,A)
                  Next Z
                  sleep
                End Scope 
     '/
     
     /'         Scope
                  Dim As Single E
                  Print "E/MeV    T/MeV"
                  For E = 1 To 30
                    Print E, U_Temp(54,140,E,1,1,Tscale,Econd)
                  Next E
                  Sleep
                End Scope '/ 
    
     ' This section is for calculating the first-chance fission probablity for a large
     ' range of excitation energy with an analytical function.
     ' In contrast to the Monte-Carlo method, used for the "normal" calculation,
     ' this works also for very low fission probabilities.
                If Bfilein = 0 Then  ' Not in batch mode
                  Scope
                    Dim As Single Ltest  ' angular momentum of compound nucleus
                    Dim As Single Ptest  ' probability value of L distribution
                    Dim As Single Pfistot,PNtot,Pgammatot,Ptot
                    Dim As Single FcollA, EcollA, FcollB, EcollB
                    f = freefile
                    C_pfis = "tmp\"+Cfileout+".pfis"
                    Open "tmp\"+Cfileout+".pfis" For Append As #f 
        '           Print #f,"<?xml version=""1.0"" encoding=""ISO-8859-1""?>"
        '           Print #f,"<pfis>"
                    Print #f, "Calculation of fission probability for first-chance fission"
                    Print #f, "* as a function of excitation energy"
                    Rdatetime = Now
                    Print #f,"**************************************************"
                    Print #f,"* Output written on ";
                    Print #f, Format( Rdatetime, "dd.mm.yyyy, hh:mm:ss")
                    Print #f, Using "& ### & ###";"* Calculation for the nucleus Z = ";P_Z_CN;", A = ";P_A_CN  
                    Print #f,"* Spin =";Spin_CN
                    Print #f,"**************************************************"
                    Print #f, "* Z_left    A_left     E_left   I_left   GN     GP     GF     Ggamma    Pfis    PN    Pgamma  af/an  Red_diss  GAmod  GBmod" 
                    Print #f, "X: EC$N$ / MeV"
                    Print #f, "Y: Pf$i$s$"
                    Print #f, "H:  N   N   X    N   N   N   N   N  Y(Pfis),LTB1   Y(PN),LT1  Y(Pgamma),LTR1  N    N   N    N"
                    For Ework = 3 To 80 Step 0.1
                      Ltest = Spin_CN
                      E_left = Ework
                      #Include "Pfistest.mac"
                      Print #f, Z_left;" ";A_left;" ";E_left;" ";Spin_CN;" "; _
                         GN;" ";GP;" ";GF;" ";Ggamma;" ";Pfis;" ";PN;" ";Pgamma;" ";af_an;"  ";Red_diss;" ";GAmod;" ";GBmod
                    Next Ework
     '              Print #f, "</pfis>"
                    Print #f, " "
                    Close #f
                    If Spin_CN > 0 Then
                      f = freefile
                      C_pfis2 = "tmp\"+Cfileout+".pfis2"                     
                      Open "tmp\"+Cfileout+".pfis2" For Append As #f 
        '             Print #f,"<?xml version=""1.0"" encoding=""ISO-8859-1""?>"
        '             Print #f,"<pfis>"
                      Print #f, "Calculation of fission probability for first-chance fission"
                      Print #f, "* as a function of excitation energy"
                      Rdatetime = Now
                      Print #f,"**************************************************"
                      Print #f,"* Output written on ";
                      Print #f, Format( Rdatetime, "dd.mm.yyyy, hh:mm:ss")
                      Print #f, Using "& ### & ###";"* Calculation for the nucleus Z = ";P_Z_CN;", A = ";P_A_CN  
                      Print #f,"* Statistical spin distributions with L_rms =";Spin_CN
                      Print #f,"**************************************************"
                      Print #f, "* Z_left    A_left     E_left   Pfis    PN    Pgamma" 
                      Print #f, "X: EC$N$ / MeV"
                      Print #f, "Y: Probabilities"
                      Print #f, "H:  N   N   X    Y(Pfis),LTB1   Y(PN),LT1  Y(Pgamma),LTR1"
                      For Ework = 3 To 80 Step 0.1
                        Pfistot = 0
                        PNtot = 0
                        Pgammatot = 0
                        For Ltest = 0 To 2.0 * Spin_CN
                          Ptest = (2 * Ltest + 1) * exp(- Ltest * (Ltest + 1)/Spin_CN^2)
                          E_left = Ework
                          Z_left = P_Z_CN
                          #Include "Pfistest.mac"
        '                 Print #f, Z_left;" ";A_left;" ";E_left;" ";Ltest;" "; _
        '                  GN;" ";GP;" ";GF;" ";Ggamma;" ";Pfis;" ";PN;" ";Pgamma;" ";af_an;"  ";Red_diss;" ";GAmod;" ";GBmod
                          Pfistot = Pfistot + Pfis * Ptest
                          PNtot = PNtot + PN * Ptest
                          Pgammatot = Pgammatot + Pgamma * Ptest
                        Next Ltest
                        Ptot = Pfistot + PNtot + Pgammatot
                        Print #f, Z_left;" ";A_left;" ";E_left;" ";Pfistot/Ptot;" ";PNtot/Ptot;" ";Pgammatot/Ptot    
                      Next Ework
     '                Print #f, "</pfis>"
                      Print #f, " "
                      Close #f
                    End If
                  End Scope
                End If 'If Bfilein = 0 
     
    
      '*********************************************************************     
    
      /'        For I = Lbound(_EgammaCN,1) To Ubound(_EgammaCN,1)
                  _EgammaCN(I) = 0
                Next I 
                For I = Lbound(EnCN,1) To Ubound(EnCN,1)
                  EnCN(I) = 0
                Next I 
                For I = Lbound(EpCN,1) To Ubound(EpCN,1)
                  EpCN(I) = 0
                Next I  '/
           
           ' Multi-chance fission
           ' Extended formalism based on 
           ' V. M. Kupriyanov, K. K. Istekov, B. I. Fursov, G. N. Smirenkin
           ' Sov. J. Nucl. Phys. 32 (1980) 184
                K = 0
           
                Do Until Imulti >= N_multi_sample 
                  IFIStot = 0  ' default: no fission
                  If Emode = 13 Then   ' Dice energy from energy distribution from file
    Dice_I_Estep:   
                    I_Estep = Rnd * Ichannel    ' guess channel of input energy distribution    
                    If I_Estep < 1 Then Goto Dice_I_Estep 
                    If Rnd < W_spectrum(I_Estep) / W_spectrum_max Then ' guess value confirmed
                      Eabsgs = E_spectrum(I_Estep)
                      Spin_CN = L_spectrum(I_Estep)
                    Else
                      Goto Dice_I_Estep ' dice again
                    End If  
                    NE_all(I_Estep) = NE_all(I_Estep) + 1 ' Monte-Carlo distribution, representing W_spectrum of input file
                  End If  
           
                  E_left = Eabsgs
                  A_left = P_A_CN
                  Z_left = P_Z_CN
             
                  Eg = 0
                  I_emit_mem = 0  
                  I_pre_last = 0
                  B_pre = 1   ' Allow pre-compound fission
                  For I = 0 To 10
    Aftergamma:   
                    If E_left < 0.1 Then Exit For
                    Z_loss = P_Z_CN - Z_left
                    A_loss = P_A_CN - A_left
                    N_loss = A_loss - Z_loss
                    Erot_gs = Spin_CN*(Spin_CN+1)/(2*U_Ired(Z_left,A_left))
     '              Erot_bf = Spin_CN*(Spin_CN+1)/(2*U_Ired(Z_left,A_left)*1.25)  ' corresponds to l_lim = 15 for 236U
                    Erot_bf = Erot_gs * Min(2.20475 , (3.94324 - 1.73237 * log(Z_left^2/A_left) / log(10) ))
             '      (formula based on 
             '         factor = 1 for Z^2/A = 50 (no mocroscopic fission barrier),
             '         factor = 1.25 for 236U and 
             '         factor = 2.20475 (touching spheres) for light nuclei)
                    Erot_bf = Max(Erot_bf,1.1 * Erot_gs)
             '         for shell effects
                    SN = AME2020(Z_left,A_left-1) - AME2020(Z_left,A_left)                     
                    SNTF = U_Mass(Z_left,A_left-1) + Lypair(Z_left,A_left-1) _
                           - (U_Mass(Z_left,A_left) + Lypair(Z_left,A_left))
                    SNTFnopair = U_Mass(Z_left,A_left-1) - U_Mass(Z_left,A_left) 
                    SNmean = 0.5E0 * (U_Mass(Z_left,A_left-2) - U_Mass(Z_Left,A_left))
                    SP = AME2020(Z_left-1,A_left-1) - AME2020(Z_Left,A_left)  
                    BP = SP + 1.44 * (Z_left-1) / (2.0 * (1 + (A_left-1)^0.333333))  
                    SPTF =  U_Mass(Z_left-1,A_left-1) + Lypair(Z_left-1,A_left-1) _
                            - (U_Mass(Z_left,A_left) + Lypair(Z_left,A_left))
                    SPTFnopair = U_Mass(Z_left-1,A_left-1) - U_Mass(Z_left,A_left)
                    BPnopair = SPTFnopair + _ 
                       1.44 * (Z_left-1) / (2.0 * (1 + (A_left-1)^0.333333))  
                    SPmean = 0.5E0 * (U_Mass(Z_left-2,A_left-2) - U_Mass(Z_Left,A_left))
                    BPmean = SPmean + _
                       1.44 * (Z_left-1) / (2.0 * (1 + (A_left-1)^0.333333))  
                    BF = BFTF(Z_left,A_left,1) 
                    BFNP = BFTF(Z_left,A_left,3) 
      '             BFLD = BFTF(Z_left,A_left,0) 
      '             BFA = BFTFA(Z_left,A_left,1)
                    BFA = BFTFA(P_Z_CN,A_left,1) + 1 / sqr(A_left) * ( (A_left-P_Z_CN + 1) Mod 2 ) 
                              ' e-o in levdens at Bf
                    BFANP = BFTFA(Z_left,A_left,3)
      '             BFB = BFTFB(Z_left,A_left,1)  
                    BFB = BFTFB(P_Z_CN,A_left,1) + 1 / sqr(A_left) * ( (A_left-P_Z_CN + 1) Mod 2 )  
                              ' e-o-in levdens at Bf
                    BFBNP = BFTFB(Z_left,A_left,3)
                    BFM = Max(BFA,BFB)        
                    BFMNP = Max(BFANP,BFBNP)
                    af_an = 1.2 - 0.2 * Gaussintegral(P_Z_CN - Ztrans, dZtrans)
                    DUN = U_SHELL(Z_left,A_left-1) 
                    DU = U_SHELL(Z_left,A_left) 
                    Rho_cn = U_levdens(Z_left,A_left,E_left-Erot_gs,1,1,Tscale,Econd,Etrans,1)
                    If E_left > SN + Erot_gs Then
                      T_n = U_Temp(Z_left,A_left-1,E_left-SN-Erot_gs,1,1,Tscale,Econd,Etrans)
                      GN = (A_left-1)^0.66667 * 0.13 * T_n^2 * _   
                         U_levdens(Z_left,A_left-1,E_left-Sn-Erot_gs,1,1,Tscale,Econd,Etrans,1) / Rho_cn
                    Else
                      GN = 0 
                    End If
               
           '        GN = GN * Min((E_left-SN-Erot_gs)/0.5,1.0) ' deviation from const. temp. level density
           '           not applied, because the data are assumed to be modified by finite energy resolution
               
                    If Z Mod 2 = 0 And (A_left - 1 - Z_left) Mod 2 = 0 Then   ' even-even daughter after neutron emission
                      If E_left-SN-Erot_gs < 2 * 12.0/sqr(A_left-1) Then   ' suppression motivated by E_n spectra 235U(n,f), Taieb 2024
                        GN = 0      
                      End If 
                    Else
                      If Z Mod 1 = 0 Or (A_left - 1 - Z_left) Mod 2 = 0 Then
                        If E_left-SN-Erot_gs < 12.0/sqr(A_left-1) Then
                          GN = 0
                        End If  
                      End If  
                    End If   
               
                    If E_left > BP + Erot_gs Then
                      T_p = U_Temp(Z_Left-1,A_Left-1,E_Left-BP-Erot_gs,1,1,Tscale,Econd,Etrans)
                      GP = (A_left-1)^0.666667 * 0.13 * T_p^2 * _
                             U_levdens(Z_left-1,A_left-1,E_left-BP-Erot_gs,1,1,Tscale,Econd,Etrans,1) / Rho_cn 
                    Else 
                      GP = 0  
                    End If      
                   
                    GNPstat = GN + GP
    
     '   Print "Imulti,I,A_left,Z_left,E_left",Imulti;" ";I;" ";A_left;" ";Z_left,E_left         
    
                    GNPpre = 0
                    If (Emode = 2 Or Emode = 12) And B_pre = 1 And GNPstat > 0 Then  ' (n,f) or (p,f), starting with first-chance fission
                      If E_left - Sn > 2.0 Then
                        GNPpre = GNPstat * (E_left - 1.3E0) / 38.E0   'pre-equilibrium emission
                        GNPpre = GNPpre * (E_left - Sn - 2.0) / (E_left-Sn) ' to avoid a discontinuity
                   ' for neutron-induced fission
                   ' from Ignatyuk et al. Sov. J. Nucl. Phys. 47 (1988) 224
        '               GNPpre = GNPstat * (E_left - 2.E0) / 30.E0   'zum Testen
                        GNPpre = Max(0,GNPpre)
                      End If  
                    End If  
                    GNPtot = GNPpre + GNPstat 
                    If GNPtot > 0 Then 
                      P_precompound = GNPpre / GNPtot   ' Probability for pre-compound emission
                    Else
                      P_precompound = 0
                      B_pre = 0
                    End If    
'         Print GNPtot            
'         TNPtot = 0.658/GNPtot
'         PRINT 4337, "E* =";E_left, "TNPtot = ";TNPtot;" zs"
'         Print TNPtot = 0.658/GNPtot
'   sleep           
     '   Print "GNPpre,GNPstat,GNPtot",GNPpre,GNPstat,GNPtot       
     '   Print "B_pre,P_precompound",B_pre,P_precompound
               
                    Dim As Single FcollA,EcollA,FcollB,EcollB
                    EcollA = E_left - BFANP - Erot_bf
                    If EcollA < 0 Then EcollA = 0
                    FcollA = GA / (1 - (1 - GA) * exp(-EcollA/F1_coll))  ' energy dependence of coll. enh.
                    FtunnA = 1/(1+exp(-(E_left-BFA-Erot_bf)/Tequi))   
                    GAmod = GA / (FtunnA * FcollA)
                    EcollB = E_left - BFBNP - Erot_bf
                    If EcollB < 0 Then EcollB = 0
                    FcollB = GB / (1 - (1 - GB) * exp(-EcollB/F1_coll))  ' energy dependence of coll. enh.
                    FtunnB = 1/(1+exp(-(E_left-BFB-Erot_bf)/Tequi))  
                    GBmod = GB / (FtunnB * FcollB)
                    T_f = U_Temp2(Z_left,A_left,E_left-BFMNP-Erot_bf,DUF,0,Tscale,Econd,Etrans)
                    G = GAmod * exp((BFANP-BFMNP)/T_f) + GBmod * exp((BFBNP-BFMNP)/T_f) 
                    ypsilon = 1.0 - P_Z_CN^2 / (A_left * 50.0)  ' 1 - fissility
                    ypsilon = max(ypsilon,0.1)   ' limitation for very heavy nuclei
                    l_lim_2 = 15.0^2 / (ypsilon/0.28) * T_f / TEgidy(P_A_CN,DUF,1.0)  ' Hasse & Myers
     '              Frot = exp( Spin_CN^2/l_lim_2 )  ' enhancement of GF by angular momentum
                    Frot = 1  ' Frot durch Erot_bf ersetzt!
                    GF = T_f / G * U_levdens(Z_left,A_left,E_left-BFMNP-Erot_bf,0,0,Tscale,Econd,Etrans,af_an) / Rho_cn * Frot
'                    Red_diss = exp(-(E_left - BFMNP - Erot_bf)/(F1_diss))
      Red_diss = exp(-(E_left - BFMNP - Erot_bf-10)/(F1_diss))
                    Red_diss = Min(Red_diss,1)
'   Red_diss = 1
                    GF = GF * Red_diss 
               
               
                    If Z_left Mod 2 = 0 And (A_left - Z_left) Mod 2 = 0 Then
                      If E_left - BFM < 2 * 12 / sqr(A_left) And _
                        E_left - BFM > 0 Then
                        GF = GF * ( 0.1 + 0.9 *(E_left - BFM)/ (2 * 12 / sqr(A_left) )) 
                      End If
                      If E_left - BFM <= 0 Then
                        GF = GF * 0.1
                      End If 
                    ElseIF Z_left Mod 2 = 0 Or (A_left - Z_left) Mod 2 = 0 Then  ' reduced lev.-density in e-o and o-e nuclei
                      If E_left - BFM < 2 * 12 / sqr(A_left) Then 
                        If E_left - BFM > 0 Then 
                          GF = GF * ( 0.5 + 0.5 * (E_left - BFM) / (12 / sqr(A_left)) )
                        Else
                          GF = GF * 0.5
                        End If  
                      End If   
                    End If   
    
                    Tm = U_temp(Z_left,A_left,E_left-Erot_gs,1,0,Tscale,Econd,Etrans)       ' emitting nucleus 
                    Ggamma = 0.624 * A_left^1.6 * Tm^5    ' in meV (Ignatyuk, Bologna)
                    Ggamma = Ggamma * 1.E-9        ' in MeV
    
       '            A way to switch off the gammas: (Ggamma = 0 does not work!)
       '            If Ggamma/(GF + GNPtot) < 0.5 Then Ggamma = 0
    
                    Gtot = GF + GNPtot + Ggamma
               
                    Grandom = Rnd * Gtot
                    If Grandom < Ggamma Then   ' gamma decay, no other decay any more
                 '    Provisional treatment: 
                 '    One gamma per reaction accumulated.
                 '    (Justification: Probability for gamma emission is small.
                 '    It would change the observables of fission
                 '    and particle emission only little. 
                      Pfis = GF / (GF + GNPtot + Ggamma)
                      Eg = P_Egamma_high(Z_left,A_left,E_left)   
      '  Print "        Gamma decay, Eleft, Pgamma, Eg =";E_left,Ggamma/Gtot,Eg       
                      E_left = E_left - Eg
                      If Pfis < 0.01 Then Exit For ' For I = 0 To 10; later fission is very unprobable
                      Pfis = 0
                      Goto Aftergamma
                    Else 
                      Pfis = GF / (GF + GNPtot + Ggamma)
' Pfis = GF / (GF + GNPtot)                     
                    End if   
               
                
    '               If Z_loss = 0 Then
     '                Print A_loss;" ";E_left;" "; GN ;" "; GP ; " "; GNPpre;" "; Gtot;" ";GF;" ";Pfis    
    '               End If
    '               sleep
    
     '              If J < 10 Then 
     '                Print "Pf (first chance) = ";Round(Pfis,2);", GN/GF = "; _
     '                     ROUND(GN/GF,3);", GN,GF:";ROUND(GN,3);" ";ROUND(GF,3)
     '                Print "Ftunn = ";Round(Ftunn,3);" Eleft = ";E_left;", G = ";G;", E100keV = ";E100keV                 
     '                Print "SN = ";SN;", BFld = ";BFLD;", BF = ";BF;", EA =";BFA;", EB = ";BFB
     '                Print A_left,E_left,Pfis          
     '                J = J + 1
     '              End If                     
    
                    If Rnd <= Pfis Then    ' fission occurs, no more particles emitted before fission
                      Ifistot = 1
     '                Print "   Fission, N_loss *** ";N_loss;" ***"          
     '                Print "Fission, Z_loss, N_loss,I_emit_mem";" ";Z_loss;" ";N_loss;" ";Oct(I_emit_mem)  
     '                Print  
    '                 Print "Fission: Z_loss, N_loss, E_left ";Z_loss;" ";N_loss;" ";E_left     
                      If Emode = 13 Then NE_fis(I_Estep) = NE_fis(I_Estep) + 1 ' for output of Pfis
                      If Eg > 0 Then ' Accumulate pre-saddle gammas
    '                   Print "Fission after gamma decay, Eleft, Eg = ";E_left, Cint(1000*Eg)            
           '            _EgammaCN(Int(1000*Eg)) = _EgammaCN(Int(1000*Eg)) + 1
                        Acc_EgammaCN(Int(1000*Eg),1)
                        Eg = 0
                      End If    
    
                      E100keV = CInt(10*E_left)
                      If N_loss <= Ubound(E_multi_chance,1) And _
                        Z_loss <= Ubound(E_multi_chance,2) And _
                        E100keV <= Ubound(E_multi_chance,3) Then
                        E_multi_chance(N_loss,Z_loss,E100keV) = E_multi_chance(N_loss,Z_loss,E100keV) + 1
                  '     Store the excitation energy at fission
                      End If  
      
                 '    Fill spectra EnCN and EpCN
                      Dim C_test As String
                      For J = 1 To A_loss
                        If J <= Ubound(EnCN_mem,1) Then
                          C_test = Mid(Oct(I_emit_mem),J,1)
                          If C_test = "1" Or C_test = "3" Then   ' Only neutrons
                            Acc_EnCN(EnCN_mem(J),1)
                          End If  
                          If C_test = "2" Or C_test = "4" Then   ' Only protons
                            Acc_EpCN(EpCN_mem(J),1)
                          End If  
                        End If
                      Next J
                               
    '               ' A_loss = number of pre-saddle particles
                      Select Case A_loss
                        Case 1
                          J = Ubound(En_multi_1) + 1
                          Redim Preserve En_multi_1(J)
                          En_multi_1(J) = E100keV _         ' E* at fission
                                      + En_multi_mem(1) * 2^10   ' E_particle pre-saddle
                          Redim Preserve I_emit_1(J)
                          I_emit_1(J) = I_emit_mem 
                        Case 2
                          J = Ubound(En_multi_2) + 1
                          Redim Preserve En_multi_2(J)
                          En_multi_2(J) = E100keV _
                                      + En_multi_mem(1) * 2^10 _
                                      + En_multi_mem(2) * 2^20 
                          Redim Preserve I_emit_2(J)
                          I_emit_2(J) = I_emit_mem 
                        Case 3
                          J = Ubound(En_multi_3) + 1
                          Redim Preserve En_multi_3(J)
                          En_multi_3(J) = E100keV _
                                       + En_multi_mem(1) * 2^10 _
                                       + En_multi_mem(2) * 2^20 _
                                       + En_multi_mem(3) * 2^30
                          Redim Preserve I_emit_3(J)
                          I_emit_3(J) = I_emit_mem 
                        Case 4
                          J = Ubound(En_multi_4) + 1
                          Redim Preserve En_multi_4(J)
                          En_multi_4(J) = E100keV _
                                       + En_multi_mem(1) * 2^10 _
                                       + En_multi_mem(2) * 2^20 _
                                       + En_multi_mem(3) * 2^30 _
                                       + En_multi_mem(4) * 2^40
      '                   Ilong = Fix(En_multi_4(J) * 2^-10)              
                          Redim Preserve I_emit_4(J)
                          I_emit_4(J) = I_emit_mem 
                        Case 5 
                          J = Ubound(En_multi_5) + 1
                          Redim Preserve En_multi_5(J)
                          En_multi_5(J) = E100keV _
                                       + En_multi_mem(1) * 2^10 _
                                       + En_multi_mem(2) * 2^20 _
                                       + En_multi_mem(3) * 2^30 _
                                       + En_multi_mem(4) * 2^40 _
                                       + En_multi_mem(5) * 2^50             
                          Redim Preserve I_emit_5(J)
                          I_emit_5(J) = I_emit_mem 
                        Case 6 
                          J = Ubound(En_multi_6) + 1
                          Redim Preserve En_multi_6(J)
                          En_multi_6(J) = E100keV _
                                       + En_multi_mem(1) * 2^10 _
                                       + En_multi_mem(2) * 2^20 _
                                       + En_multi_mem(3) * 2^30 _
                                       + En_multi_mem(4) * 2^40 _
                                       + En_multi_mem(5) * 2^50 _
                                       + En_multi_mem(6) * 2^58
       '                  Print  En_multi_mem(6), Modulo(Fix(En_multi_6(J)*2^-58),2^8)
                          Redim Preserve I_emit_6(J)
                          I_emit_6(J) = I_emit_mem  
                        Case Else
                      End Select 
                      Imulti = Imulti + 1 ' total number of fission events
                      If N_loss > 0 Or Z_loss > 0 Then
                        Inofirst = Inofirst + 1  ' number of fission events with pre-fission emission
                      End If
                      Exit For  ' For I = 0 To 10
                    Else
     '                Print "   No fission" 
                      INPtot = 0
    Repeat_multi:
                      If P_precompound > 0 Then
                        If RND < P_precompound Then ' pre-equilibrium neutron or proton will be emitted
                          If RND < Z_left / A_left Then  ' pre-equilibrium proton will be emitted
                            I_Exciton = I_pre_last + Int(11.E0*RND)
                            I_pre_last = I_Exciton
                '           Ep_kin = PPower_Griffin_v(I_Exciton+1,E_Left-SP,BP-SP)  ' sample proton kinetic energy
                            Ep_kin = PPower_Griffin_v(I_Exciton+1,E_left-BP,0) - SP + BP
                            If Ep_kin > 0 And Ep_kin > (BP-SP) and E_left - SP - Ep_kin > 0 Then
     '                        Print "Pre-CN: EP = ",Ep_kin   
                              E_left = E_left - SP - Ep_kin
                              Z_left = Z_left - 1
                              A_left = A_left - 1
                              INPtot = Inptot + 1
                              I_emit_mem = I_emit_mem + 2*8^(10-I-1)  ' marks a pre-CN proton
                              EpCN_mem(I+1) = Int(Ep_kin * 1000)
                              En_multi_mem(I+1) = CInt(10*Ep_kin)
                                If En_multi_mem(I+1) > 1023 Then
                                Print "<E> Pre-saddle proton energy > 103 MeV! (p-spectrum overflow.)"
                                En_multi_mem(I+1) = 1023
                              End If                     
                            Else
                              P_precompound = 0
                            End If
                          Else                            ' pre-equilibrium neutron emitted
                            I_Exciton = I_pre_last + Int(11.E0*RND)
                            I_pre_last = I_Exciton
                            En_kin = PPower_Griffin_v(I_Exciton+1,E_left-SN,0)  ' sample neutron kinetic energy
               '            En_kin = PPower_Griffin_v(I_Exciton+1,E_left,0) - SN
                            If En_kin > 0 And E_left - SN - En_kin > 0 Then
      '                       Print "Pre-CN: EN = ",En_kin         
                              E_left = E_left - SN - En_kin
                              A_left = A_left - 1
                              INPtot = Inptot + 1
                              I_emit_mem = I_emit_mem + 1*8^(10-I-1)  ' marks a pre-CN neutron
                              EnCN_mem(I+1) = Int(En_kin * 1000)
                              En_multi_mem(I+1) = CInt(10*En_kin)
                              If En_multi_mem(I+1) > 1023 Then
                                Print "<E> Pre-saddle neutron energy > 103 MeV! (n-spectrum overflow.)"
                                En_multi_mem(I+1) = 1023
                              End If
                            Else
                              P_Precompound = 0
                            End If  
                          End If
                        Else
                          P_Precompound = 0
                        End If      
                      End If
     '                Print "After possible PreCN decay: P_Precompound",P_Precompound            
                      If P_Precompound = 0 Then
                        IPcnt = 0
                        B_pre = 0   ' No pre-equilibrium emission after CN decay
                        If RND < GP / (GN + GP) Then  ' proton evaporation
                          Tmax = U_Temp(Z_left-1,A_left-1,E_left-SP,1,1,Tscale,Econd,Etrans)
    REpkin:   
                          Ep_kin = PMaxwell(Tmax)
                          Tfinal = U_Temp(Z_left-1,A_left-1,E_left-SP-Ep_kin,1,1,Tscale,Econd,Etrans)
                          If E_left-Ep_kin-Tmax > 10.E0 Then  ' Fermi gas regime
                            If RND > sqr(Exp(Ep_kin/Tmax)/Exp(Ep_kin/Tfinal)) Then Goto REpkin
                          End If                 
                          If E_left - SP - Ep_kin > 0 Then
                            IPcnt = 1
         '                  Print "CN: EP = ",EP_kin          
                            E_left = E_left - SP - Ep_kin
                            A_left = A_left - 1
                            Z_left = Z_left - 1
                            INPtot = Inptot + 1
                            I_emit_mem = I_emit_mem + 4*8^(10-I-1)  ' marks a CN proton
                            EpCN_mem(I+1) = Int(Ep_kin * 1000)
           '                If E_left < 0 Then Goto Repeat_multi 
                            En_multi_mem(I+1) = CInt(10*Ep_kin)
                            If En_multi_mem(I+1) > 1023 Then
                              Print "<E> Pre-saddle proton energy > 103 MeV! (p-spectrum overflow.)"
                              En_multi_mem(I+1) = 1023
                            End If
            '             Else Exit For  
                          End If
                        End If  
                        If IPcnt = 0 Then  ' neutron evaporation
                          INcnt = 0
                          Tmax = U_Temp(Z_left,A_left-1,E_left-SN,1,1,Tscale,Econd,Etrans)
                          IENtry = 0
    REnkin:  
                          IENtry = IENtry + 1 
                          En_kin = PMaxwellMod(Tmax,A_left-1)
                          If IENtry <= 10 Then
                            If E_left - SN - En_kin <= 0 Then Goto REnkin
                          End If
                          Tfinal = U_Temp(Z_left,A_left-1,E_left-SN-En_kin,1,1,Tscale,Econd,Etrans)
                          If E_left-En_kin-Tmax > 10.E0 Then  ' Fermi gas regime
                            If RND > sqr(Exp(En_kin/Tmax)/Exp(En_kin/Tfinal)) Then Goto REnkin
                          End If
                          If E_left - SN - En_kin > 0 Then
                            INcnt = 1
       '                    Print "CN: EN = ",En_kin          
                            E_left = E_left - SN - En_kin
                            A_left = A_left - 1
                            INPtot = Inptot + 1
                            I_emit_mem = I_emit_mem + 3*8^(10-I-1)  ' marks a CN neutron
           '                If E_left < 0 Then Goto Repeat_multi 
                            If I+1 <= Ubound(En_multi_mem,1) Then
                              EnCN_mem(I+1) = Int(En_kin * 1000)
                              En_multi_mem(I+1) = CInt(10*En_kin)
                              If En_multi_mem(I+1) > 1023 Then
                                Print "<E> Pre-saddle neutron energy > 103 MeV! (n-spectrum overflow.)"
                                En_multi_mem(I+1) = 1023
                              End If
                            Else
                              Print "<E> Index of En_multi_mem = ";I+1  
                            End If
            '             Else Exit For  
                          End If
                          If INPtot = 0 Then Exit For ' no neutron and no proton emitted
                        End If  
                      End If
                    End If  ' end of "no fission" section
    '               Print "Event finished"
    '               Print           
                  Next I ' For I = 0 To 10 ; go to next CN, check fission and n, p emission
                  ' Comes here when fission has occured, or E* is too low for fission to happen 
                  If IFIStot = 0 Then
                    ' accumulate number of nucleons emitted from first minimum of CN, no fission
                    Z_loss = P_Z_CN - Z_left
                    A_loss = P_A_CN - A_left
                    N_loss = A_loss - Z_loss
                    NNCNtot(N_loss) = NNCNtot(N_loss) + 1
                    NPCNtot(Z_loss) = NPCNtot(Z_loss) + 1
                  End If
                  K = K + 1
                  If K >= N_multi_sample Then ' number of events reached 
                    If Eabsgs > U_Mass(P_Z_CN,P_A_CN-1) - U_Mass(P_Z_CN,P_A_CN) + BFTF(P_Z_CN,P_A_CN-1,1) - 3 Then
                      If Imulti = 0 Then
                        Print " Multi-chance fission cannot be determined due to low fission probability."
                        Print " No fission event found."
                        Print " 100% first-chance fission assumed!"        
                      End If
                      If Imulti > 0 Then           
                        Print " Fission chances deduced from ";Imulti;" fission events."
                        If Imulti < 100 Then
                          Print " Determined fission chances are subject to large statistical uncertainties."
                        End If
                      End If  
                      Print " "
                    End If  
                    Exit Do
                  End If
                Loop  '  Do Until Imulti >= N_multi_sample
                Scope
                  Dim As Double Rnorm_N,Rnorm_P
                  Rnorm_N = 0
                  For J = 0 To Ubound(NNCNtot)
                    Rnorm_N = Rnorm_N + NNCNtot(J)
                  Next J 
                  Rnorm_P = 0 
                  For J = 0 To Ubound(NPCNtot)
                    Rnorm_P = Rnorm_P + NPCNtot(J)
                  Next J 
                  If Rnorm_N > 0 Then 
                    For J = 0 To Ubound(NNCNtot)
                      NNCNtot(J) = NNCNtot(J) / Rnorm_N
                    Next J
                    If NNCNtot(0) < 1 Then 
                      Print
                      Print "Probabilities of the number of neutrons emitted from 1. minimum"
                      Print " (only non-fission events):"
                      Print "Number of neutrons        Probability (values > 0)"
                      For J = 0 To Ubound(NNcntot,1)
                        If NNCNtot(J) > 0 Then
                          Print J, ,Round(NNCNtot(J),3)
                        End If
                      Next J
                      Print
                    End If  
                  End If
                  If Rnorm_P > 0 Then
                    For J = 0 To Ubound(NPCNtot)
                      NPCNtot(J) = NPCNtot(J) / Rnorm_P
                    Next J
                    If NPCNtot(0) < 1 Then
                      Print
                      Print "Probabilities of the number of protons emitted from 1. minimum"
                      Print " (only non-fission events):"
                      Print "Number of protons        Probability (values > 0)"
                      For J = 0 To Ubound(NPcntot,1)
                        If NPCNtot(J) > 0 Then
                          Print J, ,Round(NPCNtot(J),3)
                        End If
                      Next J
                    Print
                    End If
                  End If
                End Scope  
              End Scope
    
    
    
            End If  ' IF Eabsgs > ... (Multi-chance fission)
       
       
       /' Normalize E_multi_chance array to one '/
            For I = 0 To Ubound(W_chances,1)
              For J = 0 To Ubound(W_chances,2)
                W_chances(I,J) = 0
              Next  
            Next
            If Inofirst > 0 Or Emode = 13 Then 
               ' Inofirst is the number of multi-chance fission events (first-chance excluded!)
              For I = 0 To Ubound(E_multi_chance,1)   ' number of pre-saddle neutrons
                For J = 0 To Ubound(E_multi_chance,2)  ' number of pre-saddle protons
                  For K = 0 To Ubound(E_multi_chance,3) ' excitation energy in units of 100 keV
                    If E_multi_chance(I,J,K) > 0 Then
                      E_multi_chance(I,J,K) = E_multi_chance(I,J,K) / Imulti
    '                 E_multi_chance(I,J,K) = E_multi_chance(I,J,K) / Inofirst
                        ' Imulti = total number of fission events in the multi-chance code section
                      W_chances(I,J) = W_chances(I,J) + E_multi_chance(I,J,K)
                    End If
                  Next K 
                Next J
              Next I
              Print "Probabilities of fission chances (pre-saddle neutrons and protons) "
              If Emode = 13 Then
                Print "(Z_CN = ";P_Z_CN;", A_CN = ";P_A_CN;", E distribution from file ";C_Espectrum1;") :"
              Else
                If Emode = 1 Then
                  Print "(Z_CN = ";P_Z_CN;", A_CN = ";P_A_CN;", E = ";P_E_exc;" MeV, Spin = ";Spin_CN;") :"
                Else
                  Print "(Z_CN = ";P_Z_CN;", A_CN = ";P_A_CN;", E = ";P_E_exc;") :"
                End If  
              End If
              Print " neutrons    protons    probability"
              For I = 0 To Ubound(W_chances,1)
                For J = 0 To Ubound(W_chances,2)
                  If W_chances(I,J) > 0 Then
                    Print I,J,Round(W_chances(I,J),3)
                  End If
                Next J 
              Next I 
              Print 
            End If
          End If  ' If Emode < 3 etc.   
    
    
      
    
          B_Error_Analysis = B_Error_On
     
      /' Here the calculation of the fission process starts '/
      
          Chisqr_min = 1.E10        ' initialize for one series of perturbed calculations
                                 ' separately for each system
    calcstart:
      ' Start point of the loop for the error analysis. 
      ' Several calculations with perturbed parameter sets and
      ' finally one calculation with the nominal parameter set are performed.
      
          #include "CLEARspectra.bas" 
          Redim As Longint Mode_Events(10)  ' Reset counter of mode events
    
          If CFileoutlmd <> "" Then  
            foutlmd = freefile
            Open Cfileoutlmd_full For Append As #foutlmd   
       
            Dim As Double Rdatetime
            Rdatetime = Now
            Print #foutlmd,"**************************************************"
            Print #foutlmd,"* Output written on ";
            Print #foutlmd, Format( Rdatetime, "dd.mm.yyyy, hh:mm:ss")
            Print #foutlmd,"* "
            Print #foutlmd, Using "& ### & ###";"* Calculation for the nucleus Ztot = ";P_Z_CN;", Atot = ";P_A_CN
           
            Select Case Emode
              Case 0
                Print #foutlmd,"* at E* = ";P_E_exc;" MeV above the outer saddle"
                Print #foutlmd,"*   (E* = ";Eabsgs;" MeV above the ground state)."
                Print #foutlmd,"* Spin = ";Spin_CN
              Case 1
                Print #foutlmd,"* at E* = ";P_E_exc;" MeV above the ground state."
                Print #foutlmd,"* Spin = ";Spin_CN
              Case -1
                Print #foutlmd,"* at E* = ";P_E_exc;" MeV above the ground state."
                Print #foutlmd,"* Spin = ";Spin_CN
                Print #foutlmd,"* Only first-chance fission!"
              Case 2
                Print #foutlmd,"* formed by (n,f) with En = ";P_E_exc- E_EXC_ISO;" MeV."
                Print #foutlmd,"* Spin of target nucleus = ";Spin_target
              Case 12
                Print #foutlmd,"* formed by (p,f) with Ep = ";P_E_exc- E_EXC_ISO;" MeV."
                Print #foutlmd,"* Spin of target nucleus = ";Spin_target           
              Case 22
                Print #foutlmd,"* formed by (alpha,f) with Ealpha = ";P_E_exc- E_EXC_ISO;" MeV."
                Print #foutlmd,"* Spin of target nucleus = ";Spin_target           
              Case 3
                Print #foutlmd,"* with user-defined excitation-energy distribution"
                Print #f," from the file ";C_Espectrum;"."
                Print #foutlmd,"* Only first-chance fission."
                Print #foutlmd,"*","  E* (MeV)      Spin        Weight"
                For I = 1 To Ubound(E_spectrum)
                  Print #foutlmd,"*", E_spectrum(I), L_spectrum(I), W_spectrum(I)
                Next I
              Case 13
                Print #foutlmd,"* with user-defined excitation-energy distribution"
                Print #f," from the file ";C_Espectrum;"."
                Print #foutlmd,"*","  E* (MeV)      Spin        Weight"
                For I = 1 To Ubound(E_spectrum)
                  Print #foutlmd, E_spectrum(I), L_spectrum(I), W_spectrum(I)
                Next I
                Print #foutlmd,"* Multi-chance fission supported."
            End Select
            If I_E_iso > 0 Then
              Print #foutlmd, "* Isomer # ";I_E_iso;", at E* = ";E_EXC_ISO;" MeV" 
            End If    
            If EOscale <> 1 Then
              Print #foutlmd, "* Even-odd effect at scission scaled with a factor ";Eoscale;"."
            End If
            Print #foutlmd,"*"      
    
            If B_Error_Analysis = 1 Then
              If Brec Then 
                Print #foutlmd,"* Calculation with perturbed model parameters"
                Print #foutlmd,"* Perturbed parameter set #"+Str(I_Error+1)
              End If
            End If
            If B_Error_Analysis = 0 Then
              Print #foutlmd,"* Calculation with nominal model parameters"
            End If
            Print #foutlmd,"*"
          End If   ' If CFileoutlmd <> "" 
       
          If CFileoutlmd <> "" Then
            Print #foutlmd,"* ";
            Print #foutlmd,"Mode ";
            Print #foutlmd,"Zsad ";
            Print #foutlmd,"Asad ";
            Print #foutlmd,"Qvalue ";
            If PZ1 = 1 Then Print #foutlmd,"Z1 ";
            If PZ2 = 1 Then Print #foutlmd,"Z2 ";
            If PA1pre = 1 Then Print #foutlmd,"A1sci ";
            If PA2pre = 1 Then Print #foutlmd,"A2sci ";
            If PA1post = 1 Then Print #foutlmd,"A1post ";
            If PA2post = 1 Then Print #foutlmd,"A2post ";
            If PI1 = 1 Then Print #foutlmd,"I1pre ";
            If PI2 = 1 Then Print #foutlmd,"I2pre ";
            If PI1 = 1 Then Print #foutlmd,"I1gs ";
            If PI2 = 1 Then Print #foutlmd,"I2gs ";
            If Pdir = 1 Then print #foutlmd,"Elab1pre cos(theta1) phi1 Elab2pre cos(theta2) phi2 "; 
            If PXE = 1 And PXEdetails = 0 Then Print #foutlmd,"Eexc1 Eexc2 ";
            If PXE = 1 And PXEdetails = 1 Then 
              Print #foutlmd,"Eexc1 Erot1 Eintr1 Edef1 ";
              Print #foutlmd,"Eexc2 Erot2 Eintr2 Edef2 ";
            End If
            If PXE = 0 And PXEdetails = 1 Then
              Print #foutlmd,"Erot1 Eintr1 Edef1 ";
              Print #foutlmd,"Erot2 Eintr2 Edef2 ";
            End If
            If Pn1 = 1 Then Print #foutlmd,"n1 ";
            If Pn2 = 1 Then Print #foutlmd,"n2 ";
            If PTKEpre = 1 Then Print #foutlmd,"TKEpre ";
            If PTKEpost = 1 Then Print #foutlmd,"TKEpost ";
            If PnCN = 1 /' And Inofirst > 0 '/ Then 
              Print #foutlmd,"E@fission ";
              Print #foutlmd,"particle-list E1 cos(theta1) phi1 E2 cos(theta2) phi2 E3 cos(theta3) phi3 E4 ... "
            End If  
            If PZ1 + PZ2 + PA1pre + PA2pre + PA1post + PA2post + PI1 + PI2 + Pdir +_
               PXE + PXEdetails + Pn1 + Pn2 + PTKEpre + PTKEpost + PnCN + PENpost + PEGpost = 0 Then
              Print "<E> No listmode data defined to be written to file ";Cfileoutlmd;"."
              #ifdef __FB_WIN32__
                Print "    Please fill in the appropriate mask of the GUI!"
              #endif
              Print "    Press Enter key to leave GEF!"
              Sleep
              End
            End If
            Print #foutlmd," "
            Print #foutlmd,"* Mode: Fission mode (0:super-long, 1-3 Standard Brosa modes, >3: see Readme file"
            Print #foutlmd,"* Zsad: Number of protons at saddle (Zsad < Ztot in case of pre-saddle proton emission)"
            Print #foutlmd,"* Asad: Number of nucleons at saddle (Asad < Atot in case of pre-saddle nucleon emission)"
            Print #foutlmd,"* Qvalue [MeV], (ground state of CN(Zsad,Asad) -> 2 fragments with Z1sad, A1sad, Z2sad, A2sad)"
            If PZ1 = 1 Then Print #foutlmd,"* Z1: Atomic number of first fragment at scission"
            If PZ2 = 1 Then Print #foutlmd,"* Z2: Atomic number of second fragment at scission"
            If PA1pre = 1 Then Print #foutlmd,"* A1sci: Pre-neutron mass number of first fragment at scission"
            If PA2pre = 1 Then Print #foutlmd,"* A2sci: Pre-neutron mass number of second fragment at scission"
            If PA1pre + PA2pre > 0 Then Print #foutlmd,"* (A1sci + A2sci < Asad in case of neutron emission between saddle and scission)"
            If PA1post = 1 Then Print #foutlmd,"* A1post: Post-neutron mass number of first fragment"
            If PA2post = 1 Then Print #foutlmd,"* A2post: Post-neutron mass number of second fragment"
            If PI1 = 1 Then Print #foutlmd,"* I1pre: Spin of first fragment after scission"
            If PI2 = 1 Then Print #foutlmd,"* I2pre: Spin of second fragment after scission"
            If PI1 = 1 Then Print #foutlmd,"* I1gs: Ground-state spin of first fragment"
            If PI2 = 1 Then Print #foutlmd,"* I2gs: Ground-state spin of second fragment"
            If Pdir = 1 Then 
              Print #foutlmd,"* Elab1pre, Elab2pre: fragment kinetic energy in lab before prompt-neutron emission from fragments"
              Print #foutlmd,"* cos(theta1), phi1: Direction of first fragment in lab"
              Print #foutlmd,"* cos(theta2), phi2: Direction of second fragment in lab"
              IF Emode = 2 Then Print #foutlmd,"* (Direction of incident neutron: theta = 0, phi = 0)"
              IF Emode = 12 Then Print #foutlmd,"* (Direction of incident proton: theta = 0, phi = 0)"
              IF Emode = 22 Then Print #foutlmd,"* (Direction of incident alpha: theta = 0, phi = 0)"
            End If 
            If PXE = 1 Then Print #foutlmd,"* Eexc1: Excitation energy of first fragment [MeV] well after scission, before emission of prompt neutrons and gammas"
            If PXEdetails = 1 Then
              Print #foutlmd, "* Erot1: Rotational energy of first fragment [MeV]"
              Print #foutlmd, "* Eintr1: Intrinsic energy of first fragment [MeV] at scission"
              Print #foutlmd, "* Edef1: Deformation energy of 1st fragment, converted into intrinsic energy after scission [MeV]"
            End If
            If PXE = 1 Then Print #foutlmd,"* Eexc2: Excitation energy of second fragment [MeV] well after scission, before emission of prompt neutrons and gammas"
            If PXEdetails = 1 Then
              Print #foutlmd, "* Erot2: Rotational energy of second fragment [MeV]"
              Print #foutlmd, "* Eintr2: Intrinsic energy of second fragment [MeV] at scission"
              Print #foutlmd, "* Edef2: Deformation energy of 2nd fragment, converted into intrinsic energy after scission [MeV]"
            End If
            If PXE = 1 Then 
              If PXEdetails = 1 Then
                Print #foutlmd,"* (Eintr and Eexc do not include the energy consumed by evtl. pre-scission n-emission.)"
                Print #foutlmd,"* (Note that Erot, Eintr and Edef do not add up to Eexc due to vibrational excitations, which are not explicitly listed.)"
              End If
            End If
            If Pn1 = 1 Then Print #foutlmd,"* n1: Prompt neutrons emitted from first fragment"
            If Pn2 = 1 Then Print #foutlmd,"* n2: Prompt neutrons emitted from second fragment"
            If PTKEpre = 1 Then Print #foutlmd,"* TKEpre: Pre-neutron total kinetic energy [MeV] (in frame of fissioning nucleus)"
            If PTKEpost = 1 Then Print #foutlmd,"* TKEpost: Post-neutron total kinetic energy [MeV] (in frame of fissioning nucleus)"
            If PnCN = 1 /' And Inofirst > 0 '/ Then 
              Print #foutlmd,"* E@fission: Excitation energy at fission [MeV]"
              Print #foutlmd,"* Particle list:"        
              Print #foutlmd,"* The particle list shows the sequence of pre-scission emission ,(if any). It is padded with zeroes."
              Print #foutlmd,"* Key number for kind of pre-scission particles (1,3,5: neutrons, 2,4: protons; 1,2: pre-compound, 3,4: compound emission), 5: emission btw. saddle and scission"
              Print #foutlmd,"* E1, cos(theta1), phi1, E2, cos(theta2), phi2, E3,  ...: kinetic energies [MeV] and angles of pre-fission particles (first 6 only) in lab"
            End If  
            If PEnpost = 1 Then
              Print #foutlmd," "
              Print #foutlmd,"* In separate lines: Prompt post-scission neutrons (including acceleration phase)"
              Print #foutlmd,"*  0  E1, cos(theta1), phi1, E2, cos(theta2), phi2, E3, cos(theta3, phi3, ...: "
              Print #foutlmd,"*    Energies [MeV] in CN frame and angles vs. direction of light fragment for all post-scission neutrons"
              If Emode Mod 10 = 2 Then
                Print #foutlmd,"*  1  E1l_frag, E1l_CN, E1l_lab, cos(theta1l_lab), E2l_frag, E2l_CN, E2l_lab, cos(theta2l_lab), E3l_frag, E3l_CN, E3l_lab, cos(theta3l_lab), ...: Energies [MeV] of neutrons emitted from light fragment"
                Print #foutlmd,"*     in frame of light fragment, in frame of CN and in lab, lab angle vs incident particle."
                Print #foutlmd,"*  2  E1h_frag, E1h_CN, E1h_lab, cos(theta2l_lab), E2h_frag, E2h_CN, E2h_lab, cos(theta2l_lab), E3h_frag, E3h_CN, E3h_lab, cos(theta3l_lab), ...: Energies [MeV] of neutrons emitted from heavy fragment"
                Print #foutlmd,"*     in frame of light fragment, in frame of CN and in lab, lab angle vs incident particle."
              Else
                Print #foutlmd,"*  1  E1l_frag, E1l_CN, E2l_frag, E2l_CN, E3l_frag, E3l_CN, ...: Energies [MeV] of neutrons emitted from light fragment"
                Print #foutlmd,"*     in frame of light fragment and in frame of CN."
                Print #foutlmd,"*  2  E1h_frag, E1h_CN, E2h_frag, E2h_CN, E3h_frag, E3h_CN, ...: Energies [MeV] of neutrons emitted from heavy fragment"
                Print #foutlmd,"*     in frame of light fragment and in frame of CN."
              End If
            End If    
            If PEgpost = 1 Then
              Print #foutlmd,"* In separate lines: Prompt post-scission gammas"
              Print #foutlmd,"*  3  E1l, E2l, E3l, ...: Energies [MeV] of gammas emitted from light fragment in competition with neutrons"        
              Print #foutlmd,"*  4  E1l, E2l, E3l, ...: Energies [MeV] of statistical gammas emitted from light fragment after neutron emission"        
              Print #foutlmd,"*  5  E1l, E2l, E3l, ...: Energies [MeV] of prompt collective gammas emitted from light fragment, final state (GS or M(spin/E* [MeV])"        
              Print #foutlmd,"*  6  E1h, E2h, E3h, ...: Energies [MeV] of gammas emitted from heavy fragment in competition with neutrons"        
              Print #foutlmd,"*  7  E1h, E2h, E3h, ...: Energies [MeV] of statistical gammas emitted from heavy fragment after neutron emission"        
              Print #foutlmd,"*  8  E1h, E2h, E3h, ...: Energies [MeV] of prompt collective gammas emitted from heavy fragment, final state (GS or M(spin/E* [MeV])"        
            End If
            If Imulti > 1 Then
              Print #foutlmd," "
              Print #foutlmd,"* Note: The sequence of the events in the list-mode output is sorted" 
              Print #foutlmd,"*       in the case of multi-chance fission in order to save computing time"
              Print #foutlmd,"*       (first-chance fission appears first)."
              Print #foutlmd," "
            End If  
            If Pdir = 1 Then
              Print #foutlmd,"* Note: Elab1pre, Elab2pre are fictive quantities in case of neutron emission"
              Print #foutlmd,"*       from fragments in the acceleratoin phase, i.e. before they reach their final velocities."
              Print #foutlmd,"*       The valies correspond to the energy of fragments with masses at scission"
              print #foutlmd,"*       with velocities after full acceleration."
              Print #foutlmd," "
            End If
            Print #foutlmd,"* Note: The kinematics of the fragments, neutrons, protons and gammas is calculated"
            Print #foutlmd,"*       with some approximations, which, however, preserve the main features:"
            If PnCN = 1 /' And Inofirst > 0 '/ Then
              If Emode = 2 Then Print #foutlmd,"*       o The momentum of the incident neutron is assumed to be fully absorbed."
              If Emode = 12 Then Print #foutlmd,"*       o The momentum of the incident proton is assumed to be fully absorbed."
              If Emode = 22 Then Print #foutlmd,"*       o The momentum of the incident allpha is assumed to be fully absorbed."
              Print #foutlmd,"*       o The pre-scission particles are assumed to be emitted isotropically"
              Print #foutlmd,"*         in the frame of the emitting nucleus."
              Print #foutlmd,"*       o The recoil of the emitted particle to the emitting nucleus is"
              Print #foutlmd,"*         not considered."
            End If 
            Print #foutlmd,"*       o The recoil of the emitted neutrons to the emitting fragment is not"
            Print #foutlmd,"*         considered." 
            If PEnpost = 1 Then
              Print #foutlmd,"*       o The prompt neutrons are assumed to be emitted isotropically in the"
              Print #foutlmd,"*         in the frame of the emitting fragment."
            End If  
            IF PEgpost = 1 Then
              Print #foutlmd,"*       o The listed gamma energies do not consider the doppler shift"
              Print #foutlmd,"*         induced by the moving fragment. Therefore, measured gamma spectra,"
              Print #foutlmd,"*         in particular the lines of the non-statistical gammas," 
              Print #foutlmd,"*         are smeared out and somewhat shifted in energy."
            End If           
            Print #foutlmd," " 
          End If ' If CFileoutlmd <> ""
       
     
          Dim As LongInt NEVTused,NEVTtot,IEVTtot
          Dim As Single Racc
          Dim As LongInt ILoop
    '     Dim As Integer I_Energy_loop
          If Fenhance < 1 And B_Error_Analysis = 0 Then 
            Print "<W> The calculation with ";Csng(Fenhance*1.E5);" events will be subject"
            Print "    to grave statistical fluctuations!"
          End If     
          If B_Error_Analysis = 1 Then    
            If B_Fit = 1 Then 
              NEVTtot = Fenhance * Ten_to_five  ' all calculations with the same statistics
              N_Error_MAX = 1    ' Only one set of perturbed parameters
            Else
              N_Error_Max = Int(sqr(Fenhance * 100.0)) 
             ' Increase the number of perturbed-parameter sets to 10*sqr(Fenhance)
              NEVTtot = Fenhance * Ten_to_five / N_Error_Max  
             ' Increase statistics for calculation with one set of perturbed parameters
             ' approximately with sqr(Fenhance), while fixing the total number of calculations
             ' to Ten_to_five * Fenhance
              Print "Calculation (";I_Error+1;" of ";N_Error_Max;") with perturbed model parameters."
            End If
       '    Print "Calculation (";I_Error+1;" of ";N_Error_Max;") with perturbed model parameters."   
      /'    If Emode = 3 Then
              Print Cfileout, ", energy distribution from ";C_Espectrum
            Else
              Print Cfileout,P_E_exc;" MeV"
            End If '/ 
          Else
     '      If B_Fit = 1 Then
     '        NEVTtot = 0
     '      ELse  
            NEVTtot = Fenhance * Ten_to_five
            Print "Calculation with nominal model parameters."
     '      End If  
      /'    If Emode = 3 Then
              Print Cfileout, ", energy distribution from"; C_Espectrum
            Else
              Print Cfileout,P_E_exc;" MeV"
            End If '/  
          End If ' If B_Error_Analysis = 1
          If NEVTtot > 0 Then Print NEVTtot;" events will be calculated."  
    '     If I_Mode_selected > -1 Then
    '       Print "The number of events will be downscaled by the yield of the selected fission channel."   
    '     End If     
     '    Racc = 100.E0 / NEVTtot  ' Normalization of spectra
    
     
     
     
      /' Variation of model parameters for error analysis '/
      
          Delta_S0 = _Delta_S0  
    
          If B_Error_Analysis = 1 _ 
              And Not(B_Fit = 1 And I_Fitloop = 1) Then  
          ' first fit iteration with unperturbed parameters
            If (B_Fit = 0 And I_Double_Covar = 1) Or _
              (B_Fit = 1 And B_New_Fit_Parameters = 1) Then  
            ' Mode for single system or for passage of first system
            ' set values to perturbed parameters
              If B_Fit Then Print "New set of GEF parameters, number ";I_Fitloop;"."
              P_DZ_Mean_S1 = PGauss(_P_DZ_Mean_S1,Var_P_DZ_Mean_S1)
              P_corr_S1 = PGauss(_P_corr_S1,Var_P_corr_S1)
              P_DZ_Mean_S2 = PGauss(_P_DZ_Mean_S2,Var_P_DZ_Mean_S2)
              P_DZ_Mean_S3 = PGauss(_P_DZ_Mean_S3,Var_P_DZ_Mean_S3)
              P_DZ_Mean_S4 = PGauss(_P_DZ_Mean_S4,Var_P_DZ_Mean_S4)
              P_DZ_Mean_SL5 = PGauss(_P_DZ_Mean_SL5,Var_P_DZ_Mean_SL5)
              P_DZ_Mean_S5 = PGauss(_P_DZ_Mean_S5,Var_P_DZ_Mean_S5)
              P_Z_Curv_S1 = PGauss(_P_Z_Curv_S1,Var_P_Z_Curv_S1)
              P_Z_Curv_S2 = PGauss(_P_Z_Curv_S2,Var_P_Z_Curv_S2)
              S2leftmod = PGauss(_S2leftmod,Var_S2leftmod)
              P_A_Width_S2 = PGauss(_P_A_Width_S2,Var_P_A_Width_S2)
              P_Z_Curv_S3 = PGauss(_P_Z_Curv_S3,Var_P_Z_Curv_S3)
              P_Z_Curv_S4 = PGauss(_P_Z_Curv_S4,Var_P_Z_Curv_S4)
              P_Z_Curv_SL5 = PGauss(_P_Z_Curv_SL5,Var_P_Z_Curv_SL5)
              P_Z_Curv_S5 = PGauss(_P_Z_Curv_S5,Var_P_Z_Curv_S5)
              PZ_S3_olap_pos = PGAUSS(_PZ_S3_olap_pos,Var_PZ_S3_olap_pos)
              PZ_S3_olap_curv = PGAUSS(_PZ_S3_olap_curv,Var_PZ_S3_olap_curv)
              Delta_S0 = PGauss(_Delta_S0,Var_Delta_S0)  
              P_Shell_S1 = PGauss(_P_Shell_S1,Var_P_Shell_S1)
              P_Shell_S2 = PGauss(_P_Shell_S2,Var_P_Shell_S2)
              P_Shell_S3 = PGauss(_P_Shell_S3,Var_P_Shell_S3)
              P_Shell_S4 = PGauss(_P_Shell_S4,Var_P_Shell_S4)
              P_Shell_SL5 = PGauss(_P_Shell_SL5,Var_P_Shell_SL5)
              P_Shell_S5 = PGauss(_P_Shell_S5,Var_P_Shell_S5)
              dE_Defo_S1 = PGauss(_dE_Defo_S1,Var_dE_Defo_S1)
              dE_Defo_S2 = PGauss(_dE_Defo_S2,Var_dE_Defo_S2)
              dE_Defo_S3 = PGauss(_dE_Defo_S3,Var_dE_Defo_S3)
              dE_Defo_S4 = PGauss(_dE_Defo_S4,Var_dE_Defo_S4)
              dE_Defo_S5 = PGauss(_dE_Defo_S5,Var_dE_Defo_S5)
              betaL0 = PGauss(_betaL0,Var_betaL0)
              betaL1 = PGauss(_betaL1,Var_betaL1)
              betaH0 = PGauss(_betaH0,Var_betaH0)
              betaH1 = PGauss(_betaH1,Var_betaH1)
              dbeta_S3 = PGauss(_dbeta_S3,Var_dbeta_S3)
              T_low_SL = PGauss(_T_low_SL,Var_T_low_SL)
              T_low_S1 = PGauss(_T_low_S1,Var_T_low_S1)
              T_low_S2 = PGauss(_T_low_S2,Var_T_low_S2)
              T_low_S3 = PGauss(_T_low_S3,Var_T_low_S3)
              T_low_S4 = PGauss(_T_low_S4,Var_T_low_S4)
              T_low_S5 = PGauss(_T_low_S5,Var_T_low_S5)
              ECOLLFRAC = PGauss(_ECOLLFRAC,Var_ECOLLFRAC)
              EDISSFRAC = PGauss(_EDISSFRAC,Var_EDISSFRAC)
              P_att_pol = PGauss(_P_att_pol,Var_P_att_pol)
              P_att_rel = _P_att_rel
            ' Delta_NZ_Pol = 78.26 - 50/P_Z_CN * (P_A_CN - P_Z_CN) ' relative to 236U
            ' P_Shell_S1 = P_Shell_S1 * (1 - PGauss(0,Var_P_Att_Pol) * Delta_NZ_Pol)
              HOMPOL = PGauss(_HOMPOL,Var_HOMPOL)
              POLARadd = PGauss(_POLARadd,Var_POLARadd)  
              Jscaling = PGauss(_Jscaling,Var_Jscaling)
    
              Scope 
                Dim As Integer fpar
                Dim As String Cfile_parameters
                Dim As Double Rdatetime
    
                If Bfilein Then await(I_thread,I_thread_max)  
              ' protect writing and reading on/from file #fpar against other threads for 0.1 second
                Cfile_parameters = "tmp\"+Cfileout+".par"
                fpar = freefile
                If I_Error = 0 Then
                  Open Cfile_parameters For Append As #fpar
                  Print #fpar,"*"
                  Print #fpar,"* This file provides the values of the disturbed parameters"
                  Print #fpar,"* which are used for the calculation of uncertainties,"
                  Print #fpar,"* variances and correlations."
                  Print #fpar,"* "
                  Print #fpar,"* Output written on ";       
                  Print #fpar, Format( Rdatetime, "dd.mm.yyyy, hh:mm:ss")
                  Print #fpar,"* "
                  Print #fpar, Using "& ### & ###";"* Calculation for the nucleus Z = ";P_Z_CN;", A = ";P_A_CN
    
                  Select Case Emode
                    Case 0
                      Print #fpar,"* at E* = ";P_E_exc;" MeV above the outer saddle"
                      Print #fpar,"*   (E* = ";Eabsgs;" MeV above the ground state)."
                      Print #fpar,"* Spin = ";Spin_CN
                    Case 1
                      Print #fpar,"* at E* = ";P_E_exc;" MeV above the ground state."
                      Print #fpar,"* Spin = ";Spin_CN
                    Case -1
                      Print #fpar,"* at E* = ";P_E_exc;" MeV above the ground state."
                      Print #fpar,"* Spin = ";Spin_CN
                      Print #fpar,"* Only first-chance fission!"
                    Case 2
                      Print #fpar,"* formed by (n,f) with En = ";P_E_exc- E_EXC_ISO;" MeV."
                      Print #fpar,"* Spin of target nucleus = ";Spin_CN
                    Case 12
                      Print #fpar,"* formed by (p,f) with Ep = ";P_E_exc- E_EXC_ISO;" MeV."
                      Print #fpar,"* Spin of target nucleus = ";Spin_CN           
                    Case 22
                      Print #fpar,"* formed by (alpha,f) with Ealpha = ";P_E_exc- E_EXC_ISO;" MeV."
                      Print #fpar,"* Spin of target nucleus = ";Spin_CN           
                    Case 3
                      Print #fpar,"* with user-defined excitation-energy distribution"
                      Print #f," from the file ";C_Espectrum;"."
                      Print #fpar,"* Only first-chance fission."
                      Print #fpar,"*","  E* (MeV)      Spin        Weight"
                      For I = 1 To Ubound(E_spectrum)
                        Print #fpar,"*", E_spectrum(I), L_spectrum(I), W_spectrum(I)
                      Next I
                    Case 13
                      Print #fpar,"* with user-defined excitation-energy distribution"
                      Print #f," from the file ";C_Espectrum;"."
                      Print #fpar,"* Multi-chance fission supported."
                      Print #fpar,"*","  E* (MeV)      Spin        Weight"
                      For I = 1 To Ubound(E_spectrum)
                        Print #fpar,"*", E_spectrum(I), L_spectrum(I), W_spectrum(I)
                      Next I
                  End Select
                  If I_E_iso > 0 Then
                    Print #fpar, "* Isomer # ";I_E_iso;", at E* = ";E_EXC_ISO;" MeV" 
                  End If     
                  If EOscale <> 1 Then
                    Print #fpar, "* Even-odd effect at scission scaled with a factor ";Eoscale;"."
                  End If
         
                Else 
                  Open Cfile_parameters For Append As #fpar
                End If
                Print #fpar,"*"
                Print #fpar,"* Perturbed parameter set #"+Str(I_Error+1)
                Print #fpar,"*"
                Print #fpar,"P_DZ_Mean_S1 = ",P_DZ_Mean_S1
                Print #fpar,"P_corr_S1 =    ",P_corr_S1
                Print #fpar,"P_DZ_Mean_S2 = ",P_DZ_Mean_S2
                Print #fpar,"P_DZ_Mean_S3 = ",P_DZ_Mean_S3
                Print #fpar,"P_DZ_Mean_S4 = ",P_DZ_Mean_S4
                Print #fpar,"P_DZ_Mean_SL5 = ",P_DZ_Mean_SL5
                Print #fpar,"P_DZ_Mean_S5 = ",P_DZ_Mean_S5
                Print #fpar,"P_Z_Curv_S1 =  ",P_Z_Curv_S1
                Print #fpar,"P_Z_Curv_S2 =  ",P_Z_Curv_S2
                Print #fpar,"S2leftmod =    ",S2leftmod
                Print #fpar,"P_A_Width_S2 = ",P_A_Width_S2
                Print #fpar,"P_Z_Curv_S3 =  ",P_Z_Curv_S3
                Print #fpar,"P_Z_Curv_S4 =  ",P_Z_Curv_S4
                Print #fpar,"P_Z_Curv_SL5 =  ",P_Z_Curv_SL5
                Print #fpar,"P_Z_Curv_S5 =  ",P_Z_Curv_S5
                Print #fpar,"PZ_S3_olap_pos = ",PZ_S3_olap_pos
                Print #fpar,"PZ_S3_olap_curv = ",PZ_S3_olap_curv
                Print #fpar,"Delta_S0 =     ",Delta_S0
                Print #fpar,"P_Shell_S1 =   ",P_Shell_S1
                Print #fpar,"P_Shell_S2 =   ",P_Shell_S2
                Print #fpar,"P_Shell_S3 =   ",P_Shell_S3
                Print #fpar,"P_Shell_S4 =   ",P_Shell_S4
                Print #fpar,"P_Shell_SL5 =   ",P_Shell_SL5
                Print #fpar,"P_Shell_S5 =   ",P_Shell_S5
                Print #fpar,"dE_Defo_S1 =   ",dE_Defo_S1
                Print #fpar,"dE_Defo_S2 =   ",dE_Defo_S2
                Print #fpar,"dE_Defo_S3 =   ",dE_Defo_S3
                Print #fpar,"dE_Defo_S4 =   ",dE_Defo_S4
                Print #fpar,"dE_Defo_S5 =   ",dE_Defo_S5
                Print #fpar,"betaL0 =       ",betaL0
                Print #fpar,"betaL1 =       ",betaL1
                Print #fpar,"betaH0 =       ",betaH0
                Print #fpar,"betaH1 =       ",betaH1
                Print #fpar,"dbeta_S3 =     ",dbeta_S3
                Print #fpar,"T_low_SL =     ",T_low_SL
                Print #fpar,"T_low_S1 =     ",T_low_S1
                Print #fpar,"T_low_S2 =     ",T_Low_S2
                Print #fpar,"T_low_S3 =     ",T_Low_S3
                Print #fpar,"T_low_S4 =     ",T_low_S4
                Print #fpar,"T_low_S5 =     ",T_low_S5
                Print #fpar,"ECOLLFRAC =    ",ECOLLFRAC
                Print #fpar,"EDISSFRAC =    ",EDISSFRAC
                Print #fpar,"P_att_pol =    ",P_att_pol
                Print #fpar,"P_att_rel =    ",P_att_rel
                Print #fpar,"HOMPOL =       ",HOMPOL
                Print #fpar,"POLARadd =     ",POLARadd
                Print #fpar,"Jscaling =     ",Jscaling       
                Close #fpar
              End Scope
        
              If I_Error = 0 Then 
              ' Allocate array for storing the sequence of perturbed parameters
                ReDim As Single Double_P_DZ_Mean_S1(N_Error_Max)
                ReDim As Single Double_P_corr_S1(N_Error_Max)
                ReDim As Single Double_P_DZ_Mean_S2(N_Error_Max)
                ReDim As Single Double_P_DZ_Mean_S3(N_Error_Max)
                ReDim As Single Double_P_DZ_Mean_S4(N_Error_Max)
                ReDim As Single Double_P_DZ_Mean_SL5(N_Error_Max)
                ReDim As Single Double_P_DZ_Mean_S5(N_Error_Max)
                ReDim As Single Double_P_Z_Curv_S1(N_Error_Max)
                ReDim As Single Double_P_Z_Curv_S2(N_Error_Max)
                ReDim As Single Double_S2leftmod(N_Error_Max)
                ReDim As Single Double_P_A_Width_S2(N_Error_Max)
                ReDim As Single Double_P_Z_Curv_S3(N_Error_Max)
                ReDim As Single Double_P_Z_Curv_S4(N_Error_Max)
                ReDim As Single Double_P_Z_Curv_SL5(N_Error_Max)
                ReDim As Single Double_P_Z_Curv_S5(N_Error_Max)
                ReDim As Single Double_PZ_S3_olap_pos(N_Error_Max)
                ReDim As Single Double_PZ_S3_olap_curv(N_Error_max)
                ReDim As Single Double_Delta_S0(N_Error_Max)
                ReDim As Single Double_P_Shell_S1(N_Error_Max)
                ReDim As Single Double_P_Shell_S2(N_Error_Max)
                ReDim As Single Double_P_Shell_S3(N_Error_Max)
                ReDim As Single Double_P_Shell_S4(N_Error_Max)
                ReDim As Single Double_P_Shell_SL5(N_Error_Max)
                ReDim As Single Double_P_Shell_S5(N_Error_Max)
                ReDim As Single Double_dE_Defo_S1(N_Error_Max)
                ReDim As Single Double_dE_Defo_S2(N_Error_Max)
                ReDim As Single Double_dE_Defo_S3(N_Error_Max)
                ReDim As Single Double_dE_Defo_S4(N_Error_Max)
                ReDim As Single Double_dE_Defo_S5(N_Error_Max)
                ReDim As Single Double_betaL0(N_Error_Max)
                ReDim As Single Double_betaL1(N_Error_Max)
                ReDim As Single Double_betaH0(N_Error_Max)
                ReDim As Single Double_betaH1(N_Error_Max)
                ReDim As Single Double_dbeta_S3(N_Error_Max)
                ReDim As Single Double_T_low_S1(N_Error_Max)
                ReDim As Single Double_T_low_S2(N_Error_Max)
                ReDim As Single Double_T_low_S3(N_Error_Max)
                ReDim As Single Double_T_low_S4(N_Error_Max)
                ReDim As Single Double_T_low_S5(N_Error_Max)
                ReDim As Single Double_T_low_SL(N_Error_Max)
                ReDim As Single Double_ECOLLFRAC(N_ERROR_Max)
                ReDim As Single Double_EDISSFRAC(N_ERROR_Max)
                ReDim As Single Double_P_att_pol(N_Error_Max)
                ReDim As Single Double_HOMPOL(N_Error_Max)
                ReDim As Single Double_POLARadd(N_Error_Max)  
                ReDim As Single Double_Jscaling(N_Error_Max)
              End If
          
            ' Store perturbed parameter values for calculation with second fissioning system:
              Double_P_DZ_Mean_S1(I_Error) = P_DZ_Mean_S1
              Double_P_corr_S1(I_Error) = P_corr_S1
              Double_P_DZ_Mean_S2(I_Error) = P_DZ_Mean_S2
              Double_P_DZ_Mean_S3(I_Error) = P_DZ_Mean_S3
              Double_P_DZ_Mean_S4(I_Error) = P_DZ_Mean_S4
              Double_P_DZ_Mean_SL5(I_Error) = P_DZ_Mean_SL5
              Double_P_DZ_Mean_S5(I_Error) = P_DZ_Mean_S5
              Double_P_Z_Curv_S1(I_Error) = P_Z_Curv_S1
              Double_P_Z_Curv_S2(I_Error) = P_Z_Curv_S2
              Double_S2leftmod(I_Error) = S2leftmod
              Double_P_A_Width_S2(I_Error) = P_A_Width_S2
              Double_P_Z_Curv_S3(I_Error) = P_Z_Curv_S3
              Double_P_Z_Curv_S4(I_Error) = P_Z_Curv_S4
              Double_P_Z_Curv_SL5(I_Error) = P_Z_Curv_SL5
              Double_P_Z_Curv_S5(I_Error) = P_Z_Curv_S5
              Double_PZ_S3_olap_pos(I_Error) = PZ_S3_olap_pos
              Double_PZ_S3_olap_curv(I_ERROR) = PZ_S3_olap_curv
              Double_Delta_S0(I_Error) = Delta_S0
              Double_P_Shell_S1(I_Error) = P_Shell_S1
              Double_P_Shell_S2(I_Error) = P_Shell_S2
              Double_P_Shell_S3(I_Error) = P_Shell_S3
              Double_P_Shell_S4(I_Error) = P_Shell_S4
              Double_P_Shell_SL5(I_Error) = P_Shell_SL5
              Double_P_Shell_S5(I_Error) = P_Shell_S5
              Double_dE_Defo_S1(I_Error) = dE_Defo_S1
              Double_dE_Defo_S2(I_Error) = dE_Defo_S2
              Double_dE_Defo_S3(I_Error) = dE_Defo_S3
              Double_dE_Defo_S4(I_Error) = dE_Defo_S4
              Double_dE_Defo_S5(I_Error) = dE_Defo_S5
              Double_betaL0(I_Error) = betaL0
              Double_betaL1(I_Error) = betaL1
              Double_betaH0(I_Error) = betaH0
              Double_betaH1(I_Error) = betaH1
              Double_dbeta_S3(I_Error) = dbeta_S3
              Double_T_low_S1(I_Error) = T_low_S1
              Double_T_low_S2(I_Error) = T_low_S2
              Double_T_low_S3(I_Error) = T_low_S3
              Double_T_low_S4(I_Error) = T_low_S4
              Double_T_low_S5(I_Error) = T_low_S5
              Double_T_low_SL(I_Error) = T_low_SL
              Double_ECOLLFRAC(I_Error) = ECOLLFRAC
              Double_EDISSFRAC(I_Error) = EDISSFRAC
              Double_P_att_pol(I_Error) = P_att_pol
              Double_HOMPOL(I_Error) = HOMPOL
              Double_POLARadd(I_Error) = POLARadd  
              Double_Jscaling(I_Error) = Jscaling
            End If
            If I_Double_Covar = 2 Or _
                (B_Fit = 1 And B_New_Fit_Parameters = 0) Then  ' Passage for second fissioning system
            ' Use parameter values of first fissioning system again
              P_DZ_Mean_S1 = Double_P_DZ_Mean_S1(I_Error)  
              P_corr_S1 = Double_P_corr_S1(I_Error)
              P_DZ_Mean_S2 = Double_P_DZ_Mean_S2(I_Error)  
              P_DZ_Mean_S3 = Double_P_DZ_Mean_S3(I_Error)  
              P_DZ_Mean_S4 = Double_P_DZ_Mean_S4(I_Error)  
              P_DZ_Mean_SL5 = Double_P_DZ_Mean_SL5(I_Error)  
              P_DZ_Mean_S5 = Double_P_DZ_Mean_S5(I_Error)  
              P_Z_Curv_S1 = Double_P_Z_Curv_S1(I_Error)  
              P_Z_Curv_S2 = Double_P_Z_Curv_S2(I_Error)  
              S2leftmod = Double_S2leftmod(I_Error)
              P_A_Width_S2 = Double_P_A_Width_S2(I_Error) 
              P_Z_Curv_S3 = Double_P_Z_Curv_S3(I_Error) 
              P_Z_Curv_S4 = Double_P_Z_Curv_S4(I_Error) 
              P_Z_Curv_SL5 = Double_P_Z_Curv_SL5(I_Error) 
              P_Z_Curv_S5 = Double_P_Z_Curv_S5(I_Error) 
              PZ_S3_olap_pos = Double_PZ_S3_olap_pos(I_Error)
              PZ_S3_olap_curv = Double_PZ_S3_olap_curv(I_Error)
              Delta_S0 = Double_Delta_S0(I_Error) 
              P_Shell_S1 = Double_P_Shell_S1(I_Error) 
              P_Shell_S2 = Double_P_Shell_S2(I_Error) 
              P_Shell_S3 = Double_P_Shell_S3(I_Error) 
              P_Shell_S4 = Double_P_Shell_S4(I_Error) 
              P_Shell_SL5 = Double_P_Shell_SL5(I_Error) 
              P_Shell_S5 = Double_P_Shell_S5(I_Error) 
              dE_Defo_S1 = Double_dE_Defo_S1(I_Error)
              dE_Defo_S2 = Double_dE_Defo_S2(I_Error)
              dE_Defo_S3 = Double_dE_Defo_S3(I_Error)
              dE_Defo_S4 = Double_dE_Defo_S4(I_Error)
              dE_Defo_S5 = Double_dE_Defo_S5(I_Error)
              betaL0 = Double_betaL0(I_Error)
              betaL1 = Double_betaL1(I_Error)
              betaH0 = Double_betaH0(I_Error)
              betaH1 = Double_betaH1(I_Error)
              dbeta_S3 = Double_dbeta_S3(I_Error)
              T_low_S1 = Double_T_low_S1(I_Error) 
              T_low_S2 = Double_T_low_S2(I_Error) 
              T_low_S3 = Double_T_low_S3(I_Error) 
              T_low_S4 = Double_T_low_S4(I_Error) 
              T_low_S5 = Double_T_low_S5(I_Error) 
              T_low_SL = Double_T_low_SL(I_Error) 
              ECOLLFRAC = Double_ECOLLFRAC(I_Error)
              EDISSFRAC = Double_EDISSFRAC(I_Error)
              P_att_pol = Double_P_att_pol(I_Error) 
              HOMPOL = Double_HOMPOL(I_Error) 
              POLARadd = Double_POLARadd(I_Error)   
              Jscaling = Double_Jscaling(I_Error)
            End If
     '      B_New_Fit_Parameters = 0
        
          Else
    /'<'/
        '   Use nominal parameter values:
            P_DZ_Mean_S1 = _P_DZ_Mean_S1
            P_corr_S1 = _P_corr_S1
            P_DZ_Mean_S2 = _P_DZ_Mean_S2
            P_DZ_Mean_S3 = _P_DZ_Mean_S3
            P_DZ_Mean_S4 = _P_DZ_Mean_S4
            P_DZ_Mean_SL5 = _P_DZ_Mean_SL5
            P_DZ_Mean_S5 = _P_DZ_Mean_S5
            P_Z_Curv_S1 = _P_Z_Curv_S1
            P_Z_Curv_S2 = _P_Z_Curv_S2
            S2leftmod = _S2leftmod
            P_A_Width_S2 = _P_A_Width_S2
            P_Z_Curv_S3 = _P_Z_Curv_S3
            P_Z_Curv_S4 = _P_Z_Curv_S4
            P_Z_Curv_SL5 = _P_Z_Curv_SL5
            P_Z_Curv_S5 = _P_Z_Curv_S5
            PZ_S3_olap_pos = _PZ_S3_olap_pos
            PZ_S3_olap_curv = _PZ_S3_olap_curv
            Delta_S0 = _Delta_S0
            P_Shell_S1 = _P_Shell_S1
            P_Shell_S2 = _P_Shell_S2
            P_Shell_S3 = _P_Shell_S3
            P_Shell_S4 = _P_Shell_S4
            P_Shell_SL5 = _P_Shell_SL5
            P_Shell_S5 = _P_Shell_S5
            dE_Defo_S1 = _dE_Defo_S1
            dE_Defo_S2 = _dE_Defo_S2
            dE_Defo_S3 = _dE_Defo_S3
            dE_Defo_S4 = _dE_Defo_S4
            dE_Defo_S5 = _dE_Defo_S5
            betaL0 = _betaL0
            betaL1 = _betaL1
            betaH0 = _betaH0
            betaH1 = _betaH1
            dbeta_S3 = _dbeta_S3
            T_low_S1 = _T_low_S1
            T_low_S2 = _T_low_S2
            T_low_S3 = _T_low_S3
            T_low_S4 = _T_low_S4
            T_low_S5 = _T_low_S5
            T_low_SL = _T_low_SL
            ECOLLFRAC = _ECOLLFRAC
            EDISSFRAC = _EDISSFRAC
            P_att_pol = _P_att_pol
            P_att_rel = _P_att_rel
            HOMPOL = _HOMPOL
            POLARadd = _POLARadd
            Jscaling = _Jscaling
      
    /'>'/   
          End If  
       
    '     Print I_Double_Covar,I_Error, P_DZ_Mean_S1   
    
    
    /'<'/
          Dim As Single R_E_exc_used
          Dim As Single I_rigid_spher, I_eff_CN
          R_E_exc_used = P_E_exc
          I_A_CN = P_A_CN
          I_Z_CN = P_Z_CN
    /'>'/    
        
          IEVTtot = 0              ' Counts total number of processed events
        
          R_NEVTspectrum = 1.0         ' Default: only one energy
    
      '   Loop over array of initial excitation energy
      
          Dim As Integer N_E_distr,N_E_Multi,N_N_Multi,N_Z_Multi 
          Dim As Integer I_E_distr,I_E_Multi,I_N_Multi,I_Z_Multi  
          Dim As Integer I_A_Multi
          Dim As Integer I_N_Multi_Max = 0
          Dim As Integer I_Z_Multi_Max = 0
          N_E_distr = 1
          N_N_Multi = 0
          N_Z_Multi = 0
          N_E_Multi = 0
          If Emode = 3 Then  ' Energy distribution on input
            N_E_distr = Ubound(E_spectrum,1)
          End If
          If Inofirst > 0 Or Emode = 13 Then  ' Multi-chance fission
            N_N_Multi = 10
            N_Z_Multi = 10
            N_E_Multi = 1000  ' corresponds to 100 MeV
          End If
    
          /'** Loop for energy distribution from file **'/
          For I_E_Distr = 1 To N_E_distr
    
            /'** Loop for Multi-chance fission (N, Z and E) **'/
    
            For I_N_Multi = 0 To N_N_Multi
              For I_Z_Multi = 0 To N_Z_Multi
      '         For I_N_Multi = N_N_Multi To 0 Step -1
      '         For I_Z_Multi = N_Z_Multi To 0 Step -1
                I_A_Multi = I_N_Multi + I_Z_Multi
                For I_E_Multi = N_E_Multi To 0 Step -1    ' I_E_Multi is E* over gs in 100 keV bins
    
    Energy_loop:
               /' Definition of Emode values: 
                  -1: E over gs;     "FC"         (only first-chance fission)
                   0: E over BF_B;   "EB"
                   1: E over gs;     "GS" 
                   1: E over isomer; "IS"         I_E_ISO specifies the isomer number
                   2: E_neutron;     "EN"
                   3: E over gs;     "ES"         energy spectrum from file (first-chance fission)
                  12: E_proton;     "EP"
                  22: E_alpha;      "EA"
                  13: E over gs;    "EM"         energy spectrum from file (multi-chance fission)
        '/
    
                  If Inofirst > 0 Or Emode = 13 Then      ' Multi-chance fission (also always formally required for Emode = 13)
                    I_A_CN = P_A_CN - I_N_Multi - I_Z_Multi
                    I_Z_CN = P_Z_CN - I_Z_Multi
                    R_E_exc_used = 0.1 * I_E_Multi
                    R_NEVTspectrum =  E_multi_chance(I_N_Multi,I_Z_Multi,I_E_Multi) 
                    If Emode = 13 Then 
                      Spin_CN = 0    ' Spin for Emode = 13 is not yet supported in the following fission calculation
                    End If  
                  Else   ' Only first-chance fission
                    I_A_CN = P_A_CN
                    If Emode = 3 Then   ' Distribution of excitation energies (and evtl. spin) given, restricted to first chance
                      R_E_exc_used = E_spectrum(I_E_distr)  ' energy value
                      Spin_CN = L_spectrum(I_E_distr)    ' spin value
                      R_NEVTspectrum = W_spectrum(I_E_distr)  ' weight of spectrum
                    Else
                      R_E_exc_used = Eabsgs
                    End If
                  End If
              
                  I_rigid_spher = 1.16E0^2 * Csng(I_A_CN)^1.6667E0 / 103.8415E0
                  I_eff_CN = I_rigid_spher * (1.E0 - 0.8E0 * exp(-0.693E0 * R_E_exc_used / 5.E0))  'Nucl. Phys. A 263 (1976) 141
                  E_rot_CN = Spin_CN*(Spin_CN+1)/(2*I_eff_CN)  ' rotational energy    
        
                  NEVTused = Clngint(Csng(NEVTtot) * R_NEVTspectrum)
                ' Note: Pre-fission calculation and fission calculation is performed
           '        with different numbers of events. This has to be matched.
           '        The connection between the pre-equlibrium calculation and the
           '        fission calculation is done by scaling, not by Monte-Carlo! 
           '      NEVTspectrum is normalized to one. NEVTused scales up to NEVtot, the number
           '      of events used on the second part of GEF (after multi-chance fission).
           
                  If NEVTused > 0 Then   ' avoid considering channels with W_spectrum( )=0
    
     /'             If Inofirst > 0 Or Emode = 13 Then
                      Print "A_fission: ";I_A_CN;", E_fission: ";Round(I_E_Multi/10,3);", spin: "; Spin_CN;", weight: ";R_NEVTspectrum     
                    Else
                      Print "E_exc: ";R_E_exc_used,", spin: "; Spin_CN,", normalized weight: ";R_NEVTspectrum
                    End If  '/
                    If Emode = 3 Then
                      Print "E_exc: ";R_E_exc_used,", spin: "; Spin_CN,", normalized weight: ";R_NEVTspectrum
                    End If  
    
    /'
                    Scope
                      Static as Single Test = 0
                      Test = Test + NEVTspectrum
                      Print "***";I_A_CN;I_Z_CN;I_E_Multi;NEVTspectrum,Test;IEVTtot; Ievttot + NEvtused    
                    End Scope
     '              Print Inofirst, R_E_exc_used, I_A_CN, NEVTused 
    '/
     
                    If I_N_Multi > I_N_Multi_Max Then I_N_Multi_Max = I_N_Multi
                    If I_Z_Multi > I_Z_Multi_Max Then I_Z_Multi_Max = I_Z_Multi
    
       /'           Shell effects for the symmetric fission channel '/
       '            (This works only properly if the shell at symmetry is known for all nuclei.
       '            Since this is not the case, it is safer to keep Delta_S0 of the 1. chance.)
      '             If I_A_Multi > 0 Then 
        '             get correct shell effect at symmetry for chance fission
      '               Delta_S0 = U_Delta_S0(I_Z_CN,I_A_CN)
      '             End If  
      
      
        /'*** Neutrons emitted between saddle and scission ***'/ 
                    Dim As Single Escission_lim
                    Scope
                      Dim As Single ZsqrA_fis
           
                      ZsqrA_fis = Csng(I_Z_CN^2) / Csng(I_A_CN)
     '                Escission_lim = 1150.0 * exp(-ZsqrA_fis/13.0) ' from PRC 86 (2012) 034605
                      Escission_lim = 900.0 * exp(-ZsqrA_fis/13.0) ' from PRC 86 (2012) 034605
                    End Scope  
        
    /'<'/  
    
        /'          Central Z values of fission modes '/
        
        /'          Test of barrier height for compact fission '/
     /'             Dim As Single Fbarr_shell
                    Dim As Single Fbarr_macro
                    Fbarr_shell = 1.44 * (I_C_CN/2)^2 / (1.4 * 2 * (I_A_CN/2)^(1/3))
                    Fbarr_macro = 1.44 * (I_C_CN/2)^2 / (1.4 * 2 * (I_A_CN/2)^(1/3)) '/ 
    
        /'          Fit to positions of fission channels (Boeckstiegel et al., 2008) '/
        /'          P_DZ_Mean_S1 and P_DZ_Mean_S2 allow for slight adjustments '/
                    Scope
                      Dim As Single R_Z_mod, R_A_mod,R_corr2,R_corr1
                      R_Z_mod = Csng(I_Z_CN)
                      R_A_mod = Csng(I_A_CN)
                      R_corr1 = P_corr_S1 * (R_Z_mod - 92.0)
    '                 R_corr1 = 0.07 * (R_Z_mod - 92.0)             ' additional corrections w.r. to 236U(nth,f)
                      R_corr2 = 0.055 * (R_A_mod - R_Z_mod*236/92)  '                 "
          
          ' * SL (S0) : *
                      ZC_Mode_0 = R_Z_mod * 0.5E0      /' Central Z value of SL mode '/
    
          ' * S1 : *
                      ZC_Mode_1 = (55.8E0 - 54.5E0) / (1.56E0 - 1.50E0) * _
                        (R_Z_mod^1.3E0 / R_A_mod - 1.50E0) + 51.5E0 + P_DZ_Mean_S1 _
                        + R_corr1
    
          ' * S2: *          
                      ZC_Mode_2 = (55.8E0 - 54.5E0) / (1.56E0 - 1.50E0) * _
                        (R_Z_mod^1.3E0 / R_A_mod - 1.50E0) + 54.5E0 + P_DZ_Mean_S2 _
                        + R_corr2
                                        
          ' * S3: * 
    '                 ZC_Mode_3 = ZC_Mode_2 + 4.5E0 + P_DZ_Mean_S3   
    
    '                 ZC_Mode_3 = ZC_Mode_2 + 4.87E0 + P_DZ_Mean_S3   
    '                 ZC_Mode_3_shift = - 0.015 * (ZC_Mode_3 - ZC_Mode_0)  
    
                      ZC_Mode_3 = ZC_Mode_2 + 5.5E0 + P_DZ_Mean_S3   
                      ZC_Mode_3_shift = - 0.035 * (ZC_Mode_3 - ZC_Mode_0)  
    
                      ZC_Mode_3 = ZC_Mode_3 + ZC_Mode_3_shift
                '     To account for ZCN-dependent shift of S3 towards minimum of mac. potential
          
           ' * S4: *
                      ZC_Mode_4 = 84          
    
           ' * S5: *
                    ' Do not delete these lines (,because this is a very good fit!):
      '               ZC_Mode_5 = 38.5 + (I_A_CN-I_Z_CN-110)*0.12 - (I_A_CN-I_Z_CN-110)^2 * 0.009 _
      '                 - (I_Z_CN-77)*0.34 + P_DZ_Mean_S4 
               '      assumption: mode position moves with Z and A (adjusted to exp. data
               '        of Itkis and Andreyev et al.
         '            ZC_Mode_5 = - (55.8E0 - 54.5E0) / (1.56E0 - 1.50E0) * _
         '              (R_Z_mod^1.3E0 / I_A_CN - 1.50E0) + 37.5 + P_DZ_Mean_S5  - R_corr2 _
         '              + 0.035 * (I_A_CN- I_Z_CN - 100)   'fits Tl201 (itkis), but not so well Po194,196 (Andreyev) 
                '     corresponding P_DZ_Mean_S4 = -0.5 
                      ZC_Mode_5 = 35.5 + Csng(I_A_CN - I_Z_CN - 100) * 0.11 + P_DZ_Mean_S5   ' mean Z of light fragment in Mode 5
       
      '               Print "R_corr2: ",R_corr2                
      '               Print "Mode 2, Z and N:", ZC_Mode_2, ZC_Mode_2 / P_Z_CN * (P_A_CN-P_Z_CN)                
      '               Print "Mode 4, Z and N:", ZC_Mode_4, ZC_Mode_4 / P_Z_CN * (P_A_CN-P_Z_CN) 
      '               Print "Mode 5, Z and N:", ZC_Mode_5, ZC_Mode_5 / P_Z_CN * (P_A_CN-P_Z_CN) 
      '               sleep      
      
                    End Scope
    
    /'>'/
                    P_Z_Mean_S1 = ZC_Mode_1  /' Copy to global parameter '/
                    P_Z_Mean_S2 = ZC_Mode_2  /'             "            '/
                    P_Z_Mean_S3 = ZC_Mode_3  /'             "            '/
                    P_Z_Mean_S4 = ZC_Mode_4  /'             "            '/
                    P_Z_Mean_S5 = ZC_Mode_5  /'             "            '/
    /'<'/
                    I_N_CN = I_A_CN - I_Z_CN
    
    
        /'          Mean deformation at scission as a function of mass '/
                    If I_Z_CN = I_Z_CN_last And I_A_CN = I_A_CN_last Then
                      B_keep = 1
                    Else
                      I_Z_CN_last = I_Z_CN
                      I_A_CN_Last = I_A_CN
                      B_keep = 0
                    End If  
        
        /'          Mode 0: liquid drop with influence of shells on shape at low E* '/
                    If B_keep = 0 Then
                      If beta1_prev = 0 Or beta2_prev = 0 Then      
                        beta1_prev = 0.3
                        beta2_prev = 0.3
                      End If  
                      For I_short = 10 to I_Z_CN - 10
                        IZ1 = I_short
                        Z1 = Csng(IZ1)
                        IZ2 = I_Z_CN - IZ1
                        Z2 = Csng(IZ2)
                        A1 = Z1 / Csng(I_Z_CN) * Csng(I_A_CN)
                        A2 = I_A_CN - A1
          
            '           Deformed shell below Z=50, valid for S0 at low E*
                        Beta(-1,1,IZ1) = beta_light(IZ1,betaL0,betaL1) - 0.1  
                '       Lower deformation than S1/S2, because Coulomb repulsion from deformed heavy fragment is weaker.
                        Beta(-1,2,IZ2) = beta_light(IZ2,betaL0,betaL1) - 0.1     '          "
                        E_defo = Lymass(Z1,A1,Beta(-1,1,IZ1)) - Lymass(Z1,A1,0.0)
                        Edefo(-1,1,IZ1) = E_defo
                        E_defo = Lymass(Z2,A2,Beta(-1,2,IZ2)) - Lymass(Z2,A2,0.0)
                        Edefo(-1,2,IZ2) = E_defo
                        Beta_Equi(A1,A2,Z1,Z2,dneck,beta1_prev,beta2_prev,beta1_opt,beta2_opt)
    
    
                        Beta(0,1,IZ1) = beta1_opt /' "light" fragment '/
                        Beta(0,2,IZ2) = beta2_opt /' "heavy" fragment '/
                        beta1_prev = beta1_opt
                        beta2_prev = beta2_opt
                        E_defo = Lymass(Z1,A1,beta1_opt) - Lymass(Z1,A1,0.0)
                        Edefo(0,1,IZ1) = E_defo  /' "light" fragment '/
                        E_defo = Lymass(Z2,A2,beta2_opt) - Lymass(Z2,A2,0.0)
                        Edefo(0,2,IZ2) = E_defo  /' "heavy" fragment '/
                      Next I_short
    
        /'            Mode 1: deformed shells (light) and spherical (heavy) '/
                      For I_short = 10 to  I_Z_CN - 10
                        Z1 = Csng(I_short)
                        Z2 = Csng(I_Z_CN) - Z1
                        A1 = (Z1 - 0.5E0) / Csng(I_Z_CN) * Csng(I_A_CN) /' polarization roughly considered '/
                        A2 = Csng(I_A_CN) - A1
                        If I_Z_CN * 0.5 < ZC_Mode_1 Then
          '               Beta_opt_light(A1,A2,Z1,Z2,dneck,0,rbeta_ld)
            /'            nu_mean of Cf requires shells in the light fragment: '/
       '                  rbeta = beta_light(I,betaL0,betaL1) - 0.1 
                      '   smaller than general deformation of light fragment   
                      '        (less neck influence due to spherical heavy fragment)
                          rbeta = beta_light(I_short,betaL0,betaL1)     
  '  rbeta = rbeta + 0.1  ' compact heavy fragment induces stronger deformation by stronger Coulomb force                       
                          If rbeta < 0 Then rbeta = 0
                        Else
                          rbeta = beta_heavy(I_short,betaH0,betaH1)  ' equal to S2 channel
                          if rbeta < 0 Then rbeta = 0
                        End If
                        Beta(1,1,I_short) = rbeta    /' "light" fragment '/
                        E_defo = Lymass(Z1,A1,rbeta) - Lymass(Z1,A1,0.0)
                        Edefo(1,1,I_short) = E_defo /' "light" fragment '/
    '                 Next I_short
    '                 For I_short = 10 To I_Z_CN - 10
    '                    rbeta = 0.208
                        rbeta = 0.1             ' 19.2.2026  for nu_bar of xxxPu(sf)  
                        Beta(1,2,I_short) = rbeta
                        E_defo = Lymass(Z1,A1,rbeta) - Lymass(Z1,A1,0.0)
                        Edefo(1,2,I_short) = E_defo   /' "heavy" fragment (at S1 shell) '/
                      Next I_short
    
        
        /'            Mode 2: deformed shells (light and heavy) '/
                      For I_short = 10 to I_Z_CN - 10
                        Z1 = Csng(I_short)
                        Z2 = Csng(I_Z_CN) - Z1
                        A1 = (Z1 - 0.5E0) / Csng(I_Z_CN) * Csng(I_A_CN) /' polarization roughly considered '/
                        A2 = Csng(I_A_CN) - A1
                        If I_Z_CN * 0.5 < ZC_Mode_2 Then
        '                 Beta_opt_light(A1,A2,Z1,Z2,dneck,beta_heavy(Z2),rbeta_ld)
                          rbeta = beta_light(I_short,betaL0,betaL1)   ' general deformation of light fragment
                          If rbeta < 0 Then rbeta = 0  ' negative values replaced by 0
                        Else
                          rbeta = beta_heavy(I_short,betaH0,betaH1)  ' equal to S2 channel
                        End If  
                        Beta(2,1,I_short) = rbeta
                        E_defo = Lymass(Z1,A1,rbeta) - Lymass(Z1,A1,0.0)
                        Edefo(2,1,I_short) = E_defo
                      Next I_short
                      For I_short = 10 To I_Z_CN - 10
                        rbeta = beta_heavy(I_short,betaH0,betaH1)   /' "heavy" fragment (at S2 shell)'/
                        If rbeta < 0 Then rbeta = 0  ' negative values replaced by 0  
                        Beta(2,2,I_short) = rbeta
                        Z1 = Csng(I_short)
                        A1 = (Z1 + 0.5E0) / Csng(I_Z_CN) * Csng(I_A_CN) /' polarization roughly considered '/
                        E_defo = Lymass(Z1,A1,rbeta) - Lymass(Z1,A1,0.0)
                        iF Z1 > 58 Then E_defo = E_defo + 2.3 * (Z1 - 58)  ' taken from S3 (should be the same "super-shell")
                        Edefo(2,2,I_short) = E_defo
                      Next I_short
    
        /'            Mode 3 '/
                      For I_short = 10 to I_Z_CN - 10
                        Z1 = Csng(I_short)
                        Z2 = Csng(I_Z_CN) - Z1
                        A1 = (Z1 - 0.5E0) / Csng(I_Z_CN) * Csng(I_A_CN) /' polarization roughly considered '/
                        A2 = Csng(I_A_CN) - A1
                        rbeta = beta_light(I_short,betaL0,betaL1) 
       '                rbeta = Max(rbeta-0.10,0.0)  /' for low nu-bar of lightest fragments -> in conflict with TKE! '/
                        rbeta = Max(rbeta,0.0)  /' for low nu-bar of lightest fragments '/
       '                Beta_opt_light(A1,A2,Z1,Z2,dneck,beta_heavy(Z2,betaH0,betaH1),rbeta)  
                        Beta(3,1,I_short) = rbeta
                        E_defo = Lymass(Z1,A1,rbeta) - Lymass(Z1,A1,0.0)
                        Edefo(3,1,I_short) = E_defo
                      Next I_short
                      For I_short = 10 To I_Z_CN - 10
                        rbeta = beta_heavy(I_short,betaH0,betaH1) + dbeta_S3 ' Shift from isotopic distributions of S3 nuclei in 239Pu(nth,f)  
                        If rbeta < 0 Then rbeta = 0
                        Beta(3,2,I_short) = rbeta
                        Z1 = Csng(I_short)
                        A1 = (Z1 + 0.5E0) / Csng(I_Z_CN) * Csng(I_A_CN) /' polarization roughly considered '/
                        E_defo = Lymass(Z1,A1,rbeta) - Lymass(Z1,A1,0.0)
                        If Z1 > 58 Then E_defo = E_defo + 2.3 * (Z1 - 58)  ' ajusted to heavy wing of CF252S
                        Edefo(3,2,I_short) = E_defo
                      Next I_short
    
        /'            Mode 4: (Channel S4, Zfrag around 84) '/
                      For I_short = 10 To I_Z_CN - 10
                        rbeta = beta_light(I_short,betaL0,betaL1)  ' light fragment
                        If rbeta < 0 Then rbeta = 0
                        Beta(4,1,I_short) = rbeta
                        Z1 = Csng(I_short)
                        A1 = (Z1 - 0.5E0) / Csng(I_Z_CN) * Csng(I_A_CN) /' polarization roughly considered '/
                        E_defo = Lymass(Z1,A1,rbeta) - Lymass(Z1,A1,0.0)
                        Edefo(4,1,I_short) = E_defo
                        rbeta = 0   ' heavy fragment near Pb
                        Beta(4,2,I_short) = rbeta
                        E_defo = Lymass(Z1,A1,rbeta) - Lymass(Z1,A1,0.0)
                        Edefo(4,2,I_short) = E_defo
                      Next I_short
    
        /'            Mode 5: (Channel "S5", (fissioning nucleus in the Z=80 region), Zfrag around 38 '/
                      For I_short = 10 to  I_Z_CN - 10    ' heavy fragment
                        Z1 = Csng(I_short)
                        A1 = Z1 / Csng(I_Z_CN) * Csng(I_A_CN) /' charge polarization neglected '/
                        rbeta = Beta(2,1,I_short)  ' Deformation like the light fragment of S2 in the actinides
                        If rbeta < 0 Then rbeta = 0
                        Beta(5,1,I_short) = rbeta 
                        Beta(5,2,I_short) = rbeta
                        E_defo = Lymass(Z1,A1,rbeta) - Lymass(Z1,A1,0.0)
                        Edefo(5,1,I_short) = E_defo /' light fragment '/
                        Edefo(5,2,I_short) = E_defo /' heavy fragment '/
                      Next I_short
    
        /'            Mode 6: (Channel ST1 in both fragments) '/
                      For I_short = 10 To I_Z_CN - 10
                        Z1 = Csng(I_short)
                        Z2 = Csng(I_Z_CN) - Z1
                        rbeta = Beta(1,2,I_short)
                        If rbeta < 0 Then rbeta = 0
                        Beta(6,1,Int(Z1)) = rbeta
                        Beta(6,2,Int(Z1)) = rbeta
                      Next I_short
    
        /'            Mode 7: (Channel ST2 in both fragments) '/
                      For I_short = 10 To I_Z_CN - 10
                        Z1 = Csng(I_short)
                        Z2 = Csng(I_Z_CN) - Z1
                        rbeta = Beta(2,2,I_short)
                        If rbeta < 0 Then rbeta = 0
                        Beta(7,1,Int(Z1)) = rbeta
                        Beta(7,2,Int(Z1)) = rbeta
                      Next I_short
                    End If
    
    
        /'          Mean Z as a function of mass '/

                    If B_keep = 0 Then    
        /'            Mode 0 '/
                      For I_short = 10 To I_A_CN - 10
                        ZUCD = Csng(I_short) / Csng(I_A_CN) * Csng(I_Z_CN)
                        beta1 = Beta(0,1,Int(ZUCD + 0.5))
                        beta2 = Beta(0,2,Int(I_Z_CN - ZUCD + 0.5))
                        Z1 = Z_equi(I_Z_CN,I_short, I_A_CN - I_short, beta1, beta2, dneck,0)
                        Zmean(0,1,I_short) = Z1
                        Zshift(0,1,I_short) = Z1 - ZUCD
                        Zmean(0,2,I_A_CN - I_short) = I_Z_CN - Z1
                        Zshift(0,2,I_A_CN - I_short) = ZUCD - Z1
                      Next I_short
    
        /'            Mode 1 '/
                      For I_short = 10 To I_A_CN - 10
                        ZUCD = Csng(I_short) / Csng(I_A_CN) * Csng(I_Z_CN)
                        Z = ZUCD + ZPOL1 /' Charge polarisation is considered in a crude way '/
                        beta1 = Beta(1,1,CInt(Z)) /' "light" fragment '/
                        Z = ZUCD - ZPOL1
                        beta2 = Beta(1,2,CInt(I_Z_CN-Z)) /' "heavy" fragment at S1 shell '/
                        If Csng(I_Z_CN) * 0.5 < ZC_Mode_1 Then
                          Z1 = Z_equi(I_Z_CN,I_short, I_A_CN - I_short, beta1, beta2, dneck,1) 
                          Z1 = Z1 + Polaradd
                        Else
                          Z1 = Z_equi(I_Z_CN,I_short, I_A_CN - I_short, beta1, beta2, dneck,1)
                        End If      
                        Z1 = Z1 + ZPOL1  /' Charge polarization by shell '/
    
                        If I_Z_CN - Z1 < 50. And (Csng(I_Z_CN) - Z1) > Z1 Then
                          Z1 = Csng(I_Z_CN) - 50.    /' Z of mean heavy fragment not below 50 '/
                        End If
    
                        Zmean(1,1,I_short) = Z1
                        Zshift(1,1,I_short) = Z1 - ZUCD     ' neutron-deficient
                        Zmean(1,2,I_A_CN - I_short) = Csng(I_Z_CN) - Z1
                        Zshift(1,2,I_A_CN - I_short) = ZUCD - Z1  ' neutron rich at shell
                      Next I_short
    
        /'            Mode 2 '/
                      For I_short = 10 To I_A_CN - 10
                        ZUCD = Csng(I_short) / Csng(I_A_CN) * Csng(I_Z_CN)
                        Z = ZUCD /' Charge polarisation is here neglected '/
                        beta1 = Beta(2,1,CInt(Z))
                        beta2 = Beta(2,2,CInt(I_Z_CN-Z))
                        If Csng(I_Z_CN) * 0.5 < ZC_Mode_2 Then
                          Z1 = Z_equi(I_Z_CN,I_short, I_A_CN-I_short, beta1, beta2, dneck,2)
                          Z1 = Z1 + POLARadd
             '            Polarization caused by N=50 shell (assumption)
                          Z1 = Z1 - 0.55 * Bell(Csng(I_short)-Z1,45.0,49.5)
                        Else
                          Z1 = Z_equi(I_Z_CN,I_short, I_A_CN-I_short, beta1, beta2, dneck,2)
                        End If      
          
                        Zmean(2,1,I_short) = Z1
                        Zshift(2,1,I_short) = Z1 - ZUCD        ' neutron deficient
                        Zmean(2,2,I_A_CN - I_short) = Csng(I_Z_CN) - Z1  
                        Zshift(2,2,I_A_CN - I_short) = ZUCD - Z1  ' neutron rich at shell
                      Next I_short
    
        /'            Mode 3 '/
                      For I_short = 10 To I_A_CN - 10
                        ZUCD = Csng(I_short) / Csng(I_A_CN) * Csng(I_Z_CN)
                        Z = ZUCD /' Charge polarisation is here neglected '/
                        beta1 = Beta(3,1,CInt(Z))
                        beta2 = Beta(3,2,I_Z_CN-Cint(Z))
                        Z1 = Z_equi(I_Z_CN,I_short, I_A_CN - I_short, beta1, beta2, dneck,3)
                        Z1 = Z1 + POLARadd 
             '          Polarization caused by N=50 shell (assumption)
                        Z1 = Z1 - 0.55 * Bell(Csng(I_short)-Z1,45.0,49.5)
    '                   POLARadd+0.15,POLARfac)   ' Stronger charge polarization in S3, heavy fragment  '!!! KHS
    '                   POLARadd+0.4,POLARfac)   ' Stronger charge polarization in S3, heavy fragment
                        Zmean(3,1,I_short) = Z1
                        Zshift(3,1,I_short) = Z1 - ZUCD
                        Zmean(3,2,I_A_CN - I_short) = Csng(I_Z_CN) - Z1
                        Zshift(3,2,I_A_CN - I_short) = ZUCD - Z1
                      Next I_short
    
        /'            Mode 4 '/
                      For I_short = 10 To I_A_CN - 10
                        ZUCD = Csng(I_short) / Csng(I_A_CN) * Csng(I_Z_CN)
                        Z = ZUCD /' Charge polarisation is here neglected '/
                        beta1 = Beta(4,1,CInt(Z))
                        beta2 = Beta(4,2,I_Z_CN-Cint(Z))
                        Z1 = Z_equi(I_Z_CN,I_short, I_A_CN - I_short, beta1, beta2, dneck,4)
                        Z1 = Z1 + POLARadd 
                        Zmean(4,1,I_short) = Z1
                        Zshift(4,1,I_short) = Z1 - ZUCD
                        Zmean(4,2,I_A_CN - I_short) = Csng(I_Z_CN) - Z1
                        Zshift(4,2,I_A_CN - I_short) = ZUCD - Z1
                      Next I_short
    
        /'            Mode 5 (Charge polarization of heavy fragment assumed to be equal to light fragment in S2 in the actinides) '/
                      For I_short = 10 To I_A_CN - 10   ' Loop is over the "second" (heavy) fragment!
                        ZUCD = Csng(I_short) / Csng(I_A_CN) * Csng(I_Z_CN)
                        Z = ZUCD /' Charge polarisation is here neglected '/
                        beta1 = Beta(5,1,CInt(I_Z_CN-Z))   ' light fragment
                        beta2 = Beta(5,2,CInt(Z))          ' heavy fragment      
                        Z2 = Z_equi(I_Z_CN,I_short, I_A_CN-I_short, beta2, beta1, dneck,5)
                        Z2 = Z2 + POLARadd
                        Zmean(5,2,I_short) = Z2
                        Zshift(5,2,I_short) = Z2 - ZUCD        ' neutron deficient
                        Zmean(5,1,I_A_CN - I_short) = Csng(I_Z_CN) - Z2  
                        Zshift(5,1,I_A_CN - I_short) = ZUCD - Z2  ' neutron rich at shell
    
    /'
                        Print "I","Zshift(2,1,I)",I,Zshift(2,1,I)    
                        Print "I","Zshift(2,2,I)",I,Zshift(2,2,I)    
                        Print "I","Zshift(4,1,I)",I,Zshift(4,1,I)    
                        Print "I","Zshift(4,2,I)",I,Zshift(4,2,I)    
                        Print "I","Zshift(5,1,I)",I,Zshift(5,1,I)    
                        Print "I","Zshift(5,2,I)",I,Zshift(5,2,I)    
                        Next
                        Sleep '/
        
                      Next I_short
                    End If
    '               Sleep    
    
    
        /'          General relations between Z and A of fission channels '/
                    If B_keep = 0 Then
        '             Mode 0
                      RZpol = 0
                      For I_short = 1 To 3
                        RA = (ZC_Mode_0 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                        RZpol = Zshift(0,2,CInt(RA))  ' heavy fragment
                      Next I_short
                      AC_Mode_0 = (ZC_Mode_0 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN) /' mean position in mass '/
                      NC_Mode_0 = AC_Mode_0 - ZC_Mode_0
    
        '             Mode 1
                      RZpol = 0
                      For I_short = 1 To 3
                        RA = (ZC_Mode_1 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                        RZpol = Zshift(1,2,CInt(RA))  ' heavy fragment
                      Next I_short
                      AC_Mode_1 = (ZC_Mode_1 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                      NC_Mode_1 = AC_Mode_1 - ZC_Mode_1
        
        '             Mode 2
                      RZpol = 0
                      For I_short = 1 To 3
                        RA = (ZC_Mode_2 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                        RZpol = Zshift(2,2,CInt(RA)) ' heavy fragment
                      Next I_short
                      AC_Mode_2 = (ZC_Mode_2 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                      NC_Mode_2 = AC_Mode_2 - ZC_Mode_2
    
          '           Mode 3    
                      RZpol = 0
                      For I_short = 1 To 3
                        RA = (ZC_Mode_3 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                        RZpol = Zshift(3,2,CInt(RA))  ' heavy fragment
                      Next I_short
                      AC_Mode_3 = (ZC_Mode_3 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                      NC_Mode_3 = AC_Mode_3 - ZC_Mode_3
     
        '             Mode 4
                      RZpol = 0
                      For I_short = 1 To 3
                        RA = (ZC_Mode_4 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                        RZpol = Zshift(4,1,CInt(RA)) ' light fragment
                      Next I_short
                      AC_Mode_4 = (ZC_Mode_4 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)  ' light fragment
                      NC_Mode_4 = AC_Mode_4 - ZC_Mode_4   ' light fragment
    
          '           Mode 5
                      RZpol = 0
                      For I_short = 1 To 3
                        RA = (ZC_Mode_5 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                        RZpol = Zshift(5,1,CInt(RA)) ' light fragment
                      Next I_short
                      AC_Mode_5 = (ZC_Mode_5 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)  ' light fragment
                      NC_Mode_5 = AC_Mode_5 - ZC_Mode_5   ' light fragment
                    End If
    
        /'          Potential curvatures of fission modes '/
    
       '            For the width of the mass distribution (potential between saddle and scission):
                    R_Z_Curv_S0 = 8.E0 / Csng(I_Z_CN)^2 * Masscurv(Csng(I_Z_CN), Csng(I_A_CN), Spin_CN, kappa, kappa4)
       '            For the yields of the fission channels (potential near saddle):
                    R_Z_Curv1_S0 = 8.E0 / Csng(I_Z_CN)^2 * Masscurv1(Csng(I_Z_CN), Csng(I_A_CN), 0.0, kappa, kappa4)
                    R_A_Curv1_S0 = 8.E0 / Csng(I_A_CN)^2 * Masscurv1(Csng(I_Z_CN), Csng(I_A_CN), 0.0, kappa, kappa4)
                    R_Z_Curv2_S0 = 8.E0 / Csng(I_Z_CN)^2 * Masscurv2(Csng(I_Z_CN), Csng(I_A_CN), 0.0, kappa, kappa4)
                    R_A_Curv2_S0 = 8.E0 / Csng(I_A_CN)^2 * Masscurv2(Csng(I_Z_CN), Csng(I_A_CN), 0.0, kappa, kappa4)
    '               Print 5229,"R_A_Curv1_S0",R_A_Curv1_S0
    '               sleep    
      /'>'/  
    
        /'          Energy transformation '/
                    R_E_exc_Eb = R_E_exc_used - BFTFB(Csng(I_Z_CN),Csng(I_A_CN),1)
                    R_E_exc_GS = R_E_exc_used 
      /'<'/   
       
        /'          Fission barriers -> global parameters '/
       
                    B_F = BFTF(Csng(I_Z_CN),Csng(I_A_CN),1)   
                    B_F_ld = BFTF(Csng(I_Z_CN),Csng(I_A_CN),0)
                    E_B = BFTFB(Csng(I_Z_CN),Csng(I_A_CN),1)   
                    E_B_ld = BFTFB(Csng(I_Z_CN),Csng(I_A_CN),0)
                    E_A = BFTFA(Csng(I_Z_CN),Csng(I_A_CN),1)
                    DE_AB = E_B - E_A
        
        /'          Barriers and excitation energies of the fission modes '/
    
                    E_exc_S0_prov = R_E_exc_Eb
    
        /'          Additional influence of N=82 assumed '/
                    Delta_NZ_Pol = 82.E0/50.E0 - Csng(I_N_CN)/Csng(I_Z_CN)
                    R_Shell_S1_eff = P_Shell_S1 * (1.0 - P_Att_rel * P_Att_Pol * Abs(Delta_NZ_Pol))
  ' next line commented on 16. Feb. 2026
    '               If R_Shell_S1_eff < -2.06 Then R_Shell_S1_eff = -2.06  ' adjusted to U238F
    '               Print 5862,P_Shell_S1,R_Shell_S1_eff    
                    R_Shell_S1_eff = Min(R_Shell_S1_eff,P_Shell_S1 * 0.5) 'Min: contribution of Z=50
    '               R_Shell_S1_eff = R_Shell_S1_eff * 1.1   ' only for testing  U238F
    '               Print 5864,"Delta_NZ_Pol,P_Shell_S1, R_Shell_S1_eff",Delta_NZ_Pol,P_Shell_S1,R_Shell_S1_eff    
    '               Print 5874, (1.0 - P_Att_rel * P_Att_Pol * Abs(Delta_NZ_Pol)), Delta_NZ_Pol
    '               Print 5875, R_Shell_S1_eff
    '               sleep    
     
     '              R_Shell_S1_eff = P_Shell_S1 * _
     '                    max(1.0 - P_att_rel,(1.0 - P_att_rel* _
     '                    ( Abs(Delta_NZ_Pol)/P_Att_Pol  + (Delta_NZ_Pol/P_Att_Pol2)^2 _
     '                    + Abs(Delta_NZ_Pol/P_Att_Pol3)^3)))
     '              Print "4335 "; max(1.0 - P_att_rel,(1.0 - P_att_rel* _
     '                    ( Abs(Delta_NZ_Pol)/P_Att_Pol  + (Delta_NZ_Pol/P_Att_Pol2)^2 _
     '                    + Abs(Delta_NZ_Pol/P_Att_Pol3)^3)))
     '              Print  Abs(Delta_NZ_Pol)/P_Att_Pol, _
     '                    (Delta_NZ_Pol/P_Att_Pol2)^2, _
     '                    Abs(Delta_NZ_Pol/P_Att_Pol3)^3
    '               sleep                     
        
        /'          In Pu, the Z=50 shell meets Z=44 in the light fragment. '/
        /'          A deformed shell at Z=44 is assumed to explain the enhancement _ 
                    of the S1 channel around Pu '/
        /'          This very same shell automatically produces the double-humped '/
        /'          mass distribution in 180Hg '/   
    '               S1_enhance = P_Shell_SL5 + _
    '                 (Csng(I_Z_CN) - ZC_Mode_1 - ZC_Mode_SL5)^2 * P_Z_Curv_SL5 
          '         50 instead of ZC_Mode_1, to eliminate the influenc of the mass 
          '           (in agreement with experiment, e.g. 238U(nfast,f) ):
    
    '               2. 12. 2023 kommentiert zum Testen
                    S1_enhance = P_Shell_SL5 + _
                      (Csng(I_Z_CN) - 50.0 - ZC_Mode_SL5 + P_DZ_Mean_SL5)^2 * P_Z_Curv_SL5 
    
     '              S1_enhance = P_Shell_SL5 * _
     '                U_Gauss_abs(Csng(I_Z_CN) - 50.0 - 0.3 - ZC_Mode_SL5,P_Z_Sigma_SL5)
    '                 Print "4396: U_Gauss_abs";S1_enhance/P_Shell_SL5,R_SHell_S1_eff
    '               sleep        
    
     '              S1_enhance = P_Shell_SL5 + _
     '                (Csng(I_Z_CN) - ZC_Mode_1 - ZC_Mode_SL5)^2 * P_Z_Curv_SL5 
                    If S1_enhance > 0 Then S1_enhance = 0
    
        '           Special treatment for nuclei with low E* at scission
     '              If P_Z_CN = 91 Then S1_enhance = S1_enhance + 0.3  ' Suppress S1
     '              If P_Z_CN = 90 Then S1_enhance = S1_enhance + 0.6  ' Suppress S1
                  
     '              Print "4384 "; P_Shell_SL5, U_Gauss(Csng(I_Z_CN) - 50.0 - ZC_Mode_SL5,0.3), S1_enhance   
     '              sleep
    
    '               Print "ZC_Mode_1,ZC_Mode_4",ZC_Mode_1,ZC_Mode_4
    '               Print "Delta-Z S1-S4, S1_enhance",I_Z_CN-ZC_Mode_1 - ZC_Mode_SL5, S1_enhance      
                    R_Shell_S1_eff = R_Shell_S1_eff + S1_enhance
    '               Print 5920,I_Z_CN-ZC_Mode_1-ZC_Mode_SL5, S1_enhance,R_Shell_S1_eff
    
        /'          The high TKE of S1 in 242Pu(sf) (and neighbours) is obtained by assuming '/
        /'          that the Z=44 shell reduces the deformation of the light fragment. '/
                    For I = 10 To I_Z_CN - 10
                      Z1 = Csng(I)
                      A1 = (Z1 - 0.5E0) / Csng(I_Z_CN) * Csng(I_A_CN) /' polarization roughly considered '/
      '               Beta(1,1,Z1) = Beta(1,1,Z1) + 0.15 * S1_enhance   /' "light" fragment '/
                      Beta(1,1,I) = exp(S1_enhance) * Beta(1,1,I) _
                           + (1.E0-exp(S1_enhance)) * (Beta(1,1,I)-0.25)
                      Beta(1,1,I) = Max(Beta(1,1,I),0.0)
                      E_defo = Lymass(Z1,A1,Beta(1,1,I)) - Lymass(Z1,A1,0.0)
                      Edefo(1,1,I) = E_defo /' "light" fragment '/
                    Next I   
    
       '            Influence of S2 shell in complementary fragment
       '            May be called "S12 fission channel"
                    T_Asym_Mode_2 = 0.5
                    SigZ_Mode_2 = Sqr(0.5E0 * T_Asym_Mode_2/(P_Z_Curv_S2))
                    SigA_Mode_2 = SigZ_Mode_2 * Csng(I_A_CN) / Csng(I_Z_CN)
                    S1_enhance_S2 = P_Shell_S2 * U_Box(Csng(P_A_CN) - AC_Mode_2 - AC_Mode_1, _
                    SigA_Mode_2,P_A_Width_S2) *P_A_Width_S2
    
                    If S1_enhance_S2 < 0.01 Then 
     '                Print "S1_enhance_S2 ";S1_enhance_S2  
                      R_Shell_S1_eff = R_Shell_S1_eff + S1_enhance_S2
                    End If   
      
                    R_Shell_S2_eff = P_Shell_S2     
        
                    R_Shell_S3_eff = P_Shell_S3
        '           Overlap of S3 and shell in light fragment  
    '               R_Shell_S3_eff = P_Shell_S3 * (1.0 - 0.8* PZ_S3_olap_curv _
    '                 * (Csng(I_Z_CN) - ZC_Mode_3 - PZ_S3_olap_pos)^2)
    '               Print "4450 "; P_Shell_S3 * (1.0 - 0.8 * PZ_S3_olap_curv _
    '                 * (Csng(I_Z_CN) - ZC_Mode_3 - PZ_S3_olap_pos)^2) , ZC_Mode_3 
    '               sleep            
     '              R_Shell_S3_eff = -5.605
    '                 * (Csng(I_Z_CN) - 60.5E0 - PZ_S3_olap_pos)^2)
                    R_Shell_S3_eff = Min(R_Shell_S3_eff,0.0)    
        
    '               Additional empirical dependence on N/Z  
    '               R_Shell_S3_eff = R_Shell_S3_eff - _
    '               1 * ( (I_A_CN-I_Z_CN)/I_Z_CN - (236-92)/92)  
    '               5 * ( (I_A_CN-I_Z_CN)/I_Z_CN - (236-92)/92)  
    
                    R_Shell_S4_eff = P_Shell_S4     ' Z around 82
         
                    R_Shell_S5_eff = 2.0 * (P_Shell_S5 + P_Z_Curv_S5 * (ZC_Mode_5 - ZC_Mode_0)^2)     
           '        overlap of S5 in both fragments       
                    If R_Shell_S5_eff > P_Shell_S5 Then R_Shell_S5_eff = P_Shell_S5 
           '        no overlap at large distance
    
                    E_ld_S1 = R_A_Curv1_S0 * (Csng(I_A_CN)/Csng(I_Z_CN)*(ZC_MODE_1 - ZC_MODE_0) )^2
                    DZ_asym = ABS(ZC_MODE_1 - ZC_MODE_0)
                    If DZ_asym > 12 Then E_ld_S1 = E_ld_S1 + 1.0 * (DZ_asym - 12.5) ' deviaton from parabola asssumed
                    B_S1 = E_ld_S1 + R_Shell_S1_eff
                    E_exc_S1_prov = E_Exc_S0_prov - B_S1
    
                    E_ld_S2 = R_A_Curv1_S0 * (Csng(I_A_CN)/Csng(I_Z_CN)*(ZC_MODE_2 - ZC_MODE_0) )^2
                    DZ_asym = ABS(ZC_MODE_2 - ZC_MODE_0)
                    If DZ_asym > 12 Then E_ld_S2 = E_ld_S2 + 1.0 * (DZ_asym - 12.5) ' deviaton from parabola asssumed
                    B_S2 = E_ld_S2 + R_Shell_S2_eff
                    E_exc_S2_prov = E_Exc_S0_prov - B_S2   
    
                    E_ld_S3 = R_A_Curv1_S0 * (Csng(I_A_CN)/Csng(I_Z_CN)*(ZC_MODE_3 - ZC_MODE_0) )^2
                    DZ_asym = ABS(ZC_MODE_3 - ZC_MODE_0)
                    If DZ_asym > 12 Then E_ld_S3 = E_ld_S3 + 1.0 * (DZ_asym - 12.5) ' deviaton from parabola asssumed
                    B_S3 = E_ld_S3 + R_Shell_S3_eff
                    E_exc_S3_prov = E_Exc_S0_prov - B_S3 
    
                    E_ld_S4 = R_A_Curv1_S0 * (Csng(I_A_CN)/Csng(I_Z_CN)*(ZC_MODE_4 - ZC_MODE_0) )^2
                    DZ_asym = ABS(ZC_MODE_4 - ZC_MODE_0)
                    If DZ_asym > 12 Then E_ld_S4 = E_ld_S4 + 1.0 * (DZ_asym - 12.5) ' deviaton from parabola asssumed
                    B_S4 = E_ld_S4 + R_Shell_S4_eff
                    E_exc_S4_prov = E_Exc_S0_prov - B_S4 
    
                    If I_A_CN < 220 Then  ' Only here S5 is close enough to symmetry to have a chance
                      E_ld_S5 = R_A_Curv2_S0 * (Csng(I_A_CN)/Csng(I_Z_CN)*(ZC_MODE_5 - ZC_MODE_0) )^2
                      R_Shell_S5_eff = R_Shell_S5_eff * (1.0 + P_S5_mod * (Csng(I_A_CN-I_Z_CN) - (112)) ) ' variation with N
                      B_S5 = E_ld_S5 + R_Shell_S5_eff
                      E_exc_S5_prov = E_Exc_S0_prov - B_S5 
                    Else
                      B_S5 = 9999
                      E_exc_S5_prov = - 9999  
                    End If
        
        /'          Mode 11 (overlap of channel 1 in light and heavy fragment '/
        /'          Potential depth with respect to liquid-drop potential: B_S11 '/
     '              B_S11 = 2.E0 * (R_Shell_S1_eff + De_Defo_S1 _
     '                + P_Z_Curv_S1 * (ZC_Mode_1 - ZC_Mode_0)^2 ) - De_Defo_S1 
                    B_S11 = 2.E0 * (R_Shell_S1_eff  _
                      + P_Z_Curv_S1 * (ZC_Mode_1 - ZC_Mode_0)^2 )  
              '     Sum of S1 shells in both fragments exact at symmetry    
                    DES11ZPM = 0             
           '        The S1 shells in the two fragments must be rather close to form  one pocket:
                    If B_S11 < R_Shell_S1_eff + Level_S11 Then  
            '         Lowering of the zero-point motion grows with the width of the potential pocket:
                      DES11ZPM = -1.45 * Abs(ZC_Mode_1 - ZC_Mode_0)  ' Fits the mass distr. of 258Fm(sf)
        '             From GEF-2015/V2-3, without Leve_S11:
    '                 DES11ZPM = - Min(0.6 * (Abs(ZC_Mode_1 - ZC_Mode_0)),4.E0*P_Z_Curv_S1)
                    End If 
    
    /' 
                    Print 6050, "B_S11,DES11ZPM",B_S11,DES11ZPM    
                    Print "R_Shell_S1_eff,Level_S11",R_Shell_S1_eff,Level_S11
                    Sleep      '/
    
                    B_S11 = B_S11 + DES11ZPM
    
                    E_exc_S11_prov = E_Exc_S0_prov - B_S11
    
    
        /'          Mode 22 (overlap of channel 2 in light and heavy fragment '/
        /'          Potential depth with respect to liquid-drop potential: B_S22 '/
    
        '           First approach: flat top included in B_S22
     /'             B_S22 = 2.E0 * R_Shell_S2_eff  * _
                    U_Box(Csng(I_A_CN)/2.0 - AC_Mode_2, _
                    SigA_Mode_2,P_A_Width_S2) * P_A_Width_S2
                 '  The integral of U_Box is normalized, not the height!  '/
                 
         '          Second approach, only Gaussian included in B_S22
                    B_S22 = 2.E0 * (R_Shell_S2_eff  _
                      + 2.0 * P_Z_Curv_S2 * (ZC_Mode_2 - ZC_Mode_0)^2 )      
     '                + sqr(2.0) * P_Z_Curv_S2 * (ZC_Mode_2 - ZC_Mode_0)^2 )      
                 
     '              If I_A_CN < 226 Then B_S22 = 9999 
    
                    E_exc_S22_prov = E_Exc_S0_prov - B_S22
    
                    E_Min_Barr = Min(0.0,B_S1)
                    E_Min_Barr = Min(E_Min_Barr,B_S2)
                    E_Min_Barr = Min(E_Min_Barr,B_S3)
                    E_Min_Barr = Min(E_Min_Barr,B_S4)
                    E_Min_Barr = Min(E_Min_Barr,B_S5)
                    E_Min_Barr = Min(E_Min_Barr,B_S11)
                    E_Min_Barr = Min(E_Min_Barr,B_S22)
        
        
        /'          Energy minus the height of the respective fission saddle '/
                    E_exc_S0 = E_exc_S0_prov + E_Min_Barr - Delta_S0
                    E_exc_S1 = E_exc_S1_prov + E_Min_Barr
                    E_exc_S2 = E_exc_S2_prov + E_Min_Barr
                    E_exc_S3 = E_exc_S3_prov + E_Min_Barr
                    E_exc_S4 = E_exc_S4_prov + E_Min_Barr
                    E_exc_S5 = E_exc_S5_prov + E_Min_Barr
                    E_exc_S11 = E_exc_S11_prov + E_Min_Barr
                    E_exc_S22 = E_exc_S22_prov + E_Min_Barr
        
    '               Print 5765, "E_exc_S1"; E_exc_S1    
    '               Print 6012, "E_exc_S2", E_exc_S2    
    '               Print 5765, E_exc_S3    
    '               Print 5765, E_exc_S4    
    '               Print 5765, E_exc_S5    
    '               Print 5765, E_exc_S11    
    '               Print 6017, "E_exc_S22"; E_exc_S22    
    
        
        /'          Energy above the lowest fission saddle '/
                    E_exc_Barr = Max(E_Exc_S0,E_Exc_S1)
                    E_exc_Barr = Max(E_exc_Barr,E_Exc_S2)
                    E_exc_Barr = Max(E_exc_Barr,E_Exc_S3)
                    E_exc_Barr = Max(E_exc_Barr,E_Exc_S4)
                    E_exc_Barr = Max(E_exc_Barr,E_Exc_S5)
                    E_exc_Barr = Max(E_exc_Barr,E_exc_S11)
                    E_exc_Barr = Max(E_exc_Barr,E_exc_S22)
        
    
        /'          Collective temperature used for calculating the widths
                    in mass asymmetry and charge polarization '/
    
                    If E_Exc_S0 < 0 Then E_tunn = -E_Exc_S0 Else E_tunn = 0
                    If E_Exc_S1 < 0 Then E_tunn_S1 = - E_Exc_S1 Else E_tunn_S1 = 0
                    If E_Exc_S2 < 0 Then E_tunn_S2 = - E_Exc_S2 Else E_tunn_S2 = 0
                    If E_Exc_S3 < 0 Then E_tunn_S3 = - E_Exc_S3 Else E_tunn_S3 = 0
                    If E_Exc_S4 < 0 Then E_tunn_S4 = - E_Exc_S4 Else E_tunn_S4 = 0
                    R_E_exc_eff = Max(0.1,E_Exc_S0)
      '             T_Coll_Mode_0 = TFCOLL * R_E_exc_eff + _  /' empirical, replaced by TRusanov '/
                    T_Coll_Mode_0 = TCOLLFRAC * (De_Saddle_Scission(Csng(I_Z_CN), _ 
                      Csng(I_A_CN),ESHIFTSASCI_coll) - E_tunn)
                    T_Coll_Mode_0 = Max(T_Coll_Mode_0,0.0)
    
        /'          Temperature description fitting to the empirical systematics of Rusanov et al. '/
        /'          Here from Ye. N. Gruzintsev et al., Z. Phys. A 323 (1986) 307 '/    
        /'          Empirical description of the nuclear temperature according to the '/
        /'          Fermi-gas description. Should be valid at higher excitation energies '/
                    Dim As Single T_Rusanov
                    T_Rusanov = TRusanov(R_E_exc_eff,Csng(I_A_CN)) 
    '               Print "Temperatures, (GEF, Total, Rusanov): ", T_Coll_Mode_0, TFCOLL * R_E_exc_eff, T_Rusanov
    '               Print "R_E_exc_eff ",R_E_exc_eff
    
                    T_Coll_Mode_0 = Max(T_Coll_Mode_0,T_Rusanov)
        /'          Transition vom const. temp. to Fermi gas occurs around 20 MeV by MAX function '/
    '               T_Pol_Mode_0 = T_Pol_Red * T_Coll_Mode_0
    
        '           Application of the statistical model, intrinsic temperature at saddle
                    T_Pol_Mode_0 = U_Temp(0.5 * Csng(I_Z_CN),0.5 *Csng(I_A_CN), R_E_exc_eff, 0, 0, Tscale, Econd, Etrans)
    '               T_Asym_Mode_0 = Sqr(T_Coll_Mode_0^2 + (6E0*TCOLLMIN)^2)  
                    T_Asym_Mode_0 = Sqr(T_Coll_Mode_0^2 + (1.0*TCOLLMIN)^2)  
    '               Print "4124: T_Coll_Mode_0, TCOLLMIN"; T_Coll_Mode_0, TCOLLMIN
    '               sleep  
    
                    E_pot_scission = (De_Saddle_Scission(Csng(I_Z_CN), _ 
                    Csng(I_A_CN),ESHIFTSASCI_intr) - E_tunn) + Epot_shift 
                    E_diss_Scission = EDISSFRAC * E_pot_scission        
    '               Print "4054:";EDISSFRAC,E_pot_scission,E_diss_Scission                      
    
        /'          Suppression of S1 fission channel at very low excitation energy at scission '/
        /'          The idea behind is that the binding energy at scission is such that the
                    scission configuration cannot be reached with the available excitation energy. '/
     '              EeffS1 = Max(E_exc_S1,0.0) + EDISSFRAC * E_pot_scission
     '              EeffS1 = Max(0.0,EeffS1)
    
    '               Print "4104", U_Mass(I_Z_CN,I_A_CN); _
    '                 2 * U_Mass(I_Z_CN/2.0,I_A_CN/2.0) + 1.44*(I_Z_CN/2.0)^2 / _
    '                 (1.5 * ( (I_A_CN/2)^0.333333 + (I_A_CN/2)^0.333333) + dneck ); EeffS1, _
    '                 - 2 * U_Mass(I_Z_CN/2.0,I_A_CN/2.0) - 1.44*(I_Z_CN/2.0)^2 / _
    '                 (1.5 * ( (I_A_CN/2)^0.333333 + (I_A_CN/2)^0.333333) + dneck ) + _
    '                 + Max(E_exc_S1,0.0) + EDISSFRAC * E_pot_scission _     
    '                 + U_Mass(I_Z_CN,I_A_CN)           
     '              EeffS1 = - 2 * U_Mass(I_Z_CN/2.0,I_A_CN/2.0) - 1.44*(I_Z_CN/2.0)^2 / _
     '                (1.6 * ( (I_A_CN/2)^0.333333 + (I_A_CN/2)^0.333333) + dneck ) + _
     '                Max(E_exc_S1,0.0) + EDISSFRAC * E_pot_scission _     
     '                + U_Mass(I_Z_CN,I_A_CN)     
     '              If EeffS1 < ETHRESHSUPPS1 Then
     '                + 2.E0 * ESIGSUPPS1 Then 
     '                E_exc_S1 = E_exc_S1 + EeffS1 - ETHRESHSUPPS1
     '                0.5E0 * 1.5 * 12.E0 / Sqr(132.E0) * Gaussintegral(ETHRESHSUPPS1 - EeffS1,ESIGSUPPS1)
    ''                0.5E0 * 4.E0 * 12.E0 / Sqr(132.E0) * Gaussintegral(ETHRESHSUPPS1 - EeffS1,ESIGSUPPS1)
     '              End If
     '              If EeffS2 < ETHRESHSUPPS1 + 2.E0 * ESIGSUPPS1 Then
     '                E_exc_S1 = E_exc_S1 - _
     '                  0.5E0 * 1.5 * 12.E0 / Sqr(132.E0) * Gaussintegral(ETHRESHSUPPS1 - EeffS2,ESIGSUPPS1)
     '                  0.5E0 * 4.E0 * 12.E0 / Sqr(132.E0) * Gaussintegral(ETHRESHSUPPS1 - EeffS2,ESIGSUPPS1)
     '              EndIf
    
     '                T_low_S1_used = T_low_S1 + (0.38 - 0.31) /  (38.111 - 35.563) * (38.111 - Csng(I_Z_CN)^2 / Csng(I_A_CN)) 

           '          for better reproduction of nu_bar for xxxPu(sf)
                      If I_Z_CN >= 94 Then
                        T_low_S1_used = T_low_S1 * ( 1.0 + 0.05 * (98.0 - Csng(I_Z_CN) ) )
                      Else
                        T_low_S1_used = T_low_S1 * ( 1.0 + 0.05 * (98.0 - Csng(94) ) )  ' for 238U(sf)
                      End If

                  ' Variation of "thickness" of outer barrier (values in equation between 238U and 252Cf)
    '               Print 6148, T_low_S1, T_low_S1_used , I_Z_CN^2/I_A_CN , I_Z_CN, I_A_CN 
    '               sleep   
        
                    T_Coll_Mode_1 = TFCOLL * Max(E_exc_S1,0.E0) + _
                      TCOLLFRAC * (De_Saddle_Scission(Csng(I_Z_CN), _
                      Csng(I_A_CN),ESHIFTSASCI_coll) - E_tunn)
                    T_Coll_Mode_1 = Max(T_Coll_mode_1,0.0)
    '               T_Pol_Mode_1 = T_Pol_Red * T_Coll_Mode_1
                    T_Pol_Mode_1 = T_Pol_Mode_0
                    T_Asym_Mode_1 = Sqr(T_Coll_Mode_1^2 + (4.0*TCOLLMIN)^2)  ' TCOLLMIN for ZPM
    
                    T_Coll_Mode_2 = TFCOLL * Max(E_exc_S2,0.E0) + _
                      TCOLLFRAC * (De_Saddle_Scission(Csng(I_Z_CN), _ 
                      Csng(I_A_CN),ESHIFTSASCI_coll) - E_tunn)
                    T_Coll_Mode_2 = Max(T_Coll_mode_2,0.0)
    '               T_Pol_Mode_2 = T_Pol_Red * T_Coll_Mode_2
                    T_Pol_Mode_2 = T_Pol_Mode_0
    '               T_Asym_Mode_2 = Sqr(T_Coll_Mode_2^2 + TCOLLMIN^2)
                    T_Asym_Mode_2 = Sqr(T_Coll_Mode_2^2 + 4*TCOLLMIN^2)
        
    '               Dim As Single T_Asym_Mode_2_dyn  ' Collective dynamical effect ?  
    '               T_Asym_Mode_2_dyn = 0.009 * (I_Z_CN^2/(I_A_CN^0.333333) - 92.0^2/(238^0.333333) )
    '               T_Asym_Mode_2 = Sqr(T_Asym_Mode_2^2 + T_Asym_Mode_2_dyn^2)
    
    /'              T_Coll_Mode_3 = TFCOLL * Max(E_exc_S3,0.E0) + _
                      TCOLLFRAC * (De_Saddle_Scission(Csng(I_Z_CN), _ 
                      Csng(I_A_CN),ESHIFTSASCI_coll) - E_tunn)
                    Print 4954, TFCOLL * Max(E_exc_S3,0.E0),TCOLLFRAC * (De_Saddle_Scission(Csng(I_Z_CN), _ 
                      Csng(I_A_CN),ESHIFTSASCI_coll) - E_tunn),  _
                    TCOLLFRAC * (De_Saddle_Scission(Csng(I_Z_CN), _ 
                      Csng(I_A_CN),ESHIFTSASCI_coll) ),E_exc_S3, _
                    TCOLLFRAC * 0.03 * (De_Saddle_Scission(Csng(I_Z_CN), _ 
                      Csng(I_A_CN),ESHIFTSASCI_coll) )^2           
                    sleep '/  
    '               T_coll_Mode_3 = 0.2     ' for 239Pu(nth,f)
    '               T_coll_Mode_3 = 0.7     ' for 252Cf(sf)
    '               Fit to 239Pu(nth,f) and 252Cf(sf) ( unexpectedly large variation with Z^2/A^(1/3) )
                    T_Coll_Mode_3 = TFCOLL * Max(E_exc_S3,0.E0) + _ 
                    TCOLLFRAC * 0.03 * (De_Saddle_Scission(Csng(I_Z_CN), _ 
                    Csng(I_A_CN),ESHIFTSASCI_coll) )^2           
                    T_Coll_Mode_3 = Max(T_Coll_mode_3,0.0)
    '               T_Pol_Mode_3 = T_Pol_Red * T_Coll_Mode_3
                    T_Pol_Mode_3 = T_Pol_Mode_0
                    T_Asym_Mode_3 = Sqr(T_Coll_Mode_3^2 + TCOLLMIN^2)   '!!!
        '           Dim As Single T_Asym_Mode_3_dyn    
        '           Adjusted to the width of Mode 3 in 252Cf(sf)
        '           May be, this is a collective dynamic effect along the fission path
    '               T_Asym_Mode_3_dyn = 0.009 * (I_Z_CN^2/(I_A_CN^0.333333) - 92.0^2/(238^0.333333) )
    '               T_Asym_Mode_3_dyn = 0   
    '               T_Asym_Mode_3 = Max(T_Asym_Mode_3,T_Asym_Mode_3_dyn)
    '               T_Asym_Mode_3 = Sqr(T_Asym_Mode_3^2 + T_Asym_Mode_3_dyn^2)
        
    '               Print "4619: ";T_Coll_Mode_3,TCOLLMIN,T_Asym_Mode_3    
    '               sleep
    
                    T_Coll_Mode_4 = TFCOLL * Max(E_exc_S4,0.E0) + _
                    TCOLLFRAC * (De_Saddle_Scission(Csng(I_Z_CN), _
                      Csng(I_A_CN),ESHIFTSASCI_coll) - E_tunn)
                    T_Coll_Mode_4 = Max(T_Coll_mode_4,0.0)
    '               T_Pol_Mode_4 = T_Pol_Red * T_Coll_Mode_4
                    T_Pol_Mode_4 = T_Pol_Mode_0
                    T_Asym_Mode_4 = Sqr(T_Coll_Mode_4^2 + 4.0*TCOLLMIN^2)  ' ZPM like S1
    
                    T_Coll_Mode_5 = TFCOLL * Max(E_exc_S5,0.E0) + _
                      TCOLLFRAC * (De_Saddle_Scission(Csng(I_Z_CN), _
                      Csng(I_A_CN),ESHIFTSASCI_coll) - E_tunn)
                    T_Coll_Mode_5 = Max(T_Coll_mode_5,0.0)
    '               T_Pol_Mode_5 = T_Pol_Red * T_Coll_Mode_5
                    T_Pol_Mode_5 = T_Pol_Mode_0
                    T_Asym_Mode_5 = Sqr(T_Coll_Mode_5^2 + 4.0*TCOLLMIN^2)  ' ZPM like S1
    
                 /' Stiffness in polarization '/
                    RZ = Csng(I_Z_CN) * 0.5E0
                    RA = Csng(I_A_CN) * 0.5E0
                    beta1 = Beta(0,1,CInt(RZ))
                    beta2 = Beta(0,2,CInt(RZ))
                    R_Pol_Curv_S0 = ( LyMass( RZ - 1.E0, RA, beta1 ) + _
                      LyMass( RZ + 1.0E0, RA, beta2 ) + _
                      LyMass( RZ + 1.0E0, RA, beta1 ) + _
                      LyMass( RZ - 1.0E0, RA, beta2 ) + _
                      ecoul( RZ - 1.0E0, RA, beta1, _
                        RZ + 1.0E0, RA, beta2, dneck) + _
                      ecoul( RZ + 1.0E0, RA, beta1, _
                        RZ - 1.0E0, RA, beta2, dneck) - _
                      2.0E0*ecoul( RZ, RA, beta1, RZ, RA, beta2, dneck) - _
                      2.0E0*LyMass( RZ, RA, beta1 ) - _
                      2.0E0*LyMass( RZ, RA, beta2) ) * 0.5E0
    
                    P_Pol_Curv_S0 = R_Pol_Curv_S0
        
       '            Assumption: stiffenss is dominated (and thus well represented) by the macroscopic potential
                    R_Pol_Curv_S1 = R_Pol_Curv_S0
                    R_Pol_Curv_S2 = R_Pol_Curv_S0
                    R_Pol_Curv_S3 = R_Pol_Curv_S0
                    R_Pol_Curv_S4 = R_Pol_Curv_S0
                    R_Pol_Curv_S5 = R_Pol_Curv_S0
    
    
        /'          Mean values and standard deviations of fission modes '/
        
                    Dim As Single R_E_intr_S1, R_E_intr_S2, R_E_intr_S3   ' intrinsic exc. energies at barrier
                    Dim As Single R_E_intr_S4,R_E_intr_S5
                    ReDim As Single R_Att(7)                              ' attenuation of shell
                    ReDim As Single R_Att_Sad(7)     
      '             Dim As Single E_backshift 
      '             E_backshift = -3
      
    
                    SIGZ_Mode_0 = Sqr(0.5E0 * T_Asym_Mode_0/R_Z_Curv_S0)
    '               Print "5455: SIGZ_Mode_0, T_Asym_Mode_0, R_Z_Curv_S0)";SigZ_Mode_0,T_Asym_Mode_0,R_Z_Curv_S0
    '               sleep    
        
                    If T_Pol_Mode_0 > 1.E-2 Then
                      SigPol_Mode_0 = Sqr(0.25E0 * HOMPOL / R_Pol_Curv_S0 / _
                         Tanh(HOMPOL/(2.E0 * T_Pol_Mode_0)))
                    Else
                      SigPol_Mode_0 = Sqr(0.25E0 * HOMPOL / R_Pol_Curv_S0)
            /'        including influence of zero-point motion '/
                    Endif
    
                    R_E_intr_S1 = Max(E_Exc_S1+Lypair(I_Z_CN,I_A_CN),0.0)
                    R_Att(1) = exp(-R_E_intr_S1/Shell_fading)
                    R_Att(6) = R_Att(1)
                    R_Att_Sad(1) = exp(-R_E_intr_S1/Shell_fading)
                    R_Att_Sad(6) = R_Att_Sad(1)
                    SIGZ_Mode_1 = Sqr(0.5E0 * T_Asym_Mode_1/(P_Z_Curv_S1*Sqr(R_Att(1))))
                    If T_Pol_Mode_1 > 1.E-2 Then
                      SigPol_Mode_1 = Sqr(0.25E0 * HOMPOL / R_Pol_Curv_S1 / _
                         Tanh(HOMPOL/(2.E0 * T_Pol_Mode_1)))
                    Else
                      SigPol_Mode_1 = Sqr(0.25E0 * HOMPOL / R_Pol_Curv_S1)  
                    Endif
    
                    R_E_intr_S2 = Max(E_Exc_S2+Lypair(I_Z_CN,I_A_CN),0.0)
                    R_Att(2) = exp(-R_E_intr_S2/Shell_fading)
                    R_Att(7) = R_Att(2)
                    R_Att_Sad(2) = exp(-R_E_intr_S2/Shell_fading)
                    R_Att_Sad(7) = R_Att_Sad(2)
                    SIGZ_Mode_2 = Sqr(0.5E0 * T_Asym_Mode_2/(P_Z_Curv_S2*Sqr(R_Att(2))))
        
                    SIGZ_SL5 = Sqr(0.5E0 * T_Asym_Mode_2/(P_Z_Curv_SL5*Sqr(R_Att(2))))
        
                    If T_Pol_Mode_2 > 1.E-2 Then
                      SigPol_Mode_2 = Sqr(0.25E0 * HOMPOL / R_Pol_Curv_S2 / _
                         Tanh(HOMPOL/(2.E0 * T_Pol_Mode_2)))
                    Else
                      SigPol_Mode_2 = Sqr(0.25E0 * HOMPOL / R_Pol_Curv_S2)
                    End If
    
                    R_E_intr_S3 = Max(E_exc_S3+Lypair(I_Z_CN,I_A_CN),0.0)
                    R_Att(3) = exp(-R_E_intr_S3/Shell_fading)
                    R_Att_Sad(3) = exp(-R_E_intr_S3/Shell_fading)
                    SIGZ_Mode_3 = Sqr(0.5E0 * T_Asym_Mode_3/(P_Z_Curv_S3*Sqr(R_Att(3))))
                    If T_Pol_Mode_3 > 1.E-2 Then
                      SigPol_Mode_3 = Sqr(0.25E0 * HOMPOL / R_Pol_Curv_S3 / _
                         Tanh(HOMPOL/(2.E0 * T_Pol_Mode_3)))
                    Else
                      SigPol_Mode_3 = Sqr(0.25E0 * HOMPOL / R_Pol_Curv_S3)
                    End if
    
                    R_E_intr_S4 = Max(E_exc_S4+Lypair(I_Z_CN,I_A_CN),0.0)
                    R_Att(4) = exp(-R_E_intr_S4/Shell_fading)
                    R_Att_Sad(4) = exp(-R_E_intr_S4/Shell_fading)
                    SIGZ_Mode_4 = Sqr(0.5E0 * T_Asym_Mode_4/(P_Z_Curv_S4*Sqr(R_Att(4))))
                    If T_Pol_Mode_4 > 1.E-2 Then
                      SigPol_Mode_4 = Sqr(0.25E0 * HOMPOL / R_Pol_Curv_S4 / _
                         Tanh(HOMPOL/(2.E0 * T_Pol_Mode_4)))
                    Else
                      SigPol_Mode_4 = Sqr(0.25E0 * HOMPOL / R_Pol_Curv_S4)
                    End if
    
                    R_E_intr_S5 = Max(E_exc_S5+Lypair(I_Z_CN,I_A_CN),0.0)
                    R_Att(5) = exp(-R_E_intr_S5/Shell_fading)
                    R_Att_Sad(5) = exp(-R_E_intr_S4/Shell_fading)
                    SIGZ_Mode_5 = Sqr(0.5E0 * T_Asym_Mode_5/(P_Z_Curv_S5*Sqr(R_Att(5))))
                    If T_Pol_Mode_5 > 1.E-2 Then
                      SigPol_Mode_5 = Sqr(0.25E0 * HOMPOL / R_Pol_Curv_S5 / _
                         Tanh(HOMPOL/(2.E0 * T_Pol_Mode_5)))
                    Else
                      SigPol_Mode_5 = Sqr(0.25E0 * HOMPOL / R_Pol_Curv_S5)
                    End if
    
    
                    /' Energy-dependent shift of fission channels '/
                    Scope
                      Dim As Single DZ_S1,DZ_S2,DZ_S3,DZ_S4,DZ_S5
                      Dim As Single P_Z_Curv_S1_eff
                      P_Z_Curv_S1_eff = P_Z_Curv_S1 * P_Z_Curvmod_S1
                      Dim AS Single P_Z_Curv_S2_eff
                      P_Z_Curv_S2_eff = P_Z_Curv_S2 * P_Z_Curvmod_S2     
                      Dim As Single P_Z_Curv_S3_eff
                      P_Z_Curv_S3_eff = P_Z_Curv_S3 * P_Z_Curvmod_S3     
                      Dim As Single P_Z_Curv_S4_eff
                      P_Z_Curv_S4_eff = P_Z_Curv_S4 * P_Z_Curvmod_S4     
                      Dim As Single P_Z_Curv_S5_eff
                      P_Z_Curv_S5_eff = P_Z_Curv_S5 * P_Z_Curvmod_S5     
    
                      DZ_S1 = ZC_Mode_1 * _
                        (P_Z_Curv_S1_eff*R_Att(1) / (R_Z_Curv_S0 + P_Z_Curv_S1_eff*R_Att(1)) _
                      - (P_Z_Curv_S1_eff / (R_Z_Curv_S0 + P_Z_Curv_S1_eff) ) )
                      DZ_S2 =  ZC_Mode_2 * _
                        (P_Z_Curv_S2_eff*R_Att(2) / (R_Z_Curv_S0 + P_Z_Curv_S2_eff*R_Att(2)) _
                      - (P_Z_Curv_S2_eff / (R_Z_Curv_S0 + P_Z_Curv_S2_eff) ) )  
                      DZ_S3 =  ZC_Mode_3 * _
                        (P_Z_Curv_S3_eff*R_Att(3) / (R_Z_Curv_S0 + P_Z_Curv_S3_eff*R_Att(3)) _
                      - (P_Z_Curv_S3_eff / (R_Z_Curv_S0 + P_Z_Curv_S3_eff) ) )
                      DZ_S4 = ZC_Mode_4 * _
                        (P_Z_Curv_S4_eff*R_Att(4) / (R_Z_Curv_S0 + P_Z_Curv_S4_eff*R_Att(4)) _
                      - (P_Z_Curv_S4_eff / (R_Z_Curv_S0 + P_Z_Curv_S4_eff) ) )  
                      DZ_S5 = Sgn(ZC_Mode_5 - ZC_Mode_0) * ZC_Mode_5 * _
                        (P_Z_Curv_S5_eff*R_Att(5) / (R_Z_Curv_S0 + P_Z_Curv_S5_eff*R_Att(5)) _
                      - (P_Z_Curv_S5_eff / (R_Z_Curv_S0 + P_Z_Curv_S5_eff) ) )  
     
    
     '                DZ_S1 = 0
     '                DZ_S2 = 0
     '                DZ_S3 = 0
     '                DZ_S4 = 0
     '                DZ_S5 = 0
       
                      P_Z_Mean_S0 = ZC_Mode_0
                      ZC_Mode_1 = ZC_Mode_1 + DZ_S1  
                      P_Z_Mean_S1 = ZC_Mode_1          /' Copy to global parameter '/
                      ZC_Mode_2 = ZC_Mode_2 + DZ_S2  
                      P_Z_Mean_S2 = ZC_Mode_2          /'             "            '/
                      ZC_Mode_3 = ZC_Mode_3 + DZ_S3
                      P_Z_Mean_S3 = ZC_Mode_3
                      ZC_Mode_4 = ZC_Mode_4 + DZ_S4  
                      P_Z_Mean_S4 = ZC_Mode_4 
                      ZC_Mode_5 = ZC_Mode_5 + DZ_S5
                      P_Z_Mean_S5 = ZC_Mode_5          /'             "            '/
                    End Scope
        
       '            EsciS1 = Max(E_exc_S1 + E_diss_Scission,0.0)
       '            EsciS2 = Max(E_Exc_S2 + E_diss_Scission,0.0)  ' For Shape modification of S2
       '            EsciS3 = Max(E_exc_S3 + E_diss_Scission,0.0)
                    EsciS0 = E_exc_S0 + E_diss_Scission
                    EsciS1 = E_exc_S1 + E_diss_Scission
                    EsciS2 = E_Exc_S2 + E_diss_Scission  ' For Shape modification of S2
                    EsciS3 = E_exc_S3 + E_diss_Scission
                    EsciS4 = E_exc_S4 + E_diss_Scission
                    EsciS5 = E_exc_S5 + E_diss_Scission
     '              Print 6356,E_exc_S0,E_exc_S1,E_exc_S2,E_exc_S3
     '              Print 6356,EsciS0,EsciS1,EsciS2,EsciS3
     '              sleep
      '             Print
                    Scope                         
                      Dim As Single Snmac_local,Spmac_local,DS_local
                 
                      SNmac_local = Lymass(Csng(I_Z_CN),Csng(I_A_CN-1),0.0) - Lymass(Csng(I_Z_CN),Csng(I_A_CN),0.0)
                      SPmac_local = Lymass(Csng(I_Z_CN-1),Csng(I_A_CN-1),0.0) - Lymass(Csng(I_Z_CN),Csng(I_A_CN),0.0)
                      DS_local = Min(0.0,(SPmac_local - SNmac_local) * 2.0)
                      DS_local = 0  ' N/Z dependence switched off
                      EsciS1 = EsciS1 + DS_local
                      EsciS2 = EsciS2 + DS_local
                      EsciS3 = EsciS3 + DS_local
                      EsciS4 = EsciS4 + DS_local
                      EsciS5 = EsciS5 + DS_local
                    End Scope
    
      '             The following treatment is provisional
     '              If I_Z_CN <= 92 Then  ' where trippel-humped barrier appears  
     '                R_slope_S2 = 19.99 * exp(-0.7356*ESciS2) /' special shape for low E* at scission '/
     '                R_slope_S2 = Min(R_slope_S2,2.0)
     '              Else
     '                R_slope_S2 = 0
     '              End If  
    
                    DEsupp = 3.0
                    If I_Z_CN > 92 Then DEsupp = DEsupp - 0.3 * (I_Z_CN - 92)^2  
                           ' for S1 in 240Pu(sf): lowerung third barrier for Z > 92
                    R_supp_S0 = 1.0
                    R_supp_S1 = 1.0
                    R_supp_S2 = 1.0
                    R_supp_S3 = 1.0
        
                    If B_supp = 1 Then
                      Dim As Single SNmac,SPmac      
                      SNmac = Lymass(Csng(I_Z_CN),Csng(I_A_CN-1),0.0) - Lymass(Csng(I_Z_CN),Csng(I_A_CN),0.0)
                      SPmac = Lymass(Csng(I_Z_CN-1),Csng(I_A_CN-1),0.0) - Lymass(Csng(I_Z_CN),Csng(I_A_CN),0.0)  
    '                 Print 6428,Snmac,Spmac,exp(snmac-spmac)        
     '                If I_Z_CN <= 92 Then
     '                  R_supp_S0 = 1.0 - exp(-0.3*(Max(EsciS0,1.0)-0.14 ))
     '                  R_supp_S1 = 1.0 - exp(-0.3*(Max(EsciS1,1.0)-0.05 ))       
     '                  R_supp_S2 = 1.0 - exp(-0.3*(Max(EsciS2,1.0) )) 
     '                  R_supp_S3 = 1.0 - exp(-0.3*(Max(EsciS3,1.0)-0.1 )) 
                      If I_Z_CN - 50 > 36 Then    ' The transition should be softer
                        R_supp_S0 = 1.0 / ( 1.0 + exp(1.0 * DE_AB - EsciS0 - E_tunn + DEsupp))
            '           Suppression of S0 at low E* due to large deformation in the light fragment
                      End If  
          
                      R_supp_S1 = 1.0 / ( 1.0 + exp(DE_AB - EsciS1 - E_tunn_S1 + DEsupp))  
    '                 R_supp_S1 = 1.0 / ( 1.0 + exp( abs(DE_AB) - EsciS1 - E_tunn_S1 + DEsupp))  ' Test for U238F
     '                R_supp_S1 = (1.0 / ( 1.0 + exp(4.0 * DE_AB - EsciS1 - E_tunn_S1 + DEsupp)) * _
     '                  1.0 / ( 1.0 + exp(4.0 * DE_AB - EsciS1 - E_tunn_S1 + DEsupp - 1)) * _
     '                  1.0 / ( 1.0 + exp(4.0 * DE_AB - EsciS1 - E_tunn_S1 + DEsupp + 1)) )^0.333333 ' smoother transition
    '                 R_supp_S1 = 1.0 / ( 1.0 + exp(4.0 * DE_AB - EsciS1 - E_tunn_S1 + DEsupp + 0.1 * Abs(SNmac-SPmac)))  
                   
    '                 R_supp_S2 = 1.0 / ( 1.0 + exp(4.0 * DE_AB - EsciS2 - E_tunn_S2 + DEsupp)) 
    '                 R_supp_S3 = 1.0 / ( 1.0 + exp(2.0 * DE_AB - EsciS3 - E_tunn_S3 + DEsupp)) 
                      R_supp_S3 = 1.0 / ( 1.0 + exp(DE_AB - EsciS3 - E_tunn_S3 + DEsupp)) 
     '                R_slope_S2 = 2.5 * ( R_Supp_S2 - R_Supp_S3 ) * Fmod_slope_S2   ' Does not fit U238F
                      R_slope_S2 = exp( ( DE_AB - EsciS0 - E_tunn + DEsupp))
    
    '                 Print 6483, "E^intr_c_mod = ";EsciS0 - DE_AB - DEsupp
    '                 sleep
    '
                      R_slope_S2 = R_slope_S2 * Exp(2.6 * (Snmac - Spmac))   
                           ' additional dependence on neutron excess  
    
    '                 Print 6482,"E_A,E_B,DE_AB,EsciS0,EsciS0-DE_AB,Snmac,Spmac,Snmac-Spmac,R_slope_S2"
    '                 Print E_A,E_B,DE_AB,EsciS0,EsciS0-DE_AB,Snmac,Spmac,Snmac-Spmac,R_slope_S2
          
             '        SigZ_Mode_2 = SigZ_Mode_2 * sqr(sqr(R_Supp_S3))
     
    '                 SigZ_Mode_2 = SigZ_Mode_2 * ( 1 / ( 1 + 0.07 * R_slope_S2))  ' for U233T
        '             passt nicht für 226Th(em,f)
          
'                     R_supp_S3 = R_supp_S3 * 1 / (1 + 5 * R_slope_S2)       ' for U235T
                      R_supp_S3 = R_supp_S3 * Min(1.0, exp( - 7.7 * R_slope_S2^1.5))       ' for U235T and Pu239T
     '                End If
      '               If I_Z_CN <= 91 Then
     '                  If I_Z_CN <= 92 Then
         '                R_su pp_S2 = 1.0 
         '                R_supp_S2 = 1.0 - exp(-0.5*Max(EsciS2,1.0)) 
         '                R_supp_S3 = 1.0 ' 1.0 - exp(-0.5*Max(EsciS3,1.0))
    '                     Print 6299,R_supp_S1;R_supp_S2;R_supp_S3
    '                   Else
    '                   End If
                    End If  
    
        /'            Print 6610
                    Print "Suppression of yield:"     
                    Print "R_slope_S2:",R_slope_s2
                    Print "R_Supp_S0:",R_Supp_S0
                    Print "R_Supp_S1:",R_Supp_S1
                    Print "R_Supp_S2:",R_Supp_S2
                    Print "R_Supp_S3:",R_Supp_S3     
                    Print "E_exc_S0:",E_exc_S0
                    Print "E_exc_S1:",E_exc_S1
                    Print "E_exc_S2:",E_exc_S2
                    Print "E_exc_S3:",E_exc_S3
                    Print "E_exc_S4:",E_exc_S4
                    Print "E_exc_S5:",E_exc_S5
                    Print "EsciS0:",EsciS0
                    Print "EsciS1:",EsciS1
                    Print "EsciS2:",EsciS2
                    Print "EsciS3:",EsciS3
                    Print "EsciS4:",EsciS4
                    Print "EsciS5:",EsciS5
    
                    sleep  '/
    
    '               SigZ_Mode_2 = SigZ_Mode_2 * sqr(sqr(R_Supp_S3))
         
    /'>'/
    
       /'           Provide potential-energy distributions for the different modes '/
       /'           (valid only for first-chance fission) '/
                    Scope 
                      Dim As Integer I_Mode,I_first,I_last,I  
                      If (I_E_Distr = 1 _
                          And I_N_Multi = 0 _
                          And I_Z_Multi = 0 _
                          And I_E_Multi = 0) Then
                        I_first = 20
                        I_last = I_Z_CN - 20
                        For I = I_first To I_last
                          EMPot(0,I) = R_Z_Curv1_S0 * (I - ZC_Mode_0)^2
              
                          EMPot(1,I) = R_Z_Curv1_S0 * (ZC_Mode_1 - ZC_Mode_0)^2 + _
                                 Min(R_Shell_S1_eff + (P_Z_Curv_S1 + R_Z_Curv1_S0) * (I - ZC_Mode_1)^2, _
                                     R_Shell_S1_eff + (P_Z_Curv_S1 + R_Z_Curv1_S0) * (I_Z_CN - I - ZC_Mode_1)^2)
          '               If EMPot(1,I) >= EMPot(EMPot(0,I),I) Then EMPot(1,I) = EMPot(0,I)            
    
                          EMPot(2,I) = R_Z_Curv1_S0 * (ZC_Mode_2 - ZC_Mode_0)^2 + _
                                 Min(R_Shell_S2_eff + (P_Z_Curv_S2 + R_Z_Curv1_S0) * (I - ZC_Mode_2)^2, _
                                     R_Shell_S2_eff + (P_Z_Curv_S2 + R_Z_Curv1_S0) * (I_Z_CN - I - ZC_Mode_2)^2)
            '             If EMPot(2,I) >= EMPot(0,I) Then EMPot(2,I) = EMPot(0,I)              
    
                          EMPot(3,I) = R_Z_Curv1_S0 * (ZC_Mode_3 - ZC_Mode_0)^2 + _  
                                 Min(R_Shell_S3_eff + (P_Z_Curv_S3 + R_Z_Curv1_S0) * (I - ZC_Mode_3)^2, _
                                     R_Shell_S3_eff + (P_Z_Curv_S3 + R_Z_Curv1_S0) * (I_Z_CN - I - ZC_Mode_3)^2)
            '             If EMPot(3,I) >= EMPot(EMPot(0,I),I) Then EMPot(3,I) = EMPot(0,I)    
    
                          EMPot(4,I) = R_Z_Curv1_S0 * (ZC_Mode_4 - ZC_Mode_0)^2 + _  
                                 Min(R_Shell_S4_eff + (P_Z_Curv_S4 + R_Z_Curv1_S0) * (I - ZC_Mode_4)^2, _
                                     R_Shell_S4_eff + (P_Z_Curv_S4 + R_Z_Curv1_S0) * (I_Z_CN - I - ZC_Mode_4)^2)
         '                If EMPot(4,I) >= EMPot(EMPot(0,I),I) Then EMPot(4,I) = EMPot(0,I)            
    
                          EMPot(5,I) = R_Z_Curv1_S0 * (ZC_Mode_5 - ZC_Mode_0)^2 + _   
                                 Min(R_Shell_S5_eff + (P_Z_Curv_S5 + R_Z_Curv1_S0) * (I - ZC_Mode_5)^2, _
                                     R_Shell_S5_eff + (P_Z_Curv_S5 + R_Z_Curv1_S0) * (I_Z_CN - I - ZC_Mode_5)^2)
         '                If EMPot(4,I) >= EMPot(EMPot(0,I),I) Then EMPot(4,I) = EMPot(0,I)            
     
                          EMPot(6,I) = R_Z_Curv1_S0 * (ZC_Mode_1 - ZC_Mode_0)^2 + _
                                 R_Shell_S1_eff + (P_Z_Curv_S1 + R_Z_Curv1_S0) * (I - ZC_Mode_1)^2 _
                               + R_Shell_S1_eff + (P_Z_Curv_S1 + R_Z_Curv1_S0) * (I_Z_CN - I - ZC_Mode_1)^2
           '              If EMPot(6,I) >= EMPot(0,I) Then EMPot(6,I) = EMPot(0,I)            
    
                          EMPot(7,I) = R_Z_Curv1_S0 * (ZC_Mode_2 - ZC_Mode_0)^2 + _  
                                 R_Shell_S2_eff + (P_Z_Curv_S2 + R_Z_Curv1_S0) * (I - ZC_Mode_2)^2 _
                               + R_Shell_S2_eff + (P_Z_Curv_S2 + R_Z_Curv1_S0) * (I_Z_CN - I - ZC_Mode_2)^2
           '              If EMPot(7,I) >= EMPot(0,I) Then EMPot(7,I) = EMPot(0,I)           
                        Next I
                      End If
                    End Scope
    /'<'/        
    
        /'          Energy dependence of charge polarization '/
        /'          Due to washing out of shells '/
        
                    For I = 10 To I_A_CN - 10   ' mass number
                      For J = 1 To 5    ' fission channel
                        For K = 1 To 2    ' light - heavy group
                          Zshift(J,K,I) = Zshift(0,K,I) + (Zshift(J,K,I) - Zshift(0,K,I))*R_Att(J)
                        Next
                      Next    
                    Next    
        
         
        /'          Energy dependence of shell-induced deformation '/
        /'          Due to washing out of shells '/
        /'          (Under development) '/
      /'            For I = 10 To I_Z_CN - 10  ' mass number
                      For J = 1 To 5           ' fission channel
                        For K = 1 To 2         ' light - heavy group
                          beta(J,K,I) = beta(0,K,I) + (beta(J,K,I) - beta(0,K,I))*R_Att_Sad(J)
                          if beta(J,K,I) < 0 Then 
                            beta(J,K,I) = 0
                          End If  
                          Z1 = I
                          Z2 = I_Z_CN - Z1
                          A1 = Z1 / Csng(I_Z_CN) * Csng(I_A_CN)
                          A2 = I_A_CN - A1
                          E_defo = Lymass(Z1,A1,beta(J,K,I)) - Lymass(Z1,A1,0.0)
                          Edefo(J,K,I) = E_defo
                        Next
                      Next    
                    Next  '/  
        
        
    
    
          /'        General relations between Z and A of fission channels '/  
          /'        2nd iteration '/
    
                    RZpol = 0  ' calculations for the heavy fragment
                    For I = 1 To 3
                      RA = (ZC_Mode_0 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                      RZpol = Zshift(0,2,CInt(RA))
                    Next
                    AC_Mode_0 = (ZC_Mode_0 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN) /' mean position in mass '/
                    NC_Mode_0 = AC_Mode_0 - ZC_Mode_0
    
                    RZpol = 0  ' calculations for the heavy fragment
                    For I = 1 To 3
                      RA = (ZC_Mode_1 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                      RZpol = Zshift(1,2,CInt(RA))
                    Next
                    AC_Mode_1 = (ZC_Mode_1 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                    NC_Mode_1 = AC_Mode_1 - ZC_Mode_1 
    
                    RZpol = 0  ' calculations for the heavy fragment
                    For I = 1 To 3
                      RA = (ZC_Mode_2 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                      RZpol = Zshift(2,2,CInt(RA))
                    Next
                    AC_Mode_2 = (ZC_Mode_2 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                    NC_Mode_2 = AC_Mode_2 - ZC_Mode_2
         
                    RZpol = 0  ' calculations for the heavy fragment
                    For I = 1 To 3
                      RA = (ZC_Mode_3 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                      RZpol = Zshift(3,2,CInt(RA))
                    Next
                    AC_Mode_3 = (ZC_Mode_3 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                    NC_Mode_3 = AC_Mode_3 - ZC_Mode_3
    
                    RZpol = 0  ' calculations for the heavy fragment 
                    For I = 1 To 3
                      RA = (ZC_Mode_4 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                      RZpol = Zshift(4,2,CInt(RA))
                    Next
                    AC_Mode_4 = (ZC_Mode_4 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                    NC_Mode_4 = AC_Mode_4 - ZC_Mode_4
    
                    RZpol = 0  ' calculations for the light fragment
                    For I = 1 To 3
                      RA = (ZC_Mode_5 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                      RZpol = Zshift(5,1,CInt(RA))
                    Next
                    AC_Mode_5 = (ZC_Mode_5 - RZPol) * Csng(I_A_CN) / Csng(I_Z_CN)
                   NC_Mode_5 = AC_Mode_5 - ZC_Mode_5
    
       /'           Yields of the fission modes '/
       
       /'           Version with composite forumula for level densities  '/
                    Yield_Mode_0 = Getyield(E_exc_S0,E_exc_S0,0.0,0.0,T_low_SL,TEgidy(Csng(I_A_CN),0.E0,Tscale), _
                                                               TEgidy(Csng(I_A_CN),0.E0,Tscale),0)
                    Yield_Mode_0 = Yield_Mode_0 * R_supp_S0              
    
                    Yield_Mode_1 = _
                      Getyield(E_exc_S1,E_exc_S0,R_Shell_S1_eff+dE_Defo_S1,dE_Defo_S1, _
                                           T_low_S1_used,TEgidy(Csng(I_A_CN),R_Shell_S1_eff + dE_Defo_S1,Tscale), _
                                                         TEgidy(Csng(I_A_CN),0.0,Tscale),1)
                    Yield_Mode_1 = Yield_Mode_1 * R_supp_S1              
    
                    Yield_Mode_2 = _ 
                      Getyield(E_exc_S2,E_exc_S0,R_Shell_S2_eff + dE_Defo_S2, dE_Defo_S2,_
                                           T_low_S2,TEgidy(Csng(I_A_CN),R_Shell_S2_eff + dE_Defo_S2,Tscale), _
                                                    TEgidy(Csng(I_A_CN),0.0,Tscale),2)
                    Yield_Mode_2 = Yield_Mode_2 * R_supp_S2   
                      
                    Yield_Mode_3 = _ 
                      Getyield(E_exc_S3,E_exc_S0,R_Shell_S3_eff + dE_Defo_S3, dE_Defo_S3,_
                                           T_low_S3,TEgidy(Csng(I_A_CN),R_Shell_S3_eff + dE_Defo_S3,Tscale), _
                                                    TEgidy(Csng(I_A_CN),0.0,Tscale),3)
                    Yield_Mode_3 = Yield_Mode_3 * R_supp_S3    
    
                    Yield_Mode_4 = _
                      Getyield(E_exc_S4,E_exc_S0,R_Shell_S4_eff + dE_Defo_S4, dE_Defo_S4,  _
                                       T_low_S4,TEgidy(Csng(I_A_CN),R_Shell_S4_eff + dE_Defo_S4,Tscale), _
                                                TEgidy(Csng(I_A_CN),0.0,Tscale),4)
                      
                    Yield_Mode_5 = _
                      Getyield(E_exc_S5,E_exc_S0,R_Shell_S5_eff + dE_Defo_S5, dE_Defo_S5,  _
                                       T_low_S5,TEgidy(Csng(I_A_CN),R_Shell_S5_eff + dE_Defo_S5,Tscale), _
                                                TEgidy(Csng(I_A_CN),0.0,Tscale),5)
                     
                    Yield_Mode_11 = _ 
                      Getyield(E_exc_S11,E_exc_S0, R_Shell_S1_eff + 2 * dE_Defo_S1, 2 * dE_Defo_S1, _
                                           T_low_S11, TEgidy(Csng(I_A_CN),R_Shell_S1_eff + 2.E0 * dE_Defo_S1,Tscale), _
                                                      TEgidy(Csng(I_A_CN),0.0,Tscale),11)
                    If Yield_Mode_11 > Yield_Mode_1 Then  ' avoid double counting
                      Yield_Mode_1 = 0
                    Else
                      Yield_Mode_11 = 0
                    End If     
    
                    Yield_Mode_22 = _
                      Getyield(E_exc_S22,E_exc_S0, R_Shell_S2_eff + 2 * dE_Defo_S2,2 * dE_Defo_S2, _
                                           T_low_S22, TEgidy(Csng(I_A_CN),R_Shell_S2_eff + 2E0 * dE_Defo_S2,Tscale), _
                                                     TEgidy(Csng(I_A_CN),0.0,Tscale),22)
                    If Yield_Mode_22 > Yield_Mode_2 Then  ' avoid double counting
                      Yield_Mode_2 = 0
                    Else
                      Yield_Mode_22 = 0
                    End If         
                    
       /'           Version with const. temp. formula used for all energies
                    Yield_Mode_0 = Getyield(E_exc_S0,E_exc_S0,0.0,0.0,T_low_SL,TEgidy(Csng(I_A_CN),0.E0,Tscale), _
                                                               TEgidy(Csng(I_A_CN),0.E0,Tscale),0)
                    Yield_Mode_0 = Yield_Mode_0 * R_supp_S0              
    
                    Yield_Mode_1 = _
                      Getyield(E_exc_S1,E_exc_S0,R_Shell_S1_eff+dE_Defo_S1,dE_Defo_S1, _
                                           T_low_S1_used,TEgidy(Csng(I_A_CN),R_Shell_S1_eff + dE_Defo_S1,Tscale), _
                                                         TEgidy(Csng(I_A_CN),0.0,Tscale),1)
                    Yield_Mode_1 = Yield_Mode_1 * R_supp_S1              
    
                    Yield_Mode_2 = _ 
                      Getyield(E_exc_S2,E_exc_S0,R_Shell_S2_eff + dE_Defo_S2, dE_Defo_S2,_
                                           T_low_S2,TEgidy(Csng(I_A_CN),R_Shell_S2_eff + dE_Defo_S2,Tscale), _
                                                    TEgidy(Csng(I_A_CN),0.0,Tscale),2)
                    Yield_Mode_2 = Yield_Mode_2 * R_supp_S2   
                      
                    Yield_Mode_3 = _ 
                      Getyield(E_exc_S3,E_exc_S0,R_Shell_S3_eff + dE_Defo_S3, dE_Defo_S3,_
                                           T_low_S3,TEgidy(Csng(I_A_CN),R_Shell_S3_eff + dE_Defo_S3,Tscale), _
                                                    TEgidy(Csng(I_A_CN),0.0,Tscale),3)
                    Yield_Mode_3 = Yield_Mode_3 * R_supp_S3    
    
                    Yield_Mode_4 = _
                      Getyield(E_exc_S4,E_exc_S0,R_Shell_S4_eff + dE_Defo_S4, dE_Defo_S4,  _
                                       T_low_S4,TEgidy(Csng(I_A_CN),R_Shell_S4_eff + dE_Defo_S4,Tscale), _
                                                TEgidy(Csng(I_A_CN),0.0,Tscale),4)
                      
                    Yield_Mode_5 = _
                      Getyield(E_exc_S5,E_exc_S0,R_Shell_S5_eff + dE_Defo_S5, dE_Defo_S5,  _
                                       T_low_S5,TEgidy(Csng(I_A_CN),R_Shell_S5_eff + dE_Defo_S5,Tscale), _
                                                TEgidy(Csng(I_A_CN),0.0,Tscale),5)
                     
                    Yield_Mode_11 = _ 
                      Getyield(E_exc_S11,E_exc_S0, R_Shell_S1_eff + 2 * dE_Defo_S1, 2 * dE_Defo_S1, _
                                           T_low_S11, TEgidy(Csng(I_A_CN),R_Shell_S1_eff + 2.E0 * dE_Defo_S1,Tscale), _
                                                      TEgidy(Csng(I_A_CN),0.0,Tscale),11)
                    If Yield_Mode_11 > Yield_Mode_1 Then  ' avoid double counting
                      Yield_Mode_1 = 0
                    Else
                      Yield_Mode_11 = 0
                    End If     
    
                    Yield_Mode_22 = _
                      Getyield(E_exc_S22,E_exc_S0, R_Shell_S2_eff + 2 * dE_Defo_S2,2 * dE_Defo_S2, _
                                           T_low_S22, TEgidy(Csng(I_A_CN),R_Shell_S2_eff + 2E0 * dE_Defo_S2,Tscale), _
                                                     TEgidy(Csng(I_A_CN),0.0,Tscale),22)
                    If Yield_Mode_22 > Yield_Mode_2 Then  ' avoid double counting
                      Yield_Mode_2 = 0
                    Else
                      Yield_Mode_22 = 0
                    End If         '/
        
                    Yield_Norm = Yield_Mode_0 + Yield_Mode_1 + Yield_Mode_2 + Yield_Mode_3 _
                       + Yield_Mode_4 + Yield_Mode_5 + Yield_Mode_11 + Yield_Mode_22
                    Yield_Mode_0 = Yield_Mode_0 / Yield_Norm
                    Yield_Mode_1 = Yield_Mode_1 / Yield_Norm
                    Yield_Mode_2 = Yield_Mode_2 / Yield_Norm
                    Yield_Mode_3 = Yield_Mode_3 / Yield_Norm
                    Yield_Mode_4 = Yield_Mode_4 / Yield_Norm
                    Yield_Mode_5 = Yield_Mode_5 / Yield_Norm
                    Yield_Mode_11 = Yield_Mode_11 / Yield_Norm
                    Yield_Mode_22 = Yield_Mode_22 / Yield_Norm
          
                    P_selected = 1.0
    
                    Select Case I_Mode_selected
                      Case 0
                        P_selected = Yield_Mode_0
                      Case 1
                        P_selected = Yield_Mode_1
                      Case 2
                        P_selected = Yield_Mode_2
                      Case 3
                        P_selected = Yield_Mode_3
                      Case 4
                        P_selected = Yield_Mode_4       
                      Case 5
                        P_selected = Yield_Mode_5       
                      Case 6
                        P_selected = Yield_Mode_11       
                      Case 7
                        P_selected = Yield_Mode_22       
                      Case -1
                        P_selected = 1.0
                    End Select
        
        
                    If P_selected = 0 Then
                      Print "<I> Yield of the selected fission mode too low."
                      Print "    No calculation performed."
                    End If
    
          /'        Mass widhts of the fission channels '/ 
    
                    SigA_Mode_0 = SigZ_Mode_0 * Csng(I_A_CN) / Csng(I_Z_CN) /' width in mass '/
                    SigA_Mode_1 = SigZ_Mode_1 * Csng(I_A_CN) / Csng(I_Z_CN)
                    SigA_Mode_1 = Min(SigA_Mode_1,SigA_Mode_0)  ' not broader than liquid-drop
                    SigA_Mode_2 = SigZ_Mode_2 * Csng(I_A_CN) / Csng(I_Z_CN)
                    SigA_Mode_2 = Min(SigA_Mode_2,SigA_Mode_0)  ' not broader than liquid-drop
                    SigA_Mode_3 = SigZ_Mode_3 * Csng(I_A_CN) / Csng(I_Z_CN)
                    SigA_Mode_3 = Min(SigA_Mode_3,SigA_Mode_0)
                    SigA_Mode_4 = SigZ_mode_4 * Csng(I_A_CN) / Csng(I_Z_CN)
                    SigA_Mode_4 = Min(SigA_Mode_4,SigA_Mode_0)
                    SigA_Mode_5 = SigZ_mode_5 * Csng(I_A_CN) / Csng(I_Z_CN)
                    SigA_Mode_5 = Min(SigA_Mode_5,SigA_Mode_0)
                    SigA_Mode_11 = SigZ_Mode_1 * sqr(2.E0) * Csng(I_A_CN) / Csng(I_Z_CN)
                    SigA_Mode_11 = Min(SigA_Mode_11,SigA_Mode_0)
                    SigA_Mode_22 = SigZ_Mode_2 * Csng(I_A_CN) / Csng(I_Z_CN) ' * sqr(2)
                    SigA_Mode_22 = Min(SigA_Mode_22,SigA_Mode_0)
    
    
    
          /'        Shell effects of different fission channels '/
          /'        This is the "real" microscopic shell effect, not the effective shell-correction energy '/
          /'        EShell acts on the level density and determines the T parameter '/
    
                    For I = 1 To I_A_CN - 1
                      For J = 0 To 4
                        EShell(J,1,I) = 0   /' Shells in "light" fragment assumed to be zero '/
                      Next
                      DU0 = 0
                      EShell(0,2,I) = 0 /' Shell = 0 in symmetric mode '/
    
                      DU1 = R_Shell_S1_eff + dE_Defo_S1 /' + R_A_Curv1_S1 * (AC_Mode_1 - Float(I,6))**2; '/
                      DU1 = MIN(DU1,0.E0)  /' Technical limit '/
                      EShell(1,2,I) = DU1
    
                      DU2 = R_Shell_S2_eff + dE_Defo_S2 /' + R_A_Curv1_S2 * (AC_Mode_2 - Float(I,6))**2; '/
                      DU2 = Min(DU2,0.E0)  /' Technical limit '/
                      EShell(2,2,I) = DU2
    
                      DU3 = R_Shell_S3_eff + dE_Defo_S3 /' + R_A_Curv1_S3 * (AC_Mode_3 - Float(I,6))**2; '/
                      DU3 = Min(DU3,0.E0)  /' Technical limit '/
                      EShell(3,2,I) = DU3
    
                      DU4 = R_Shell_S4_eff + dE_Defo_S4 /' + R_A_Curv1_S4 * (AC_Mode_4 - Float(I,6))**2; '/
                      DU4 = Min(DU4,0.E0)  /' Technical limit '/
                      EShell(4,2,I) = DU4
    
                      DU5 = R_Shell_S5_eff + dE_Defo_S5 /' + R_A_Curv1_S5 * (AC_Mode_5 - Float(I,6))**2; '/
                      DU5 = Min(DU5,0.E0)  /' Technical limit '/
                      EShell(5,2,I) = DU5
                    Next
    
    
        /'          Intrinsic temperatures of fragments at scission '/
    
        /'          Mean values '/
                    T_intr_Mode_0 = TEgidy(AC_Mode_0,0.0,0.8)
                    T_intr_Mode_1_heavy = TEgidy(AC_Mode_1,R_Shell_S1_eff + dE_Defo_S1,Tscale)
                    T_intr_Mode_1_light = TEgidy(Csng(I_A_CN) - AC_Mode_1,0.0,Tscale)
                    T_intr_Mode_2_heavy = TEgidy(AC_Mode_2,R_Shell_S2_eff + dE_Defo_S2,Tscale)
                    T_intr_Mode_2_light = TEgidy(Csng(I_A_CN) - AC_Mode_2,0.0,Tscale)
                    T_intr_Mode_3_heavy = TEgidy(AC_Mode_3,R_Shell_S3_eff + dE_Defo_S3,Tscale)
                    T_intr_Mode_3_light = TEgidy(Csng(I_A_CN) - AC_Mode_3,0.0,Tscale)
                    T_intr_Mode_4_heavy = TEgidy(AC_Mode_4,R_Shell_S4_eff + dE_Defo_S4,Tscale)
                    T_intr_Mode_4_light = TEgidy(Csng(I_A_CN) - AC_Mode_4,0.0,Tscale)
                    T_intr_Mode_5_heavy = TEgidy(AC_Mode_5,R_Shell_S5_eff + dE_Defo_S5,Tscale)
                    T_intr_Mode_5_light = TEgidy(Csng(I_A_CN) - AC_Mode_5,0.0,Tscale)
    
    
          /'        Mass-dependent values of individual fragments '/
          /'        Mode 0 '/
                    For I = 1 To I_A_CN - 1
                      T = TEgidy(Csng(I),EShell(0,1,I),Tscale)
                      Temp(0,1,I) = T /' "light" fragment at freeze-out (somewhere before scission) '/
                      T = TEgidy(Csng(I),EShell(0,2,I),Tscale)
                      Temp(0,2,I) = T /' "heavy" fragment at freeze-out (somewhere before scission) '/
    
                      T = TEgidy(Csng(I),0.0,1.0)
                      TempFF(0,1,I) = T       ' FF in their ground state
                      TempFF(0,2,I) = T       ' FF in their ground state 
                    Next
    
          /'        Mode 1 '/
                    For I = 1 To I_A_CN - 1
                      T = TEgidy(Csng(I),EShell(1,1,I),Tscale)
                      Temp(1,1,I) = T  /' "light" fragment '/
                      T = TEgidy(Csng(I),EShell(1,2,I),Tscale)
                      Temp(1,2,I) = T  /' "heavy" fragment '/
    
                      T = TEgidy(Csng(I),0.0,1.0)
                      TempFF(1,1,I) = T       ' FF in their ground state
                      TempFF(1,2,I) = T       ' FF in their ground state
                    Next
    
        /'          Mode 2 '/
                    For I = 1 To I_A_CN - 1
                      T = TEgidy(Csng(I),EShell(2,1,I),Tscale)
                      Temp(2,1,I) = T /' "light" fragment '/
                      T = TEgidy(Csng(I),EShell(2,2,I),Tscale)
                      Temp(2,2,I) = T /' "heavy" fragment '/
    
       /'             The next section is introduced, because energy sorting is not strong enough,
                      when shells are only introduced in the heavy fragment.
                      Ad hoc assumption: For Mode 2 there are shells in both fragments of about
                      equal size. Technically, we neglect the shells in both fragments.
                      This has about the same effect for the energy sorting. '/
                      T = TEgidy(Csng(I),0.0,Tscale)   ' FF at scssion
                      Temp(2,1,I) = T /' "light" fragment '/
                      T = TEgidy(Csng(I),0.0,Tscale)   ' FF at scission
                      Temp(2,2,I) = T /' "heavy" fragment '/
    
                      T = TEgidy(Csng(I),0.0,1.0)    ' shell effect neglected
                      TempFF(2,1,I) = T    ' FFs in their ground state
                      TempFF(2,2,I) = T    ' FFs in their ground state
                    Next
        
          /'        Mode 3 '/
                    For I = 1 To I_A_CN -1
                      T = TEgidy(Csng(I),0.0,Tscale)
                      Temp(3,1,I) = T
                      T = TEgidy(Csng(I),0.0,Tscale)
                      Temp(3,2,I) = T
          
                      T = TEgidy(Csng(I),0.0,1.0)
                      TempFF(3,1,I) = T       ' FF in their ground state
                      TempFF(3,2,I) = T       ' FF in their ground state
                    Next
    
          /'        Mode 4 '/
                    For I = 1 To I_A_CN -1
                      T = TEgidy(Csng(I),0.0,Tscale)
                      Temp(4,1,I) = T
                      T = TEgidy(Csng(I),0.0,Tscale)
                      Temp(4,2,I) = T
           
                      T = TEgidy(Csng(I),0.0,1.0)
                      TempFF(4,1,I) = T       ' FF in their ground state
                      TempFF(4,2,I) = T       ' FF in their ground state
                    Next
    
                 /' Mode 5 '/
                    For I = 1 To I_A_CN -1
                      T = TEgidy(Csng(I),0.0,Tscale)
                      Temp(5,1,I) = T
                      T = TEgidy(Csng(I),0.0,Tscale)
                      Temp(5,2,I) = T
           
                      T = TEgidy(Csng(I),0.0,1.0)
                      TempFF(5,1,I) = T       ' FF in their ground state
                      TempFF(5,2,I) = T       ' FF in their ground state
                    Next
    
    
        /'**        Intrinsic excitation energy at saddle and at scission as well as   **'/
        /'**        Even-odd effect in proton and neutron number for each fission mode **'/
                    Dim As Single Etot,E1FG,E1ES
                    Dim As Single Rincr1P,Rincr1N,Rincr2,Rincr2P,Rincr2N
                    Dim As Single T1,T2,E1,E2
                    Redim As Single E_coll_saddle(0 To 7)
                    Dim As Single Ediff
    
    
                    For I_Mode = 0 To 7
                      E_coll_saddle(I_Mode) = 0
                      If I_Mode = 0 Then Etot = E_exc_S0
                      If I_Mode = 1 Then Etot = E_exc_S1
                      If I_Mode = 2 Then Etot = E_exc_S2
                      If I_Mode = 3 Then Etot = E_exc_S3
                      If I_Mode = 4 Then Etot = E_exc_S4
                      If I_Mode = 5 Then Etot = E_exc_S5
                      If I_Mode = 6 Then Etot = E_exc_S11
                      If I_Mode = 7 Then Etot = E_exc_S22
          
                      Etot = Etot - E_rot_CN  ' Erot of CN is not intrinsic 
    
                      If I_Z_CN Mod 2 + I_N_CN Mod 2 = 0 Then  ' Even-even CN       
                        If Etot > 0 And Etot < 2.E0 * 14.E0/Sqr(Csng(I_A_CN)) Then
                          E_coll_saddle(I_Mode) = Etot
                          Etot = 0
               '         Excitation below the pairing gap in even-even CN goes into collective excitations 
                        End If
                      End If   
    
        '             If I_Z_CN Mod 2 + I_N_CN Mod 2 = 0 Then    ' even-even
        '               Ediff = Min(Etot, 14.0/sqr(Csng(I_A_CN)))
        '             End If
      '               If I_Z_CN Mod 2 + I_N_CN Mod 2 = 1 Then    ' even-odd or odd-even
      '                 Ediff = Min(Etot, 2.0 * 14.0/sqr(Csng(I_A_CN)))
      '               End If
      '               Ediff = Max(Ediff,0.0) 
      '               Etot = Etot - Ediff
     
          
                      If Etot < 0 Then E_tunn = -Etot Else E_tunn = 0
                      Etot = Max(Etot,0.0)
           
                      E_pot_scission = (De_Saddle_Scission(Csng(I_Z_CN), _ 
                        Csng(I_A_CN),ESHIFTSASCI_intr) ) 
                      E_diss_Scission = EDISSFRAC * (E_pot_scission - E_tunn) + Epot_shift  
                      If E_diss_Scission < 0 Then E_diss_Scission = 0
                      Etot = Etot + E_diss_Scission
          /'          All excitation energy at saddle and part of the potential-energy gain to scission
                      go into intrinsic excitation energy at scission '/
     
                      If I_Mode = 2 Then
                        EINTR_SCISSION = Etot /' (For Mode 2) Global parameter '/
                      End If
    
                      Dim As Single DT
    
                      For IA1 = 40 To I_A_CN - 40
    
                        IA2 = I_A_CN - IA1  
                        If I_Mode <= 5 Then
                          T1 = Temp(I_Mode,1,IA1)
                          T2 = Temp(I_Mode,2,IA2)
                        End If
                        If I_Mode = 6 Then
                          T1 = Temp(1,2,IA1)
                          T2 = Temp(1,2,IA2)
                        End If  
                        If I_Mode = 7 Then
                          T1 = Temp(2,2,IA1)
                          T2 = Temp(2,2,IA2)
                        End If
                        DT = ABS(T2 - T1)
            
                /'      Even-odd effect '/
                        IF I_Z_CN Mod 2 = 0 Then
                          Rincr1P = Exp(-Etot/PZ_EO_symm)
                        Else
                          Rincr1P = 0
                        End If
                        If I_N_CN Mod 2 = 0 Then
                          Rincr1N = Exp(-Etot/PN_EO_symm)
                        Else
                          Rincr1N = 0
                        End If
            
                        PEOZ(I_Mode,1,IA1) = Rincr1P
                        PEOZ(I_Mode,2,IA2) = Rincr1P
                        PEON(I_Mode,1,IA1) = Rincr1N
                        PEON(I_Mode,2,IA2) = Rincr1N
    
                        If Etot > 0 Then
                          Rincr2 = Gaussintegral(DT/Etot-R_EO_Thresh, _
                            R_EO_Sigma*(DT+0.0001))
                            /' even-odd effect due to asymmetry '/
                        Else   ' even-odd effect is already 100%
                          Rincr2 = 0
                        End If             
                        Rincr2P = (R_EO_MAX - Rincr1P) * Rincr2
                        Rincr2N = (R_EO_MAX - Rincr1N) * Rincr2        
    
                        If IA1 <= IA2 Then  ' A1 is lighter or equal to A2
                          PEOZ(I_Mode,1,IA1) = _
                            PEOZ(I_Mode,1,IA1) + Rincr2P
                          IF I_Z_CN Mod 2 = 0 Then
                            PEOZ(I_Mode,2,IA2) = _
                            PEOZ(I_Mode,2,IA2) + Rincr2P
                          Else
                            PEOZ(I_Mode,2,IA2) = _
                            PEOZ(I_Mode,2,IA2) - Rincr2P
                          End if
                          PEON(I_Mode,1,IA1) = _
                          PEON(I_Mode,1,IA1) + Rincr2N
                          IF I_N_CN Mod 2 = 0 Then
                            PEON(I_Mode,2,IA2) = _
                             PEON(I_Mode,2,IA2) + Rincr2N
                          Else
                            PEON(I_Mode,2,IA2) = _
                              PEON(I_Mode,2,IA2) - Rincr2N
                          End if
                        Else   
                          PEOZ(I_Mode,1,IA1) = PEOZ(I_Mode,2,IA1)
                          PEON(I_Mode,1,IA1) = PEON(I_Mode,2,IA1)
                          PEOZ(I_Mode,2,IA2) = PEOZ(I_Mode,1,IA2)
                          PEON(I_Mode,2,IA2) = PEON(I_Mode,1,IA2)
                        End If            
              
               
        /'              Else
                          PEOZ(I_Mode,2,IA2) = _
                          PEOZ(I_Mode,1,IA2) + Rincr2P
                          IF I_Z_CN Mod 2 = 0 Then
                            PEOZ(I_Mode,1,IA1) = _
                              PEOZ(I_Mode,1,IA1) + Rincr2P
                          Else
                            PEOZ(I_Mode,1,IA1) = _
                              PEOZ(I_Mode,1,IA1) - Rincr2P
                          End if
                          PEON(I_Mode,2,IA2) = _
                            PEON(I_Mode,2,IA2) + Rincr2N
                          IF I_N_CN Mod 1 = 0 Then
                            PEON(I_Mode,1,IA1) = _
                            PEON(I_Mode,1,IA1) + Rincr2N
                          Else
                            PEON(I_Mode,1,IA1) = _
                              PEON(I_Mode,1,IA1) - Rincr2N
                        End if
                      End If  '/
              
                        PEOZ(I_Mode,1,IA1) = PEOZ(I_Mode,1,IA1) * EOscale
                        PEOZ(I_Mode,2,IA2) = PEOZ(I_Mode,2,IA2) * EOscale
                        PEON(I_Mode,1,IA1) = PEON(I_Mode,1,IA1) * EOscale
                        PEON(I_Mode,2,IA2) = PEON(I_Mode,2,IA2) * EOscale
    
    
    /'                  For T1 = 0.5 To 1 Step 0.05  
                          T2 = 1 - T1
                          Print T1,T2, 1.E - Gaussintegral(T2-T1,0.1)
                        Next T1
                        Sleep  '/
    
              /'        Energy sorting '/
         /'             E1 = Etot * Gaussintegral(T2-T1,0.03); '/
         
         
                        If Abs(T1-T2) < 1.E-6 Then
                          E1 = 0.5E0 * Etot
     '      E1 = IA1 / I_A_CN * Etot
                        Else
           '              E1ES = Csort * T1 * T2 / ( Abs(T1 - T2) )
                          If I_Mode = 0 Then
                            E1ES = Etot * Gaussintegral(T2-T1,Esort_Slope_S0)
                            E1ES = Min(E1ES,0.5E0*Etot)
                          ElseIf I_MOde = 1 Then
                            E1ES = Etot * Min( 1.0 , ( 1.0 - Exp(-(Etot-4.3)/2) ) )
                                         ' energy goes to the light fragment (heavy fr. is shell stabilized)
'  Print 7116, Etot,T1,T2,1.0 - exp(-(Etot-4.3)/2)
'  sleep                        
                            E1ES = Max(E1ES, IA1/IA2 * Etot)    ' should be reasonable, but disagrees with <En> in 235U(n,f)
                          Else
                            E1ES = Etot * Gaussintegral(T2-T1,Esort_Slope)
                            E1ES = Min(E1ES,0.5E0*Etot)
                        End If  
               /'         Asymptotic value after "complete" energy sorting '/
                          E1FG = Etot * IA1 / I_A_CN  /' in Fermi-gas regime '/
              
                /'        The following section assumes T=const in the superfluid regime
                          If Etot < 13 Then E1 = E1ES  ' complete energy sorting
                          If Etot >= 13 and Etot <= 20 Then  ' transition region
                            E1 = E1ES + (Etot-13)/7*(E1FG-E1ES)
                          End If
                          If Etot > 20 Then E1 = E1FG   ' Fermi-gas regime   '/
              
                /'        The following section extends energy sorting to higher energies '/
                          If Etot < 13 * Esort_extend Then E1 = E1ES  ' complete energy sorting
                          If Etot >= 13 * Esort_extend and Etot <= 20 * Esort_extend Then  ' transition region
                            E1 = E1ES + (Etot-13 * Esort_extend)/7*(E1FG-E1ES)
                          End If
                          If Etot > 20 * Esort_extend Then E1 = E1FG   ' Fermi-gas regime   
              
                        End If
                        E2 = Etot - E1
'Print 7194,I_MOde,IA1,E1,E2
                        EPART(I_Mode,1,IA1) = Max(E1,0.0)  /' Mean E* in light fragment '/                        
                        EPART(I_Mode,2,IA2) = Max(E2,0.0)  /' Mean E* in heavy fragment '/
                      Next IA1
                    Next I_mode
      
       /'** RMS angular momentum of fission fragments **'/
       /'           Following Naik et al., EPJ A 31 (2007) 195 and  '/
       /'           S. G. Kadmensky, Phys. At. Nucl. 71 (2008) 1193 '/ 
    
                    Scope
                      Dim As Single AUCD   /' UCD fragment mass '/
    '                 Dim As Single I_rigid_spher  /' I rigid for spherical shape '/
                      Dim As Single I_rigid        /' I rigid for deformed scission shape '/
                      Dim As Single I_eff          /' I with reduction due to pairing '/
                      Dim As Single alph           /' deformation parameter '/
                      Dim As Single E_exc          /' Excitation energy '/
                      Dim As Single J_rms          /' rms angular momentum '/
    /'>'/
    '                 Dim As Integer ZT,AT         /' Z and A of target nucleus '/
    '                 Dim As Single I_ISO          /' ISO number '/
    '                 Dim As Integer I_MAT
    
    '              /' CN spin '/
    '                 ZT = P_Z_CN
    '  '              AT = I_A_CN
    '                 AT = P_A_CN
    '                 If Emode = 2 Then AT = AT -1
    '                 If Emode = 12 Then
    '                   AT = AT - 1
    ''                  ZT = ZT - 1
    '                 End If    
    '                 If Emode = 22 Then
    '                   AT = AT - 4
    '                   ZT = ZT - 2
    '                 End If    
        
    /'
    /'<'/ 
                      Spin_CN = P_J_CN
    /'>'/
    '/    
        
        
    /'<'/    
        
                      For IZ1 = 10 To I_Z_CN - 10
                        AUCD = Int(Csng(IZ1) * Csng(I_A_CN) / Csng(I_Z_CN))
                        For IA1 = Int(AUCD - 15) To Int(AUCD + 15)
                          IN1 = IA1 - IZ1
                          If IA1 - IZ1 >= 10 Then
                      /'    Rigid momentum of inertia for spherical nucleus '/
                            I_rigid_spher = 1.16E0^2 * Csng(IA1)^1.6667E0 / 103.8415E0
                        /'  unit: hbar^2/MeV '/
                            For I_Mode = 0 To 7  
              
                  /'          First (normally light) fission fragment: '/
              
                              beta1 = Beta(I_Mode,1,IZ1)
                              alph = beta1 / sqr(4.E0 * pi / 5.E0)
                              I_rigid = I_rigid_spher * (1.E0 + 0.5E0*alph + 9.E0/7.E0*alph^2)
                           /' From Hasse & Myers, Geometrical Relationships ... '/
                              E_exc = EPART(I_Mode,1,IA1)
                              If E_exc < 0 Then E_exc = 0
                              T = U_Temp(Csng(IZ1),Csng(IA1),E_exc,1,1,Tscale,Econd,Etrans)          
               '              T = sqr(T^2 + 0.8^2)       ' For ZPM
               '              T = T_orbital
               '              T =  sqr(T^2 + T_orbital^2)
                              If T_orbital > 0.1 Then
                                T = T_orbital / tanh(T_orbital/T)  ' T_orbital represents the ZPM
                              End If  
                              I_eff = I_rigid * (1.E0 - 0.8E0 * exp(-0.693E0 * E_exc / 5.E0))  'Nucl. Phys. A 263 (1976) 141
                              J_rms = sqr(2.E0 * I_eff * T)  
              
                              J_rms = J_rms * Jscaling 
    
                              If IZ1 Mod 2 = 1 Or IN1 Mod 2 = 1 Then _ 
                                J_rms = J_rms + Spin_odd * (Csng(IA1)/140.0)^0.66667 
             '                    * Max(0,1 - (E_exc-1)/9) /' empirical '/
                   /'         Additional angular momentum of unpaired proton. '/ 
                   /'         See also Tomar et al., Pramana 68 (2007) 111 '/
               
    '                         Print Z1,I_Mode,beta1,T,E_exc,Spin_CN         
    '                         Print " ",I_rigid_spher,I_rigid,I_eff,J_rms
    
                              J_rms = sqr(J_rms^2 + (IA1/I_A_CN * 0.5 * Spin_CN)^2)  
                    '         Part of Spin_CN goes into orbital angular momentum
                    '         (deduced from small variation of TKE with angular momentum)
                
                              SpinRMSNZ(I_Mode,1,IA1-IZ1,IZ1) = J_rms
              
        '                     Print
        '                     Print IA1,T,E_exc,I_rigid_spher,I_rigid,I_eff,J_rms
    
              /'              Second (normally heavy) fission fragment: '/
    
                              beta2 = Beta(I_Mode,2,IZ1)
                              alph = beta2 / sqr(4.E0 * pi / 5.E0)
                              I_rigid = I_rigid_spher * (1.E0 + 0.5E0*alph + 9.E0/7.E0*alph^2)
                          /'  From Hasse & Myers, Geometrical Relationships ... '/
                              E_exc = EPART(I_Mode,2,IA1)
                              If E_exc < 0 Then E_exc = 0
                              T = U_Temp(Csng(IZ1),Csng(IA1),E_exc,1,1,Tscale,Econd,Etrans)          
          '                   T = sqr(T^2 + 0.8^2)       ' For ZPM
          '                   T = T_orbital
          '                   T =  sqr(T^2 + T_orbital^2)
                              If T_orbital > 0.1 Then
                                T = T_orbital / tanh(T_orbital/T)  ' T_orbital represents the ZPM
                              End If
                              I_eff = I_rigid * (1.E0 - 0.8E0 * exp(-0.693E0 * E_exc / 5.E0))
                              J_rms = sqr(2.E0 * I_eff * T)
    
                              J_rms = J_rms * Jscaling 
    
                              If IZ1 Mod 2 = 1 Or IN1 Mod 2 = 1 Then _ 
                                J_rms = J_rms + Spin_odd * (Csng(IA1)/140.0)^0.66667  
            '                 * Max(0,1 - (E_exc-1)/9) /' empirical '/
                           /' Additional angular momentum of unpaired proton. '/ 
                           /' See also Tomar et al., Pramana 68 (2007) 111 '/
               
                              J_rms = sqr(J_rms^2 + (IA1/I_A_CN * 0.5 * Spin_CN)^2)
                 '            Part of Spin_CN goes into orbital angular momentum
                  '           (deduced from small variation of TKE with angular momentum)
              
                              SpinRMSNZ(I_Mode,2,IA1-IZ1,IZ1) = J_rms
              
       '                      Print IA1,T,E_exc,I_rigid_spher,I_rigid,I_eff,J_rms          
    
                            Next I_Mode
                          End If 
                        Next IA1
                      Next IZ1
                    End Scope
    /'>'/   
        
    
       '            Print " "
       '            Print "Pre-routines finished at ";time;"."
    
    /'
    /'<'/
    
    ' ****************************************************************
    ' *** Filling arrays with results in the folding mode (GEFSUB) *** 
    ' ****************************************************************
                    Scope
                      Dim As Integer J_short,K_short
                      Dim As Integer Ic, Jc
                      Dim As Single R_Help,Zs,R_Sum
     
                      For I_short = 10 To I_A_CN - P_Z_CN - 10  ' fragment mass
                        For J_short = 10 To P_Z_CN - 10   ' fragment Z
                          For K_short = 0 To 7
                            NZMPRE(K_short,I_short,J_short) = 0.0  ' initialization
                          Next K_short
                        Next J_short
                      Next I_short
     
      '               Mode 0 
                      For I_short = 20 To I_A_CN - 20   ' fragment mass
                        Ic = I_A_CN - I_short  ' mass of complementary fragment
                        R_Help = Yield_Mode_0 * (U_Gauss_mod(AC_Mode_0 - Csng(I_short), SigA_Mode_0) _ 
                          + U_Gauss_mod(AC_Mode_0 - Csng(Ic), SigA_Mode_0)) ' Mass yield
                        If I_short < Ic Then  ' I_short is the light fragment
                          Zs = ZShift(0,1,I_short)
                        Else  ' Ic is the light fragment 
                          Zs = -ZShift(0,1,Ic)
                        End If
                        For J_short = 10 To P_Z_CN - 10   ' fragment Z
                          Jc = P_Z_CN - J_short  ' Z of complementary fragment
                          If I_short-J_short >= 0 And Ic-Jc >= 0 And I_short-J_short <= 200 _
                            And Ic-Jc <= 200 Then  ' boundaries of NZMPRE
                               ' Z yield for fixed A, mode 0:
                            NZMPRE(0,I_short-J_short,J_short) = R_Help * _
                            U_Gauss_mod(Csng(P_Z_CN)/Csng(I_A_CN)*Csng(I_short) + Zs - _
                              Csng(J_short),SigPol_Mode_0) * _
                            U_Even_Odd(J_short,PEOZ(0,1,I_short)) * U_Even_Odd(I_short-J_short,PEON(0,1,I_short))   
                          End If     
                        Next J_short
                      Next I_short
    
     '                Mode 1
                      For I_short = 20 To I_A_CN - 20
                        Ic = I_A_CN - I_short
                        R_Help = Yield_Mode_1 * (U_Gauss_mod(AC_Mode_1 - Csng(I_short), SigA_Mode_1) _
                          + U_Gauss_mod(AC_Mode_1 - Csng(Ic), SigA_Mode_1)) ' Mass yield
                        If I_short < Ic Then
                          Zs = ZShift(1,1,I_short)
                        Else
                          Zs = -ZShift(1,1,Ic)
                        End If  
                        For J_short = 10 To P_Z_CN - 10 
                          Jc = P_Z_CN - J_short
                          If I_short-J_short >= 0 And Ic-Jc >= 0 And I_short-J_short <= 200 And Ic-Jc <= 200 Then
                            NZMPRE(1,I_short-J_short,J_short) = R_Help * _ 
                              U_Gauss_mod(Csng(P_Z_CN)/Csng(I_A_CN)*Csng(I_short) + Zs - Csng(J_short),SigPol_Mode_1)* _
                              U_Even_Odd(J_short,PEOZ(1,1,I_short)) * U_Even_Odd(I_short-J_short,PEON(1,1,I_short))   
                          End If    
                        Next J_short
                      Next I_short
     
     '                Mode 2
                      Dim As Single R_Cut1, R_Cut2
                      For I_short = 20 To I_A_CN - 20
                        Ic = I_A_CN - I_short
                        R_Help = Yield_Mode_2 * (U_Box2(AC_Mode_2 - Csng(I_short), _
                          sqr(2.0)*S2leftmod*SigA_Mode_2, _
                          sqr(2.0)*SigA_Mode_2,P_A_Width_S2,R_Slope_S2) + _
                        U_Box2(AC_Mode_2 - Csng(Ic), _
                          sqr(2.0)*S2leftmod*SigA_Mode_2, _
                          sqr(2.0)*SigA_Mode_2,P_A_Width_S2,R_Slope_S2))
                        If I_short < Ic Then
                          Zs = ZShift(2,1,I_short)
                        Else
                          Zs = -ZShift(2,1,Ic)
                        End If   
                        For J_short = 10 To P_Z_CN - 10
                          Jc = P_Z_CN - J_short 
                          If I_short-J_short >= 0 And Ic-Jc >= 0 And I_short-J_short <= 200 And Ic-Jc <= 200 Then
                            R_Cut1 = R_Help
                            R_Cut2 = R_Help
                            If J_short > Jc Then
                              R_Cut1 = R_Help * Gaussintegral(Csng(J)-ZTRUNC50,FTRUNC50*SigZ_Mode_2)
                            Else 
                              R_Cut2 = R_Help * Gaussintegral(Csng(J)-ZTRUNC50,FTRUNC50*SigZ_Mode_2)
                            End If     
                            NZMPRE(2,I_short-J_short,J_short) = R_Help * _ 
                              U_Gauss_mod(Csng(P_Z_CN)/Csng(I_A_CN)*Csng(I_short) + Zs - Csng(J_short),SigPol_Mode_2) * _
                              U_Even_Odd(J_short,PEOZ(2,1,I_short)) * U_Even_Odd(I_short-J_short,PEON(2,1,I_short))  
                          End If     
                        Next J_short
                      Next I_short
    
     '                Mode 3
                      For I_short = 20 To I_A_CN - 20
                        Ic = I_A_CN - I_short
                        R_Help = Yield_Mode_3 * (U_Gauss_mod(AC_Mode_3 - Csng(I_short), SigA_Mode_3) + _
                          U_Gauss_mod(AC_Mode_3 - Csng(Ic), SigA_Mode_3)) ' Mass yield   
                        If I_short < Ic Then
                          Zs = ZShift(3,1,I_short)
                        Else
                          Zs = -ZShift(3,1,Ic)
                        End If   
                        For J_short = 10 To P_Z_CN - 10 
                          Jc = P_Z_CN - J_short
                          If I_short-J_short >= 0 And Ic-Jc >= 0 And I_short-J_short <= 200 And Ic-Jc <= 200 Then
                            NZMPRE(3,I_short-J_short,J_short) = R_Help * _ 
                              U_Gauss_mod(Csng(P_Z_CN)/Csng(I_A_CN)*Csng(I_short) + Zs - Csng(J_short),SigPol_Mode_3) * _
                              U_Even_Odd(J_short,PEOZ(3,1,I_short)) * U_Even_Odd(I_short-J_short,PEON(3,1,I_short))         
                          End If     
                        Next J_short
                      Next I_short  
     
     '                Mode 4
                      For I_short = 20 To I_A_CN - 20
                        Ic = I_A_CN - I_short
                        R_Help = Yield_Mode_4 * (U_Gauss_mod(AC_Mode_4 - Csng(I_short), SigA_Mode_4) + _
                          U_Gauss_mod(AC_Mode_4 - Csng(Ic), SigA_Mode_4))
                        If I_short < Ic Then    
                          Zs = ZShift(3,1,I_short)   ' light fragment  
                        Else
                          Zs = -ZShift(3,1,Ic)  ' heavy fragment
                        End If   
                        For J_short = 10 To P_Z_CN - 10 
                          Jc = P_Z_CN - J_short
                          If I_short-J_short >= 0 And Ic-Jc >= 0 And I_short-J_short <= 200 And Ic-Jc <= 200 Then
                            NZMPRE(4,I_short-J_short,J_short) = R_Help * _ 
                            U_Gauss_mod(Csng(P_Z_CN)/Csng(I_A_CN)*Csng(I_short) + Zs - Csng(J_short),SigPol_Mode_4) * _
                            U_Even_Odd(J_short,PEOZ(4,1,I_short)) * U_Even_Odd(I_short-J_short,PEON(4,1,I_short))         
                          End If           
                        Next J_short
                      Next I_short
    
     '                Mode 5
                      For I_short = 20 To I_A_CN - 20
                        Ic = I_A_CN - I_short
                        R_Help = Yield_Mode_5 * (U_Gauss_mod(AC_Mode_5 - Csng(I_short), SigA_Mode_5) + _
                          U_Gauss_mod(AC_Mode_5 - Csng(Ic), SigA_Mode_5)) ' Mass yield   
                        If I_short < Ic Then
                          Zs = ZShift(5,1,I_short)
                        Else
                          Zs = -ZShift(5,1,Ic)
                        End If   
                        For J_short = 10 To P_Z_CN - 10 
                          Jc = P_Z_CN - J_short
                          If I_short-J_short >= 0 And Ic-Jc >= 0 And I_short-J_short <= 200 And Ic-Jc <= 200 Then
                            NZMPRE(5,I_short-J_short,J_short) = R_Help * _ 
                            U_Gauss_mod(Csng(P_Z_CN)/Csng(I_A_CN)*Csng(I_short) + Zs - Csng(J_short),SigPol_Mode_5) * _
                            U_Even_Odd(J_short,PEOZ(5,1,I_short)) * U_Even_Odd(I_short-J_short,PEON(5,1,I_short))         
                          End If     
                        Next J_short
                      Next I_short 
      
       '              Mode 11
                      For I_short = 20 To I_A_CN - 20
                        Ic = I_A_CN - I_short
                        R_Help = Yield_Mode_11 * (U_Gauss_mod(AC_Mode_0 - Csng(I_short), SigA_Mode_11) + _
                        U_Gauss_mod(AC_Mode_0 - Csng(Ic), SigA_Mode_11)) ' Mass yield   
                        For J_short = 10 To P_Z_CN - 10 
                          Jc = P_Z_CN - J_short
                          If I_short-J_short >= 0 And Ic-Jc >= 0 And I_short-J_short <= 200 And Ic-Jc <= 200 Then
                            NZMPRE(6,I_short-J_short,J_short) = R_Help * _ 
                            U_Gauss_mod(Csng(P_Z_CN)/Csng(I_A_CN)*Csng(I_short) - Csng(J_short),SigPol_Mode_0) * _
                            U_Even_Odd(J_short,PEOZ(6,1,I_short)) * U_Even_Odd(I_short-J_short,PEON(6,1,I_short))         
                          End If    
                        Next J_short
                      Next I_short
     
     '                Mode 22
                      For I_short = 20 To I_A_CN - 20
                        Ic = I_A_CN - I_short
                        R_Help = Yield_Mode_22 * (U_Gauss_mod(AC_Mode_0 - Csng(I_short), SigA_Mode_22) + _
                          U_Gauss_mod(AC_Mode_0 - Csng(Ic), SigA_Mode_22)) ' Mass yield   
                        For J_short = 10 To P_Z_CN - 10 
                          Jc = P_Z_CN - J_short
                          If I_short-J_short >= 0 And Ic-Jc >= 0 And I_short-J_short <= 200 And Ic-Jc <= 200 Then
                            NZMPRE(7,I_short-J_short,J_short) = R_Help * _ 
                              U_Gauss_mod(Csng(P_Z_CN)/Csng(I_A_CN)*Csng(I_short) - Csng(J_short),SigPol_Mode_0) * _
                              U_Even_Odd(J_short,PEOZ(7,1,I_short)) * U_Even_Odd(I_short-J_short,PEON(7,1,I_short))        
                          End If            
                        Next J_short
                      Next I_short
     
    
     '                Normalization 
                      R_Sum = 0
                      For I_short = 10 To (I_A_CN - P_Z_CN) - 10
                        For J_short = 10 To P_Z_CN - 10
                          NZPRE(I_short,J_short) = 0
                          For K_short = 0 To 7
                            If NZMPRE(K_short,I_short,J_short) > 0 Then
                              R_Sum = R_Sum + NZMPRE(K_short,I_short,J_short) 
                              NZPRE(I_short,J_short) = NZPRE(I_short,J_short) + NZMPRE(K_short,I_short,J_short)  ' sum of all modes
                            End If
                          Next K_short
                        Next J_short
                      Next I_short
                      Print R_Sum
                      For I_short = 10 To (I_A_CN - P_Z_CN) - 10
                        For J_short = 10 To P_Z_CN - 10
                          NZPRE(I_short,J_short) = NZPRE(I_short,J_short) / R_Sum
                          For K_short = 0 To 7
                            NZMPRE(K_short,I_short,J_short) = NZMPRE(K_short,I_short,J_short) / R_Sum
                          Next K_short
                        Next J_short
                      Next I_short
                    End Scope
     
     '              Calculate and store distributions of fragment excitation energy and spin
     
                    Dim As Integer N_index,Z_index,A_index,M_index 
                    Dim As Single Ymin = 1.E-7           ' Minimum yield to be stored
                    Dim As Single Eexc_mean, Eexc_sigma
                    Dim As Single Eexc_intr, Eexc_coll
    
     /' ***************** Begin Module GEFRESULTS ********************* '/
                    Dim As Integer N_cases            ' Number of cases in NZMkey, Etab, Jtab and Ytab
     '              (First dimension of NZMkey, Etab, Jtab and Ytab)
                    ReDim NZMkey(10000,3) As Integer  ' Key (Mode,N,Z) for E*, spin and yield distr. of fragments 
                    ReDim Etab(10000,1000) As Single  ' Distribution of E*(exc. energy above yrast line 
        '           of fragments at scission (0.1 MeV bins).
        '           Note that E* = Etab + Erot_fragment with
        '           Erot_fragment =  Jtab * (Jtab + 1) / (2.0 * IfragEff),
        '           IfragEff = U_Ired(I_Z_fragment,I_A_fragment).
        '           Erot and Jtab are correlated!
                    Redim Jtab(10000,100) As Single   ' Spin distribution of fragments
     '              (0 to 100 hbar for even-A or 1/2 to 201/2 hbar for odd-A nuclei)
                    Redim Ytab(10000) As Single       ' Yield of fragments
     /' ****************** End Module GEFRESULTS ********************* '/
     
      
                    N_cases = 0 
                    For N_index = 10 To (P_A_CN - P_Z_CN) - 10   ' Neutron number
                      For Z_index = 10 To P_Z_CN - 10            ' Atomic number
                        For M_index = 0 To 7                     ' Fission channel
                          If NZMPRE(M_index,N_index,Z_index) > Ymin Then
                            N_cases = N_cases + 1
                            If N_cases = Ubound(NZMkey,1) Then
                              Print "Upper bound of NZkey reached"
                              Print "Result will be incomplete"
                              Exit For, For, For 
                            End If
                            NZMkey(N_cases,1) = M_index  ' Fission mode
                            NZMkey(N_cases,2) = N_index  ' Neutron number of fragment
                            NZMkey(N_cases,3) = Z_index  ' Atomic number of fragment
                          End If
                        Next M_index 
                      Next Z_index
                    Next N_index
                    Print "N_cases  ",N_cases
     /'<FO WRITE (*,*) "N_cases ",N_cases FO>'/
     
                    For K = 1 To N_cases
                      M_index = NZMkey(K,1)   ' fission mode
                      N_index = NZMkey(K,2)   ' neutron number
                      Z_index = NZMkey(K,3)   ' atomic number 
                      A_index = N_index + Z_index
    
       '              Yield
                      Ytab(K) = NZMpre(M_index,N_index,Z_index)
       
       '              Angular momentum:
                      For I = 1 To 100
                        If M_index <= 5 Then
                          If Z_index < 0.5 * P_Z_CN Then
                            Jtab(K,I) = _
                              U_LinGauss(Csng(I),SpinRMSNZ(M_index,1,N_index,Z_index)/sqr(2.0))
                          Else
                            Jtab(K,I) = _
                              U_LinGauss(Csng(I),SpinRMSNZ(M_index,2,N_index,Z_index)/sqr(2.0))
                          End If  
                        End If
                        If M_index = 6 Then
                          Jtab(K,I) = _
                          U_LinGauss(Csng(I),SpinRMSNZ(1,2,N_index,Z_index)/sqr(2.0))
                        End If
                        If M_index = 7 Then
                          Jtab(K,I) = _
                            U_LinGauss(Csng(I),SpinRMSNZ(2,2,N_index,Z_index)/sqr(2.0))
                        End If
                      Next I 
       
         '            Normalize numerically (due to non-continuous values) 
                      Scope
                        Dim As Single Rint
                        Rint = 0
                        For I = 1 To 100
                          Rint = Rint + Jtab(K,I)
                        Next   
                        If Rint > 0 Then
                          For I = 1 To 100
                            Jtab(K,I) = Jtab(K,I) / Rint
                          Next  
                        End If
                      End Scope  
       
       
       '              Excitation energy:
       '              1. Deformation energy at scission
                      Scope
                        Dim As Single RS,EtotS0,RW_mac
                        If M_index = 0 Then
                          EtotS0 = Max(E_Exc_S0 + E_diss_Scission,0.0)
         '                Transition from shell-defined to macroscopic shape with increasing E* 
         '                RW_mac = relative macroscopic influence
                          RW_mac = Gaussintegral(EtotS0-20.0,5.0)
                          If Z_index < 0.5 * P_Z_CN Then
                            Eexc_mean = (1.0 - RW_mac) * Edefo(-1,1,Z_index) + RW_mac * Edefo(0,1,Z_index)
                            Eexc_sigma = _
                              ( Lymass(Csng(Z_index),Csng(A_index),beta(0,1,Z_index) + SIGDEFO_0) - _
                              Lymass(Csng(Z_index),Csng(A_index),beta(0,1,Z_index) ))       
                          Else
                            Eexc_mean = (1.0 - RW_mac) * Edefo(-1,2,Z_index) + RW_mac * Edefo(0,2,Z_index)
                            Eexc_sigma = _ 
                            ( Lymass(Csng(Z_index),Csng(A_index),beta(0,2,Z_index) + SIGDEFO_0) - _
                            Lymass(Csng(Z_index),Csng(A_index),beta(0,2,Z_index) ))
                          End If 
                        End If
                        If M_index > 0 And M_index <= 5 Then
                          If Z_index < 0.5 * P_Z_CN Then
                            Eexc_mean = Edefo(M_index,1,Z_index)
       '                    RS = SIGDEFO/Sqr(R_Att_Sad(M_index))
                            RS = SIGDEFO
                            Eexc_sigma = _
                              ( Lymass(Csng(Z_index),Csng(A_index),beta(M_index,1,Z_index) + RS) - _
                              Lymass(Csng(Z_index),Csng(A_index),beta(M_index,1,Z_index) ))       
                          Else
                            Eexc_mean = Edefo(M_index,2,Z_index)
       '                    RS = SIGDEFO/Sqr(R_Att_Sad(M_index))       
                            RS = SIGDEFO       
                            Eexc_sigma = _ 
                              ( Lymass(Csng(Z_index),Csng(A_index),beta(M_index,2,Z_index) + RS) - _
                              Lymass(Csng(Z_index),Csng(A_index),beta(M_index,2,Z_index) ))
                          End If
                        End If    
                        If M_index = 6 Then
                          Eexc_mean = Edefo(1,2,Z_index)
       '                  RS = SIGDEFO/Sqr(R_Att_Sad(M_index))       
                          RS = SIGDEFO       
                          Eexc_sigma = _
                            ( Lymass(Csng(Z_index),Csng(A_index),beta(1,2,Z_index) + RS) - _
                            Lymass(Csng(Z_index),Csng(A_index),beta(1,2,Z_index) ))  
                        End If
                        If M_index = 7 Then
                          Eexc_mean = Edefo(2,2,Z_index)  
       '                  RS = SIGDEFO/Sqr(R_Att_Sad(M_index))       
                          RS = SIGDEFO       
                          Eexc_sigma = _ 
                            ( Lymass(Csng(Z_index),Csng(A_index),beta(2,2,Z_index) + RS) - _
                            Lymass(Csng(Z_index),Csng(A_index),beta(2,2,Z_index) ))
                        End If 
                        Eexc_mean = Max(Eexc_mean,0.0)
                      End Scope
        
         '            2. Intrinsic excitation energy at scission
                      If Z_index < 0.5 * Csng(P_Z_CN) Then   
                        Eexc_intr = EPART(M_index,1,A_index)
                      Else
                        Eexc_intr = EPART(M_index,2,A_index) 
                      End If  
                      If  M_index = 0 Then  ' add shell and pairing of final fragment
                        Eexc_intr = Eexc_intr - _
                          AME2020(Z_index,A_index) + LDMass(Csng(Z_index),Csng(A_index),0.) _   
                          - 2.0 * 12.0 / sqr(Csng(A_index))     ' general shift  
                      End If
                      Eexc_intr = Max(Eexc_intr,0.0)
                      Eexc_mean = Eexc_mean + Eexc_intr
                      Eexc_sigma = sqr(Eexc_sigma^2 + (EexcSIGrel * E_diss_Scission)^2)
        
         '            3. Pairing staggering
                      Eexc_mean = Eexc_mean - Lypair(Z_index,A_index)
         
       '              4. Collective energy
                      Eexc_coll = 0.5 * ECOLLFRAC * (De_Saddle_Scission(Csng(P_Z_CN), _
                        Csng(I_A_CN),ESHIFTSASCI_coll) - E_tunn) 
                      Eexc_coll = Max(Eexc_coll,0.0)
                      Eexc_sigma = sqr(Eexc_sigma^2 + 0.5*(EexcSIGrel*Eexc_coll)^2)
                      Eexc_mean = Eexc_mean + Eexc_coll + 0.5 * E_coll_saddle(M_index)
    
         '            5. Total excitation energy distribution of fragments (all contributions summed up)
              '       This is the value above the yrast line. Erot must be added!
                      For I = 0 To 1000  ' 100 keV bins up to 100 MeV
                        Etab(K,I) = exp(-(0.1*Csng(I)-Eexc_mean)^2/(2.0 * Eexc_sigma))
                      Next
       
       '              Normalize excitation-energy distribution
                      Scope
                        Dim As Single RintE 
                        RintE = 0
                        For I = 0 To 1000
                          RintE = RintE + Etab(K,I)
                        Next   
                        If RintE > 0 Then
                          For I = 0 To 1000
                            Etab(K,I) = Etab(K,I) / RintE
                          Next  
                        End If
                      End Scope  
       
                    Next K
    
    
    
    /'>'/
     '/
     
                    Racc = 100.E0 / NEVTtot * P_selected  ' Normalization of spectra  
     
                    For ILoop = 1 To NEVTused        /' Loop for events with same parameters '/
      
            /'      Choosing fission mode'/
    
                      Scope
                        Dim As Single R_Sum_0,R_Sum_1,R_Sum_2,R_Sum_3,R_Sum_4,R_Sum_5,R_Sum_6,R_Sum_7
                        Dim As Single R_Choice,Rincr
          
                        If I_Mode_selected = -1 Then
                          R_Choice = Rnd  
                          R_Sum_0 = Yield_Mode_0
                          R_Sum_1 = R_Sum_0 + Yield_Mode_1
                          R_Sum_2 = R_Sum_1 + Yield_Mode_2
                          R_Sum_3 = R_Sum_2 + Yield_Mode_3
                          R_Sum_4 = R_Sum_3 + Yield_Mode_4
                          R_Sum_5 = R_Sum_4 + Yield_Mode_5
                          R_Sum_6 = R_Sum_5 + Yield_Mode_11
                          R_Sum_7 = R_Sum_6 + Yield_Mode_22
                          I_Mode = 7
                          IF R_Choice < R_Sum_0 Then I_Mode = 0
                          If R_Choice >= R_Sum_0 And R_Choice < R_Sum_1 Then I_Mode = 1
                          If R_Choice >= R_Sum_1 And R_Choice < R_Sum_2 Then I_Mode = 2
                          If R_Choice >= R_Sum_2 And R_Choice < R_Sum_3 Then I_Mode = 3
                          If R_Choice >= R_Sum_3 And R_Choice < R_Sum_4 Then I_Mode = 4
                          If R_Choice >= R_Sum_4 And R_Choice < R_Sum_5 Then I_Mode = 5
                          If R_Choice >= R_Sum_5 And R_Choice < R_Sum_6 Then I_Mode = 6
                          If R_Choice >= R_Sum_6 And R_Choice < R_Sum_7 Then I_Mode = 7
                        Else
                          I_Mode = I_Mode_selected
                        End If
                        Mode_Events(I_Mode) = Mode_Events(I_Mode) + 1  
                        Mode_Events(10) = Mode_Events(10) + 1  ' For normalization
                      End Scope
         
        /'            Chosing Z and A values '/
                      Dim As Single R_A_help,RN
                      Dim As Integer Iguess 
      
    DiceA:  
                      Select Case I_Mode
                        Case 0        
                          R_A_heavy = PGauss(AC_Mode_0,SigA_Mode_0) /' random choice of mass '/
                          RZpol = Zshift(0,2,CInt(R_A_heavy)) /' local polarization '/
                          RZ = R_A_heavy * I_Z_CN / I_A_CN + RZpol /' mean position in Z for given mass '/
                          R_Z_heavy = PGauss(RZ,SigPol_Mode_0) /' random choice of Z '/
                        Case 1
                          R_A_heavy = PGauss(AC_Mode_1,SigA_Mode_1)
                          RZpol = Zshift(1,2,CInt(R_A_heavy)) /' local polarization '/
                          RZ = R_A_heavy * I_Z_CN / I_A_CN + RZpol          
                          R_Z_heavy = PGauss(RZ,SigPol_Mode_1)
                        Case 2
                          Iguess = 0
    Next2:
                          Iguess = Iguess + 1
                          R_A_heavy = PBox2(AC_Mode_2,SigA_Mode_2*S2leftmod,SigA_Mode_2,P_A_Width_S2,R_slope_S2)
                          RZpol = Zshift(2,2,CInt(R_A_heavy))
                          RZ = R_A_heavy * I_Z_CN / I_A_CN + RZpol       
                          RN = R_A_heavy - RZ   
        '                 If Iguess < 1.E3 Then
        '                   If Rtest > Gaussintegral(RN-82,1.5*SigZ_Mode_2) Then
        '                     Goto Next2
        '                   End If   
        '                 End If
          '               If Iguess < 1.E3 Then
          '                 If Rtest > Gaussintegral(RZ-ZTRUNC50,FTRUNC50*SigZ_Mode_2) Then 
          '                   If  Rtest > 0.5 * ERF((RZ-ZTRUNC50)/(FTRUNC50*SigZ_Mode_2)) + 0.5E0 Or _
          '                     Rtest > 0.5 * ERF((I_Z_CN - RZ - ZTRUNC28)/(FTRUNC28*SigZ_Mode_2)) + 0.5 Then 
          '                   Goto Next2
          '                 End If
          '               End If     
            /'            truncation below Z = 35 and below Z = 50 due to properties of deformed shells '/
                          R_Z_heavy = PGauss(RZ,SigPol_Mode_2)   
                          Case 3
                            R_A_heavy = PGauss(AC_Mode_3,SigA_Mode_3)
                            RZpol = Zshift(3,2,R_A_heavy)
                            RZ = R_A_heavy * I_Z_CN / I_A_CN + RZpol  
                            R_Z_heavy = PGauss(RZ,SigPol_Mode_3)
                          Case 4
                            R_A_heavy = PGauss(AC_Mode_4,SigA_Mode_4)
                            RZpol = Zshift(4,2,R_A_heavy)
                            RZ = R_A_heavy * I_Z_CN / I_A_CN + RZpol  
                            R_Z_heavy = PGauss(RZ,SigPol_Mode_4)
                          Case 5  
                            If ZC_Mode_5 > ZC_Mode_0 Then
                              R_A_heavy = PGauss(AC_Mode_5,SigA_Mode_5)
                            Else  
                              R_A_heavy = I_A_CN - PGauss(AC_Mode_5,SigA_Mode_5)
                    '         AC_Mode_5 refers to the light fragment
                            End If  
                            RZpol = Zshift(5,2,R_A_heavy)
                            RZ = R_A_heavy * I_Z_CN / I_A_CN + RZpol  
                            R_Z_heavy = PGauss(RZ,SigPol_Mode_4)
                          Case 6
                            R_A_heavy = PGauss(AC_Mode_0,SigA_Mode_11)
                            RZ = R_A_heavy * I_Z_CN / I_A_CN
                            R_Z_heavy = PGAUSS(RZ,SigPol_Mode_0)
                          Case 7
                            R_A_heavy = PGauss(AC_Mode_0,SigA_Mode_22)
                            RZ = R_A_heavy * I_Z_CN / I_A_CN
                            R_Z_heavy = PGauss(RZ,SigPol_Mode_0)
                          Case Else
                      End Select
    '                 If R_A_light < 20 Or R_A_heavy > I_A_CN - 20 Then Goto DiceA
                      R_Z_light = I_Z_CN - R_Z_heavy
                      R_A_light = I_A_CN - R_A_heavy
    
                      If R_A_heavy < 1 Or R_A_light < 1 Then Goto DiceA
                      If R_A_heavy < R_A_light Then Goto DiceA
    
          /'          Pre-neutron Z distribution, without even-odd effect '/
                      I = CInt(R_Z_heavy)
                      If I >= Lbound(ZPROV) and I <= Ubound(Zprov) Then
                        ZPROV(I) = ZPROV(I) + Racc
                        ZMPROV(I_Mode,I) = ZMPROV(I_Mode,I) + Racc
                      End If 
                      I = CInt(R_Z_light)
                      If I >= Lbound(ZPROV) and I <= Ubound(Zprov) Then 
                        ZPROV(I) = ZPROV(I) + Racc
                        ZMPROV(I_Mode,I) = ZMPROV(I_Mode,I) + Racc
                      End If
    
    
        /'            Provisional mass distribution, pre-neutron,
                      directly deduced from Z distribution with UCD assumption '/
    
                      APROV(CInt(R_Z_heavy * I_A_CN / I_Z_CN + 0.5)) = _
                        APROV(CInt(R_Z_heavy * I_A_CN / I_Z_CN + 0.5)) + Racc
                      APROV(CInt(R_Z_light * I_A_CN / I_Z_CN + 0.5)) = _
                        APROV(CInt(R_Z_light * I_A_CN / I_Z_CN + 0.5)) + Racc
                      AMPROV(I_Mode,CInt(R_Z_heavy * I_A_CN / I_Z_CN + 0.5)) = _
                        AMPROV(I_Mode,CInt(R_Z_heavy * I_A_CN / I_Z_CN + 0.5)) + Racc
                      AMPROV(I_Mode,CInt(R_Z_light * I_A_CN / I_Z_CN + 0.5)) = _
                        AMPROV(I_Mode,CInt(R_Z_light * I_A_CN / I_Z_CN + 0.5)) + Racc
    
        /'            Round on integer values with even-odd effect '/
                      Dim As Single R_N_heavy
                      Dim As Integer I_Z_sad, I_N_sad, I_A_sad
                      Dim As Integer I_Z_heavy_sad, I_A_heavy_sad
                      Dim As Integer I_Z_light_sad, I_A_light_sad
                      Dim As Integer I_N_heavy_sad, I_N_light_sad
                      Dim As Integer I_Z_sci, I_N_sci, I_A_sci    'sci: values at scission, before prompt-neutron emission
                      Dim As Integer I_Z_light_sci, I_N_light_sci, I_A_light_sci
                      Dim As Integer I_Z_heavy_sci, I_N_heavy_sci, I_A_heavy_sci
                      Dim As Integer I_Z_post, I_N_post, I_A_post 
                      Dim As Integer I_Z_light_post, I_N_light_post, I_A_light_post
                      Dim As Integer I_Z_heavy_post, I_N_heavy_post, I_A_heavy_post
        
                      Dim As Single ESIGDEFOlight,ESIGDEFOheavy
                      Dim As Single RS
    
                      R_N_heavy = R_A_heavy - R_Z_heavy
                      I_N_heavy_sad = Even_odd(R_N_heavy,PEON(I_Mode,2,CInt(R_A_heavy)))
                      I_Z_heavy_sad = Even_odd(R_Z_heavy,PEOZ(I_Mode,2,CInt(R_A_heavy)))
                      I_A_heavy_sad = I_N_heavy_sad + I_Z_heavy_sad
          
                      I_N_light_sad = I_N_CN - I_N_heavy_sad
                      I_Z_light_sad = I_Z_CN - I_Z_heavy_sad
                      I_A_light_sad = I_A_CN - I_A_heavy_sad
        
                      I_A_sad = I_A_CN
                      I_Z_sad = I_Z_CN
                      I_N_sad = I_N_CN
    
       
    '                 Q value from TF masses (M&S) + shell + pairing      
     '                Qvalue_sad = U_Mass(I_Z_CN,I_A_CN) + Lypair(I_Z_CN,I_A_CN) - _
     '                  (U_Mass(I_Z_heavy,I_A_heavy) + Lypair(I_Z_heavy,I_A_heavy) _
     '                  + U_Mass(I_Z_light,I_A_light) + Lypair(I_Z_light,I_A_light) )    
    
       '              Q value from 2020 mass evaluation 
                      Qvalue_sad = AME2020(I_Z_sad,I_A_sad) - _
                        (AME2020(I_Z_heavy_sad,I_A_heavy_sad)  _
                         + AME2020(I_Z_light_sad,I_A_light_sad))
    
          /'          Excitation energy of fragments '/
                      E_intr_light = EPART(I_Mode,1,I_A_light_sad) 
                      E_intr_heavy = EPART(I_Mode,2,I_A_heavy_sad) 
        
          
        /'*** Neutron emission between saddle and scission ***'/
                      Dim As Integer I_nu_ss   ' number of neutrons emitted between saddle and scission
                      Scope
                        Dim As Integer I
                        Dim As Single E_Final_Light,J_Frag_light,TlightFF,R_Z_light_sci,R_A_light_sci
                        Dim As Single E_Final_heavy,J_Frag_heavy,TheavyFF,R_Z_heavy_sci,R_A_heavy_sci
                        ReDim As Single Array_E_n1_ss(50),Array_E_n2_ss(50)
           
                        TlightFF = 1  'not used
                        TheavyFF = 1  'not used
          
                        I_nu_ss = 0
                        C_pattern_sci = "0000000000"  ' for list-mode output 
    
                        If E_intr_light + E_intr_heavy > Escission_lim Then  
                          For I = 1 To UBound(Array_E_n1_ss)
                            Array_E_n1_ss(I) = 0
                            Array_Tn(I) = 0
                          Next I 
                          E_Final_Light = Escission_lim * Csng(I_A_light_sad) / Csng(I_A_sad) - 9
            
                          J_Frag_light = 0
                          Eva(0,I_Z_light_sad,I_A_light_sad,E_intr_light,TlightFF,J_Frag_light,R_Z_Light_sci, _
                            R_A_Light_sci,E_Final_Light,Array_E_n1_ss(),Array_Tn(), _
                            Array_Eg0_light())
    
                          For I = 1 To Ubound(Array_E_n1_ss)
                            If Array_E_n1_ss(I) = 0 Then Exit For
                            ENsci(Cint(Array_E_n1_ss(I)*1000)) = ENsci(Cint(Array_E_n1_ss(I)*1000)) + 1
                            I_nu_ss = I_nu_ss + 1
                            Redim Preserve Array_En_sci(I_nu_ss)  ' for list-mode output
                            Array_En_sci(I_nu_ss) = Array_E_n1_ss(I)
                            Mid(C_pattern_sci,I_nu_ss,1) = "5"
                          Next I
                          I_A_light_sci = R_A_light_sci
                          I_Z_light_sci = R_Z_light_sci
                          I_N_light_sci = I_A_light_sci - I_Z_light_sci
                          E_intr_light =  E_Final_light 
    
                          For I = 1 To UBound(Array_E_n2_ss)
                            Array_E_n2_ss(I) = 0
                            Array_Tn(I) = 0
                          Next I 
                          E_Final_Heavy = Escission_lim * Csng(I_A_heavy_sad) / Csng(I_A_sad) - 9
                          J_Frag_heavy = 0
                          Eva(0,I_Z_heavy_sad,I_A_heavy_sad,E_intr_heavy,TheavyFF,J_Frag_heavy,R_Z_Heavy_sci, _
                            R_A_Heavy_sci,E_Final_Heavy,Array_E_n2_ss(),Array_Tn(), _
                            Array_Eg0_heavy()) 
                      
                          For I = 1 To Ubound(Array_E_n2_ss)
                            If Array_E_n2_ss(I) = 0 Then Exit For
                            ENsci(Cint(Array_E_n2_ss(I)*1000)) = ENsci(Cint(Array_E_n2_ss(I)*1000)) + 1
                            I_nu_ss = I_nu_ss + 1
                            Redim Preserve Array_En_sci(I_nu_ss)  ' for list-mode output
                            Array_En_sci(I_nu_ss) = Array_E_n2_ss(I)
                            Mid(C_pattern_sci,I_nu_ss,1) = "5"
                          Next I
                          I_A_heavy_sci = R_A_heavy_sci
                          I_Z_heavy_sci = R_Z_heavy_sci
                          I_N_heavy_sci = I_A_heavy_sci - I_Z_heavy_sci
                          E_intr_heavy =  E_Final_heavy
    
                          I_A_sci = I_A_light_sci + I_A_heavy_sci
                          I_Z_sci = I_Z_light_sci + I_Z_heavy_sci
                          I_N_sci = I_N_light_sci + I_N_heavy_sci
                        Else
                          I_A_light_sci = I_A_light_sad
                          I_Z_light_sci = I_Z_light_sad
                          I_N_light_sci = I_N_light_sad
                          I_A_heavy_sci = I_A_heavy_sad
                          I_Z_heavy_sci = I_Z_heavy_sad
                          I_N_heavy_sci = I_N_heavy_sad
                          I_A_sci = I_A_light_sad + I_A_heavy_sad
                          I_Z_sci = I_Z_light_sad + I_Z_heavy_sad
                          I_N_sci = I_N_light_sad + I_N_heavy_sad
                        End If
          
                        NNsci(I_nu_ss) = NNsci(I_nu_ss) + 1
    
                      End Scope      
        
          
                      If I_Mode = 0 Then
         '              Transition from shell-defined to macroscopic shape with increasing E* 
         '              RW_mac = relative macroscopic influence      
          
                        Dim As Single EtotS0
                        EtotS0 = Max(E_Exc_S0 + E_diss_Scission,0.0)
                        RW_mac = Gaussintegral(EtotS0-20.0,5.0)
    
            /'          Only deformation energy: '/
                        Edef1_mean = (1.0 - RW_mac) * Edefo(-1,1,I_Z_light_sci) _
                            + RW_mac * Edefo(0,1,I_Z_light_sci)
                        Edef2_mean = (1.0 - RW_mac) * Edefo(-1,2,I_Z_heavy_sci) _
                            + RW_mac * Edefo(0,2,I_Z_heavy_sci)
                            
     '                  RS = SIGDEFO_0 * Sqr(T_Pol_Mode_0 / TEgidy(P_A_CN,0.0,1.0))
               '        Scaling with Sqr(intrinsic temperature / const. T value)    
                        RS = Min(SIGDEFO_0,beta(I_Mode,1,I_Z_light_sci)) 
                        ESIGDEFOlight = _
                          ( Lymass(I_Z_light_sci,I_A_light_sci,beta(I_Mode,1,I_Z_light_sci) + RS) - _
                          Lymass(I_Z_light_sci,I_A_light_sci,beta(I_Mode,1,I_Z_light_sci) ))    
                        RS = Min(SIGDEFO_0,beta(I_Mode,2,I_Z_heavy_sci)) 
                        ESIGDEFOheavy = _
                          ( Lymass(I_Z_heavy_sci,I_A_heavy_sci,beta(I_Mode,2,I_Z_heavy_sci) + RS) - _
                          Lymass(I_Z_heavy_sci,I_A_heavy_sci,beta(I_Mode,2,I_Z_heavy_sci) ))
                      End If
                      If I_Mode > 0 And I_Mode <= 5 Then
                        Edef1_mean = Edefo(I_Mode,1,I_Z_light_sci) /' Only deformation energy '/
                        Edef2_mean = Edefo(I_Mode,2,I_Z_heavy_sci) /' Only deformation energy '/
                        RS = Min(SIGDEFO,beta(I_Mode,1,I_Z_light_sci)) 
                        ESIGDEFOlight = _
                          ( Lymass(I_Z_light_sci,I_A_light_sci,beta(I_Mode,1,I_Z_light_sci) + RS) - _
                          Lymass(I_Z_light_sci,I_A_light_sci,beta(I_Mode,1,I_Z_light_sci) )) 
                        RS = Min(SIGDEFO,beta(I_Mode,2,I_Z_heavy_sci)) 
                        ESIGDEFOheavy = _
                          ( Lymass(I_Z_heavy_sci,I_A_heavy_sci,beta(I_Mode,2,I_Z_heavy_sci) + RS) - _
                          Lymass(I_Z_heavy_sci,I_A_heavy_sci,beta(I_Mode,2,I_Z_heavy_sci) )) 
                    
    '                   If beta(I_MOde,1,I_Z_light) > 0.68 Then
    '                     ESIGDEFOlight = 0.4*ESIGDEFOlight
    '                   End If              
                   
                      End If  
                      If I_Mode = 6 Then
                        Edef1_mean = Edefo(1,2,I_Z_light_sci)  /' Shell effect stored for "heavy" fragment '/
                        Edef2_mean = Edefo(1,2,I_Z_heavy_sci)
                        RS = Min(SIGDEFO,beta(2,2,I_Z_light_sci)) 
                        ESIGDEFOlight = _
                          ( Lymass(I_Z_light_sci,I_A_light_sci,beta(2,2,I_Z_light_sci) + RS) - _
                          Lymass(I_Z_light_sci,I_A_light_sci,beta(2,2,I_Z_light_sci) ))
                        RS = Min(SIGDEFO,beta(1,2,I_Z_heavy_sci)) 
                        ESIGDEFOheavy = _
                          ( Lymass(I_Z_heavy_sci,I_A_heavy_sci,beta(1,2,I_Z_heavy_sci) + RS) - _
                          Lymass(I_Z_heavy_sci,I_A_heavy_sci,beta(1,2,I_Z_heavy_sci) ))
                      End If
                      If I_Mode = 7 Then
                        Edef1_mean = Edefo(2,2,I_Z_light_sci)  /' Shell effect stored for "heavy" fragment '/
                        Edef2_mean = Edefo(2,2,I_Z_heavy_sci)
                        RS = Min(SIGDEFO,beta(2,2,I_Z_light_sci)) 
                        ESIGDEFOlight = _
                          ( Lymass(I_Z_light_sci,I_A_light_sci,beta(2,2,I_Z_light_sci) + RS) - _
                          Lymass(I_Z_light_sci,I_A_light_sci,beta(2,2,I_Z_light_sci) ))
                        RS = Min(SIGDEFO,beta(2,2,I_Z_heavy_sci)) 
                        ESIGDEFOheavy = _
                          ( Lymass(I_Z_heavy_sci,I_A_heavy_sci,beta(2,2,I_Z_heavy_sci) + RS) - _
                          Lymass(I_Z_heavy_sci,I_A_heavy_sci,beta(2,2,I_Z_heavy_sci) ))
                      End If
                      If Edef1_mean < 0 Then Edef1_mean = 0
                      If Edef2_mean < 0 Then Edef2_mean = 0
        
          /'          Deformation of heavy and light fragment assumed to be uncorrelated '/
        
                      TKEmin = 1.44 * I_Z_light_sci * I_Z_heavy_sci / (3.0 * (I_A_light_sci^0.33333 + I_A_heavy_sci^0.3333))
          /'          TKEmin for limiting the excitation energies of the fragments '/
                      If Qvalue_sad-TKEmin < 0 Then
                        Print "<W> Estimated TKEmin > Qvalue: TKEmin = ";TKEmin;", Qvalue = ";Qvalue_sad
                        Print "    A_heavy = ";I_A_heavy_sci;", A_light;";I_A_light_sci;", Mode = ";I_Mode
                        Print "    Z_heavy = ";I_Z_heavy_sci;", Z_light;";I_Z_light_sci;", Mode = ";I_Mode
                        TKEmin = Qvalue_sad - 1  
                      End If
        
          '           Limitation of E* to avoid impossible values: Switch from shell-shape to macroscopic shape
                      If Edef1_mean > (Qvalue_sad-TKEmin) * I_A_heavy_sci / I_A_sci Then
                        Edef1_mean = Edefo(0,1,I_Z_light_sci)
                      End If
                      If Edef2_mean > (Qvalue_sad-TKEmin) * I_A_light_sci / I_A_sci Then
                        Edef2_mean = Edefo(0,2,I_Z_heavy_sci)
                      End If
         
      '               Contribution to width of TKE and TXE by fluctuation of neck length
     '                ESIGDEFOlight = sqr(ESIGDEFOLight^2 + (SIGENECK * R_Z_Light * R_Z_heavy)^2)    
     '                ESIGDEFOheavy = sqr(ESIGDEFOheavy^2 + (SIGENECK * R_Z_light * R_Z_heavy)^2)
        
                      Edef1 = -1. 
                      ESIGDEFOlight = Min(ESIGDEFOlight,Edef1_mean)
                      While Edef1 < 0. or Edef1 > (Qvalue_sad-TKEmin) * I_A_heavy_sci / I_A_sci
                        Edef1 = PGAUSS(Edef1_mean,ESIGDEFOlight)
                      Wend 
                      Edef2 = -1.
                      ESIGDEFOheavy = Min(ESIGDEFOheavy,Edef2_mean)
                      While Edef2 < 0. or Edef2 > (Qvalue_sad-TKEmin) * I_A_light_sci / I_A_sci 
                        Edef2 = PGAUSS(Edef2_mean,ESIGDEFOheavy)
                      Wend
                      Eexc_light = Edef1   ' accumulates contributions to Eexc ...
                      Eexc_heavy = Edef2   ' accululates contributions to Eexc ...
    '                 If Edef1_mean > 50 or Edef2_mean > 50 Then    
    '                   Print "Mode,Zlight,Alight,Edef1_mean",I_Mode,I_Z_light,I_A_light,Edef1_mean
    '                   Print "Mode,Zheavy,Aheavy,Edef2_mean",I_Mode,I_Z_heavy,I_A_heavy,Edef2_mean
    '                 End If
          
        /'            Assumption: width in TKE is the '/
        /'            quadratic sum of widths in defo and coll. '/
        /'            Remark of caution: The width of the TKE for fixed mass contains often
                      several fission modes. The width in Lang et al. for fixed Z contains several A,
                      which contributes already with about 3% to the width. Therefore, the
                      width in TXE (or TKE) for fixed A and fixed mode may be much smaller than
                      4 or 5 percent! '/
    
                      Acc_Edefo2d(I_A_light_sci,CInt(10.0*Edef1),Racc)       
                      Acc_Edefo2d(I_A_heavy_sci,CInt(10.0*Edef2),Racc)
    
          /'          Temperatures of fragments '/
    
                      If I_Mode <= 5 Then
                        Tlight = Temp(I_Mode,1,I_A_light_sci)
                        Theavy = Temp(I_Mode,2,I_A_heavy_sci)
                      End If
                      If I_Mode = 6 Then
                        Tlight = Temp(1,2,I_A_light_sci)
                        Theavy = Temp(1,2,I_A_heavy_sci)
                      End If
                      If I_Mode = 7 Then
                        Tlight = Temp(2,2,I_A_light_sci)
                        Theavy = Temp(2,2,I_A_heavy_sci)
                      End If 
    
    
        /'            Intrinsic excitation energies of fragments '/
        
                      Dim As Single Delta_E_Q
                      Dim As Single TKEsci, TKEsci_mean    
                      Dim As Integer I_E_Q
                      Dim As Single E_intr_tot, Sigma_E_intr
        
                      E_intr_light_mean = EPART(I_Mode,1,I_A_light_sci)
                      E_intr_heavy_mean = EPART(I_Mode,2,I_A_heavy_sci)
    
     '                TKEsci_mean = sqr( _
     '                  (0.4 * De_Saddle_Scission(Csng(I_Z_sci),Csng(I_A_sci),ESHIFTSASCI_coll))^2 +  _
     '                  (0.6 * BFTFB(I_Z_sci,I_A_sci,0)^2))  
                      TKEsci_mean = 0.4 * De_Saddle_Scission(Csng(I_Z_sci),Csng(I_A_sci),ESHIFTSASCI_coll)
    
                      If I_Mode = 0 Then  
          '             At high E*(CN), where the SL (S0) mode is dominant,
          '             TKE is only a macroscopic quantity, microscopic contributions
          '             must be suppressed.
          '             TKE is derived from empirical formula.
    
                        I_E_Q = 0
    Repeat_E_Q:
                        I_E_Q = I_E_Q + 1
                        E_intr_light = -1.
                        E_intr_tot = E_intr_light_mean + E_intr_heavy_mean
                        If E_intr_tot < 10 Then
                '         Fit function: Fluctuation of energy division from
                '         width of phase-space factor with Fermi-gas level density 
                '         (below 10 MeV: constant-T level density).
                '         Fluctuation of E_intr_tot not changed.
                          Sigma_E_intr = E_intr_tot * 0.47 * Exp(-Sqr(10/160)) / I_E_Q / 2.35
                        Else
                          Sigma_E_intr = E_intr_tot * 0.47 * Exp(-Sqr(E_intr_tot/160)) / I_E_Q / 2.35
                        End If
                        E_intr_light = PGauss(E_intr_light_mean, Sigma_E_intr)
                        E_intr_heavy = E_intr_tot - E_intr_light 
      
          '             Add E* gain after scission due to shell and pairing of fragments.
          '             This way, they are removed from TKE (further down in the code).
          '             This is reasonable, because fragment shell and pairing energies appear after scisssion.
          '             Thus, they do not appear in the TKE.
                        E_intr_light = E_intr_light - _
                        AME2020(I_Z_light_sci,I_A_light_sci) + LDMass(I_Z_light_sci,I_A_light_sci,0.) _  ' shell and pairing
                          - 2.0 * 12.0 / sqr(I_A_light_sci)     ' general shift    
                        E_intr_heavy = E_intr_heavy - _
                        AME2020(I_Z_heavy_sci,I_A_heavy_sci) + LDMass(I_Z_heavy_sci,I_A_heavy_sci,0.) _  ' shell and pairing
                          - 2.0 * 12.0 / sqr(I_A_heavy_sci)     ' general shift    
                        Dim As Single TKE_mac,TKE1,TKE2,dmod
          '             Mean pre-scission kinetic energy 
        '               dmod = (dneck + 1) '  adjusted to TKE of 250Fm(E*=45 MeV) (in conflict with Loveland 1970?)
                        dmod = dneck       '  works well for TKE of pre-actinides  
                        TKE_mac = 1.44*I_Z_light_sci*I_Z_heavy_sci/ _  
                          (1.16*(I_A_light_sci^0.33333*(1.0+0.66667*Beta(0,1,I_Z_light_sci)) + _
                          I_A_heavy_sci^0.33333*(1.0+0.66667*Beta(0,2,I_Z_heavy_sci))) +  dmod) _
                          - 1.44*(I_Z_sci/2)^2 / _   
                          (1.16*( (I_A_sci/2)^0.33333*(1.0+0.66667*Beta(0,1,I_Z_sci/2)) + _
                          (I_A_sci/2)^0.33333*(1.0+0.66667*Beta(0,2,I_Z_sci/2))) + dneck)
                   '    (Variation of TKE from macroscopic formula of Wilkins et al.
                   '    relative to value at symmetry.)
                        Delta_E_Q = - AME2020(I_Z_sci,I_A_sci) + LDMass(I_Z_sci,I_A_sci,0.) _
                          + LYMass(I_Z_light_sci,I_A_light_sci,0.) + LYMass(I_Z_heavy_sci,I_A_heavy_sci,0.) _
                          - LYMass(I_Z_sci,I_A_sci,0) _
                          - (LYMass(I_Z_sci/2,I_A_sci/2,0.) + LYMass(I_Z_sci/2,I_A_sci/2,0.) _
                          - LYMass(I_Z_sci,I_A_sci,0)) _  
                          + TKE_mac   ' replace macr. variation of Q value by Wilkins formula              
                '         + TKEsci_mean  ' add pre-scission TKE  
    '                   Print "Delta_E_Q",Delta_E_Q,I_Z_sci,I_A_sci,TKE_mac,TKEsci_mean                
          '             positives Delta_E_Q (ohne TKE_mac) erhöht TKE in den Flanken (mehr als TKE_mac)   
          '             positives TKEsci_mean erhöht TKE
          '             positives TKE_mac vermindert TKE in den Flanken   
                      
                        E_intr_light = E_intr_light - I_A_light_sci/I_A_sci * (Delta_E_Q)
                        E_intr_heavy = E_intr_heavy - I_A_heavy_sci/I_A_sci * (Delta_E_Q) 
                        E_intr_light_S0_mac = Max(0.0,E_intr_light)
                        E_intr_heavy_S0_mac = Max(0.0,E_intr_heavy)
          
    '                   Print, "After fission: ";E_intr_light,E_intr_heavy
          
                        If E_intr_light_S0_mac < 0 or E_intr_heavy_S0_mac < 0 Then 
                          If I_E_Q < 3 Then 
                            PRINT "Reapeat_E_Q"
                            Goto Repeat_E_Q
                          End If  
                          print "8158: E_intr_light/heavy = ";E_intr_light; E_intr_heavy
                          print "8159: Mean values: ";E_intr_light_mean,E_intr_heavy_mean
                          E_intr_light_S0_mac = Max(0.0,E_intr_light)
                          E_intr_heavy_S0_mac = Max(0.0,E_intr_heavy)
                        End If   
     
          
          
         '-------------------------------------------------------- 
    
                        Dim As Single TXE_shift,EtotS0
                        If I_Z_CN Mod 2 = 0 Then  
              '           Even-odd fluctuation of TXE acc. to Lang et al. NPA 345 (1980) 34
              '           Lower TXE for completely paired configuration at scission.
              '           Only the even-odd effect at symmetry is considered, because the
              '           energy gain by the asymmetry-driven even-odd effect goes to E_intr
              '           of the heavy fragment due to energy sorting.
                          If I_Z_light_sci Mod 2 = 0 Then
                            If RND < PEOZ(I_Mode,1,0.5E0*I_A_sci) Then
                              TXE_shift = - 2.0 * 12.0/sqr(I_A_sci)    ' 
                            End If   
                          End If
                        End If
             
                        E_intr_light_S0_mic = E_intr_light_mean + TXE_shift * _
                          E_intr_light_mean / (E_intr_light_mean + E_intr_heavy_mean)
                        If E_intr_light_S0_mic < 0. Then E_intr_light_S0_mic = 0.
                        E_intr_heavy_S0_mic = E_intr_heavy_mean + TXE_shift * _
                          E_intr_heavy_mean / (E_intr_heavy_mean + E_intr_light_mean)             
                        If E_intr_heavy_S0_mic < 0. Then E_intr_heavy_S0_mic = 0.        
    
                        E_intr_light_S0_mic = E_intr_light_S0_mic - Lypair(I_Z_heavy_sci,I_A_heavy_sci)  
                        E_intr_heavy_S0_mic = E_intr_heavy_S0_mic - Lypair(I_Z_heavy_sci,I_A_heavy_sci)   
    
         '-------------------------------------------------------- 
    
                        EtotS0 = Max(E_Exc_S0 + E_diss_Scission,0.0)
                        RW_mac = Gaussintegral(EtotS0-20.0,5.0)
                        E_intr_light_mean = (1.0 - Rw_mac) * E_intr_light_S0_mic + _
                                  Rw_mac * E_intr_light_S0_mac
            
                        E_intr_heavy_mean = (1.0 - Rw_mac) * E_intr_heavy_S0_mic + _
                                  Rw_mac * E_intr_heavy_S0_mac
    
         '-------------------------------------------------------- 
         
                        E_intr_light = -1.
                        RS = EexcSIGrel* sqr(2) * 0.5*sqr(E_diss_Scission^2+SIGENECK^2)+0.5
                        RS = Min(RS,E_intr_light_mean)
                        While E_intr_light < 0.  
                          E_intr_light = PGauss(E_intr_light_mean,RS)
                        Wend
    '                   Print 8196,E_intr_light_mean,RS      
                        E_intr_heavy = -1.
                        RS = EexcSIGrel* sqr(2) * 0.5*sqr(E_diss_Scission^2+SIGENECK^2)+0.5
                        RS = Min(RS,E_intr_heavy_mean)
                        While E_intr_heavy < 0.
                          E_intr_heavy = PGauss(E_intr_heavy_mean,RS)
                        Wend  
    '                   Print 8202,E_intr_heavy_mean,RS      
         '-------------------------------------------------------- 
    
                        If E_intr_light < 0 or E_intr_heavy < 0 Then _ 
                          Print "E_intr < 0",E_intr_light,E_intr_heavy        
            
                        Eintr1 = E_intr_light   ' for list-mode output
                        Eintr2 = E_intr_heavy   ' for list-mode output
      
                      Else ' If I_Mode <> 0
          
     '                    Delta_E_Q = TKEsci_mean
                          Delta_E_Q = 0
      
                          Dim As Single TXE_shift
                          If I_Z_CN Mod 2 = 0 Then  
              '             Even-odd fluctuation of TXE acc. to Lang et al. NPA 345 (1980) 34
              '             Lower TXE for completely paired configuration at scission.
              '             Only the even-odd effect at symmetry is considered, because the
              '             energy gain by the asymmetry-driven even-odd effect goes to E_intr
              '             of the heavy fragment due to energy sorting.
                            If I_Z_light_sci Mod 2 = 0 Then
                              If RND < PEOZ(I_Mode,1,0.5E0*I_A_sci) Then
                                TXE_shift = - 2.0 * 12.0/sqr(I_A_sci)            
                              End If
                            End If  
                          End If
    
                          E_intr_light_mean = E_intr_light_mean + TXE_shift * _
                            E_intr_light_mean / (E_intr_light_mean + E_intr_heavy_mean)
                          If E_intr_light_mean < 0. Then E_intr_light_mean = 0.
                          E_intr_heavy_mean = E_intr_heavy_mean + TXE_shift * _
                            E_intr_heavy_mean / (E_intr_heavy_mean + E_intr_light_mean)             
                          If E_intr_heavy_mean < 0. Then E_intr_heavy_mean = 0.
    
          '               Reduction of E_intr by TKEsci_mean
                          E_intr_light_mean = E_intr_light_mean - I_A_light_sci/I_A_sci * (Delta_E_Q)
                          E_intr_heavy_mean = E_intr_heavy_mean - I_A_heavy_sci/I_A_sci * (Delta_E_Q) 
                          If E_intr_light_mean < 0 Then
                            Print "<W> E_intr_light_mean < 0"
                            E_intr_light_mean = Max(E_intr_light_mean,0)
                          End If
                          If E_intr_heavy < 0 Then
                            Print"<W> E_intr_heavy < 0"
                            E_intr_heavy_mean = Max(E_intr_heavy_mean,0)
                          End If
    
                          E_intr_light = -1.
                          RS = EexcSIGrel* sqr(2) * 0.5*sqr(E_diss_Scission^2+SIGENECK^2)+0.5
                          
   /'                 If I_Mode = 0 Then Etot = E_exc_S0
                      If I_Mode = 1 Then Etot = E_exc_S1
                      If I_Mode = 2 Then Etot = E_exc_S2
                      If I_Mode = 3 Then Etot = E_exc_S3
                      If I_Mode = 4 Then Etot = E_exc_S4
                      If I_Mode = 5 Then Etot = E_exc_S5
                      If I_Mode = 6 Then Etot = E_exc_S11
                      If I_Mode = 7 Then Etot = E_exc_S22  '/                          
   '  RS = EexcSIGrel* sqr(2) * 0.5*sqr( ( EINTR_SCISSION)^2+SIGENECK^2)+0.5
     
                          RS = Min(RS,E_intr_light_mean)
                          While E_intr_light < 0.  
                            E_intr_light = PGauss(E_intr_light_mean,RS)
                            E_intr_light = E_intr_light - Lypair(I_Z_light_sci,I_A_light_sci)
                          Wend
    
                          E_intr_heavy = -1.
                          RS = EexcSIGrel* sqr(2) * 0.5*sqr(E_diss_Scission^2+SIGENECK^2)+0.5
                          RS = Min(RS,E_intr_heavy_mean)
                          While E_intr_heavy < 0.
                            E_intr_heavy = PGauss(E_intr_heavy_mean,RS)
                            E_intr_heavy = E_intr_heavy - Lypair(I_Z_heavy_sci,I_A_heavy_sci)  
                          Wend  
          
        
      '                   E_intr_light = E_intr_light - Lypair(I_Z_light,I_A_light)
      '                   E_intr_heavy = E_intr_heavy - Lypair(I_Z_heavy,I_A_heavy)  
                /'        Staggering of BE of fragments by pairing '/   
                /'        Assumption: pairing only felt in the lowest nuclear levels, '/
                /'        at the end of the evaporation cascade '/
                /'        (This should be a good assumption for higher excitation energies. '/
                /'        Some deviations occur due to the even-odd effect at low exc. energies. '/
          
                          Eintr1 = E_intr_light   ' for list-mode output
                          Eintr2 = E_intr_heavy   ' for list-mode output
         
                        End If ' If I_Mode <> 0
    
    '                   Print "8280 Mode,Eintr_light(mean and value) : ";I_mode,E_intr_light_mean,E_intr_light
    '                   Print "8281 Mode,Eintr_heavy(mean and value),";I_mode,E_intr_heavy_mean,E_intr_heavy
        
    
                        Qvalue_sci = AME2020(I_Z_sci,I_A_sci) - _
                          (AME2020(I_Z_heavy_sci,I_A_heavy_sci)  _
                          + AME2020(I_Z_light_sci,I_A_light_sci))
               
    /'                  I_Z_sci = 34
                        I_A_sci = 115
                        Print 34,115
                        Print AME2020(I_Z_sci,I_A_sci)
                        Print BEldmTF(CInt(I_A_sci-I_Z_sci),CInt(I_Z_sci)) 
                        Print LDmass(I_Z_sci,I_A_sci,0)
                        Print Lymass(I_Z_sci,I_A_sci,0)
                        sleep '/
               
                        If Qvalue_sci < 0 Then
                          Print "<W> Q value = ";Qvalue_sci;" (<0)."
                          Print "I_Mode = ";I_Mode
                          Print AME2020(I_Z_sci,I_A_sci),AME2020(I_Z_light_sci,I_A_light_sci), _
                          AME2020(I_Z_heavy_sci,I_A_heavy_sci)
                          Print Lymass(I_Z_sci,I_A_sci,0),Lymass(I_Z_light_sci,I_A_light_sci,0), _
                          Lymass(I_Z_heavy_sci,I_A_heavy_sci,0)     
                          Print I_Z_sci,I_A_sci,I_Z_light_sci,I_A_light_sci,I_Z_heavy_sci,I_A_heavy_sci
                          Print Ldmass(I_Z_sci,I_A_sci,0.0), U_SHELL(I_Z_sci,I_A_sci), Lypair(I_Z_sci,I_A_sci)
                          Print Ldmass(I_Z_light_sci,I_A_light_sci,0.0), U_SHELL(I_Z_light_sci,I_A_light_sci), Lypair(I_Z_light_sci,I_A_light_sci)
                          Print Ldmass(I_Z_heavy_sci,I_A_heavy_sci,0.0), U_SHELL(I_Z_heavy_sci,I_A_heavy_sci), Lypair(I_Z_heavy_sci,I_A_heavy_sci)
                        End If       
               
        /'              Nuclide distribution, pre-neutron '/
        
                        APRE(I_A_heavy_sci) = APRE(I_A_heavy_sci) + Racc 
                        APRE(I_A_light_sci) = APRE(I_A_light_sci) + Racc
                        AMPRE(I_Mode,I_A_heavy_sci) = AMPRE(I_Mode,I_A_heavy_sci) + Racc
                        AMPRE(I_Mode,I_A_light_sci) = AMPRE(I_Mode,I_A_light_sci) + Racc
    
    
                        NZPRE(I_N_light_sci,I_Z_light_sci) = NZPRE(I_N_light_sci,I_Z_light_sci) + 1
                        NZPRE(I_N_heavy_sci,I_Z_heavy_sci) = NZPRE(I_N_heavy_sci,I_Z_heavy_sci) + 1
                        NPRE(I_N_light_sci) = NPRE(I_N_light_sci) + Racc
                        NPRE(I_N_heavy_sci) = NPRE(I_N_heavy_sci) + Racc
                        NMPRE(I_Mode,I_N_light_sci) = NMPRE(I_Mode,I_N_light_sci) + Racc
                        NMPRE(I_Mode,I_N_heavy_sci) = NMPRE(I_Mode,I_N_heavy_sci) + Racc
    
    '                   ZISOPRE(I_A_Light_sci,I_Z_Light_sci) = ZISOPRE(I_A_Light_sci,I_Z_Light_sci) + Racc
                        Acc_ZISOPRE(I_A_Light_sci,I_Z_Light_sci,Racc)
    '                   ZISOPRE(I_A_Heavy_sci,I_Z_Heavy_sci) = ZISOPRE(I_A_Heavy_sci,I_Z_Heavy_sci) + Racc
                        Acc_ZISOPRE(I_A_Heavy_sci,I_Z_Heavy_sci,Racc)
    
    
                        Acc_Eintr2d(I_A_light_sci,CInt(10*E_intr_light),Racc)
                        Acc_Eintr2d(I_A_heavy_sci,CInt(10*E_intr_heavy),Racc)
    
                        Eexc_light = Eexc_light + E_intr_light
                        Eexc_heavy = Eexc_heavy + E_intr_heavy
        /'              Now: deformation + intrinsic excitation energy '/
    '                   Print 8312,I_Mode,I_Z_light_sci,E_intr_light,I_Z_heavy_sci,E_intr_heavy    
    '                   Print 8313,I_Mode,I_Z_light_sci,E_intr_light,I_Z_heavy_sci,E_intr_heavy    
    
        /'              Collective energy of fragments '/
        
                        Ecoll_mean = ECOLLFRAC * _ 
                          (De_Saddle_Scission(Csng(I_Z_CN),Csng(I_A_CN),ESHIFTSASCI_coll) - E_tunn)
    
                        If Ecoll_mean < 0. Then Ecoll_mean = 0.
        
        /'              Experimental data of prompt neutron yields show an enhancement of the '/  
        /'              neutron yield for odd-Z CN, corresponding to an enhanced E* by about 1.6 MeV '/
        /'              The enhancement is equally shared to the light and the heavy fragment. '/
        /'              The neutron number of the CN has no influence. '/ 
        /'              The origin of this effect is not clear. '/
        /'              By technical reasons, this additional energy is introduced here into the '/
        /'              collective energy at scission, because this energy is divided equally between both fragments. '/
        /'              KHS, 31. Jan. 2012 '/
      '                 If  (I_Z_CN Mod 2) = 1 Then Ecoll_mean = Ecoll_mean + 1.6
      '                 This is not used any more. It seems to be wrong or to be replaced by something else  .
    
    '                   Assuming positive correlation of Ecoll_heavy and Ecoll_light.
    '                   This is probably not realistic!
    '                   See Nix & Swiatecki, Nucl. Phys. 71 (1965) 1    
    /'                  Ecoll = -1.
                        While Ecoll < 0.
                          Ecoll = PGauss(Ecoll_mean,EexcSIGrel* Ecoll_mean)
                        Wend  
                        Ecoll = Ecoll + E_coll_saddle(I_Mode)
                        Ecoll_heavy = 0.5E0 * Ecoll
                        Ecoll_light = 0.5E0 * Ecoll '/
        
    '                   Assuming no correlation (partly positive, partly negative correlation)
    '                   See Nix & Swiatecki, Nucl. Phys. 71 (1965) 1    
                        Scope
                          Dim As Single Rmean,Rsigma 
                          Rmean = 0.5 * Ecoll_mean
                          Rsigma = sqr(0.5) * EexcSIGrel * Ecoll_mean
                          Ecoll_light = -1    
                          While Ecoll_light < 0. 
                            Ecoll_light = PGauss(Rmean,Rsigma)
                          Wend
                          Ecoll_light = Ecoll_light + 0.5E0 * E_coll_saddle(I_Mode)
                          Ecoll_heavy = -1.
                          While Ecoll_heavy < 0. 
                            Ecoll_heavy = PGauss(Rmean,Rsigma)
                          Wend
                          Ecoll_heavy = Ecoll_heavy + 0.5E0 * E_coll_saddle(I_Mode)
                          Ecoll = Ecoll_heavy + Ecoll_light
                        End Scope    
        
                        Acc_Ecoll2d(I_A_light_sci,CInt(10*Ecoll_light),Racc)
                        Acc_Ecoll2d(I_A_heavy_sci,CInt(10*Ecoll_heavy),Racc)
         
                        Eexc_light = Eexc_light + Ecoll_light
                        Eexc_heavy = Eexc_heavy + Ecoll_heavy
        /'              Now: also collective excitation energy added '/
        
    
       /'               Excitation energy not including the rotational energy at scission: '/
                        Acc_EexcA2d(I_A_light_sci,CInt(10*Eexc_light),Racc)      
                        Acc_EexcA2d(I_A_heavy_sci,CInt(10*Eexc_heavy),Racc)
    
        /'** Angular momentum of fragments **'/
    
                        Dim As Single J_Frag_light,J_Frag_heavy
                        Dim As Single J_Frag_rot_light,J_Frag_rot_heavy ' collective spin
                        Dim As Single N_J_attempt
                        N_J_attempt = 0
    J_attempt:
                        N_J_attempt = N_J_attempt + 1
                        If I_Mode <= 5 Then
                          J_Frag_light = PLinGauss(SpinRMSNZ(I_Mode,1,I_N_Light_sci,I_Z_light_sci)/sqr(2.0)) - 0.5
                          J_Frag_heavy = PLinGauss(SpinRMSNZ(I_Mode,2,I_N_Heavy_sci,I_Z_heavy_sci)/sqr(2.0)) - 0.5
                        End If
                        If I_Mode = 6 Then
                          J_Frag_light = PLinGauss(SpinRMSNZ(1,2,I_N_Light_sci,I_Z_light_sci)/sqr(2.0)) - 0.5
                          J_Frag_heavy = PLinGauss(SpinRMSNZ(1,2,I_N_Heavy_sci,I_Z_heavy_sci)/sqr(2.0)) - 0.5
                        End If
                        If I_Mode = 7 Then
                          J_Frag_light = PLinGauss(SpinRMSNZ(2,2,I_N_Light_sci,I_Z_light_sci)/sqr(2.0)) - 0.5
                          J_Frag_heavy = PLinGauss(SpinRMSNZ(2,2,I_N_Heavy_sci,I_Z_heavy_sci)/sqr(2.0)) - 0.5
                        End If  
    
                        If J_Frag_light < 0 Then J_Frag_light = 0
                        Acc_JFRAGpre(I_N_light_sci,I_Z_light_sci,J_Frag_light,1)
        
                        If J_Frag_heavy < 0 Then J_Frag_heavy = 0
                        Acc_JFRAGpre(I_N_heavy_sci,I_Z_heavy_sci,J_Frag_heavy,1)
        
                        Dim As Single Erotlight,Erotheavy,TXElight,TXEheavy
      
    
                        Dim As Single IfragEff_light,IfragEff_heavy
                        Dim As Single IfragYrast_light,IfragYrast_heavy
                        Dim As Single EYrast_light,EYrast_heavy
                        Dim As String C_iso_lmd_light, C_iso_lmd_heavy
                        Scope
                          Dim As Single TXE, E_total
      
                          IfragEff_light = U_Ired(I_Z_light_sci,I_A_light_sci)  
                          Erotlight =  J_Frag_light*(J_Frag_light+1)/(2*IfragEff_light)
               '          rotational energy at scission
          
                          IfragEff_heavy = U_Ired(I_Z_heavy_sci,I_A_heavy_sci)
                          Erotheavy =  J_Frag_heavy*(J_Frag_heavy+1)/(2*IfragEff_heavy)
               '          rotational energy at scission
             
                          Erot1 = Erotlight  ' for list-mode output
                          Erot2 = Erotheavy  ' for list-mode output
    
      /'                  Kinetic energies of fragments '/ 
      
            '             TXE includes E*_CN 
    
                          TXE = Eexc_light + Eexc_heavy + Erotlight + Erotheavy ' provisional value   
          
                          Acc_AQpre(I_A_light_sci,Qvalue_sci,1)
                          Acc_AQpre(I_A_heavy_sci,Qvalue_sci,1)
                          If Qvalue_sci < Ubound(Qvalues,1) and Qvalue_sci > Lbound(Qvalues,1) Then
                            Qvalues(Qvalue_sci) = Qvalues(Qvalue_sci) + 1
                          End If
          
          '               Effective Q value <Epot+E*> at outer barrier - <binding energy of fragments>
                          E_total = Qvalue_sci + R_E_exc_GS
    
                          TKE = E_total - TXE
          
                          Static As Integer Ntimes = 0     
                          If TKE < 0 Then
      '                   If TKE < 0 Or I_Mode =0 Then
                            If N_J_attempt <= 3 Then Goto J_attempt
                            Dim As Single TXEcorr
                            Print "<E> Event with excessive excitation energy found."
                            Print "I_A_light,I_Z_light,I_A_heavy,I_Z_heavy",I_A_light_sci,I_Z_light_sci,I_A_heavy_sci,I_Z_heavy_sci
                            Print "Q value,TKE,I_Mode",Qvalue_sci,TKE,I_Mode
                            Print "Eexc_light,Eexc_heavy,Erot_light,Erot_heavy",Eexc_light,Eexc_heavy,Erotlight,Erotheavy
                            Print "J_rms_light,J_rms_heavy",SpinRMSNZ(I_Mode,1,I_N_Light_sci,I_Z_light_sci), _
                              SpinRMSNZ(I_Mode,2,I_N_Heavy_sci,I_Z_heavy_sci)
                            Print "J_light,J_heavy",J_Frag_light,J_Frag_heavy
                            Print "Ecoll_light,Eintr_light",Ecoll_light,E_intr_light
                            Print "Ecoll_heavy,Eintr_heavy",Ecoll_heavy,E_intr_heavy
                            If I_Mode = 0 Then
                              Print "I_Mode,Edefo(light),Edefo_mic(heavy),Edefo_mac(heavy)",I_Mode, _
                              Edefo(I_Mode,1,I_Z_light_sci),Edefo(-1,2,I_Z_heavy_sci),Edefo(I_mode,2,I_Z_heavy_sci)
                              Print "E_intr_light_S0_mic,..mac,..heavy_S0_mic,..heavy_S0_mac",_
                              E_intr_light_S0_mic,E_intr_light_S0_mac,E_intr_heavy_S0_mic,E_intr_heavy_S0_mac           
                            Else
                              Print "I_Mode,Edefo(light),Edefo_(heavy)",I_Mode, _
                                Edefo(I_Mode,1,I_Z_light_sci),Edefo(I_Mode,2,I_Z_heavy_sci)
                            End If            
                            TXEcorr = TXE + TKE - 1
                            TKE = 1
                            Eexc_light = Eexc_light * TXEcorr/TXE
                            Eexc_heavy = Eexc_heavy * TXEcorr/TXE
                            TXE = TXEcorr
                            Ntimes = Ntimes + 1
                            If Ntimes > 99 Then
                              Print "<S> Calculation stopped due to numerical problem."
                              End 
                            End If      
                          End If
          
                          If Eexc_light*10 >= Lbound(EexcL2dlight,1) And _
                            Eexc_light*10 <= Ubound(EexcL2dlight,1) And _
                            J_frag_light >= Lbound(EexcL2dlight,2) And _
                            J_frag_light <= Ubound(EexcL2dlight,2) Then
                            EexcL2dlight(Eexc_light*10,J_frag_light) = EexcL2dlight(Eexc_light*10,J_frag_light) + Racc
                          End If
                          If Eexc_heavy*10 >= Lbound(EexcL2dheavy,1) And _
                            Eexc_heavy*10 <= Ubound(EexcL2dheavy,1) And _
                            J_frag_heavy >= Lbound(EexcL2dheavy,2) And _
                            J_frag_heavy <= Ubound(EexcL2dheavy,2) Then
                            EexcL2dheavy(Eexc_heavy*10,J_frag_heavy) = EexcL2dheavy(Eexc_heavy*10,J_frag_heavy) + Racc
                          End If       
                          If Erotlight*10 >= Lbound(ErotL2dlight,1) And _
                            Erotlight*10 <= Ubound(ErotL2dlight,1) And _
                            J_frag_light >= Lbound(ErotL2dlight,2) And _
                            J_frag_light <= Ubound(ErotL2dlight,2) Then
                            ErotL2dlight(Erotlight*10,J_frag_light) = ErotL2dlight(Erotlight*10,J_frag_light) + Racc
                          End If
                          If Erotheavy*10 >= Lbound(ErotL2dheavy,1) And _
                            Erotheavy*10 <= Ubound(ErotL2dheavy,1) And _
                            J_frag_heavy >= Lbound(ErotL2dheavy,2) And _
                            J_frag_heavy <= Ubound(ErotL2dheavy,2) Then
                            ErotL2dheavy(Erotheavy*10,J_frag_heavy) = ErotL2dheavy(Erotheavy*10,J_frag_heavy) + Racc
                          End If  
    
    
                          TXElight = Eexc_light  + Erotlight    ' final values
                          TXEheavy = Eexc_heavy  + Erotheavy    '  "      " 
          
          
            '             Print TXElight,TXEheavy, Erotlight,Erotheavy      
          
          
                          TXE = TXElight + TXEheavy            '  "      "  
                          TKE = E_total - TXE    ' added (Dec. 2022) to consider TXEcorr above
          
                          If TXE < Ubound(TotXE,1) and TXE > Lbound(TotXE,1) Then
                            TotXE(CInt(TXE)) = TotXE(CInt(TXE)) + 1
                          End If
    
                          Ekinlight_sci = TKE * I_A_heavy_sci / I_A_sci
                          Ekinheavy_sci = TKE * I_A_light_sci / I_A_sci
    '                     Print 7058,TKE,I_A_light_sci,I_A_heavy_sci      
    '                     Print "7057 ";I_A_light_sci,Erotlight+Erotheavy,TXE,TKE,Qvalue_sci, _    
    '                       AME2020(I_Z_sci,I_A_sci) - _
    '                      (AME2020(I_Z_heavy_sci,I_A_heavy_sci)  _
    '                      + AME2020(I_Z_light_sci,I_A_light_sci))      
    
                          If Ekinlight_sci < Ubound(Ekinpre,1) and Ekinlight_sci > Lbound(EKinpre,1) Then
                            Ekinpre(CInt(Ekinlight_sci)) = Ekinpre(CInt(Ekinlight_sci)) + 1
                            EkinpreM(I_Mode,CInt(Ekinlight_sci)) = EkinpreM(I_Mode,CInt(Ekinlight_sci)) + 1
                          End If
                          If Ekinheavy_sci < Ubound(Ekinpre,1) and Ekinheavy_sci > Lbound(EKinpre,1) Then
                            Ekinpre(CInt(Ekinheavy_sci)) = Ekinpre(CInt(Ekinheavy_sci)) + 1
                            EkinpreM(I_Mode,CInt(Ekinheavy_sci)) = EkinpreM(I_Mode,CInt(Ekinheavy_sci)) + 1
                          End If
                          Acc_AEkinpre(I_A_light_sci,CInt(Ekinlight_sci),1)
                          Acc_AEkinpre(I_A_heavy_sci,CInt(Ekinheavy_sci),1)
                          If TKE < Ubound(TKEpre,1) and TKE > Lbound(TKEpre,1) Then
                            TKEpre(CInt(TKE)) = TKEpre(CInt(TKE)) + 1
                            TKEpreM(I_Mode,CInt(TKE)) = TKEpreM(I_Mode,CInt(TKE)) + 1
                          End If
                          Acc_ATKEpre(I_A_light_sci,Cint(TKE),1)
                          Acc_ATKEpre(I_A_heavy_sci,Cint(TKE),1)
    
                        End Scope
        
     '                  Print " "
        /'** Neutron evaporation from fragments **'/
        
                        Ngtot = 0
                        Nglight = 0
                        Ngheavy = 0
                        Egtot1000 = 0
        
                        Dim As Single R_Z_Heavy_Post,R_A_Heavy_Post,R_N_Heavy_Post
                        Dim As Single R_Z_Light_Post,R_A_Light_Post,R_N_Light_Post
                        Dim As Single TLIGHTFF,THEAVYFF
                        Dim As Single E_Final,E_Kin,E_Final_Light,E_Final_Heavy
                        Dim As Single I_nu,I_nu_light,I_nu_heavy,I_nu_fr
                        Dim As Single v_N,v_N_long,v_N_perp,v_N_cm,E_N_cm,E_N_cm_eV
                        Dim As Single v_f1_CN,v_f2_CN
                        Dim As Single cos_alpha   
                        Redim As Single Array_cosalpha_nall_frag1(100)
                        Redim As Single Array_phi_nall_frag1(100) 
        
           '            Pre-scission kinetic energy
    '                   TKEsci = E_pot_scission + E_exc_Barr - Ecoll - E_intr_light - E_intr_heavy - Erotlight - Erotheavy
    '                   TKEsci_mean = sqr( _ 
    '                     (0.4 * De_Saddle_Scission(Csng(I_Z_CN),Csng(I_A_CN),ESHIFTSASCI_coll))^2 + _
    '                     (0.6 * BFTFB(I_Z_sci,I_A_sci,0)^2))  
                        TKEsci_mean = 0.4 * De_Saddle_Scission(Csng(I_Z_CN),Csng(I_A_CN),ESHIFTSASCI_coll)
    TKEsci_again:    
    '                   TKEsci = Pgauss(5,5)
    '                   TKEsci = Pgauss(7, 6.E0 * U_temp(I_Z_CN,I_A_CN,E_exc_Barr,1,1,Tscale,Econd))
    '                   TKEsci = Pgauss(4, 6.E0 * U_temp(I_Z_CN,I_A_CN,E_exc_Barr,1,1,Tscale,Econd))
    '                   TKEsci = Pgauss(TKEpre_mean, 6.E0 * U_temp(I_Z_CN,I_A_CN,E_exc_Barr,1,1,Tscale,Econd))
                        TKEsci = Pgauss(TKEsci_mean, TKEsci_mean)
    
                        If TKEsci < 0 Then Goto TKEsci_again    
    
    '                   If TKEsci < 0 Then TKEsci = 0
    
                        If I_Mode <= 5 Then
                          TlightFF = TempFF(I_Mode,1,I_A_light_sci)
                          TheavyFF = TempFF(I_Mode,2,I_A_heavy_sci)
                        End If
                        If I_Mode = 6 Then  ' S11
                          TlightFF = TempFF(1,2,I_A_light_sci)
                          TheavyFF = TempFF(1,2,I_A_heavy_sci)
                        End If   
                        If I_Mode = 7 Then  ' S22
                          TlightFF = TempFF(2,2,I_A_light_sci)
                          TheavyFF = TempFF(2,2,I_A_heavy_sci)
                        End If
    
        '*** Neutron evaporation from light fragment ***   
    
                        In_post = 0
    
                        For I = 1 To UBound(Array_E_n1_frag1)
                          Array_E_n1_frag1(I) = 0
                          Array_vlong_n1_frag1(I) = 0
                          Array_vperp_n1_frag1(I) = 0
                          Array_Tn(I) = 0
                        Next I 
                        For I = 1 To UBound(Array_Eg0_light)
                          Array_Eg0_light(I) = 0
                        Next I  
                        E_Final_Light = 0    
                        Eva(1,I_Z_light_sci,I_A_light_sci,Eexc_light,TlightFF,J_Frag_light,R_Z_Light_Post, _
                          R_A_Light_Post,E_Final_Light,Array_E_n1_frag1(),Array_Tn(), _
                          Array_Eg0_light())
                       
    ' Section inserted in order to perform the evaporation calculations for the IAEA modeling subgroup (May 2021), KHS 
    /'
                        Scope
                          Dim As Longint J,NNN
                          Dim As Integer K,L
                          Redim AZ_array(200,100) As Longint
                          NNN = 1.E8
                          Print "Start"
                          For J = 1 To NNN
    '                       Print J
                            I_A_light_sci = 139
                            I_Z_light_sci = 54
    Nochmal:
    '                       Eexc_light = 15
                            Eexc_light = Pgauss(15,3)
                            If Eexc_light > 15 + 3*2.5 Then Goto Nochmal
                            J_Frag_light = 5/2
                            E_Final_light = 0
                            TlightFF = TempFF(2,2,I_A_light_sci)  
                            Eva(1,I_Z_light_sci,I_A_light_sci,Eexc_light,TlightFF,J_Frag_light,R_Z_Light_Post, _
                              R_A_Light_Post,E_Final_Light,Array_E_n1_frag1(),Array_Tn(), _
                              Array_Eg0_light())
                            AZ_array(R_A_Light_Post,R_Z_Light_Post) = AZ_array(R_A_light_Post,R_Z_light_Post) + 1
                          Next J
                          Print "Result:"
                          For K = 130 To 140
                            For L = 50 To 60
                              If AZ_array(K,L) <> 0 Then
                                Print K,L,AZ_array(K,L)/NNN
                              End If
                            Next L
                          Next K 
                        End Scope
                        Print "Sleep"
                        Sleep
     '/
     
    
                      
     '                  Print "E_Final_Light",E_Final_light   
     '                  Print "E_Final_tot  ",E_Final_light + E_FInal_heavy      
     
                        R_N_Light_Post = R_A_Light_Post - R_Z_Light_Post
                        I_Z_Light_Post = CInt(R_Z_Light_Post)
                        I_N_Light_Post = CInt(R_N_Light_Post)
                        I_A_Light_Post = I_Z_Light_Post + I_N_Light_Post
    
                        v_f1_CN = sqr(Ekinlight_sci/I_A_light_sci)  ' final fragment velocity
                        For I = 1 To UBound(Array_E_n1_frag1)  ' Array_E_n1_frag1: n-energy in fragment frame
                          If Array_E_n1_frag1(I) = 0 Then Exit For
                          v_N = sqr(Array_E_n1_frag1(I))    ' neutron velocity, units of velocity sqrt(E/A), E in MeV
                          Array_v_n1_frag1(I) = v_N
                          If Array_Tn(I) > 100 Then
                            Array_v_f1_CN(I) = v_f1_CN  ' fragment velocity at neutron emission (=final)
                          Else
                            Array_v_f1_CN(I) = u_accel(I_A_light_sci,I_Z_light_sci,I_A_heavy_sci,I_Z_heavy_sci,TKE,TKEsci,Array_Tn(I)) 
                        '   fragment velocity at neutron emission 
                          End If  
    '                     Print 7179,Array_v_f1_CN(I),Array_Tn(I)      
                          v_N_long = v_N * (2.E0*rnd - 1.E0)  
              '           v_N * cos(theta) random choice, isotropic (long: in direction of fragment)
                          Array_vlong_n1_frag1(I) = v_N_long
                          v_N_perp = sqr(v_N^2 - v_N_long^2)  ' perp: perpendicular to direction of fragment
                          Array_vperp_n1_frag1(I) = v_N_perp
                          v_N_cm = sqr( (Array_v_F1_CN(I)+v_N_long)^2 + v_N_perp^2 )  ' neutron velocity in frame of fissioning nucleus
                          E_N_cm = v_N_cm^2   ' neutron energy in frame of fissioning nucleus
    '                     Print "*** Array_v_f1_CN(I), v_N, v_N_long, v_N_perp, v_N_cm",Array_v_f1_CN(I), v_N, v_N_long, v_N_perp, v_N_cm      
    
                          Array_E_n1_CN(I) = E_N_cm
                          In_post = In_post + 1
                          Array_E_nall_CN(In_post) = E_N_cm
         
              '           cosine of angle between light fragment and neutron 
              '           (approximation: recoil of additional neutrons neglected
                          cos_alpha = (Array_v_F1_CN(I) + v_N_long) / v_N_cm
                          Array_cosalpha_n1_frag1(I) = cos_alpha
                          Array_cosalpha_nall_frag1(In_post) = cos_alpha
                          Array_phi_n1_frag1(I) = Rnd * 360  ' phi random choice, isotropic
                          Array_phi_nall_frag1(In_post) = Array_phi_n1_frag1(I)
                          J = Int(100*cos_alpha)
                          If E_N_cm > 0.4 Then Ndirlight(J) = Ndirlight(J) + 1
           
       '                  If E_N_cm > 0 and E_N_cm*10 < UBOUND(EN) Then  
       '                    EN(Int(E_N_cm*10)) = EN(Int(E_N_cm*10)) + 1 
       '           '        neutron spectrum in cm of CN, 100 keV steps
       '                  End If
                          For J  = 1 To Ubound(ENfrvar) ' Spectrum with variable bin size
                            E_N_cm_eV = 1.E6 * E_N_cm
                            If E_N_cm_eV >= ENfrvar_lim(J-1) and E_N_cm_eV < ENfrvar_lim(J) Then
                              ENfrvar(J) = ENfrvar(J) + 1
                              Exit For
                            End If
                          Next J
                          Acc_ENfr(Int(E_N_cm*1000),1) 
            '             neutron spectrum in cm of CN, 1 keV steps
                          If Int(E_N_cm*1000) >= Lbound(_ENfr) and Int(E_N_cm*1000) <= Ubound(_ENfr) Then
                            If I_N_Multi < Ubound(_ENfrC,1) And _          ' lost neutrons
                              I_Z_Multi < Ubound(_ENfrC,2) Then            ' lost protons 
                            ' "C": for multi-Chance fission, nucleons emitted before fission
                              Acc_ENfrC(I_N_Multi,I_Z_Multi,Int(E_N_cm*1000),1)       
                            End If       
                            ENM(I_Mode, Int(E_N_cm*1000)) = ENM(I_Mode, Int(E_N_cm*1000)) + 1
                            ENlight(Int(E_N_cm*1000)) = ENlight(Int(E_N_cm*1000)) + 1
                            ENApre2d(I_A_Light_sci,Cint(E_N_cm*10)) = ENApre2d(I_A_Light_sci,Cint(E_N_cm*10)) + 1
                            ENApost2d(I_A_Light_Post,Cint(E_N_cm*10)) = _
                            ENApost2d(I_A_Light_Post,Cint(E_N_cm*10)) + 1
                            Acc_ENApre2dfs(I_A_Light_sci,Cint(Array_E_n1_frag1(I)*10),1)            
                            Acc_ENApost2dfs(I_A_Light_Post,Cint(Array_E_n1_frag1(I)*10),1)            
                            Acc_ENfrfs(Cint(Array_E_n1_frag1(I)*1000),1)         
                          Else 
                            Print "<W> Neutron kinetic energy outside spectrum range, E_N_cm = ";E_N_cm
                            Print Ekinlight_sci,TKE,R_A_light_post,I_A_light_sci,Array_Tn(I)
                            Print I,Array_E_n1_frag1(I),v_N,Array_v_F1_CN(I),v_N_long,v_N_cm,E_N_cm
                            Print I_Z_light_sci,I_N_light_sci,Eexc_light,TlightFF,E_Final_light
                            Print Lbound(_ENfr),Ubound(_ENfr),Int(E_N_cm * 1000)
                          End If        
                        Next I    
    
                        APOST(I_A_light_Post)=APOST(I_A_light_Post)+Racc
                        AMPOST(I_MODE,I_A_light_Post)=AMPOST(I_MODE,I_A_light_Post)+Racc
    
                        ZPOST(I_Z_light_Post)=ZPOST(I_Z_light_Post)+Racc
                        ZMPOST(I_Mode,I_Z_light_Post)=ZMPOST(I_Mode,I_Z_light_Post)+Racc
    
                        NPOST(I_N_Light_Post)=NPOST(I_N_Light_Post)+Racc 
                        NMPOST(I_Mode,I_N_Light_Post)=NMPOST(I_Mode,I_N_Light_Post)+Racc
    
                        Acc_NZPOST(I_N_light_Post,I_Z_light_post,Racc)               
                       
                        I_nu_light = I_A_Light_sci - I_A_Light_Post               
                        If I_nu_light >= 0 and I_nu_light <= 50 Then
                          NNlight(I_nu_light) = NNlight(I_nu_light) + 1
                        End If
                        If I_nu_light >= 0 and I_nu_light <= 20 Then
                          N2dpost(I_A_Light_Post,I_nu_light)=N2dpost(I_A_Light_post,I_nu_light)+1
                          N2dpre(I_A_Light_sci,I_nu_light)=N2dpre(I_A_Light_sci,I_nu_light)+1
                        End If  
    
    
        '*** Neutron evaporation from heavy fragment ***   
        
                        For I = 1 To UBound(Array_E_n2_frag2)
                          Array_E_n2_frag2(I) = 0
                          Array_vlong_n2_frag2(I) = 0
                          Array_vperp_n2_frag2(I) = 0
                          Array_Tn(I) = 0
                        Next 
                        For I = 1 To UBound(Array_Eg0_heavy)
                          Array_Eg0_heavy(I) = 0
                        Next I       
                        E_Final_Heavy = 0
                        Eva(2,I_Z_heavy_sci,I_A_heavy_sci,Eexc_heavy,TheavyFF,J_Frag_heavy,R_Z_Heavy_Post, _
                          R_A_Heavy_Post,E_Final_Heavy,Array_E_n2_frag2(),Array_Tn(), _
                          Array_Eg0_heavy()) 
                      
                        R_N_Heavy_Post = R_A_Heavy_Post - R_Z_Heavy_Post
                        I_Z_Heavy_Post = CInt(R_Z_Heavy_Post)
                        I_N_Heavy_Post = CInt(R_N_Heavy_Post)
                        I_A_Heavy_Post = I_Z_Heavy_Post + I_N_Heavy_Post
    
                        v_f2_CN = sqr(Ekinheavy_sci/I_A_heavy_sci)
                        For I = 1 To UBound(Array_E_n2_frag2)
                          If Array_E_n2_frag2(I) = 0 Then Exit For
                          v_N = sqr(Array_E_n2_frag2(I))    ' units of velocity sqrt(E/A), E in MeV
                          Array_v_n2_frag2(I) = v_N
                          If Array_Tn(I) > 100 Then
                            Array_v_f2_CN(I) = v_f2_CN
                          Else
                            Array_v_f2_CN(I) = u_accel(I_A_heavy_sci,I_Z_heavy_sci,I_A_light_sci,I_Z_light_sci,TKE,TKEsci,Array_Tn(I))  
                          End If  
                          v_N_long = v_N * (2.E0*rnd - 1.E0)
                          Array_vlong_n2_frag2(I) = v_N_long
                          v_N_perp = sqr(v_N^2 - v_N_long^2)
                          Array_vperp_n2_frag2(I) = v_N_perp
                          v_N_cm = sqr( (Array_v_f2_CN(I)+v_N_long)^2 + v_N_perp^2 )
                          E_N_cm = v_N_cm^2
    '                     Print "*** Array_v_f2_CN(I), v_N, v_N_long, v_N_perp, v_N_cm",Array_v_f2_CN(I), v_N, v_N_long, v_N_perp, v_N_cm      
          
                          Array_E_n2_CN(I) = E_N_cm
                          In_post = In_post + 1
                          Array_E_nall_CN(In_post) = E_N_cm
          
            '             cosine of angle between heavy and light fragment and emitted neutron in CN frame 
            '             (approximation: recoil of additional neutrons neglected)
                          cos_alpha = (Array_v_f2_CN(I) + v_N_long) / v_n_cm
                          Array_cosalpha_n2_frag2(I) = cos_alpha
                          Array_cosalpha_nall_frag1(In_post) = - cos_alpha
                          Array_phi_n2_frag2(I) = Rnd * 360
                          Array_phi_nall_frag1(In_post) = Array_phi_n2_frag2(I) + 180
                          If Array_phi_nall_frag1(In_post) > 360 Then
                            Array_phi_nall_frag1(In_post) = Array_phi_nall_frag1(In_post) - 360
                          End If
                          J = Int(100*cos_alpha)
                          If E_N_cm > 0.4 Then Ndirlight(J) = Ndirlight(J) + 1            
          
       /'                 If E_N_cm > 0 and E_N_cm*10 < UBOUND(EN) Then  
                            EN(Int(E_N_cm*10)) = EN(Int(E_N_cm*10)) + 1 
                '           neutron spectrum in cm of CN, 100 keV steps
                          End If  '/ 
                          For J  = 1 To Ubound(ENfrvar) ' Spectrum with variable bin size
                            E_N_cm_eV = 1.E6 * E_N_cm
                            If E_N_cm_eV >= ENfrvar_lim(J-1) and E_N_cm_eV < ENfrvar_lim(J) Then
                              ENfrvar(J) = ENfrvar(J) + 1
                              Exit For
                            End If
                          Next J   
                          Acc_ENfr(Int(E_N_cm*1000),1)
                          If Int(E_N_cm*1000) >= Lbound(_ENfr) and Int(E_N_cm*1000) <= Ubound(_ENfr) Then   ' Enfr = neutron energy emitted from fragments
                            Acc_ENfrc(I_N_Multi,I_Z_Multi,Int(E_N_cm*1000),1)       
                            ENM(I_Mode,Int(E_N_cm*1000))= ENM(I_Mode,Int(E_N_cm*1000)) + 1
                            ENheavy(Int(E_N_cm*1000)) = ENheavy(Int(E_N_cm*1000)) + 1 
                            ENApre2d(I_A_Heavy_sci,Cint(E_N_cm*10)) = ENApre2d(I_A_Heavy_sci,Cint(E_N_cm*10)) + 1
                            ENApost2d(I_A_Heavy_Post,Cint(E_N_cm*10)) = _
                            ENApost2d(I_A_Heavy_Post,Cint(E_N_cm*10)) + 1
                            Acc_ENApre2dfs(I_A_Heavy_sci,Cint(Array_E_n2_frag2(I)*10),1)            
                            Acc_ENApost2dfs(I_A_Heavy_Post,Cint(Array_E_n2_frag2(I)*10),1)            
                            Acc_ENfrfs(Cint(Array_E_n2_frag2(I)*1000),1)
                          Else 
                            Print "<W> Neutron kinetic energy outside spectrum range, E_N_cn =";E_N_cm;" MeV"
                            Print Ekinheavy,TKE,R_A_heavy_post,I_A_heavy_sci,Array_Tn(I)
                            Print I,Array_E_n2_frag2(I),v_N,v_f2_CN,v_N_long,v_N_cm,E_N_cm
                            Print I_Z_heavy_sci,I_N_heavy_sci,Eexc_heavy,TheavyFF,E_Final_heavy
                            Print Lbound(_ENfr),Ubound(_ENfr),Int(E_N_cm * 1000)
                          End If     
                        Next I              
    
                        APOST(I_A_heavy_Post)=APOST(I_A_heavy_Post)+Racc
                        AMPOST(I_MODE,I_A_heavy_Post)=AMPOST(I_MODE,I_A_heavy_Post)+Racc
    
                        ZPOST(I_Z_heavy_Post)= ZPOST(I_Z_heavy_Post)+Racc  
                        ZMPOST(I_Mode,I_Z_heavy_post)=ZMPOST(I_Mode,I_Z_heavy_post)+Racc 
    
                        NPOST(I_N_Heavy_Post)=NPOST(I_N_Heavy_Post)+Racc
                        NMPOST(I_Mode,I_N_Heavy_Post)=NMPOST(I_Mode,I_N_Heavy_Post)+Racc
    
                        Acc_NZPOST(I_N_heavy_Post,I_Z_heavy_post,Racc)    
                        I_nu_heavy = I_A_heavy_sci - I_A_Heavy_Post
                        If I_nu_heavy >= 0 and I_nu_heavy <= 50 Then
                          NNheavy(I_nu_heavy) = NNheavy(I_nu_heavy) + 1
                        End If    
                        If I_nu_heavy >= 0 and I_nu_heavy <= 20 Then
                          N2dpost(I_A_Heavy_Post,I_nu_heavy)=N2dpost(I_A_Heavy_Post,I_nu_heavy)+1
                          N2dpre(I_A_Heavy_sci,I_nu_heavy)=N2dpre(I_A_Heavy_sci,I_nu_heavy)+1
                        End If  
                        I_nu_fr = I_nu_heavy + I_nu_light
                        If I_nu_fr >= 0 and I_nu_fr <= 50 Then
                          NNfr(I_nu_fr) = NNfr(I_nu_fr) + 1
                        End If
        
        '*** Neutrons emitted from CN prior to fission
        
                        If I_A_Light_sci >= Lbound(Nmulti2dpre,1) And I_A_Light_sci <= Ubound(Nmulti2dpre,1) And _
                          I_N_Multi >= Lbound(Nmulti2dpre,2) And I_N_Multi <= Ubound(Nmulti2dpre,2) Then
                          Nmulti2dpre(I_A_light_sci,I_N_Multi) = Nmulti2dpre(I_A_light_sci,I_N_Multi) + 1
                        End If    
                        If I_A_Light_post >= Lbound(Nmulti2dpost,1) And I_A_Light_post <= Ubound(Nmulti2dpost,1) And _
                          I_N_Multi >= Lbound(Nmulti2dpost,2) And I_N_Multi <= Ubound(Nmulti2dpost,2) Then
                          Nmulti2dpost(I_A_light_post,I_N_Multi) = Nmulti2dpost(I_A_light_post,I_N_Multi) + 1
                        End If    
                        If I_A_heavy_sci >= Lbound(Nmulti2dpre,1) And I_A_heavy_sci <= Ubound(Nmulti2dpre,1) And _
                          I_N_Multi >= Lbound(Nmulti2dpre,2) And I_N_Multi <= Ubound(Nmulti2dpre,2) Then
                          Nmulti2dpre(I_A_heavy_sci,I_N_Multi) = Nmulti2dpre(I_A_heavy_sci,I_N_Multi) + 1
                        End If    
                        If I_A_heavy_post >= Lbound(Nmulti2dpost,1) And I_A_heavy_post <= Ubound(Nmulti2dpost,1) And _
                          I_N_Multi >= Lbound(Nmulti2dpost,2) And I_N_Multi <= Ubound(Nmulti2dpost,2) Then
                          Nmulti2dpost(I_A_heavy_post,I_N_Multi) = Nmulti2dpost(I_A_heavy_post,I_N_Multi) + 1
                        End If    
           
    
        '*** Post-neutron energies
    
                        If TKE >= 0 and TKE <= 250 and I_nu_fr >=0 and I_nu_fr <=20 Then
                          nuTKEpre(TKE,I_nu_fr) = nuTKEpre(TKE,I_nu_fr) + 1
                        End If
     '                  Ekinlight_post = Ekinlight_sci * (I_A_light_post/I_A_Light)  ' not exact!
                        vkinlight = sqr(Ekinlight_sci/I_A_Light_sci)   ' velocity in units of sqr(MeV/A)
                        J = I_A_light_sci
                        For I = 1 To Ubound(Array_vlong_n1_frag1)
                          If Array_vlong_n1_frag1(I) <> 0 Then
                          J = J - 1
                          vkinlight = vkinlight - Array_vlong_n1_frag1(I) / J
                          vkinlight = sqr(vkinlight^2 + (Array_vperp_n1_frag1(I)/J)^2 )
                        End If 
                      Next I
                      Ekinlight_post = vkinlight^2 * I_A_light_post
    
     '                Ekinheavy_post = Ekinheavy * (I_A_heavy_post/I_A_heavy_sci)  '  "    "
                      vkinheavy = sqr(Ekinheavy_sci/I_A_heavy_sci)   ' velocity in units of sqr(MeV/A)
                      J = I_A_heavy_sci
                      For I = 1 To Ubound(Array_vlong_n2_frag2)
                        If Array_vlong_n2_frag2(I) <> 0 Then
                          J = J - 1
                          vkinheavy = vkinheavy - Array_vlong_n2_frag2(I) / J
                          vkinheavy = sqr(vkinheavy^2 + (Array_vperp_n2_frag2(I)/J)^2 )
                        End If
                      Next I
                      Ekinheavy_post = vkinheavy^2 * I_A_heavy_post
    
                      TKE_post = Ekinlight_post + Ekinheavy_post          
                      If TKE_post >= 0 and TKE_post <= 250 and I_nu_fr >=0 and I_nu_fr <=20 Then
                        nuTKEpost(TKE_post,I_nu_fr) = nuTKEpost(TKE_post,I_nu_fr) + 1
                      End If    
        
                      If Ekinlight_post < Ubound(Ekinpost,1) and Ekinlight_post > Lbound(EKinpost,1) Then
                        Ekinpost(CInt(Ekinlight_post)) = Ekinpost(CInt(Ekinlight_post)) + 1
                        EkinpostM(I_Mode,CInt(Ekinlight_post)) = EkinpostM(I_Mode,CInt(Ekinlight_post)) + 1
                      End If
                      If Ekinheavy_post < Ubound(Ekinpost,1) and Ekinheavy_post > Lbound(EKinpost,1) Then
                        Ekinpost(CInt(Ekinheavy_post)) = Ekinpost(CInt(Ekinheavy_post)) + 1
                        EkinpostM(I_Mode,CInt(Ekinheavy_post)) = EkinpostM(I_Mode,CInt(Ekinheavy_post)) + 1
                      End If
    
                      If TKE_post < Ubound(TKEpost,1) and TKE_post > Lbound(TKEpost,1) Then
                        TKEpost(CInt(TKE_post)) = TKEpost(CInt(TKE_post)) + 1
                        TKEpostM(I_Mode,CInt(TKE_post)) = TKEpostM(I_Mode,CInt(TKE_post)) + 1
                      End If    
                      Acc_AEkinpost(I_A_light_post,CInt(Ekinlight_post),1)
                      Acc_AEkinpost(I_A_heavy_post,CInt(Ekinheavy_post),1)
                      Acc_ATKEpost(I_A_light_post,Cint(TKE_post),1)                 
                      Acc_ATKEpost(I_A_heavy_post,Cint(TKE_post),1)
    
                      Acc_ZISOPOST(I_A_Light_Post,I_Z_Light_post,Racc)             
                      Acc_ZISOPOST(I_A_Heavy_Post,I_Z_Heavy_post,Racc)
    
                      Acc_JFRAGpost(I_N_light_post,I_Z_light_post,J_Frag_light,1)
                      Acc_JFRAGpost(I_N_heavy_post,I_Z_heavy_post,J_Frag_heavy,1) 
    
      /'              Scission neutrons (for testing only, not considered in energy balance!) '/
      /'              If Rnd < 0.3 Then
                        E_N_cm = PMaxwell(0.5)
                        EN(Int(E_N_cm*1000)) = EN(Int(E_N_cm*1000)) + 1
                      End If '/
    
    
      /' Prompt gamma emission '/
    
                      Scope
                        Dim As Single Einit,Eg0,Eg,Erest
                        Dim As Single sigmaEgyrast  ' rms fluctuation of Eg to yrast line by orientation of E1 photon
                        Dim As Single Jfrag,Ifrag  ' angular momentum, inertia
        '               Dim As Single I_rigid_spher_yrast,I_eff
        '               Dim As Integer Nspectrum,N,I,Icount
                        Dim As Single RJeff
                        Dim As Integer Nspectrum
                        Dim As Single xran,yran
                        Dim As Integer I_MAT,N_iso,I_iso
                        Dim As Single alph
                        Dim As Single J,K
    
      '                 1st (light) fragment    
      
    '                   I_Z_light = 36
    '                   I_A_light_post = 92    
    '                   Print "92Kr"
      
                        I_MAT = I_MAT_ENDF(I_Z_light_sci,I_A_light_post) ' MAT nmbr of the ground state
                        If I_MAT >= LBound(NucTab) And I_MAT <= UBound(NucTab) Then
                          Spin_gs_light =  NucTab(I_MAT).R_SPI  ' ground.state spin of light fragment
                        Else
                          Spin_gs_light = 0
                        End If   
                        J_frag_rot_light = ( (J_frag_light - Spin_gs_light) \ 2 ) * 2  ' collective spin
                        Jfrag = J_frag_rot_light
    '                   Jfrag = 10      
    
                        Einit = E_Final_Light 
     '                  Entrance energy above yrast line (energy after last prompt neutron)
                        Nspectrum = Einit*1000 
                        Acc_Eentrance(Nspectrum,1)
          
      '                 E1 gammas
                        Erest = E_Final_Light  
                        sigmaEgyrast = 0.3 * Erotlight * ((Jfrag+1)^2 / (Jfrag-1)^2)
          '             Energy spread by spin of E1 gamma (changing the FF angular momentum):
          '             Erest = Pgauss(Erest,sigmaEgyrast)
                        Ig1_light = 0
                        While Erest >= 0.1   
    Repeat_Eg_light:
                          Eg0 = P_Egamma_low(I_Z_light_sci, I_A_light_post, Erest)  ' in MeV
                          Eg = Pgauss(Eg0,sigmaEgyrast)
                          If Eg < 0 Or Eg > 2*Eg0 Then Goto Repeat_EG_light 
              
                          Ig1_light = Ig1_light + 1 
                          Array_Eg1_light(Ig1_light) = Eg
            
                          xran = 1000.*Eg  ' in keV
    
           '              Accumulate E1 gammas
                          Nspectrum = CInt(xran)
                          If Nspectrum > 0 Then
                            If Nspectrum <= Ubound(_Egamma) Then
                              #Ifdef B_EgammaA 
                                StoreEgammaA(Nspectrum,I_A_light)
                              #EndIf 
                            End If
                            Acc_Egamma(Nspectrum,1)
                            Acc_EgammaL(Nspectrum,1)
                            Nglight = Nglight + 1
                            Ngtot = Ngtot + 1
                            Egtot1000 = Egtot1000 + xran    ' in 1 keV units
                          End If  
                          Erest = Erest - Eg  '  in MeV units
                        Wend
           
          
            '           Rotational band (note that Erest is counted above the yrast line!)
                        Dim As Single E_E2_tot 
                        E_E2_tot = 0         
                        IfragEff_light = U_IredFF(I_Z_light_sci,I_A_light_post) 
                        beta1 = DEFOtab(I_A_light_post - I_Z_light_sci, I_Z_light_sci)
                        alph = beta1 / sqr(4.E0 * pi / 5.E0)
                        IfragEff_light = IfragEff_light * (1.E0 + 0.5E0*alph + 9.E0/7.E0*alph^2)
                     /' From Hasse & Myers, Geometrical Relationships ... '/      
                        Ig2_light = 0
                        N_iso = N_ISO_MAT(I_MAT) ' nmbr of isomers in the nucleus with Mat nmbr I_MAT
                        If N_iso > 0 Then
                          I_iso = ISO_for_MAT(I_MAT)
                        End If    
                        C_iso_lmd_light = "GS"    
                        For J = Jfrag to 2 step -2
                    '     Stop gamma cascade at next isomer:
                          If N_iso > 0 And I_DelGam = 0 Then 
    '                       Print        
    '                       Print "Z,A",I_Z_light,I_A_light_post
    '                       Print "N_iso,N_states",N_iso,Isotab(I_iso).N_STATES        
                            For K = 1 To Isotab(I_iso).N_STATES
                              If J = Jfrag Then
       '                      If Isotab(I_iso).R_SPI(K) = Cint(J_frag_light + Spin_gs_light) Then Exit For, For
                                If Isotab(I_iso).R_SPI(K) = Cint(J_frag_light) Then Exit For, For
                              End If  
    '                         Print "K,Spin",K,Isotab(I_iso).R_SPI(K)          
                              If Isotab(I_iso).R_SPI(K) <= Jfrag + Spin_gs_light + 0.01 Then
                                If Isotab(I_iso).R_SPI(K) >= J + Spin_gs_light - 0.01 Then
                                  C_iso_lmd_light = "M("+Trim(Str(Isotab(I_iso).R_SPI(K)))+"/"+ _
                                          Trim(Str(Isotab(I_iso).R_EXC(K)))+")"
                                  Exit For, For
                                End If 
                              End If  
                            Next K   
    '                       Print "Jfrag,J",Jfrag,J          
                          End If
               '          Influence of shell effect: transition from rotation to vibration:
                          RJeff = 2 + (J - 2) * ( U_I_Shell(I_Z_light_sci,I_A_light_post) )^2 
               '          Influence of pairing: transition from irrotational flow to rigid body:
                          RJeff = 0.45 * RJeff + 0.65 * RJeff * Max( (12.0 - RJeff)/12.0 , 0.0)     
                          Eg = RJeff*(RJeff+1)/(2*IfragEff_light) - (RJeff-2)*(RJeff-1)/(2*IfragEff_light)
                          E_E2_tot = E_E2_tot + Eg
    '                     Print J,Eg        
                          Ig2_light = Ig2_light + 1
                          Array_Eg2_light(Ig2_light) = Eg  ' Store next gamma in the array of emitted gammas      
                          Nspectrum = Int(Eg*1000 + 0.5)   ' 1 keV units
                          If Nspectrum > 0 Then
                            Nglight = Nglight + 1
                            Ngtot = Ngtot + 1
                            Egtot1000 = Egtot1000 + Eg * 1000
                            If Nspectrum <= Ubound(_Egamma) Then 
                              #Ifdef B_EgammaA 
                                StoreEgammaA(Nspectrum,I_A_light)
                              #EndIf  
                            End If 
                            Acc_Egamma(Nspectrum,1)
                            Acc_EgammaL(Nspectrum,1)
                            Acc_EgammaE2(Nspectrum,1)
                          End If      
                        Next J   
           
      '                 2nd (heavy) fragment   
        
    '                   Input I_Z_Heavy, I_A_heavy_post, J_frag_heavy
      
    '                   I_Z_heavy = 58
    '                   I_A_heavy_post = 140     
    '                   Print "58,140"
      
      
                        I_MAT = I_MAT_ENDF(I_Z_heavy_sci,I_A_heavy_post)    
                        If I_MAT >= Lbound(NucTab) And I_MAT <= Ubound(NucTab) Then
                          Spin_gs_heavy =  NucTab(I_MAT).R_SPI  ' ground.state spin of light fragment
                        Else
                          Spin_gs_heavy = 0
                        End If  
                        J_frag_rot_heavy = ( (J_frag_heavy - Spin_gs_heavy) \ 2 ) * 2   ' collective spin
                        Jfrag = J_frag_rot_heavy
    
                        Einit = E_Final_Heavy
     '                  Entrance energy above yrast line (energy after last prompt neutron)
                        Nspectrum = Einit*1000 
                        Acc_Eentrance(Nspectrum,1)
          
              '         E1 gammas
                        Erest = E_Final_Heavy   
                        sigmaEgyrast = 0.3 * Erotheavy * ((Jfrag+1)^2 / (Jfrag-1)^2)
          '             Energy spread by spin of E1 gamma (changing the FF angular momentum):
          '             Erest = Pgauss(Erest,sigmaEgyrast)
                        Ig1_heavy = 0 
                        While  Erest >= 0.1
    Repeat_EG_heavy:
                          Eg0 = P_Egamma_low(I_Z_heavy_sci, I_A_heavy_post, Erest)   ' in MeV
                          Eg = Pgauss(Eg0,sigmaEgyrast)
                          If Eg < 0 Or Eg > 2*Eg0 Then Goto Repeat_EG_heavy 
                          Ig1_heavy = Ig1_heavy + 1 
                          If Ig1_heavy < Lbound(Array_Eg1_heavy) or Ig1_heavy > Ubound(Array_Eg1_heavy) Then
                            Print "<W> Array_Eg1_heavy out of bounds, Ig1_heavy = ";Ig1_heavy
                          Else
                            Array_Eg1_heavy(Ig1_heavy) = Eg
                          End If     
                 
                          xran = 1000 * Eg  
          
          '               Accumulate E1 gammas
                          Nspectrum = CInt(xran)
                          If Nspectrum > 0 Then
                            If Nspectrum <= Ubound(_Egamma) Then
                              Egamma(Nspectrum) = Egamma(Nspectrum) + 1         ' 1 keV units
                              #If EgammaA 
                                StoreEgammaA(Nspectrum,I_A_heavy)
                              #EndIf 
                            End If
                            Acc_EgammaH(Nspectrum,1)
                            Ngheavy = Ngheavy + 1
                            Ngtot = Ngtot + 1
                            Egtot1000 = Egtot1000 + xran    ' in 1 keV units
                          End If  
                          Erest = Erest - Eg  '  in MeV units
                        Wend 
    
          '               Rotational band (note that Erest is counted above the yrast line!)
                        E_E2_tot = 0      
                        IfragEff_heavy = U_IredFF(I_Z_heavy_sci,I_A_heavy_post) 
                        beta1 = DEFOtab(I_A_heavy_post - I_Z_heavy_sci, I_Z_heavy_sci)
                        alph = beta1 / sqr(4.E0 * pi / 5.E0)
                        IfragEff_heavy = IfragEff_heavy * (1.E0 + 0.5E0*alph + 9.E0/7.E0*alph^2)
                     /' From Hasse & Myers, Geometrical Relationships ... '/   
                        Ig2_heavy = 0
                        N_iso = N_ISO_MAT(I_MAT)  ' nmbr of isomeric states in the fragment
                        If N_iso > 0 Then
                          I_iso = ISO_for_MAT(I_MAT)
                        End If    
                        C_iso_lmd_heavy = "GS"    
                        For J = Jfrag to 2 step -2
                        ' Stop gamma cascade at next isomer:
                          If N_iso > 0 And I_DelGam = 0 Then 
                            For K = 1 To Isotab(I_iso).N_STATES
                              If J = Jfrag Then
       '                        If Isotab(I_iso).R_SPI(K) = Cint(J_frag_heavy + Spin_gs_heavy) Then Exit For, For
                                If Isotab(I_iso).R_SPI(K) = Cint(J_frag_heavy) Then Exit For, For
                              End If  
                              If Isotab(I_iso).R_SPI(K) <= Jfrag + Spin_gs_heavy + 0.01 Then
                                If Isotab(I_iso).R_SPI(K) >= J + Spin_gs_heavy - 0.01 Then 
                                  C_iso_lmd_heavy = "M("+Trim(Str(Isotab(I_iso).R_SPI(K)))+"/"+ _
                                          Trim(Str(Isotab(I_iso).R_EXC(K)))+")"
                                  Exit For, For
                                End If 
                              End If  
                            Next K   
                          End If      
               '          Influence of shell effect: transition from rotation to vibration:
                          RJeff = 2 + (J - 2) * ( U_I_Shell(I_Z_heavy_sci,I_A_heavy_post) )^2   
               '          Influence of pairing: transition from irrotational flow to rigid body:
                          RJeff = 0.45 * RJeff + 0.65 * RJeff * Max( (12.0 - RJeff)/12.0 , 0.0)     
                          Eg = RJeff*(RJeff+1)/(2*IfragEff_heavy) - (RJeff-2)*(RJeff-1)/(2*IfragEff_heavy)
                          E_E2_tot = E_E2_tot + Eg
              
    '                     Print J,Eg        
                          Ig2_heavy = Ig2_heavy + 1
                          Array_Eg2_heavy(Ig2_heavy) = Eg        
                          Nspectrum = Int(Eg*1000 + 0.5)   ' 1 keV units
                          If Nspectrum > 0 Then
                            Ngheavy = Ngheavy + 1        
                            Ngtot = Ngtot + 1
                            Egtot1000 = Egtot1000 + Eg * 1000
                            If Nspectrum <= Ubound(_Egamma) Then 
                              #Ifdef B_EgammaA 
                                StoreEgammaA(Nspectrum,I_A_heavy)
                              #EndIf  
                            End If 
                            Acc_Egamma(Nspectrum,1)
                            Acc_EgammaH(Nspectrum,1)
                            Acc_EgammaE2(Nspectrum,1)
                          End If      
                        Next J 
        
                      End Scope
    '                 sleep  
      
                      If Nglight <= Ubound(NgammaA,2) Then _
                        NgammaA(I_A_light_post,Nglight) = NgammaA(I_A_light_post,Nglight) + 1
                      If Ngheavy <= Ubound(NgammaA,2) Then _
                        NgammaA(I_A_heavy_post,Ngheavy) = NgammaA(I_A_heavy_post,Ngheavy) + 1
                      If Ngtot <= Ubound(Ngammatot) Then Ngammatot(Ngtot)=Ngammatot(Ngtot) + 1  
                      Acc_Egammatot(EGtot1000,1)   
    
                      Nglight = 0
                      Ngheavy = 0
                      Ngtot = 0
                      Egtot1000 = 0
    
    
        /'            Keeping track of pre-saddle particle emission '/
                      Scope 
                        Dim As String C_test
                        Dim As ULongint Ilong
                        Redim As Integer IE_array(10)
          
          '             1. Multiplicities
                        NP(I_Z_Multi) = NP(I_Z_Multi) + 1 
                        NNCN(I_N_Multi) = NNCN(I_N_Multi) + 1
                        I_nu = I_nu_fr + I_nu_ss + I_N_Multi
                        If I_nu < Lbound(NN) Or I_nu > Ubound(NN) Then
                          Print "<W> NN out of bounds, I_nu =";I_nu
                        Else
                          NN(I_nu) = NN(I_nu) + 1
                        End If  
    
          '             2. Energies  
          '             (This is also a preparation for the list-mode output.)
                        Select Case I_A_multi
                          Case 1
                            For J = J_multi_last(1) To 2 * Imulti  ' Loop over 2nd-chance fission events,
                          '   starts at 0 (first time) and J_multi_last(1), last found match.
                              K = J Mod Ubound(En_multi_1) + 1  
                '             search next 2nd-chance fission event  
                '             but remain <= total number of 2nd-chance events
                              If PLoss(I_emit_1(K)) = I_Z_Multi Then ' condition on number of pre-fission protons
                                If En_multi_1(K) Mod 2^10 = I_E_Multi Then ' check whether E_CN fits
                                  J_multi_last(1) = K  ' update J_multi_last(1) 
                                  C_test = Oct(I_emit_1(K))
                                  Ilong = Fix(En_multi_1(K)*2^-10)
                                  IE_array(1) = Ilong Mod 2^10
                                  Exit For
                                End If  
                              End If
                            Next J
                          Case 2
                            For J = J_multi_last(2) To 2 * Imulti
                              K = J Mod Ubound(En_multi_2) + 1
                              If PLoss(I_emit_2(K)) = I_Z_Multi Then
                                If En_multi_2(K) Mod 2^10 = I_E_Multi Then                   
                                  J_multi_last(2) = K
                                  C_test = Oct(I_emit_2(K))
                                  Ilong = Fix(En_multi_2(K)*2^-10)
                                  IE_array(1) = Ilong Mod 2^10
                                  Ilong = Fix(En_multi_2(K)*2^-20)
                                  IE_array(2) = Ilong Mod 2^10
                                  Exit For
                                End If  
                              End If
                            Next J            
                          Case 3
                            For J = J_multi_last(3) To 2 * Imulti
                              K = J Mod Ubound(En_multi_3) + 1
                              If PLoss(I_emit_3(K)) = I_Z_Multi Then
                                If En_multi_3(K) Mod 2^10 = I_E_Multi Then
                                  J_multi_last(3) = K
                                  C_test = Oct(I_emit_3(K))
                                  Ilong = Fix(En_multi_3(K)*2^-10)
                                  IE_array(1) = Ilong Mod 2^10
                                  Ilong = Fix(En_multi_3(K)*2^-20)
                                  IE_array(2) = Ilong Mod 2^10
                                  Ilong = Fix(En_multi_3(K)*2^-30)
                                  IE_array(3) = Ilong Mod 2^10
                                  Exit For
                                End If   
                              End If 
       
                            Next J  
                          Case 4
                            For J = J_multi_last(4) To 2 * Imulti
                              K = J Mod Ubound(En_multi_4) + 1 
                              If En_multi_4(K) Mod 2^10 = I_E_Multi And _
                                     PLoss(I_emit_4(K)) = I_Z_Multi Then 
                                J_multi_last(4) = K
                                C_test = Oct(I_emit_4(K))
                                Ilong = Fix(En_multi_4(K)*2^-10)
                                IE_array(1) = Ilong Mod 2^10
                                Ilong = Fix(En_multi_4(K)*2^-20)
                                IE_array(2) = Ilong Mod 2^10
                                Ilong = Fix(En_multi_4(K)*2^-30)
                                IE_array(3) = Ilong Mod 2^10
                                Ilong = Fix(En_multi_4(K)*2^-40)
                                IE_array(4) = Ilong Mod 2^10
                                Exit For
                              End If
                            Next J            
                          Case 5 
                            For J = J_multi_last(5) To 2 * Imulti
                              K = J Mod Ubound(En_multi_5) + 1
                              If En_multi_5(K) Mod 2^10 = I_E_Multi And _
                                PLoss(I_emit_5(K)) = I_Z_Multi Then 
                                J_multi_last(5) = K
                                C_test = Oct(I_emit_5(K))
                                Ilong = Fix(En_multi_5(K)*2^-10) 
                                IE_array(1) = Ilong Mod 2^10
                                Ilong = Fix(En_multi_5(K)*2^-20)
                                IE_array(2) = Ilong Mod 2^10
                                Ilong = Fix(En_multi_5(K)*2^-30)
                                IE_array(3) = Ilong Mod 2^10
                                Ilong = Fix(En_multi_5(K)*2^-40)
                                IE_array(4) = Ilong Mod 2^10
                                Ilong = Fix(En_multi_5(K)*2^-50)
                                IE_array(5) = Ilong Mod 2^10
                                Exit For
                              End If
                            Next J            
                          Case 6  
                            For J = J_multi_last(6) To 2 * Imulti
                              K = J Mod Ubound(En_multi_6) + 1
                              If En_multi_6(K) Mod 2^10 = I_E_Multi And _
                                    PLoss(I_emit_6(K)) = I_Z_Multi Then 
                                J_multi_last(6) = K
                                C_test = Oct(I_emit_6(K))
                                Ilong = Fix(En_multi_6(K)*2^-10)
                                IE_array(1) = Ilong Mod 2^10
                                Ilong = Fix(En_multi_6(K)*2^-20)
                                IE_array(2) = Ilong Mod 2^10
                                Ilong = Fix(En_multi_6(K)*2^-30)
                                IE_array(3) = Ilong Mod 2^10
                                Ilong = Fix(En_multi_6(K)*2^-40)
                                IE_array(4) = Ilong Mod 2^10
                                Ilong = Fix(En_multi_6(K)*2^-50)
                                IE_array(5) = Ilong Mod 2^8
                                Ilong = Fix(En_multi_6(K)*2^-58)
                                IE_array(6) = Ilong Mod 2^8
                                Exit For
                              End If
                            Next  
                          Case Else
                        End Select    
    
       /'               For J = 1 To I_A_Multi
                          If Mid(C_Test,J,1) = "1" or Mid(C_Test,J,1) = "3" Then
          '                  ENCNtest(IE_array(J)) = ENCNtest(IE_array(J)) + 1
          '                  EN(IE_array(J)) = EN(IE_array(J)) + 1
                          End If
                          If Mid(C_Test,J,1) = "2" or Mid(C_test,J,1) = "4" Then
          '                 EP(IE_array(J)) = EP(IE_array(J)) + 1
                          End If
                        Next  '/     
    
    
        /'              List-mode output '/
                        Dim As Single J_frag_light_q, J_frag_heavy_q
                        Dim As Integer J_max
                        Dim As Single phi_frag1,phi_frag2,Elabpre1,Elabpre2
                        Dim As Single EAfrag1,EAfrag2
                        Dim As Single costheta_f1_CN, costheta_f1_lab, costheta_f2_CN, costheta_f2_lab
                        Dim As Single Vfrag1long,Vfrag2long
                        Dim As Single Vfrag1perp,Vfrag2perp
          
                        If CFileoutlmd <> "" Then
                          If B_Error_Analysis  = 0 Or Brec = 1 Then
                            Print #foutlmd,Using "### ";I_Mode;
                            Print #foutlmd,Using "#### ";I_Z_light_sad + I_Z_heavy_sad;
                            Print #foutlmd,Using "#### ";I_A_light_sad + I_A_heavy_sad;
                            Print #foutlmd,Using "###.# ";Qvalue_sad;
                            If PZ1 = 1 Then Print #foutlmd,Using "### ";I_Z_Light_Post; 
    		                If PZ2 = 1 Then Print #foutlmd,Using "### ";I_Z_Heavy_Post;
                            If PA1pre = 1 Then Print #foutlmd,Using "#### ";I_A_light_sci;
                            If PA2pre = 1 Then Print #foutlmd,Using "#### ";I_A_heavy_sci;
                            If PA1post = 1 Then Print #foutlmd,Using "#### ";I_A_Light_Post;
                            If PA2post = 1 Then Print #foutlmd,Using "#### ";I_A_Heavy_Post;
                            If I_A_light_sci Mod 2 = 0 Then
                              J_frag_light_q = Int(J_frag_light + 0.5)
                            Else 
                              J_frag_light_q = Int(J_frag_light) + 0.5
                            End If  
                            IF PI1 = 1 Then Print #foutlmd,Using "###.# ";J_frag_light_q;
                            If I_A_heavy_sci Mod 2 = 0 Then
                              J_frag_heavy_q = Int(J_frag_heavy + 0.5)
                            Else
                              J_frag_heavy_q = Int(J_frag_heavy) + 0.5
                            End If   
                            If PI2 = 1 Then Print #foutlmd,Using "###.# ";J_frag_heavy_q;
                            If PI1 = 1 Then Print #foutlmd,Using "###.# ";Spin_gs_light;
                            If PI2 = 1 Then Print #foutlmd,Using "###.# ";Spin_gs_heavy;
                            If Pdir = 1 Then
                              costheta_f1_CN = (1.0 - 2.0 * rnd)  ' theta_f1 relative to incident particle direction
                                 ' approximation: isotropic fragment emission assumed
                              costheta_f2_CN = - costheta_f1_CN
                              If Emode = 2 Or Emode = 12 Then   ' incident neutron or proton
                         '      Vfrag1long = Array_v_f1_CN(I) * costheta_f1_CN  ' isotropic in CN frame
                         '      Vfrag2long = Array_v_f2_CN(I) * costheta_f2_CN  
                                Vfrag1long = v_f1_CN * costheta_f1_CN  ' isotropic in CN frame
                                Vfrag2long = v_f2_CN * costheta_f2_CN  
                                Vfrag1perp = sqr(v_f1_CN^2 - Vfrag1long^2)  
                                Vfrag2Perp = sqr(v_f2_CN^2 - Vfrag2long^2)  
                                Vfrag1long = Vfrag1long + sqr(P_E_exc)/ I_A_CN ' + momentum of incident particle
                                Vfrag2long = Vfrag2long + sqr(P_E_exc)/ I_A_CN ' "
                                costheta_f1_lab = Vfrag1long / sqr(Vfrag1long^2 + Vfrag1perp^2)
                                costheta_f2_lab = VFrag2long / sqr(Vfrag2long^2 + Vfrag2perp^2)
    '                           Print 7930,v_f1_CN,v_f2_CN,Vfrag1perp,Vfrag2Perp,Vfrag1long,Vfrag2long,P_E_exc
                                Elabpre1 = (Vfrag1long^2 + Vfrag1perp^2) * I_A_light_sci
                                Elabpre2 = (Vfrag2long^2 + Vfrag2perp^2) * I_A_heavy_sci 
                              ElseIf Emode = 22 Then   ' incident alpha
            '                   Vfrag1long = Array_v_f1_CN(I) * costheta_f1_CN  ' isotropic in CN frame
            '                   Vfrag2long = Array_v_f2_CN(I) * costheta_f2_CN  
                                Vfrag1long = v_f1_CN * costheta_f1_CN  ' isotropic in CN frame
                                Vfrag2long = v_f2_CN * costheta_f2_CN  
                                Vfrag1perp = sqr(v_f1_CN^2 - Vfrag1long^2)  
                                Vfrag2Perp = sqr(v_f2_CN^2 - Vfrag2long^2)  
                                Vfrag1long = Vfrag1long + 4 * sqr(P_E_exc/4)/ I_A_CN ' + momentum of incident particle
                                Vfrag2long = Vfrag2long + 4 * sqr(P_E_exc/4)/ I_A_CN ' "
                                costheta_f1_lab = Vfrag1long / sqr(Vfrag1long^2 + Vfrag1perp^2)
                                costheta_f2_lab = VFrag2long / sqr(Vfrag2long^2 + Vfrag2perp^2)
    '                           Print 7930,v_f1_CN,v_f2_CN,Vfrag1perp,Vfrag2Perp,Vfrag1long,Vfrag2long,P_E_exc
                                Elabpre1 = (Vfrag1long^2 + Vfrag1perp^2) * I_A_light_sci
                                Elabpre2 = (Vfrag2long^2 + Vfrag2perp^2) * I_A_heavy_sci 
                              Else
                                costheta_f1_lab = costheta_f1_CN
                                costheta_f2_lab = costheta_f2_CN
                                EAfrag1 = v_f1_CN^2 * I_A_light_sci
                                EAfrag2 = v_f2_CN^2 * I_A_heavy_sci
                                Elabpre1 = EAfrag1
                                Elabpre2 = EAfrag2
                              End If
                              phi_frag1 = rnd * 360
                              phi_frag2 = phi_frag1 + 180
                              If phi_frag2 > 360 Then phi_frag2 = phi_frag2 - 360
                              Print #foutlmd,Using "####.## ";Elabpre1;
                              Print #foutlmd,Using "###.#### ";costheta_f1_lab;
                              Print #foutlmd,Using "#####.## ";phi_frag1;  
                              Print #foutlmd,Using "####.## ";Elabpre2; 
                              Print #foutlmd,Using "###.#### ";costheta_f2_lab;
                              Print #foutlmd,Using "#####.## ";phi_frag2;
                            End If
                            If PXE = 1 And PXEdetails = 0 Then 
                              Print #foutlmd,Using "####.## ";TXElight;
                              Print #foutlmd,Using "####.## ";TXEheavy;
                            End If
                            If PXE = 1 And PXEdetails = 1 Then
                              Print #foutlmd,Using "####.## ";TXElight;
                              Print #foutlmd,Using "####.## ";Erot1;
                              Print #foutlmd,Using "####.## ";Eintr1;
                              Print #foutlmd,Using "####.## ";Edef1;
                              Print #foutlmd,Using "####.## ";TXEheavy;
                              Print #foutlmd,Using "####.## ";Erot2;
                              Print #foutlmd,Using "####.## ";Eintr2;
                              Print #foutlmd,Using "####.## ";Edef2;
                            End If
                            If PXE = 0 And PXEdetails = 1 Then
                              Print #foutlmd,Using "####.## ";Erot1;
                              Print #foutlmd,Using "####.## ";Eintr1;
                              Print #foutlmd,Using "####.## ";Edef1;
                              Print #foutlmd,Using "####.## ";Erot2;
                              Print #foutlmd,Using "####.## ";Eintr2;
                              Print #foutlmd,Using "####.## ";Edef2;
                            End If
                            If Pn1 = 1 Then Print #foutlmd,Using "### ";I_nu_light;
                            If Pn2 = 1 Then Print #foutlmd,Using "### ";I_nu_heavy;
                            If PTKEpre = 1 Then Print #foutlmd,Using "####.## ";TKE;
                            If PTKEpost = 1 Then Print #foutlmd,Using "####.## ";TKE_post;
                            If PnCN = 1 /' And Inofirst > 0 '/ Then
                          ' E* at fission:
                              If Inofirst > 0 Then 
                                Print #foutlmd,Using "###.#";R_E_exc_GS;
                              Else
                                Print #foutlmd,Using "###.###";R_E_exc_GS;              
                              End If
                              If I_A_multi <= 6 Then   ' Restriction to 6 first energies!
                                Scope
                                  Dim As Single En0,En,vn0,vn,cosn0,cosn,vn0long,vnlong,vnperp,phin
                          '       Print list of particle keys:
                                  Print #foutlmd," ";C_test;" ";
                                  For J = 1 To I_A_multi
                                    If Emode = 2 Or Emode = 12 Then
                                      En0 = 0.1 * (IE_array(J) + rnd) ' energy of emitted neutron in CN system [100 keV]
                                '     rnd produces a continous En distribution, filling the 100-kev gaps.
                                '     This causes a systematic shift by 50 keV, which is not fully consistent.
                                '     It is smaller than the rounding by the 100-keV bins of E* of the nucleus.
                                '     Thus, it may be tolerable.
                                      vn0 = sqr(En0)
                                      cosn0 = (2.0*rnd - 1.0)   ' isotropic in CN system
                                      vn0long = cosn0 * vn0
                                      vnperp = sqr(vn0^2 - vn0long^2)
                                      vnlong = vn0long + sqr(P_E_exc)/I_A_CN  ' + momentum of incident particle
                                      vn = sqr(vnlong^2 + vnperp^2)
                                      cosn = vnlong / vn  ' angle with respect to incident particle
                                      En = vn^2           ' energy of emitted neutron in lab system
                                    ElseIf Emode = 22 Then
                                      En0 = 0.1 * (IE_array(J) + rnd) ' energy of emitted neutron in CN system [100 keV]
                                '     rnd produces a continous En distribution, filling the 100-kev gaps.
                                '     This causes a systematic shift by 50 keV, which is not fully consistent.
                                '     It is smaller than the rounding by the 100-keV bins of E* of the nucleus.
                                '     Thus, it may be tolerable.
                                      vn0 = sqr(En0)
                                      cosn0 = (2.0*rnd - 1.0)   ' isotropic in CN system
                                      vn0long = cosn0 * vn0
                                      vnperp = sqr(vn0^2 - vn0long^2)
                                      vnlong = vn0long + 4 * sqr(P_E_exc/4)/I_A_CN  ' + momentum of incident particle
                                      vn = sqr(vnlong^2 + vnperp^2)
                                      cosn = vnlong / vn  ' angle with respect to incident particle
                                      En = vn^2           ' energy of emitted neutron in lab system
                                    Else   
                                      En = 0.1 * (IE_array(J) + rnd)  ' ' energy of emitted neutron in CN system [100 keV]
                                    ' See above comment about rnd!
                                      cosn = (2.0*rnd - 1.0)   ' isotropic in CN system
                                    End If  
                                    phin = rnd * 360
                                    Print #foutlmd,Using "####.### ";En;
                                    Print #foutlmd,Using "###.#### ";cosn; 
                                    Print #foutlmd,Using "#####.## ";phin;
                                  Next
                                End Scope  
                              End If  
                              If I_A_multi > 6 Then
                                Print #foutlmd," Multiplicity of pre-scission particles > 6!";     
                              End If
                            End If
                            If PnCN = 1 Then  
                              If I_nu_ss > 0 Then  ' Emission btw. saddle and scission (included in PnCN option) 
                                Scope
                                  Dim As Single En0,En,vn0,vn,cosn0,cosn,vn0long,vnlong,vnperp,phin
                                  Print #foutlmd," ";C_pattern_sci;" ";
                                  For I = 1 To I_nu_ss
                                    If Emode = 2 Or Emode = 12 Then
                                      vn0 = sqr(Array_En_sci(I))
                                      cosn0 = (2.0*rnd - 1.0)   ' isotropic
                                      vn0long = cosn0 * vn0
                                      vnperp = sqr(vn0^2 - vn0long^2)
                                      vnlong = vn0long + sqr(P_E_exc)/I_A_CN  ' + momentum of incident particle
                                      vn = sqr(vnlong^2 + vnperp^2)
                                      cosn = vnlong / vn
                                      En = vn^2 
                                    ElseIf Emode = 22 Then
                                      vn0 = sqr(Array_En_sci(I))
                                      cosn0 = (2.0*rnd - 1.0)   ' isotropic
                                      vn0long = cosn0 * vn0
                                      vnperp = sqr(vn0^2 - vn0long^2)
                                      vnlong = vn0long + 4 * sqr(P_E_exc/4)/I_A_CN  ' + momentum of incident particle
                                      vn = sqr(vnlong^2 + vnperp^2)
                                      cosn = vnlong / vn
                                      En = vn^2 
                                    Else
                                      En = Array_En_sci(I)
                                    End If
                                    phin = rnd * 360
                                    Print #foutlmd,Using "####.### ";En;
                                    Print #foutlmd,Using "###.#### ";cosn;
                                    Print #foutlmd,Using "#####.## ";phin;
                                  Next I
                                End Scope  
                              End If
                            End If
                            If PEnpost = 1 Then
                              Print #foutlmd," "
                              Print #foutlmd,"  0";
                              For J = 1 To In_post
                                Print #foutlmd,Using "####.### "; Array_E_nall_CN(J);  ' n-energy in CN frame
                                Print #foutlmd,Using "####.### "; Array_cosalpha_nall_frag1(J); 
                              ' cos of angle between emitted neutron and light fragment in CN frame
                                Print #foutlmd,Using "#####.## "; Array_phi_nall_frag1(J);
                              ' angle phi of emitted neutron around v-vector of light fragment in CN frame
                              Next J
                              Print #foutlmd," "
                              Print #foutlmd,"  1";
                              Dim As Single vn_long_CN, vn_long_lab, vn_perp_CN, vn_perp_lab, En_lab
                              For J = 1 To UBound(Array_E_n1_frag1)
                                If Array_E_n1_frag1(J) = 0 Then Exit For
                                Print #foutlmd,Using "####.### "; Array_E_n1_frag1(J);  ' n-energy in fragment frame
                                Print #foutlmd,Using "####.### "; Array_E_n1_CN(J); ' n-energy in CN frame
                                If Emode = 2 Or Emode = 12 Then   ' incident neutron or proton
                                  vn_long_CN = (Array_v_f1_CN(J) + Array_vlong_n1_frag1(J)) * costheta_f1_CN _  
                                  -  Array_vperp_n1_frag1(J) * cos(pi/180.0 * Array_phi_n1_frag1(J)) _
                                  * sin(acos(costheta_f1_CN))
                                  If Array_E_n1_CN(J) > vn_long_CN^2 Then
                                    vn_perp_CN = sqr(Array_E_n1_CN(J) - vn_long_CN^2)  
                                  Else
                                    vn_perp_CN = 0
                                  End If
                                  vn_long_lab = vn_long_CN + sqr(P_E_exc)/I_A_CN
                                  vn_perp_lab = vn_perp_CN
                                  En_lab = vn_long_lab^2 + vn_perp_lab^2   
                                  Print #foutlmd,Using "####.### "; En_lab;   
                                  Print #foutlmd,Using "####.### "; vn_long_lab/sqr(En_lab);      
                                End If
                                If Emode = 22 Then   ' incident alpha
                                  vn_long_CN = (Array_v_f1_CN(J) + Array_vlong_n1_frag1(J)) * costheta_f1_CN _  
                                  -  Array_vperp_n1_frag1(J) * cos(pi/180.0 * Array_phi_n1_frag1(J)) _
                                  * sin(acos(costheta_f1_CN))
                                  If Array_E_n1_CN(J) > vn_long_CN^2 Then
                                    vn_perp_CN = sqr(Array_E_n1_CN(J) - vn_long_CN^2)  
                                  Else
                                    vn_perp_CN = 0
                                  End If
                                  vn_long_lab = vn_long_CN + 4 * sqr(P_E_exc/4)/I_A_CN
                                  vn_perp_lab = vn_perp_CN
                                  En_lab = vn_long_lab^2 + vn_perp_lab^2   
                                  Print #foutlmd,Using "####.### "; En_lab;   
                                  Print #foutlmd,Using "####.### "; vn_long_lab/sqr(En_lab);      
                                End If
                              Next J
                              Print #foutlmd," "
                              Print #foutlmd,"  2";
                              For J = 1 To UBound(Array_E_n2_frag2)
                                If Array_E_n2_frag2(J) = 0 Then Exit For
                                Print #foutlmd,Using "####.### "; Array_E_n2_frag2(J);  ' n-energy in fragment frame
                                Print #foutlmd,Using "####.### "; Array_E_n2_CN(J); ' n-energy in CN frame
                                If Emode = 2 Or Emode = 12 Then   ' incident neutron or proton
                                  vn_long_CN = (Array_v_f1_CN(J) + Array_vlong_n2_frag2(J)) * costheta_f2_CN _  
                                  - Array_vperp_n2_frag2(J) * cos(pi/180.0 * Array_phi_n2_frag2(J)) _
                                  * sin(acos(costheta_f2_CN))
                                  If Array_E_n2_CN(J) > vn_long_CN^2 Then
                                    vn_perp_CN = sqr(Array_E_n2_CN(J) - vn_long_CN^2) 
                                  Else 
                                    vn_perp_CN = 0   
                                  End If 
                                  vn_long_lab = vn_long_CN + sqr(P_E_exc)/I_A_CN
                                  vn_perp_lab = vn_perp_CN
                                  En_lab = vn_long_lab^2 + vn_perp_lab^2   
                                  Print #foutlmd,Using "####.### "; En_lab;   
                                  Print #foutlmd,Using "####.### "; vn_long_lab/sqr(En_lab);      
                                End If
                                If Emode = 22 Then   ' incident alpha
                                  vn_long_CN = (Array_v_f1_CN(J) + Array_vlong_n2_frag2(J)) * costheta_f2_CN _  
                                  - Array_vperp_n2_frag2(J) * cos(pi/180.0 * Array_phi_n2_frag2(J)) _
                                  * sin(acos(costheta_f2_CN))
                                  If Array_E_n2_CN(J) > vn_long_CN^2 Then
                                    vn_perp_CN = sqr(Array_E_n2_CN(J) - vn_long_CN^2) 
                                  Else 
                                    vn_perp_CN = 0   
                                  End If 
                                  vn_long_lab = vn_long_CN + 4 * sqr(P_E_exc/4)/I_A_CN
                                  vn_perp_lab = vn_perp_CN
                                  En_lab = vn_long_lab^2 + vn_perp_lab^2   
                                  Print #foutlmd,Using "####.### "; En_lab;   
                                  Print #foutlmd,Using "####.### "; vn_long_lab/sqr(En_lab);      
                                End If
                              Next J
                            End If
                            If PEgpost = 1 Then
           '                  If Array_Eg0_light(1) <> 0 Then
                                Print #foutlmd," "
                                Print #foutlmd,"  3";
                                For J = 1 To UBound(Array_Eg0_light)
                                  If Array_Eg0_light(J) = 0 Then Exit For
                                  Print #foutlmd,Using "####.### "; Array_Eg0_light(J);
                                Next J 
           '                  End If             
                              Print #foutlmd," "
                              Print #foutlmd,"  4";
                              For J = 1 To Ig1_light
                                If Array_Eg1_light(J) = 0 Then Exit For
                                Print #foutlmd,Using "####.### "; Array_Eg1_light(J);
                              Next J            
                              Print #foutlmd," "
                              Print #foutlmd,"  5";
                              For J = 1 To Ig2_light
                                If Array_Eg2_light(J) = 0 Then Exit For
                                Print #foutlmd,Using "####.### "; Array_Eg2_light(J);
                              Next J  
                              Print #foutlmd,"  ";C_iso_lmd_light;
           '                  If Array_Eg0_heavy(1) <> 0 Then          
                                Print #foutlmd," "
                                Print #foutlmd,"  6";
                                For J = 1 To UBound(Array_Eg0_heavy)
                                  If Array_Eg0_heavy(J) = 0 Then Exit For
                                  Print #foutlmd,Using "####.### "; Array_Eg0_heavy(J);
                                Next J            
           '                  End If
                              Print #foutlmd," "
                              Print #foutlmd,"  7"; 
                              For J = 1 To Ig1_heavy
                                If Array_Eg1_heavy(J) = 0 Then Exit For
                                Print #foutlmd,Using "####.### "; Array_Eg1_heavy(J);
                              Next J            
                              Print #foutlmd," "
                              Print #foutlmd,"  8";
                              For J = 1 To Ig2_heavy
                                If Array_Eg2_heavy(J) = 0 Then Exit For
                                Print #foutlmd,Using "####.### "; Array_Eg2_heavy(J);
                              Next J           
                              Print #foutlmd,"  ";C_iso_lmd_heavy;
                            End If
                            Print #foutlmd," "
                          End If  
                        End If
                      End Scope
          
    SkipEvent:
                      IEVTtot = IEVTtot + 1
    
                      Scope  
                        If (NEVTtot >= 1.E6 And (IEVTtot * 100) = NEVTtot)  Or _
                          (NEVTtot >= 1.E5 And (IEVTtot * 10) Mod NEVTtot = 0) Or _
                          (NEVTtot >= 1.E4 And (IEVTtot * 2) Mod NEVTtot = 0) Then  
                          Dim As Double Rdatetime
                          Rdatetime = Now
                          Print IEVTtot;" Events (";Cint(100*IEVTtot/NEVTtot);"% ) of "; _
                            NEVTtot;" events processed at ";
                          Print Format( Rdatetime, "dd.mm.yyyy, hh:mm:ss")
                        End If
                      End Scope 
        
                    Next ILoop  ' For ILoop = 1 To NEVTused
    
                  End If  ' If NEVTused  (from W_spectrum(I_E_distr)) > 0     
      '           End of loop over energy spectrum from file   
                Next I_E_multi  ' For I_E_multi
              Next I_Z_multi  ' For I_Z_multi
            Next I_N_multi  ' For I_N_multi 
          Next I_E_distr  ' For I_E_distr   
    
          If CFileoutlmd <> "" Then Close #foutlmd
       
     /'   Output  '/ 
       
          Print " "
       '  Print "Calculation finished at ";time;"."
       
          IF B_Error_Analysis = 0 Then  
            Print "Output is written to file ";
            Print CFileout_full;"."
            Print " "
          End If  
          If CFileoutlmd <> "" Then
            If B_Error_Analysis = 0 Or Brec Then   
              Print "List-mode data are written to file ";
              Print CFileoutlmd_full;"."  
              Print
    '         Close #foutlmd
            End If
          End If
       
    
    '     If Bfilein = 0 And BGUI = 0 And B_Error_Analysis = 0 Then
    '       Print "Press 'ENTER' to start the code again or 'Q' to quit!" 
    '       Print "(Focus must be on graphic window.)"
    '     End If
       
        ' Synchronize output (allow only one process to print on file at a time)
          If Bfilein Then 
            Do
              await(I_thread,I_thread_max)    ' avoid collisions in reading and writing from/to sync.ctl  
              Sleep 10
              fsync = freefile
              CHDIR("ctl")
              If Fileexists("sync.ctl") = 0 Then  ' fsync must be created 
                Open "sync.ctl" For Output As #fsync
                  Print #fsync,0 
                Close fsync
              End If
              CHDIR("..")
              Open "ctl\sync.ctl"  For Input As #fsync
                Input #fsync, Isync
              Close #fsync  
            Loop Until Isync = 0                   ' no current output from other GEF calculation 
            Open "ctl\sync.ctl" For Output As #fsync
              Print #fsync,1     ' block output of other GEF calculations
            Close #fsync
          End If 
       
       
    
          f = freefile
          If B_Error_Analysis = 1 Then
            If Brec = 1 Then 
     '        Open "out\"+Cfileout+".ptb" For Append As #f   ' for results with perturbed parameters
              Open "out\"+Csystem+".ptb" For Append As #f   ' for results with perturbed parameters
            Else 
     '        Open "tmp\"+Cfileout+".ptb" For Output As #f               ' overwrite previous content
              Open "tmp\"+Csystem+".ptb" For Output As #f               ' overwrite previous content
              Print #f," Note: This file only keeps the last calculation."
              Print #f," Choose the appropriate output option:" 
              Print #f," 'extended output of perturbed calculations'" 
              Print #f," to provide full information!"
            End If 
            Print #f," "
            Print #f,"*******************************************"
            Print #f,"***  Results of perturbed calculations  ***"
            Print #f,"          Parameter set #"+Str(I_Error+1)
            Print #f,"*******************************************"
            Print #f," "
          Else
            Open Cfileout_full For Append As #f   ' for final result, with error bars if available 
          End If  
    
       /' Calculation of mean neutron yield per mass '/
          Scope
            Dim As Integer I,J
            Dim As Double Zaehler, Nenner
         
        '   Emission from CN prior to fission:
            For I = Lbound(Nmulti2dpre,1) To Ubound(Nmulti2dpre,1) 
              Zaehler = 0
              Nenner = 0
              For J = Lbound(Nmulti2dpre,2) To Ubound(Nmulti2dpre,2)
                Zaehler = Zaehler + J * Nmulti2dpre(I,J)
                Nenner = Nenner + Nmulti2dpre(I,J)
              Next J 
              If Nenner > 0 Then
                NmultiApre(I) = Zaehler / Nenner
              Else
                NmultiApre(I) = 0
              End If
            Next I       
            For I = Lbound(Nmulti2dpost,1) To Ubound(Nmulti2dpost,1)
              Zaehler = 0
              Nenner = 0
              For J = Lbound(Nmulti2dpost,2) To Ubound(Nmulti2dpost,2)
                Zaehler = Zaehler + J * Nmulti2dpost(I,J)
                Nenner = Nenner + Nmulti2dpost(I,J)
              Next J 
              If Nenner > 0 Then
                NmultiApost(I) = Zaehler / Nenner
              Else
                NmultiApost(I) = 0
              End If
            Next I       
         
        '   Emission from fragments:
            For I = Lbound(NApre,1) To Ubound(NApre,1)
              NApre(I) = 0
            Next I  
            For I = Lbound(N2dpre,1) To Ubound(N2dpre,1)
              Zaehler = 0
              Nenner = 0
              For J = Lbound(N2dpre,2) To Ubound(N2dpre,2)
                Zaehler = Zaehler + J * N2Dpre(I,J)
                Nenner = Nenner + N2Dpre(I,J)
              Next J
              If Nenner > 0 Then
                NApre(I) = Zaehler / Nenner
              Else
                NApre(I) = 0
              End If    
            Next I
         
            For I = Lbound(NApost,1) To UBound(NApost,1)
              NApost(I) = 0
            Next I  
            For I = Lbound(N2Dpost,1) To Ubound(N2Dpost,1)
              Zaehler = 0
              Nenner = 0
              For J = Lbound(N2dpost,2) To Ubound(N2dpost,2)
                Zaehler = Zaehler + J * N2Dpost(I,J)
                Nenner = Nenner + N2Dpost(I,J)
              Next
              If Nenner > 0 Then
                NApost(I) = Zaehler / Nenner
              Else
                NApost(I) = 0
              End If    
            Next I
          End Scope
    
     /'   Calculation of mean neutron energy per mass '/
          Scope
            Dim As Integer I,J
            Dim As Double Zaehler, Nenner
            For I = LBound(ENApre,1) To Ubound(ENApre,1)
              ENApre(I) = 0
            Next I
            For I = 0 To 350
              Zaehler = 0
              Nenner = 0
              For J = 0 To 1000
                Zaehler = Zaehler + 0.1 * J * ENApre2d(I,J)
                Nenner = Nenner + ENApre2d(I,J)
              Next
              If I >= Lbound(ENApre,1) And I <= Ubound(ENApre,1) Then
                If Nenner > 0 Then
                  ENApre(I) = Zaehler / Nenner
                Else
                  ENApre(I) = 0
                End If    
              End If 
            Next I
         
            For I = Lbound(ENApost,1) To Ubound(ENApost,1)
              ENApost(I) = 0
            Next I
            For I = 0 To 350
              Zaehler = 0
              Nenner = 0
              For J = 0 To 1000
                Zaehler = Zaehler + 0.1 * J * ENApost2d(I,J)
                Nenner = Nenner + ENApost2d(I,J)
              Next J
              If I >= LBound(ENApost,1) And I <= UBound(ENApost,1) Then
                If Nenner > 0 Then
                  ENApost(I) = Zaehler / Nenner
                Else
                  ENApost(I) = 0
                End If  
              End If    
            Next I   
         
            For I = LBound(ENAprefs,1) To Ubound(ENAprefs,1)
              ENAprefs(I) = 0
            Next I
            For I = 0 To 350    ' fs = fragment system
              Zaehler = 0
              Nenner = 0
              For J = 0 To 1000
                Zaehler = Zaehler + 0.1 * J * ENApre2dfs(I,J)
                Nenner = Nenner + ENApre2dfs(I,J)
              Next J
              If I >= LBound(ENAprefs,1) And I <= Ubound(ENAprefs,1) Then
                If Nenner > 0 Then
                  ENAprefs(I) = Zaehler / Nenner
                Else
                  ENAprefs(I) = 0
                End If    
              End If
            Next I
         
            For I = Lbound(ENApostfs,1) to Ubound(ENApostfs,1)
              ENApostfs(I) = 0
            Next I
            For I = 0 To 350
              Zaehler = 0
              Nenner = 0
              For J = 0 To 1000
                Zaehler = Zaehler + 0.1 * J * ENApost2dfs(I,J)
                Nenner = Nenner + ENApost2dfs(I,J)
              Next J
              If I >= LBound(ENApostfs,1) And I <= Ubound(ENApostfs,1) Then
                If Nenner > 0 Then
                  ENApostfs(I) = Zaehler / Nenner
                Else
                  ENApostfs(I) = 0
                End If
              End If      
            Next I  
          End Scope 
       
       
           ' Projections of 2-dimensional arrays
         Scope
          ' EdefoA
            Dim As Double Zaehler, Nenner
            For I = Lbound(EdefoA,1) To Ubound(EdefoA,1)
              EdefoA(I) = 0
            Next I 
            For I = 0 To 350
              Zaehler = 0
              Nenner = 0
              For J = 0 To 800  ' 100 kev bin
                Zaehler = Zaehler + (0.1*J+0.5) * Edefo2d(I,J)
                Nenner = Nenner + Edefo2d(I,J)
              Next J 
              If I >= LBound(EdefoA,1) And I <= UBound(EdefoA,1) Then
                If Nenner > 0 Then
                  EdefoA(I) = Zaehler / Nenner
                Else
                  EdefoA(I) = 0  
                End If
              End If   
            Next I
        
          ' EintrA
            For I = Lbound(EintrA,1) To Ubound(EintrA,1)
              EintrA(I) = 0
            Next I
            For I = 0 To 350
              Zaehler = 0
              Nenner = 0
              For J = 0 To 1000  ' 100 kev bin
                Zaehler = Zaehler + (0.1*J+0.5) * Eintr2d(I,J)
                Nenner = Nenner + Eintr2d(I,J)
              Next J 
              If I >= Lbound(EintrA,1) And I <= UBound(EintrA,1) Then 
                If Nenner > 0 Then
                  EintrA(I) = Zaehler / Nenner
                Else
                  EintrA(I) = 0  
                End If
              End If   
            Next I
        
          ' EcollA
            For I = Lbound(EcollA,1) To Ubound(EcollA,1)
              EcollA(I) = 0
            Next I
            For I = 0 To 350
              Zaehler = 0
              Nenner = 0
              For J = 0 To 500  ' 100 keV bin
                Zaehler = Zaehler + (J*0.1+0.5) * Ecoll2d(I,J)
                Nenner = Nenner + Ecoll2d(I,J)
              Next J 
              If I >= Lbound(EcollA,1) And I <= Ubound(EcollA,1) Then
                If Nenner > 0 Then
                  EcollA(I) = Zaehler / Nenner
                End If
              End If   
            Next I
        
          ' EkinApre
            For I = Lbound(EkinApre,1) To Ubound(EkinApre,1)
              EkinApre(I) = 0
            Next I
            For I = 0 To 350
              Zaehler = 0
              Nenner = 0
              For J = 0 To 300
                Zaehler = Zaehler + (J+0.5) * AEkinpre(I,J)
                Nenner = Nenner + AEkinpre(I,J)
              Next J
              If I >= Lbound(EkinApre,1) And I<= Ubound(EkinApre,1) Then
                If Nenner > 0 Then
                  EkinApre(I) = Zaehler / Nenner
                End If
              End If
            Next I 
          
          ' EkinApost
            For I = Lbound(EkinApost,1) To Ubound(EkinApost,1) 
              EkinApost(I) = 0
            Next
            For I = 0 To 350
              Zaehler = 0
              Nenner = 0
              For J = 0 To 300
                Zaehler = Zaehler + (J+0.5) * AEkinpost(I,J)
                Nenner = Nenner + AEkinpost(I,J)
              Next J
              If I >= Lbound(EkinApost,1) And I <= UBound(EkinApost,1) Then
                If Nenner > 0 Then
                  EkinApost(I) = Zaehler / Nenner
                End If
              End If
            Next I 
        
          ' TKEApre
            For I = Lbound(TKEApre,1) To Ubound(TKEApre,1)
              TKEApre(I) = 0
            Next I
            For I = 0 To 350
              Zaehler = 0
              Nenner = 0
              For J = 0 To 300
                Zaehler = Zaehler + (J+0.5) * ATKEpre(I,J)
                Nenner = Nenner + ATKEpre(I,J)
              Next J
              If I >= Lbound(TKEApre,1) And I <= UBound(TKEApre,1) Then
                If Nenner > 0 Then
                  TKEApre(I) = Zaehler / Nenner
                End If
              End If
            Next I 
          
          ' TKEApost
            For I = Lbound(TKEApost,1) To Ubound(TKEApost,1)
              TKEApost(I) = 0
            Next I
            For I = 0 To 350
              Zaehler = 0
              Nenner = 0
              For J = 0 To 300
                Zaehler = Zaehler + (J+0.5) * ATKEpost(I,J)
                Nenner = Nenner + ATKEpost(I,J)
              Next J
              If I >= Lbound(TKEApost,1) And I <= UBound(TKEApost,1) Then
                If Nenner > 0 Then
                  TKEApost(I) = Zaehler / Nenner
                End If
              End If  
            Next I 
        
          ' QA
            For I = Lbound(QA,1) To Ubound(QA,1)
              QA(I) = 0 
            Next I
            For I = 0 To 350
              Zaehler = 0
              Nenner = 0
              For J = 0 To 300
                Zaehler = Zaehler + (J+0.5) * AQpre(I,J)
                Nenner = Nenner + AQpre(I,J)
              Next J
              If I >= Lbound(QA,1) And I <= UBound(QA,1) Then
                If Nenner > 0 Then
                  QA(I) = Zaehler / Nenner
                End If
              End If
            Next I 
        
          ' Filling spectrum EN (Sum of EnCN and Enfr) -> # of events in EnCN and ENfr may be different!
      /'    If NEVTtot = Imulti Then 
              For I = 1 To Ubound(En)
                En(I) = EnCN(I) + Enfr(I)
              Next I
            End If'/  
        
          End Scope
    
    
       /' Analysis of uncertainties and covariances '/
          Static As Integer fmvd_single, fmvd  'files
          Dim As Integer NAptb,NZptb,NZAptb
          
          Redim SZCovar(1,1) As OCovar
          Redim SZCorr(1,1) As OCorr
          Redim SApreCovar(1,1) As OCovar
          Redim SApreCorr(1,1) As OCorr
          Redim SApostCovar(1,1) As OCovar
          Redim SApostCorr(1,1) As OCorr
          Redim SZApreCovar(1,1,1,1) As OCovar
          Redim SZApreCorr(1,1,1,1) As OCorr
          Redim SZApostCovar(1,1,1,1) As OCovar
          Redim SZApostCorr(1,1,1,1) As Ocorr
       
          Dim As Integer Zmin,Zmax
          Dim As Integer Apremin,Apremax
          Dim As Integer Apostmin,Apostmax
          Dim As Integer dApremax
          Dim As Integer dApostmax
          Redim VAprelim(1,2) As Integer   ' Amin, Amax
          Redim VApostlim(1,2) As Integer   ' Amin, Amax
          Dim As Integer L
    
          Redim SZ_Double_Covar(1,1) As OCovar
          Redim SZ_Double_Corr(1,1) As OCorr
          Redim SApre_Double_Covar(1,1) As OCovar
          Redim SApre_Double_Corr(1,1) As OCorr
          Redim SApost_Double_Covar(1,1) As OCovar
          Redim SApost_Double_Corr(1,1) As OCorr
          Redim SZApre_Double_Covar(1,1,1,1) As OCovar
          Redim SZApre_Double_Corr(1,1,1,1) As OCorr
          Redim SZApost_Double_Covar(1,1,1,1) As OCovar
          Redim SZApost_Double_Corr(1,1,1,1) As OCorr
          Dim As Integer Z_Double_min,Z_Double_max
          Dim As Integer Apre_Double_min,Apre_Double_max
          Dim As Integer Apost_Double_min,Apost_Double_max
          Dim As Integer dApre_Double_max
          Dim As Integer dApost_Double_max
          Redim VApre_Double_lim(1,2) As Integer   ' Amin, Amax
          Redim VApost_Double_lim(1,2) As Integer   ' Amin, Amax
          Redim rms_Double(1,2) As Double
          Redim rms_ZA_Double(1,1,2) As Double
    
    
          If B_Error_On = 1 Then
            If B_Error_Analysis = 1 Then
    
          ' Mass yields
              For I = 20 To P_A_CN - 20
                If APost(I) > 0 Then
                  d_APost(1,I) = d_APost(1,I) + APost(I)
                  d_APost(2,I) = d_APost(2,I) + (APost(I))^2
                End If
              Next I     
           
            ' Z yields
              For I = 10 To P_Z_CN - 10
                If ZPOST(I) > 0 Then 
                  d_ZPost(1,I) = d_ZPost(1,I) + ZPost(I)
                  d_ZPost(2,I) = d_ZPost(2,I) + (ZPost(I))^2
                End If  
              Next I       
         
            ' Nuclide yields
              For I = 20 To P_A_CN - 20
                For J = 10 To P_Z_CN - 10
                  If ZISOPOST(I,J) > 0 Then
                    Acc_d_ZISOPOST(1,I,J,ZISOPOST(I,J))
                    Acc_d_ZISOPOST(2,I,J,(ZISOPOST(I,J))^2)
                  End If
                Next J
              Next I
           
           
           '  Uncertainties of specific fission quantities
              Scope
           
            '   prompt-neutron multiplicities
                Dim As Double Zaehler,Nenner
                Dim As Double NCN_mean
                Zaehler = 0
                Nenner = 0  
                For I = 0 To Ubound(NNCN,1)
                  Zaehler = Zaehler + I * NNCN(I)
                  Nenner = Nenner + NNCN(I)
                Next I       
                NCN_mean = Zaehler / Nenner
                d_NCN(1) = d_NCN(1) + NCN_mean
                d_NCN(2) = d_NCN(2) + NCN_mean^2      
           
                Dim As Double Nsci_mean
                Zaehler = 0
                Nenner = 0  
                For I = 0 To Ubound(NNsci,1)
                  Zaehler = Zaehler + I * NNsci(I)
                  Nenner = Nenner + NNsci(I) 
                Next I
                Nsci_mean = Zaehler / Nenner
                d_Nsci(1) = d_Nsci(1) + Nsci_mean
                d_Nsci(2) = d_Nsci(2) + Nsci_mean^2
           
                Dim As Double Nfr_mean
                Zaehler = 0
                Nenner = 0
                For I = 0 To Ubound(NNfr,1)
                  Zaehler = Zaehler + I * NNfr(I)
                  Nenner = Nenner + NNfr(I)
                Next I
                Nfr_mean = Zaehler / Nenner
                d_Nfr(1) = d_Nfr(1) + Nfr_mean
                d_Nfr(2) = d_Nfr(2) + Nfr_mean^2
    
                Dim As Double Nlight_mean
                Zaehler = 0
                Nenner = 0
                For I = 0 To Ubound(NNlight,1)
                  Zaehler = Zaehler + I * NNlight(I)
                  Nenner = Nenner + NNlight(I)
                Next I
                Nlight_mean = Zaehler / Nenner
                d_Nlight(1) = d_Nlight(1) + Nlight_mean
                d_Nlight(2) = d_Nlight(2) + Nlight_mean^2
    
                Dim As Double Nheavy_mean 
                Zaehler = 0
                Nenner = 0
                For I = 0 To Ubound(NNheavy,1)
                  Zaehler = Zaehler + I * NNheavy(I)
                  Nenner = Nenner + NNheavy(I)
                Next I
                Nheavy_mean = Zaehler / Nenner
                d_Nheavy(1) = d_Nheavy(1) + Nheavy_mean
                d_Nheavy(2) = d_Nheavy(2) + Nheavy_mean^2
             
                Dim As Double Ntot_mean
                Ntot_mean = NCN_mean + Nsci_mean + Nfr_mean
                d_Ntot(1) = d_Ntot(1) + Ntot_mean
                d_Ntot(2) = d_Ntot(2) + Ntot_mean^2
    
              ' Mean neutron energy (from fragments)
                Dim As Double ENfr_mean
                Zaehler = 0
                Nenner = 0
                For I = Lbound(_ENfr) To Ubound(_ENfr)
                  Zaehler = Zaehler + Csng(I)/1000.0 * ENfr(I)   ' kev -> MeV
                  Nenner = Nenner + ENfr(I)
                Next I
                ENfr_mean = Zaehler/Nenner
                d_ENfr(1) = d_ENfr(1) + ENfr_mean
                d_ENFr(2) = d_ENfr(2) + ENfr_mean^2
             
              ' Gamma multiplitiy
                Dim As Double Ng_mean
                Zaehler = 0
                Nenner = 0
                For I = 0 To Ubound(Ngammatot)
                  Zaehler = Zaehler + I * Ngammatot(I)
                  Nenner = Nenner + Ngammatot(I)
                Next I
                Ng_mean = Zaehler/Nenner
                d_Ng(1) = d_Ng(1) + Ng_mean
                d_Ng(2) = d_NG(2) + Ng_mean^2
             
              ' Mean gamma energy
                Dim As Double Eg_mean
                Zaehler = 0
                Nenner = 0
                For I = 1 To Ubound(_Egamma)
                  Zaehler = Zaehler + Csng(I)/1000.0 * _Egamma(I)
                  Nenner = Nenner + _Egamma(I)
                Next I
                Eg_mean = Zaehler / Nenner
                d_Eg(1) = d_Eg(1) + Eg_mean
                d_Eg(2) = d_Eg(2) + Eg_mean^2
             
              ' Total gamma energy (sum of all gammas in one fission event)
                Dim As Double Egtot_mean
                Zaehler = 0
                Nenner = 0
                For I = 1 To Ubound(_Egammatot)
                  Zaehler = Zaehler + Csng(I)/1000.0 * _Egammatot(I)
                  Nenner = Nenner + _Egammatot(I)
                Next I
                Egtot_mean = Zaehler / Nenner
                d_Egtot(1) = d_Egtot(1) + Egtot_mean
                d_Egtot(2) = d_Egtot(2) + Egtot_mean^2
             
              ' Mean Q value
                Dim As Double Q_mean
                Zaehler = 0
                Nenner = 0
                For I = 1 To Ubound(Qvalues)
                  Zaehler = Zaehler + Csng(I) * Qvalues(I)
                  Nenner = Nenner + Qvalues(I)
                Next I  
                Q_mean = Zaehler / Nenner
                d_Q(1) = d_Q(1) + Q_mean
                d_Q(2) = d_Q(2) + Q_mean^2
             
              ' Mean total kinetic energy
                Dim As Double TKEpre_mean
                Zaehler = 0
                Nenner = 0
                For I = 1 To Ubound(TKEpre)
                  Zaehler = Zaehler + Csng(I) * TKEpre(I)
                  Nenner = Nenner + TKEpre(I)
                Next I
                TKEpre_mean = Zaehler / Nenner
                d_TKEpre(1) = d_TKEpre(1) + TKEpre_mean
                d_TKEpre(2) = d_TKEpre(2) + TKEpre_mean^2
    
                Dim As Double TKEpost_mean 
                Zaehler = 0
                Nenner = 0
                For I = 1 To Ubound(TKEpost)
                  Zaehler = Zaehler + Csng(I) * TKEpost(I)
                  Nenner = Nenner + TKEpost(I)
                Next I
                TKEpost_mean = Zaehler / Nenner
                d_TKEpost(1) = d_TKEpost(1) + TKEpost_mean
                d_TKEpost(2) = d_TKEpost(2) + TKEpost_mean^2
             
              ' Mean total excitation energy
                Dim As Double TotXE_mean
                Zaehler = 0
                Nenner = 0
                For I = 1 To Ubound(TotXE)
                  Zaehler = Zaehler + Csng(I) * TotXE(I)
                  Nenner = Nenner + TotXE(I)
                Next I
                TotXE_mean = Zaehler / Nenner
                d_TotXE(1) = d_TotXE(1) + TotXE_mean
                d_TotXE(2) = d_TotXE(2) + TotXE_mean^2
      
             
              End Scope
           
           
           
    '         Cfilemvd_single = "tmp\"+Cfileout_single+".mvd"
              Cfilemvd_single = "tmp\"+Csystem+"_Single.mvd"
              fmvd_single = freefile
              If I_Error = 0 Then
                Open Cfilemvd_Single For Output As #fmvd_single
                Print #fmvd_single,"* This file provides the multi-variate distributions of GEF" 
                Print #fmvd_single,"* yields, which form the raw data for determining covariance data"
                Print #fmvd_single,"* for fission yields by establishing correlations of the results" 
                Print #fmvd_single,"* of several perturbed calculations."
              Else 
                Open Cfilemvd_single For Append As #fmvd_single
              End If  
              Print #fmvd_single,"*"
              Dim As Double Rdatetime
              Rdatetime = Now
              Print #fmvd_single,"* Output written on ";
              Print #fmvd_single, Format( Rdatetime, "dd.mm.yyyy, hh:mm:ss")
              Print #fmvd_single,"* "
              Print #fmvd_single, Using "& ### & ###";"* Calculation for the nucleus Z = ";P_Z_CN;", A = ";P_A_CN
    
              Select Case Emode
                Case 0
                  Print #fmvd_single,"* at E* = ";P_E_exc;" MeV above the outer saddle"
                  Print #fmvd_single,"*   (E* = ";Eabsgs;" MeV above the ground state)."
                  Print #fmvd_single,"* Spin = ";Spin_CN
                Case 1
                  Print #fmvd_single,"* at E* = ";P_E_exc;" MeV above the ground state."
                  Print #fmvd_single,"* Spin = ";Spin_CN
                Case -1
                  Print #fmvd_single,"* at E* = ";P_E_exc;" MeV above the ground state."
                  Print #fmvd_single,"* Spin = ";Spin_CN
                  Print #fmvd_single,"* Only first-chance fission!"
                Case 2
                  Print #fmvd_single,"* formed by (n,f) with En = ";P_E_exc- E_EXC_ISO;" MeV."
                  Print #fmvd_single,"* Spin of target nucleus = ";Spin_target
                Case 12
                  Print #fmvd_single,"* formed by (p,f) with Ep = ";P_E_exc- E_EXC_ISO;" MeV."
                  Print #fmvd_single,"* Spin of target nucleus = ";Spin_target       
                Case 22
                  Print #fmvd_single,"* formed by (alpha,f) with Ealpha = ";P_E_exc- E_EXC_ISO;" MeV."
                  Print #fmvd_single,"* Spin of target nucleus = ";Spin_target       
                Case 3
                  Print #fmvd_single,"* with user-defined excitation-energy distribution"
                  Print #f," from the file ";C_Espectrum;"."
                  Print #fmvd_single,"* Only first-chance fission."
                  Print #fmvd_single,"*","  E* (MeV)      Spin        Weight"
                  For I = 1 To Ubound(E_spectrum)
                    Print #fmvd_single,"'", E_spectrum(I), L_spectrum(I), W_spectrum(I)
                  Next I
         '        Print #fmvd_single,"* Spin = ";Spin_CN
                Case 13
                  Print #fmvd_single,"* with user-defined excitation-energy distribution"
                  Print #f," from the file ";C_Espectrum;"."
                  Print #fmvd_single,"* Multi-chance fission supported."
                  Print #fmvd_single,"*","  E* (MeV)      Spin        Weight"
                  For I = 1 To Ubound(E_spectrum)
                    Print #fmvd_single,"'", E_spectrum(I), L_spectrum(I), W_spectrum(I)
                  Next I
         '        Print #fmvd_single,"* Spin = ";Spin_CN
              End Select
              If I_E_iso > 0 Then
                Print #fmvd_single, "* Isomer # ";I_E_iso;", at E* = ";E_EXC_ISO;" MeV" 
              End If     
              If EOscale <> 1 Then
                Print #fmvd_single, "* Even-odd effect at scission scaled with a factor ";Eoscale;"."
              End If
         
              Print #fmvd_single,"*"
              Print #fmvd_single,"* Perturbed parameter set #"+Str(I_Error+1)
              Print #fmvd_single,"*"
              Print #fmvd_single,"* Set     Z         Y(Z)"
              Print #fmvd_single,"*Z*"
              For I = 10 To P_Z_CN - 10
                If ZPost(I) > 0 Then
                  Print #fmvd_single,Using "####    ####    ###.#####";I_Error+1;I;ZPOST(I)
       	        End If
              Next I      
              Print #fmvd_single,"*" 
              Print #fmvd_single,"* Set","A"," Y(A) ","    Y(A) "
              Print #fmvd_single,"*"," "," pre-neutron","    post-neutron"
              Print #fmvd_single,"*A*"
              For I = 20 To P_A_CN - 20
                If APost(I) > 0 Or APre(I) > 0 Then 
                  Print #fmvd_single,Using "####        ####         ###.#####        ###.#####";_
       	                I_Error+1;I;APre(I);APost(I)
       	        End If         
       	      Next I 
       	      Print #fmvd_single,"*"
              Print #fmvd_single,"* Set          A             Z            Y(A,Z)pre        Y(A,Z)post"  
              Print #fmvd_single,"*AZ*"
              For I = 20 To P_A_CN - 20
                For J = 10 To P_Z_CN - 10
                  If ZISOPRE(I,J) > 0 Or ZISOPOST(I,J) > 0 Then
              	    Print #fmvd_single,I_Error+1,I,J,Csng(ZISOPRE(I,J));Tab(60);Csng(ZISOPOST(I,J))
                  End If   
                Next J
              Next I
              If I_Error + 1 = N_Error_Max Then
         '    Print #fmvd_single,"***********************END****************************"
              End If  
              Close #fmvd_single
           
              For I = Lbound(_NZpost,1) To Ubound(_NZPost,1)    ' I is N-Z, J is Z
                For J = Lbound(_NZpost,2) To Ubound(_NZPOst,2)
                  Acc_d_NZPost(1,I+J,J,NZPost(I+J,J))  ' simple sum
                  Acc_d_NZPost(2,I+J,J,(NZPost(I+J,J))^2)  ' quadratic sum
                Next J
              Next I
           
            Else  ' Last passage, calculate final uncertainties and covariances
         
           '  Open file for values needed for covariances between different fissioning systems     
              If B_Double_Covar = 1 Then
                Cfilemvd = "tmp\"+Cfileout+".mvd"
                fmvd = freefile
                If I_Double_Covar = 1 Then
     '            Cfilemvd = "tmp\"+Csystem+".mvd"
                  Open Cfilemvd For Output As #fmvd
                Else
                  Open Cfilemvd For Append As #fmvd
                End If
              End If
    
         
           ' --- Covariances and uncertainties for single systems ---
    
           '  Covariances
           
              Dim As String Coption
              Dim As String Cread
           
           /' First step: Read and count event data from file '/
              fmvd_single = freefile       
              Open Cfilemvd_single For Input As #fmvd_single
              Coption = "None"
              NZptb = 0
              NAptb = 0
              NZAptb = 0
           
              Do Until EOF(fmvd_single)
                Line Input #fmvd_single, Cread
                If Left(Cread,1) = "*" Then Coption = "None"
                If Cread = "*Z*" Then 
                  Coption = "Z"
                  Line Input #fmvd_single, Cread
                End If  
                If Cread = "*A*" Then 
                  Coption = "A"
                  Line Input #fmvd_single, Cread
                End If  
                If Cread = "*AZ*" Then 
                  Coption = "AZ"
                  Line Input #fmvd_single, Cread
                End If  
                Select Case Coption
                  Case "Z"
                    NZptb = NZptb + 1
                  Case "A"
                    NAptb = NAptb + 1
                  Case "AZ" 
                    NZAptb = NZAptb + 1
                  Case Else
                End Select
              Loop
              Close #fmvd_single    
           
    
              Redim VApreptb(NAptb) As OCovarEvt1d
              Redim VApostptb(NAptb) As OCovarEvt1d
              Redim VZptb(NZptb) As OCovarEvt1d
              Redim VZApreptb(NZAptb) As OCovarEvt2d
              Redim VZApostptb(NZAptb) As OCovarEvt2d
           
              Dim As Integer IcntA,IcntZ,IcntZA
              Dim CVsplit(5) As String
              Dim Nsplit As Integer
              IcntZ=0
              IcntA=0
              IcntZA=0
    
    
         /'   Calculation of covariance matrices '/
           
         /'   Second step: Read event data from file '/
              fmvd_single = freefile       
              Open Cfilemvd_single For Input As #fmvd_single
              Coption = "None"
              Do Until EOF(fmvd_single)
                Line Input #fmvd_single, Cread
                If Left(Cread,1) = "*" Then Coption = "None"
                If Cread = "*Z*" Then 
                  Coption = "Z"
                  Line Input #fmvd_single, Cread
                End If  
                If Cread = "*A*" Then 
                  Coption = "A"
                  Line Input #fmvd_single, Cread
                End If  
                If Cread = "*AZ*" Then 
                  Coption = "AZ"
                  Line Input #fmvd_single, Cread
                End If  
                Select Case Coption
                  Case "Z"
                    CC_cut Cread," ",CVsplit(),Nsplit
                    IcntZ = IcntZ + 1
                    VZptb(IcntZ).IParameter = Cast(Integer,CVsplit(1))
                    VZptb(IcntZ).ICoordinate = Cast(Integer,CVsplit(2))
                    VZptb(IcntZ).Ryield = Cast(Single,CVsplit(3))
                  Case "A"
                    CC_cut Cread," ",CVsplit(),Nsplit
                    IcntA = IcntA + 1
                    VApreptb(IcntA).IParameter = Cast(Integer,CVsplit(1))
                    VApreptb(IcntA).ICoordinate = Cast(Integer,CVsplit(2))
                    VApreptb(IcntA).RYield = Cast(Single,CVsplit(3))
                    VApostptb(IcntA).IParameter = Cast(Integer,CVsplit(1))
                    VApostptb(IcntA).ICoordinate = Cast(Integer,CVsplit(2))
                    VApostptb(IcntA).Ryield = Cast(Single,CVsplit(4))
                  Case "AZ" 
                    CC_cut Cread," ",CVsplit(),Nsplit
                    IcntZA = IcntZA + 1  
                    VZApreptb(IcntZA).IParameter = Cast(Integer,CVsplit(1))
                    VZApreptb(IcntZA).ICoordinate1 = Cast(Integer,CVsplit(2))
                    VZApreptb(IcntZA).ICoordinate2 = Cast(Integer,CVsplit(3)) 
                    VZApreptb(IcntZA).Ryield = Cast(Single,CVsplit(4))
                    VZApostptb(IcntZA).IParameter = Cast(Integer,CVsplit(1))
                    VZApostptb(IcntZA).ICoordinate1 = Cast(Integer,CVsplit(2))
                    VZApostptb(IcntZA).ICoordinate2 = Cast(Integer,CVsplit(3))
                    VZApostptb(IcntZA).Ryield = Cast(Single,CVsplit(5))
                  Case Else
                End Select
              Loop
              Close #fmvd_single
             
         /'   Step 3, calculate covariances '/  
              Dim As Integer IParset, IMatrix
    
              Dim Bfound As Byte 
              Dim As Integer Nsum
              Dim As Double Rsum,Rsquare
      
      
           
          '   Covariances for Z distribution
              Zmax = 0
              Zmin = 100   
              For I = 1 To IcntZ
                Zmax = Max(Zmax,VZptb(I).ICoordinate)
                Zmin = Min(Zmin,VZptb(I).ICoordinate)
              Next I   
           
              Redim VZmean(Zmin to Zmax) As Single
              Redim VZrms(Zmin to Zmax) As Single
              Redim SZCovar(Zmin to Zmax,Zmin to Zmax) As OCovar
              Redim SZCorr(Zmin to Zmax,Zmin to Zmax) As OCorr
           
          '   Determine mean values and variances
              For I = Zmin To Zmax
                Rsum = 0
                Rsquare = 0
                Nsum = 0
                For J = 1 To IcntZ
                  If VZptb(J).ICoordinate = I Then   
                    RSum = RSum + VZptb(J).Ryield
                    Rsquare = Rsquare + (VZptb(J).Ryield)^2
                    Nsum = Nsum + 1
                  End If
                Next  
                If Nsum > 0 Then
                  VZmean(I) = RSum / Nsum
                  VZrms(I) = sqr((Rsquare - Rsum^2/Nsum)/(Nsum-1))
                Else
                  VZmean(I) = 0
                  VZrms(I) = 0
                End If   
              Next
           
           '  Determine covariance matrix
              For I = 1 To IcntZ
                For J = 1 To IcntZ
                  If VZptb(I).IParameter = Vzptb(J).IParameter Then 
                    SZCovar(VZptb(I).ICoordinate,VZptb(J).ICoordinate).Rval = _
                       SZCovar(VZptb(I).ICoordinate,VZptb(J).ICoordinate).Rval + _
                    (VZptb(I).Ryield - VZmean(VZptb(I).ICoordinate)) * _
                    (VZptb(J).Ryield - VZmean(VZptb(J).ICoordinate))
                    SZCovar(VZptb(I).ICoordinate,VZptb(J).ICoordinate).Nval = _
                    SZCovar(VZptb(I).ICoordinate,VZptb(J).ICoordinate).Nval + 1             
                  End If  
                Next      
              Next
              For I = Zmin To Zmax
                For J = Zmin To Zmax
    '             If SZCovar(I,J).Nval > 1 Then   ' Leads to unrealistic correlation coefficients
                  If SZCovar(I,J).Nval = N_Error_Max Then
                    SZCovar(I,J).Rval = SZCovar(I,J).Rval / (SZCovar(I,J).Nval-1)
                    If VZrms(I) <> 0 And VZrms(J) <> 0 Then
                      SZCorr(I,J).Rval = SZCovar(I,J).Rval / (VZrms(I) * VZrms(J))
                    End If
                  Else
                    SZCovar(I,J).Rval = 0
                  End If  
                Next J
              Next I
           
              If B_Double_Covar = 1 Then  ' Store values for covariances between different systems
                Print #fmvd, "* System Nr.   Parameterset  Observable     Number (1. 2. dim)        Deviation"
                For I = 1 To IcntZ
                  Print #fmvd, I_Double_Covar, VZptb(I).IParameter, "Z", VZptb(I).ICoordinate, 0, _
                            VZptb(I).Ryield - VZmean(VZptb(I).ICoordinate)
                Next I
              End If
    
    
    
          '   Covariances for A_pre Distribution
              Apremax = 0
              Apremin = 300   
              For I = 1 To IcntA
                Apremax = Max(Apremax,VApreptb(I).ICoordinate)
                Apremin = Min(Apremin,VApreptb(I).ICoordinate)
              Next I   
           
              Redim VApremean(Apremin to Apremax) As Single
              Redim VAprerms(Apremin to Apremax) As Single
              Redim SApreCovar(Apremin to Apremax,Apremin to Apremax) As OCovar
              Redim SApreCorr(Apremin to Apremax,Apremin to Apremax) As OCorr
           
          '   Determine mean values and variances
              For I = Apremin To Apremax
                Rsum = 0
                Rsquare = 0
                Nsum = 0
                For J = 1 To IcntA
                  If VApreptb(J).ICoordinate = I Then   
                    RSum = RSum + VApreptb(J).Ryield
                    Rsquare = Rsquare + (VApreptb(J).Ryield)^2
                    Nsum = Nsum + 1
                  End If
                Next J  
                If Nsum > 0 Then
                  VApremean(I) = RSum / Nsum
                  VAprerms(I) = sqr((Rsquare - Rsum^2/Nsum)/(Nsum-1))
                Else
                  VApremean(I) = 0
                  VAprerms(I) = 0
                End If            
              Next
    
           '  Determine covariance matrix
              For I = 1 To IcntA
                For J = 1 To IcntA
                  If VApreptb(I).IParameter = VApreptb(J).IParameter Then 
                    SApreCovar(VApreptb(I).ICoordinate,VApreptb(J).ICoordinate).Rval = _
                       SApreCovar(VApreptb(I).ICoordinate,VApreptb(J).ICoordinate).Rval + _
                    (VApreptb(I).Ryield - VApremean(VApreptb(I).ICoordinate)) * _
                    (VApreptb(J).Ryield - VApremean(VApreptb(J).ICoordinate))
                    SApreCovar(VApreptb(I).ICoordinate,VApreptb(J).ICoordinate).Nval = _
                    SApreCovar(VApreptb(I).ICoordinate,VApreptb(J).ICoordinate).Nval + 1             
                  End If  
                Next      
              Next
              For I = Apremin To Apremax
                For J = Apremin To Apremax
    '             If SApreCovar(I,J).Nval > 1 Then
                  If SApreCovar(I,J).Nval = N_Error_Max Then
                    SApreCovar(I,J).Rval = SApreCovar(I,J).Rval / (SApreCovar(I,J).Nval-1)
                    If VAprerms(I) <> 0 And VAprerms(J) <> 0 Then
                      SApreCorr(I,J).Rval = SApreCovar(I,J).Rval / (VAprerms(I) * Vaprerms(J))
                    End If
                  Else
                    SApreCovar(I,J).Rval = 0  
                  End If  
                Next
              Next
    
              If B_Double_Covar = 1 Then  ' Store values for covariances between different systems
                Print #fmvd, "* System Nr.   Parameterset  Observable     Number (1. 2. dim)        Deviation"
                For I = 1 To IcntA
                  Print #fmvd, I_Double_Covar, VApreptb(I).IParameter, "Apre", VApreptb(I).ICoordinate, 0, _
                            VApreptb(I).Ryield - VApremean(VApreptb(I).ICoordinate)
                Next I
              End If
    
           
            ' Covariances for A_post distribution       
              Apostmax = 0
              Apostmin = 300   
              For I = 1 To IcntA
                Apostmax = Max(Apostmax,VApostptb(I).ICoordinate)
                Apostmin = Min(Apostmin,VApostptb(I).ICoordinate)
              Next I   
            
              Redim VApostmean(Apostmin to Apostmax) As Single
              Redim VApostrms(Apostmin to Apostmax) As Single
              Redim SApostCovar(Apostmin to Apostmax,Apostmin to Apostmax) As OCovar
              Redim SApostCorr(Apostmin to Apostmax,Apostmin to Apostmax) As OCorr
           
            ' Determine mean values and variances
              For I = Apostmin To Apostmax
                Rsum = 0
                Rsquare = 0
                Nsum = 0
                For J = 1 To IcntA
                  If VApostptb(J).ICoordinate = I Then   
                    RSum = RSum + VApostptb(J).Ryield
                    Rsquare = Rsquare + (VApostptb(J).Ryield)^2
                    Nsum = Nsum + 1
                  End If
                Next  
                If Nsum > 0 Then
                  VApostmean(I) = RSum / Nsum
                  VApostrms(I) = sqr((Rsquare - Rsum^2/Nsum)/(Nsum-1))         
                Else
                  VApostmean(I) = 0
                  VApostrms(I) = 0
                End If  
              Next
    
           '  Determine covariance matrix
              For I = 1 To IcntA
                For J = 1 To IcntA
                  If VApostptb(I).IParameter = VApostptb(J).IParameter Then 
                    SApostCovar(VApostptb(I).ICoordinate,VApostptb(J).ICoordinate).Rval = _
                       SApostCovar(VApostptb(I).ICoordinate,VApostptb(J).ICoordinate).Rval + _
                    (VApostptb(I).Ryield - VApostmean(VApostptb(I).ICoordinate)) * _
                    (VApostptb(J).Ryield - VApostmean(VApostptb(J).ICoordinate))
                    SApostCovar(VApostptb(I).ICoordinate,VApostptb(J).ICoordinate).Nval = _
                    SApostCovar(VApostptb(I).ICoordinate,VApostptb(J).ICoordinate).Nval + 1             
                  End If  
                Next      
              Next
              For I = Apostmin To Apostmax
                For J = Apostmin To Apostmax
    '             If SApostCovar(I,J).Nval > 1 Then
                  If SApostCovar(I,J).Nval = N_Error_Max Then
                    SApostCovar(I,J).Rval = SApostCovar(I,J).Rval / (SApostCovar(I,J).Nval-1)
                    If VApostrms(I) <> 0 And VApostrms(J) <> 0 Then
                      SApostCorr(I,J).Rval = SApostCovar(I,J).Rval / (VApostrms(I) * Vapostrms(J))
                    End If
                  Else
                    SApostCovar(I,J).Rval = 0
                  End If  
                Next
              Next
           
              If B_Double_Covar = 1 Then  ' Store values for covariances between different systems
                Print #fmvd, "* System Nr.   Parameterset  Observable     Number (1. 2. dim)        Deviation"
                For I = 1 To IcntA
                  Print #fmvd, I_Double_Covar, VApostptb(I).IParameter, "Apost", VApostptb(I).ICoordinate, 0, _
                             VApostptb(I).Ryield - VApostmean(VApostptb(I).ICoordinate)
                Next I
              End If
    
            
    
    
          '   Covariance for pre-neutron nuclide distribution 
          '   Determine dimension of covariance matrix
              Redim VAprelim(Zmin to Zmax ,2) As Integer
              Dim As Integer A1full,A1red,A2full,A2red,Z1,Z2
              For I = Zmin to Zmax
                VAprelim(I,1) = 1000
                VAprelim(I,2) = 0
              Next
              dApremax = 0
              For I = 1 To IcntZA
                If I <= Ubound(VZApreptb) Then
                  Z1 = VZApreptb(I).Icoordinate2
                  VAprelim(Z1,1) = Min(VAprelim(Z1,1),VZApreptb(I).Icoordinate1)
                  VAprelim(Z1,2) = Max(VAprelim(Z1,2),VZApreptb(I).Icoordinate1)
                Else
                  Print "Internal error 1: I,IcntZA",I,IcntZA
                  Print "Press ENTER key to leave GEF!"
                  Sleep
                  End
                End If 
              Next
              For I = Zmin to Zmax
                dApremax = Max(dApremax, VAprelim(I,2) - VAprelim(I,1))
              Next
              dApremax = dApremax + 1
              Redim VZApremean(Zmin to Zmax,1 to dApremax) As Single
              Redim VZAprerms(Zmin to Zmax,1 to dApremax) As Single       
              Redim SZApreCovar(Zmin to Zmax,1 to dApremax, _
                                Zmin to Zmax,1 to dApremax) As OCovar 
              Redim SZApreCorr(Zmin to Zmax,1 to dApremax, _
                                Zmin to Zmax,1 to dApremax) As OCorr 
                               
            ' Determine mean values and variances
              For I = Zmin To Zmax
                For J = VAprelim(I,1) To VAprelim(I,2) 
                  Rsum = 0
                  Rsquare = 0
                  Nsum = 0
                  For K = 1 To IcntZA
                    If K <= Ubound(VZApreptb) Then
                      If VZApreptb(K).ICoordinate2 = I And _
                         VZApreptb(K).ICoordinate1 = J Then
                        RSum = RSum + VZApreptb(K).Ryield
                        Rsquare = Rsquare + (VZApreptb(K).Ryield)^2
                        Nsum = Nsum + 1
                      End If
                    Else
                      Print "Internal error 2: I,J,K,IcntZA=",I,J,K,IcntZA
                      Print "Press Enter key to leave GEF!"
                      Sleep
                      End
                    End If
                  Next  
                  A1red = J-VAprelim(I,1)+1
                  If Nsum > 0 Then
                    VZApremean(I,A1red) = RSum / Nsum
                    VZAprerms(I,A1red) = sqr((Rsquare - Rsum^2/Nsum)/(Nsum-1))
                  Else
                    VZApremean(I,A1red) = 0
                    VZAprerms(I,A1red) = 0
                  End If       
                Next 
              Next
           
           '  Determine covariance matrix
              For I = 1 To IcntZA
                If I <= Ubound(VZApreptb) Then
                  Z1 = VZApreptb(I).ICoordinate2
                  A1full = VZApreptb(I).ICoordinate1
                  A1red = A1full - VAprelim(Z1,1) + 1
                  For J = 1 To IcntZA
                    If J <= Ubound(VZApreptb) Then
                      Z2 = VZApreptb(J).ICoordinate2
                      A2full = VZApreptb(J).ICoordinate1
                      A2red = A2full - VAprelim(Z2,1) + 1
                      If VZApreptb(I).IParameter = VZApreptb(J).IParameter Then 
                        SZApreCovar(Z1,A1red,Z2,A2red).Rval = SZApreCovar(Z1,A1red,Z2,A2red).Rval + _
                          (VZApreptb(I).Ryield - VZApremean(Z1,A1red)) * _
                          (VZApreptb(J).Ryield - VZApremean(Z2,A2red)) 
                        SZApreCovar(Z1,A1red,Z2,A2red).Nval = SZApreCovar(Z1,A1red,Z2,A2red).Nval + 1                       
                      End If       
                    Else
                      Print "Internal error 3: I,J,IcntZA=",I,J,IcntZA
                      Print "Press Enter key to leave GEF!"
                      Sleep
                      End
                    End If    
                  Next
                Else
                  Print "Internal error 4: I,IcountZA=",I,IcntZA
                  Print "Press Enter key to leave GEF!"
                  Sleep
                  End
                End If
              Next      
           
              For I = Zmin To Zmax
                For J = VAprelim(I,1) To VAprelim(I,2) 
                  A1red = J - VAprelim(I,1) + 1
                  For K = Zmin To Zmax
                    For L = VAprelim(K,1) To VAprelim(K,2)
                      A2red = L - VAprelim(K,1) + 1 
    '                 If SZApreCovar(I,A1red,K,A2red).Nval > 1 Then
                      If SZApreCovar(I,A1red,K,A2red).Nval = N_Error_Max Then
                        SZApreCovar(I,A1red,K,A2red).Rval = SZApreCovar(I,A1red,K,A2red).Rval / _
                                                 (SZApreCovar(I,A1red,K,A2red).Nval-1)
                        If VZAprerms(I,A1red) <> 0 And VZAprerms(K,A2red) <> 0 Then
                           SZApreCorr(I,A1red,K,A2red).Rval = SZApreCovar(I,A1red,K,A2red).Rval / _
                                 (VZAprerms(I,A1red) * VZAprerms(K,A2red))                   
                        End If                         
                      Else
                        SZApreCovar(I,A1red,K,A2red).Rval = 0
                      End If                           
                    Next
                  Next
                Next
              Next       
           
              If B_Double_Covar = 1 Then  ' Store values for covariances between different systems
                Print #fmvd, "* System Nr.   Parameterset  Observable     Number (1. 2. dim)        Deviation"
                For I = 1 To IcntZA
                  Print #fmvd, I_Double_Covar, VZApreptb(I).IParameter, "ZApre", _ 
                               VZApreptb(I).ICoordinate1, _
                               VZApreptb(I).ICoordinate2, _
                               VZApreptb(I).Ryield  - _
                               VZApremean(VZApreptb(I).ICoordinate2,VZApreptb(I).ICoordinate1 + 1 - _ 
                               VAprelim(VZApreptb(I).ICoordinate2,1)) 
                Next I
              End If
    
    
    
          '   Covariance for post-neutron nuclide distribution 
          '   Determine dimension of covariance matrix
              Redim VApostlim(Zmin to Zmax ,2) As Integer
              For I = Zmin to Zmax
                VApostlim(I,1) = 1000
                VApostlim(I,2) = 0
              Next
              dApostmax = 0
              For I = 1 To IcntZA
                If I <= Ubound(VZApostptb) Then
                  Z1 = VZApostptb(I).Icoordinate2
                  VApostlim(Z1,1) = Min(VApostlim(Z1,1),VZApostptb(I).Icoordinate1)
                  VApostlim(Z1,2) = Max(VApostlim(Z1,2),VZApostptb(I).Icoordinate1)
                Else
                  Print "Internal error 5: I,IcntZA",I,IcntZA
                  Print "Press ENTER key to leave GEF!"
                  Sleep
                  End
                End If  
              Next
              For I = Zmin to Zmax
                dApostmax = Max(dApostmax, VApostlim(I,2) - VApostlim(I,1))
              Next
              dApostmax = dApostmax + 1
              Redim VZApostmean(Zmin to Zmax,1 to dApostmax) As Single
              Redim VZApostrms(Zmin to Zmax,1 to dApostmax) As Single       
              Redim SZApostCovar(Zmin to Zmax,1 to dApostmax, _
                                 Zmin to Zmax,1 to dApostmax) As OCovar 
              Redim SZApostCorr(Zmin to Zmax,1 to dApostmax, _
                                Zmin to Zmax,1 to dApostmax) As OCorr 
    
          '   Determine mean values and variances
              For I = Zmin To Zmax
                For J = VApostlim(I,1) To VApostlim(I,2) 
                  Rsum = 0
                  Rsquare = 0
                  Nsum = 0
                  For K = 1 To IcntZA
                    If K <= Ubound(VZApostptb) Then
                      If VZApostptb(K).ICoordinate2 = I And _
                         VZApostptb(K).ICoordinate1 = J Then
                        RSum = RSum + VZApostptb(K).Ryield
                        Rsquare = Rsquare + (VZApostptb(K).Ryield)^2
                        Nsum = Nsum + 1
                      End If
                    Else  
                      Print "Internal error 6: I,J,K,IcntZA=",I,J,K,IcntZA  
                      Print "Press ENTER key to leave GEF!"
                      Sleep
                      End
                    End If
                  Next  
                  A1red = J-VApostlim(I,1)+1     
                  If Nsum > 0 Then     
                    VZApostmean(I,A1red) = RSum / Nsum
                    VZApostrms(I,A1red) = sqr((Rsquare - Rsum^2/Nsum)/(Nsum-1)) 
                  Else
                    VZApostmean(I,A1red) = 0
                    VZApostrms(I,A1red) = 0 
                  End If           
                Next 
              Next
         
           
             'Determine covariance matrix
              For I = 1 To IcntZA
                If I <= Ubound(VZApostptb) Then
                  Z1 = VZApostptb(I).ICoordinate2
                  A1full = VZApostptb(I).ICoordinate1
                  A1red = A1full - VApostlim(Z1,1) + 1
                  For J = 1 To IcntZA
                    If J <= Ubound(VZApostptb) Then
                      Z2 = VZApostptb(J).ICoordinate2
                      A2full = VZApostptb(J).ICoordinate1
                      A2red = A2full - VApostlim(Z2,1) + 1
                      If VZApostptb(I).IParameter = VZApostptb(J).IParameter Then 
                        SZApostCovar(Z1,A1red,Z2,A2red).Rval = SZApostCovar(Z1,A1red,Z2,A2red).Rval + _
                          (VZApostptb(I).Ryield - VZApostmean(Z1,A1red)) * _
                          (VZApostptb(J).Ryield - VZApostmean(Z2,A2red)) 
                        SZApostCovar(Z1,A1red,Z2,A2red).Nval = SZApostCovar(Z1,A1red,Z2,A2red).Nval + 1    
    
                      End If
                    Else
                      Print "Internal error 7: I,J,IcntZA",I,J,IcntZA
                      Print "Press ENTER key to leave GEF!"
                      Sleep
                      End
                    End If             
                  Next
                Else
                  Print "Internal error 8: I,J,IcntZA",I,J,IcntZA
                  Print "Press ENTER key to leave GEF!"
                  Sleep
                  End
                End If  
              Next     
           
              For I = Zmin To Zmax
                For J = VApostlim(I,1) To VApostlim(I,2) 
                  A1red = J - VApostlim(I,1) + 1
                  For K = Zmin To Zmax
                    For L = VApostlim(K,1) To VApostlim(K,2)
                      A2red = L - VApostlim(K,1) + 1 
    '                 If SZApostCovar(I,A1red,K,A2red).Nval > 1 Then
                      If SZApostCovar(I,A1red,K,A2red).Nval = N_Error_Max Then
                        SZApostCovar(I,A1red,K,A2red).Rval = SZApostCovar(I,A1red,K,A2red).Rval / _
                                               (SZApostCovar(I,A1red,K,A2red).Nval-1)
                        If VZApostrms(I,A1red) <> 0 And VZApostrms(K,A2red) <> 0 Then
                          SZApostCorr(I,A1red,K,A2red).Rval = SZApostCovar(I,A1red,K,A2red).Rval / _
                               (VZApostrms(I,A1red) * VZApostrms(K,A2red))     
                        End If      
                      Else
                        SZApostCovar(I,A1red,K,A2red).Rval = 0
                      End If                           
                    Next
                  Next
                Next
              Next       
           
              If B_Double_Covar = 1 Then  ' Store values for covariances between different systems
                Print #fmvd, "* System Nr.   Parameterset  Observable     Number (1. 2. dim)        Deviation"
                For I = 1 To IcntZA
                  Print #fmvd, I_Double_Covar, VZApostptb(I).IParameter, "ZApost", _ 
                               VZApostptb(I).ICoordinate1, _
                               VZApostptb(I).ICoordinate2, _
                               VZApostptb(I).Ryield  - _
                               VZApostmean(VZApostptb(I).ICoordinate2,VZApostptb(I).ICoordinate1 + 1 - _ 
                               VApostlim(VZApostptb(I).ICoordinate2,1)) 
                Next I
                Close #fmvd
              End If
           
           
    
          '   Uncertainties
    
              For I = 20 To 190
                If d_APost(1,I) > 0 Then
                  d_APost(0,I) = sqr ( (d_APost(2,I) - _
                                        d_APost(1,I)^2/N_Error_Max ) /(N_Error_Max-1.0) )
                Else
                  d_APost(0,I) = APost(I)                       
                End If
                If d_APost(0,I) > APost(I) Or d_APost(0,I) = 0 Then 
                  d_APost(0,I) = APost(I)
                End If   
              Next            
    
              For I = 20 To 70
                If d_ZPost(1,I) > 0 Then
                  d_ZPost(0,I) = sqr ( (d_ZPost(2,I) - _
                                        d_ZPost(1,I)^2/N_Error_Max ) /(N_Error_Max-1.0) )
                Else
                  d_ZPost(0,I) = ZPost(I)                       
                End If
                If d_ZPost(0,I) > ZPost(I) Or d_ZPost(0,I) = 0 Then 
                  d_ZPost(0,I) = ZPost(I)
                End If        
              Next I
    
              For I = Lbound(_ZISOPOST,1) To Ubound(_ZISOPOST,1)
                For J = Lbound(_ZISOPOST,2) To Ubound(_ZISOPOST,2)
                  If ZISOPOST(I,J) > 0 Then
    '               d_ZISOPOST(0,I,J) = sqr ( (d_ZISOPOST(2,I,J) - _
    '                                         d_ZISOPOST(1,I,J)^2/N_Error_Max ) /(N_Error_Max-1.0) )
                    Acc_d_ZISOPOST(0,I,J,sqr ( (d_ZISOPOST(2,I,J) - _
                                             d_ZISOPOST(1,I,J)^2/N_Error_Max ) /(N_Error_Max-1.0) ) )                                      
                  Else
    '               d_ZISOPOST(0,I,J) = ZISOPOST(I,J) 
                    Acc_d_ZISOPOST(0,I,J,ZISOPOST(I,J))     
            	  End If
            	  If d_ZISOPOST(0,I,J) > ZISOPOST(I,J) or d_ZISOPOST(0,I,J) = 0 Then
    '        	                d_ZISOPOST(0,I,J) = ZISOPOST(I,J)
                    Acc_d_ZISOPOST(0,I,J,ZISOPOST(I,J))      	                
            	  End If             
                Next
              Next
              For I = Lbound(_NZPost,1) To Ubound(_NZPost,1)   ' I is N-Z !
                For J = Lbound(_NZPost,2) To Ubound(_NZPost,2) ' J is Z
                  If NZPost(I+J,J) > 0 Then                    ' I + J is N !
    '               d_NZPOST(0,I,J) = sqr ( (d_NZPOST(2,I,J) - _
    '                                        d_NZPOST(1,I,J)^2/N_Error_Max ) /(N_Error_Max-1.0) )
                    Acc_d_NZPOST(0,I+J,J, _
                       sqr( (d_NZPOST(2,I+J,J) - d_NZPOST(1,I+J,J)^2/N_Error_Max ) /(N_Error_Max-1.0) ) )                         
                  Else
    '               d_NZPost(0,I,J) = NZPost(I,J)
                        ' relative error set to 100%
                    Acc_d_NZPOST(0,I+J,J,NZPost(I+J,J))      
                  End If
                  If d_NZPost(0,I+J,J) > NZPost(I+J,J) Or d_NZPost(0,I+J,J) = 0 Then 
                         _d_NZPost(0,I,J) = NZPost(I+J,J)  
                        ' relative error limited to 100% 
                  End If         
                Next
              Next
              d_NCN(0) = sqr( (d_NCN(2) - d_NCN(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
              d_Nsci(0) = sqr( (d_Nsci(2) - d_Nsci(1)^2/N_Error_Max) / (N_Error_Max - 1.0) ) 
              d_Nfr(0) = sqr( (d_Nfr(2) - d_Nfr(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
              d_Nlight(0) = sqr( (d_Nlight(2) - d_Nlight(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
              d_Nheavy(0) = sqr( (d_Nheavy(2) - d_Nheavy(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
              d_Ntot(0) = sqr( (d_Ntot(2) - d_Ntot(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
              d_ENfr(0) = sqr( (d_ENfr(2) - d_ENfr(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
           
              d_Ng(0) = sqr( (d_Ng(2) - d_Ng(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
              d_Eg(0) = sqr( (d_Eg(2) - d_Eg(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
              d_Egtot(0) = sqr( (d_Egtot(2) - d_Egtot(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
              d_Q(0) = sqr( (d_Q(2) - d_Q(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
              d_TKEpre(0) = sqr( (d_TKEpre(2) - d_TKEpre(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
              d_TKEpost(0) = sqr( (d_TKEpost(2) - d_TKEpost(1)^2/N_Error_Max) / (N_Error_max - 1.0) )
              d_TotXE(0) = sqr( (d_TotXE(2) - d_TotXE(1)^2/N_Error_Max) / (N_Error_Max - 1.0) )
        
        
           ' --- Covariances between the yields of two fissioning systems ---
           
              If B_Double_Covar = 1 And I_Double_Covar = 2 Then
                Dim As String C_dummy
                Redim As String C_part(1) 
                Dim As Integer Nstored, Istored, Nvalues
                fmvd = freefile       
                Open Cfilemvd For Input As #fmvd
                Nstored = 0
                Do 
                  Line Input #fmvd, C_dummy
                  If Left(Ltrim(C_dummy),1) <> "*" Then Nstored = Nstored + 1
                Loop Until EOF(fmvd)
                Close #fmvd 
    
                Redim As Integer VIstored(4,Nstored)
                ' 1: System, 2: Parset, 3: Dim. 1, 4: Dim. 2
                Redim As Single VRstored(Nstored)  
                Redim As String VCstored(Nstored) 
    
                fmvd = freefile        
                Open Cfilemvd For Input As #fmvd
                Istored = 0
                Do 
                  Line Input #fmvd, C_dummy
                  If Left(Ltrim(C_dummy),1) <> "*" Then 
                    Istored = Istored + 1
                    Nvalues = CC_Count(C_dummy," ")
                    Redim C_part(Nvalues)
                    CC_Cut(C_dummy," ",C_part(),Nvalues)
                    VIstored(1,Istored) = Val(C_part(1))  ' Fissioning system (1 or 2)
                    VIstored(2,Istored) = Val(C_part(2))  ' Parameter set (1 To N_Error_Max)
                    VIstored(3,Istored) = Val(C_part(4))  ' Dimension 1 (e.g. Z or A)
                    VIstored(4,Istored) = Val(C_part(5))  ' Dimension 2 (e.g. Z)
                    VRstored(Istored) = Val(C_part(6))    ' Deviation from mean value
                    VCstored(Istored) = C_part(3)         ' Kind of data (Z, Apre, Apost, ZApre, ZApost)
                  End If  
                Loop Until EOF(fmvd) 
                Close #fmvd                  
             
        
              
              ' Covariances between the Z distributions of the two systems
              ' Determine dimension of the covariance matrix.
                Z_Double_max = 0
                Z_Double_min = 1000
                For I = 1 To Nstored
                  If VCstored(I) = "Z" Then
                    Z_Double_min = Min(Z_Double_min,VIstored(3,I))
                    Z_Double_max = Max(Z_Double_max,VIstored(3,I))
                  End If
                Next I
             
            '   Reorder deviations for faster access
                Redim As Single VRZ_Double(2,N_Error_Max,Z_Double_min To Z_Double_max)
                For I = 1 To Nstored
                  If VCstored(I) = "Z" Then
                    VRZ_Double(VIstored(1,I),VIstored(2,I),VIstored(3,I)) = VRstored(I)
                  End If  
                Next I
    
            '   Calculate covariances
                Redim SZ_Double_Covar(Z_Double_min to Z_Double_max, _
                                      Z_Double_min to Z_Double_max) As OCovar
                Redim SZ_Double_Corr(Z_Double_min to Z_Double_max, _
                                     Z_Double_min to Z_Double_max) As OCorr
                For I = Z_Double_min To Z_Double_max
                  For J = Z_Double_min To Z_Double_max
                    For K = 1 To N_Error_Max
                      If VRZ_Double(1,K,I) <> 0 And VRZ_Double(2,K,J) <> 0 Then
                        SZ_Double_Covar(I,J).Rval = _
                             SZ_Double_Covar(I,J).Rval + VRZ_Double(1,K,I) * VRZ_Double(2,K,J)
                             SZ_Double_Covar(I,J).Nval = SZ_Double_Covar(I,J).Nval + 1
                      End If       
                    Next K
                  Next J
                Next I
    
            '   Normalize and remove incomplete results         
                For I = Z_Double_min To Z_Double_max
                  For J = Z_Double_min To Z_Double_max
                    If SZ_Double_Covar(I,J).Nval = N_Error_Max Then 
                      SZ_Double_Covar(I,J).Rval = SZ_Double_Covar(I,J).Rval _
                                               / (SZ_Double_Covar(I,J).Nval-1)
                    Else
                      SZ_Double_Covar(I,J).Rval = 0
                    End If                           
                  Next J
                Next I  
             
                Redim rms_Double(Z_Double_min to Z_Double_max,2)
                For I = Z_Double_min To Z_Double_max
                  For J = 1 To N_Error_Max
                    rms_Double(I,1) = rms_Double(I,1) + VRZ_Double(1,J,I)^2
                    rms_Double(I,2) = rms_Double(I,2) + VRZ_Double(2,J,I)^2
                  Next J
                Next I
                For I = Z_Double_min To Z_Double_max
                  rms_Double(I,1) = sqr(rms_Double(I,1) / (N_Error_Max - 1))
                  rms_Double(I,2) = sqr(rms_Double(I,2) / (N_Error_Max - 1))
                Next I
                For I = Z_Double_min To Z_Double_max
                  For J = Z_Double_min To Z_Double_max
                    If rms_Double(I,1) <> 0 And rms_Double(J,2) <> 0 Then                          
                        SZ_Double_Corr(I,J).Rval = SZ_Double_Covar(I,J).Rval / _
                               (rms_Double(I,1) * rms_Double(J,2))          
                    End If                       
                  Next J
                Next I  
                Erase VRZ_Double
       
             
    
              ' Covariances between the Apre distributions of the two systems
              ' Determine dimensions of the covariance matrix
                Apre_Double_max = 0
                Apre_Double_min = 1000
                For I = 1 To Nstored
                  If VCstored(I) = "Apre" Then
                    Apre_Double_min = Min(Apre_Double_min,VIstored(3,I))
                    Apre_Double_max = Max(Apre_Double_max,VIstored(3,I))
                  End If
                Next I
             
              ' Reorder deviations for faster access         
                Redim As Single VRApre_Double(2,N_Error_Max,Apre_Double_min To Apre_Double_max)
                For I = 1 To Nstored
                  If VCstored(I) = "Apre" Then
                    VRApre_Double(VIstored(1,I),VIstored(2,I),VIstored(3,I)) = VRstored(I)
                  End If  
                Next I         
    
            '   Calculate covariances
                Redim SApre_Double_Covar(Apre_Double_min to Apre_Double_max, _
                                    Apre_Double_min to Apre_Double_max) As OCovar
                Redim SApre_Double_Corr(Apre_Double_min to Apre_Double_max, _
                                    Apre_Double_min to Apre_Double_max) As OCorr
                For I = Apre_Double_min To Apre_Double_max
                  For J = Apre_Double_min To Apre_Double_max
                    For K = 1 To N_Error_Max
                      If VRApre_Double(1,K,I) <> 0 And VRApre_Double(2,K,J) <> 0 Then
                        SApre_Double_Covar(I,J).Rval = _
                             SApre_Double_Covar(I,J).Rval + VRApre_Double(1,K,I) * VRApre_Double(2,K,J)
                             SApre_Double_Covar(I,J).Nval = SApre_Double_Covar(I,J).Nval + 1
                      End If       
                    Next K
                  Next J
                Next I
    
              ' Normalize and remove incomplete results         
                For I = Apre_Double_min To Apre_Double_max
                  For J = Apre_Double_min To Apre_Double_max
                    If SApre_Double_Covar(I,J).Nval = N_Error_Max Then 
                      SApre_Double_Covar(I,J).Rval = SApre_Double_Covar(I,J).Rval _
                                               / (SApre_Double_Covar(I,J).Nval-1)
                    Else
                      SApre_Double_Covar(I,J).Rval = 0
                    End If                              
                  Next J
                Next I  
             
                Redim rms_Double(Apre_Double_min to Apre_Double_max,2)
                For I = Apre_Double_min To Apre_Double_max
                  For J = 1 To N_Error_Max
                    rms_Double(I,1) = rms_Double(I,1) + VRApre_Double(1,J,I)^2
                    rms_Double(I,2) = rms_Double(I,2) + VRApre_Double(2,J,I)^2
                  Next J
                Next I
                For I = Apre_Double_min To Apre_Double_max
                  rms_Double(I,1) = sqr(rms_Double(I,1) / (N_Error_Max - 1))
                  rms_Double(I,2) = sqr(rms_Double(I,2) / (N_Error_Max - 1))
                Next I
                For I = Apre_Double_min To Apre_Double_max
                  For J = Apre_Double_min To Apre_Double_max
                    If rms_Double(I,1) <> 0 And rms_Double(J,2) <> 0 Then                          
                        SApre_Double_Corr(I,J).Rval = SApre_Double_Covar(I,J).Rval / _
                               (rms_Double(I,1) * rms_Double(J,2))          
                    End If                       
                  Next J
                Next I  
                Erase VRApre_Double
    
            
       
            '   Covariances between the Apost distributions of the two systems
            '   Determine dimensions of the covariance matrix
                Apost_Double_max = 0
                Apost_Double_min = 1000
                For I = 1 To Nstored
                  If VCstored(I) = "Apost" Then
                    Apost_Double_min = Min(Apost_Double_min,VIstored(3,I))
                    Apost_Double_max = Max(Apost_Double_max,VIstored(3,I))
                  End If
                Next I
             
              ' Reorder deviations for faster access         
                Redim As Single VRApost_Double(2,N_Error_Max,Apost_Double_min To Apost_Double_max)
                For I = 1 To Nstored
                  If VCstored(I) = "Apost" Then
                    VRApost_Double(VIstored(1,I),VIstored(2,I),VIstored(3,I)) = VRstored(I)
                  End If  
                Next I         
    
              ' Calculate covariances
                Redim SApost_Double_Covar(Apost_Double_min to Apost_Double_max, _
                                      Apost_Double_min to Apost_Double_max) As OCovar
                Redim SApost_Double_Corr(Apost_Double_min to Apost_Double_max, _
                                    Apost_Double_min to Apost_Double_max) As OCorr
                For I = Apost_Double_min To Apost_Double_max
                  For J = Apost_Double_min To Apost_Double_max
                    For K = 1 To N_Error_Max
                      If VRApost_Double(1,K,I) <> 0 And VRApost_Double(2,K,J) <> 0 Then
                        SApost_Double_Covar(I,J).Rval = _
                           SApost_Double_Covar(I,J).Rval + VRApost_Double(1,K,I) * VRApost_Double(2,K,J)
                           SApost_Double_Covar(I,J).Nval = SApost_Double_Covar(I,J).Nval + 1
                      End If       
                    Next K
                  Next J
                Next I
    
            '   Normalize and remove incomplete results         
                For I = Apost_Double_min To Apre_Double_max
                  For J = Apost_Double_min To Apre_Double_max
                    If SApost_Double_Covar(I,J).Nval = N_Error_Max Then 
                      SApost_Double_Covar(I,J).Rval = SApost_Double_Covar(I,J).Rval _
                                             / (SApost_Double_Covar(I,J).Nval-1)
                    Else
                      SApost_Double_Covar(I,J).Rval = 0
                    End If                           
                  Next J
                Next I  
    
                Redim rms_Double(Apost_Double_min to Apost_Double_max,2)
                For I = Apost_Double_min To Apost_Double_max
                  For J = 1 To N_Error_Max
                    rms_Double(I,1) = rms_Double(I,1) + VRApost_Double(1,J,I)^2
                    rms_Double(I,2) = rms_Double(I,2) + VRApost_Double(2,J,I)^2
                  Next J
                Next I
                For I = Apost_Double_min To Apost_Double_max
                  rms_Double(I,1) = sqr(rms_Double(I,1) / (N_Error_Max - 1))
                  rms_Double(I,2) = sqr(rms_Double(I,2) / (N_Error_Max - 1))
                Next I
                For I = Apost_Double_min To Apost_Double_max
                  For J = Apost_Double_min To Apost_Double_max
                    If rms_Double(I,1) <> 0 And rms_Double(J,2) <> 0 Then                          
                        SApost_Double_Corr(I,J).Rval = SApost_Double_Covar(I,J).Rval / _
                               (rms_Double(I,1) * rms_Double(J,2))          
                    End If                       
                  Next J
                Next I  
                Erase VRApost_Double            
                Erase rms_Double
             
    
    
              ' Covariance between the pre-neutron nuclide distributions of the two systems 
              ' Determine dimension of covariance matrix
                Redim VApre_Double_lim(Z_Double_min to Z_Double_max,2) As Integer
                Dim As Integer M
                For I = Z_Double_min To Z_Double_max
                  VApre_Double_lim(I,1) = 1000
                  VApre_Double_lim(I,2) = 0
                Next I
                dApre_Double_max = 0 
                For I = 1 To Nstored
                  If VCstored(I) = "ZApre" Then
                    Z1 = VIstored(4,I)
                    If Z1 >= Z_Double_min And Z1 <= Z_Double_max Then
                      VApre_Double_lim(Z1,1) = Min(VApre_Double_lim(Z1,1),VIstored(3,I))
                      VApre_Double_lim(Z1,2) = Max(VApre_Double_lim(Z1,2),VIstored(3,I))
                    Else
                      Print "GEF 9889: Z1 =";Z1  
                    End If
                  End If         
                Next I
                For I = Z_Double_min To Z_Double_max
                  If VApre_Double_lim(I,1) = 1000 Then 
                    VApre_Double_lim(I,1) = 0
                  Else 
                    dApre_Double_max = Max(dApre_Double_max, VApre_Double_lim(I,2) - VApre_Double_lim(I,1) + 1) 
                  End If  
                Next I
             
              ' Reorder deviations for faster access
                Redim As Single VRZApre_Double(2,N_Error_Max,Z_Double_min To Z_Double_max,dApre_Double_max)
                For I = 1 To Nstored
                  If VCstored(I) = "ZApre" Then
                    Z1 = VIstored(4,I)
                    A1 = VIstored(3,I)
                    A1red = A1 - VApre_Double_lim(Z1,1) + 1
    '               Print "8824 ";VIstored(1,I),VIstored(2,I),Z1,A1red            
                    VRZApre_Double(VIstored(1,I),VIstored(2,I),Z1,A1red) = _
                          VRstored(I)
                  End If
                Next I
             
             
            '   Calculate covariances
                Redim SZApre_Double_Covar(Z_Double_min to Z_Double_max, 1 to dApre_Double_max,_
                                        Z_Double_min to Z_Double_max, 1 to dApre_Double_max) As OCovar
                Redim SZApre_Double_Corr(Z_Double_min to Z_Double_max, 1 to dApre_Double_max,_
                                        Z_Double_min to Z_Double_max, 1 to dApre_Double_max) As OCorr
                For I = Z_Double_min to Z_Double_max
                  For J = VApre_Double_lim(I,1) To VApre_Double_lim(I,2)
                    A1full = J
                    A1red = J - VApre_Double_lim(I,1) + 1
                    For K = Z_Double_min To Z_Double_max
                      For L = VApre_Double_lim(K,1) To VApre_Double_lim(K,2)
                        A2full = L
                        A2red = L - VApre_Double_lim(K,1) + 1
                        For M = 1 To N_Error_Max
                          If VRZApre_Double(1,M,I,A1red) <> 0 And VRZApre_Double(2,M,K,A2red) <> 0 Then    
     '                      Print M,I,J,VRZApre_Double(1,M,I,A1red),VRZApre_Double(2,M,K,A2red)                              
                            SZApre_Double_Covar(I,A1red,K,A2red).Rval = _
                                       SZApre_Double_Covar(I,A1red,K,A2red).Rval _ 
                                     + VRZApre_Double(1,M,I,A1red) * VRZApre_Double(2,M,K,A2red) 
                            SZApre_Double_Covar(I,A1red,K,A2red).Nval = _
                                       SZApre_Double_Covar(I,A1red,K,A2red).Nval + 1
                          End If              
                        Next M       
                      Next L
                    Next K
                  Next J    
                Next I          
             
            '   Normalize and remove incomplete results   
                For I = Z_Double_min to Z_Double_max
                  For J = 1 To dApre_Double_max
                    For K = Z_Double_min To Z_Double_max
                      For L = 1 To dApre_Double_max
                        If SZApre_Double_Covar(I,J,K,L).Nval = N_Error_Max Then 
                          SZApre_Double_Covar(I,J,K,L).Rval = SZApre_Double_Covar(I,J,K,L).Rval / _
                                         (SZApre_Double_Covar(I,J,K,L).Nval - 1) 
                        Else
                          SZApre_Double_Covar(I,J,K,L).Rval = 0
                        End If  
                      Next L
                    Next K
                  Next J
                Next I       
             
                Redim rms_ZA_Double(Z_Double_min to Z_Double_max, 1 to dApre_Double_max,2)
                For I = Z_Double_min to Z_Double_max
                  For J = 1 To dApre_Double_max
                    For K = 1 To N_Error_Max 
                      rms_ZA_Double(I,J,1) = rms_ZA_Double(I,J,1) + VRZApre_Double(1,K,I,J)^2
                      rms_ZA_Double(I,J,2) = rms_ZA_Double(I,J,2) + VRZApre_Double(2,K,I,J)^2   
                    Next K     
                  Next J
                Next I
                For I = Z_Double_min to Z_Double_max
                  For J = 1 To dApre_Double_max
                    rms_ZA_Double(I,J,1) = sqr(rms_ZA_Double(I,J,1) / (N_Error_Max - 1))
                    rms_ZA_Double(I,J,2) = sqr(rms_ZA_Double(I,J,2) / (N_Error_Max - 1))
                  Next J
                Next I
                For I = Z_Double_min to Z_Double_max
                  For J = 1 To dApre_Double_max
                    For K = Z_Double_min to Z_Double_max
                      For L = 1 To dApre_Double_max
                        If rms_ZA_Double(I,J,1) <> 0 And rms_ZA_Double(K,L,2) <> 0 Then
                          SZApre_Double_Corr(I,J,K,L).Rval = SZApre_Double_Covar(I,J,K,L).Rval / _
                            (rms_ZA_Double(I,J,1) * rms_ZA_Double(K,L,2))
                        End If
                      Next L
                    Next K
                  Next J
                Next I
                Erase VRZApre_Double
             
             
             
            '   Covariance between the post-neutron nuclide distributions of the two systems 
            '   Determine dimension of covariance matrix
                Redim VApost_Double_lim(Z_Double_min to Z_Double_max,2) As Integer
                For I = Z_Double_min To Z_Double_max
                  VApost_Double_lim(I,1) = 1000
                  VApost_Double_lim(I,2) = 0
                Next I
                dApost_Double_max = 0 
                For I = 1 To Nstored
                  If VCstored(I) = "ZApost" Then
                    Z1 = VIstored(4,I)
                    If Z1 >= Z_Double_min And Z1 <= Z_Double_max Then
                      VApost_Double_lim(Z1,1) = Min(VApost_Double_lim(Z1,1),VIstored(3,I))
                      VApost_Double_lim(Z1,2) = Max(VApost_Double_lim(Z1,2),VIstored(3,I))
                    Else
                      Print "GEF 10005: Z1 =";Z1
                    End If  
                  End If         
                Next I
                For I = Z_Double_min To Z_Double_max
                  If VApost_Double_lim(I,1) = 1000 Then 
                    VApost_Double_lim(I,1) = 0
                  Else 
                    dApost_Double_max = Max(dApost_Double_max, VApost_Double_lim(I,2) - VApost_Double_lim(I,1) + 1) 
                  End If  
                Next I
             
              ' Reorder deviations for faster access
                Redim As Single VRZApost_Double(2,N_Error_Max,Z_Double_min To Z_Double_max,dApost_Double_max)
                For I = 1 To Nstored
                  If VCstored(I) = "ZApost" Then
                    Z1 = VIstored(4,I)
                    A1 = VIstored(3,I)
                    A1red = A1 - VApost_Double_lim(Z1,1) + 1
                    VRZApost_Double(VIstored(1,I),VIstored(2,I),Z1,A1red) = _
                            VRstored(I)
     '              Print VIstored(1,I),VIstored(2,I),Z1,A1,A1red,VRstored(I),VRZApost_Double(VIstored(1,I),VIstored(2,I),Z1,A1red)                   
                  End If
                Next I
             
     '          Print "****************"  
     '          Print Z_Double_min, Z_Double_max, dApost_Double_max
     '          Print "****************"  
           
             
         /'     For I = 1 To 2
                  For J = 0 To N_Error_Max 
                    For K = Z_Double_min to Z_Double_max
                      For L = 1 To dApost_Double_max
                        If VRZApost_Double(I,J,K,L) <> 0 Then
                          Print I,J,K,L,VRZApost_Double(I,J,K,L)
                        End If
                      Next
                    Next 
                  Next 
                Next  '/     
             
            '   Calculate covariances
                Redim SZApost_Double_Covar(Z_Double_min to Z_Double_max, 1 to dApost_Double_max,_
                                           Z_Double_min to Z_Double_max, 1 to dApost_Double_max) As OCovar
                Redim SZApost_Double_Corr(Z_Double_min to Z_Double_max, 1 to dApost_Double_max,_
                                          Z_Double_min to Z_Double_max, 1 to dApost_Double_max) As OCorr
                For I = Z_Double_min to Z_Double_max
                  For J = VApost_Double_lim(I,1) To VApost_Double_lim(I,2)
                    A1full = J
                    A1red = J - VApost_Double_lim(I,1) + 1
                    For K = Z_Double_min To Z_Double_max
                      For L = VApost_Double_lim(K,1) To VApost_Double_lim(K,2)
                        A2full = L
                        A2red = L - VApost_Double_lim(K,1) + 1
                        For M = 1 To N_Error_Max
                          If VRZApost_Double(1,M,I,A1red) <> 0 And VRZApost_Double(2,M,K,A2red) <> 0 Then    
    '                       Print I,J,K,L,VRZApost_Double(1,M,I,A1red),VRZApost_Double(2,M,K,A2red)                  
                            SZApost_Double_Covar(I,A1red,K,A2red).Rval = _
                                       SZApost_Double_Covar(I,A1red,K,A2red).Rval _ 
                                       + VRZApost_Double(1,M,I,A1red) * VRZApost_Double(2,M,K,A2red) 
                            SZApost_Double_Covar(I,A1red,K,A2red).Nval = _
                                       SZApost_Double_Covar(I,A1red,K,A2red).Nval + 1
                          End If              
                        Next M       
                      Next L
                    Next K
                  Next J    
                Next I          
             
            '   Normalize and remove incomplete results   
                For I = Z_Double_min to Z_Double_max
                  For J = 1 To dApost_Double_max
                    For K = Z_Double_min To Z_Double_max
                      For L = 1 To dApost_Double_max
                        If SZApost_Double_Covar(I,J,K,L).Nval = N_Error_Max Then 
                          SZApost_Double_Covar(I,J,K,L).Rval = SZApost_Double_Covar(I,J,K,L).Rval / _
                                         (SZApost_Double_Covar(I,J,K,L).Nval - 1)
    '                     Print I,J,K,L                                   
                        Else                  
                          SZApost_Double_Covar(I,J,K,L).Rval = 0
                        End If  
                      Next L
                    Next K
                  Next J
                Next I                              
    
                Redim rms_ZA_Double(Z_Double_min to Z_Double_max, 1 to dApre_Double_max,2)
                For I = Z_Double_min to Z_Double_max
                  For J = 1 To dApost_Double_max
                    For K = 1 To N_Error_Max 
                      rms_ZA_Double(I,J,1) = rms_ZA_Double(I,J,1) + VRZApost_Double(1,K,I,J)^2
                      rms_ZA_Double(I,J,2) = rms_ZA_Double(I,J,2) + VRZApost_Double(2,K,I,J)^2   
                    Next K          
                  Next J
                Next I
                For I = Z_Double_min to Z_Double_max
                  For J = 1 To dApost_Double_max
                    rms_ZA_Double(I,J,1) = sqr(rms_ZA_Double(I,J,1) / (N_Error_Max - 1))
                    rms_ZA_Double(I,J,2) = sqr(rms_ZA_Double(I,J,2) / (N_Error_Max - 1))
                  Next J
                Next I
                For I = Z_Double_min to Z_Double_max
                  For J = 1 To dApost_Double_max
                    For K = Z_Double_min to Z_Double_max
                      For L = 1 To dApost_Double_max
                        If rms_ZA_Double(I,J,1) <> 0 And rms_ZA_Double(K,L,2) <> 0 Then
                          SZApost_Double_Corr(I,J,K,L).Rval = SZApost_Double_Covar(I,J,K,L).Rval / _
                            (rms_ZA_Double(I,J,1) * rms_ZA_Double(K,L,2))
                        End If
                      Next L
                    Next K
                  Next J
                Next I
                Erase VRZApost_Double
                Erase rms_ZA_Double
             
             
             
              End If  ' If B_Double_Covar ...
                    
            End If
                
          End If
    
          If B_Double_Covar = 1 And I_Double_Covar = 2 Then
            Print #f," "
            Print #f," <GEF2>"
          Else  
            Print #f,"<?xml version=""1.0"" encoding=""ISO-8859-1""?>"
            Print #f,"<GEF>"
            If B_Double_Covar = 1 And I_Double_Covar = 1 Then
              Print #f," <GEF1>"
            End If
          End If  
          If B_Double_Covar = 1 Then
            If I_Double_Covar = 1 Then
              Print #f,"This GEF block contains only data of the first system!"
              Print #f,"The data of the second system and the combined data of" 
              Print #f,"both systems are found in the next GEF block."
            End If
            If I_Double_Covar = 2 Then
              Print #f,"This GEF block contains the data of the second system"
              Print #f,"and the combined data (e.g. covariances/correlations) of both systems."
            End If  
          End If
          Print #f,"  <Title>"
          Print #f,"***********************************************************"
          Print #f," "
          Print #f,"       *****************************"
          Print #f,"       *    GEF, Version "+C_GEF_Version+"  *"
          Print #f,"       * K.-H. Schmidt, B. Jurado  *"
          Print #f,"       *****************************"
          Print #f," "
          Dim As Double Rdatetime
          Rdatetime = Now
          Print #f,"Output written on ";
          Print #f, Format( Rdatetime, "dd.mm.yyyy, hh:mm:ss")
          Print #f,"Calculation with";IEVTtot;" events."
          If IEVTtot < NEVTtot Then
            Print #f,"  The nominal number of";NEVTtot;" events was not reached, because"
            Print #f,"  part of the excitation-energy distribution at fission was below"
            Print #f,"  one event per energy bin. This loss can be reduced by increasing"
            Print #f,"  the nominal number of events to be calculated." 
          End If  
          Print #f," "
          Print #f, Using "& ### & ###";"Calculated yields for the nucleus Z = ";P_Z_CN;", A = ";P_A_CN
    
          Select Case Emode
            Case 0
              Print #f," at E* = ";P_E_exc;" MeV above the outer saddle"
              Print #f,"   (E* = ";Eabsgs;" MeV above the ground state)."
              Print #f," Spin = ";Spin_CN
            Case 1
              Print #f," at E* = ";P_E_exc;" MeV above the ground state."
              Print #f," Spin = ";Spin_CN
            Case -1
              Print #f," at E* = ";P_E_exc;" MeV above the ground state."
              Print #f," Spin = ";Spin_CN
              Print #f," Only first-chance fission!"
            Case 2
              Print #f," formed by (n,f) with En = ";P_E_exc- E_EXC_ISO;" MeV."
              Print #f," Spin of target nucleus = ";Spin_target
              Print #f," rms spin of commpound nucleus = ";Spin_CN;"."
            Case 12
              Print #f," formed by (p,f) with Ep = ";P_E_exc- E_EXC_ISO;" MeV."
              Print #f," Spin of target nucleus = ";Spin_target    
              Print #f," rms spin of commpound nucleus = ";Spin_CN
            Case 22
              Print #f," formed by (alpha,f) with Ealpha = ";P_E_exc- E_EXC_ISO;" MeV."
              Print #f," Spin of target nucleus = ";Spin_target    
              Print #f," rms spin of commpound nucleus = ";Spin_CN
            Case 3
              Print #f," with user-defined excitation-energy distribution"
              Print #f," from the file ";C_Espectrum;"."
              Print #f," Only first-chance fission."
              Print #f,"*","  E* (MeV)      Spin        Weight"
              For I = 1 To Ubound(E_spectrum)
                Print #f,"*", E_spectrum(I), L_spectrum(I), W_spectrum(I)
              Next I
          '   Print #f," Spin = ";Spin_CN
            Case 13
              Print #f," with user-defined excitation-energy distribution"
              Print #f," from the file ";C_Espectrum;"."
              Print #f," Multi-chance fission supported."
              Print #f,"*","  E* (MeV)      Spin        Weight"
              For I = 1 To Ubound(E_spectrum)
                Print #f,"*", E_spectrum(I), L_spectrum(I), W_spectrum(I)
              Next I
          '   Print #f," Spin = ";Spin_CN
          End Select
          If I_E_iso > 0 Then
            Print #f, " Isomer # ";I_E_iso;", at E* = ";E_EXC_ISO;" MeV" 
          End If   
    '     If clocal = "localon" Then
          If Ilocal = 1 Then
            Print #f, " Locally adjusted parameters used."
          Else
            Print #f, " Global parameter values used."
          End If
          If B_supp = 0 Then
            Print #f, "Influence of 3rd barrier omitted."
          End If
          Print #f, " Shell effect at symmetry Delta_S0 = ",Delta_S0
          If B_MyParameters Then
            If Fileexists("MyParameters.dat") Then
              Print #f, " Values of Parameters found in MyParameters.dat are replaced."
              Scope
                Dim As Integer fMyPar,Ileft,Iright
                Dim As String Cline
                FMyPar = FreeFile 
                Open "MyParameters.dat" For Input As #FMyPar 
                Do Until EOF(FMyPar)
                  Line Input #FMyPar,Cline
                  Do While Instr(Cline,"/"+"'") > 0   ' Remove limited comments
                    Cline = Trim(Cline)
                    Ileft = Instr(Cline,"/"+"'") 
                    Iright = Instr(Cline,"'"+"/")
                    If Ileft < Iright Then 
                      Cline = Mid(Cline,1,Ileft-1) + Mid(Cline,Iright+2)
                    End If      
                  Loop
                  Cline = Trim(Cline)
                  If Instr(Cline,"'") > 0 Then    ' Remove text after comment sign
                    Cline = Mid(Cline,1,Instr(Cline,"'")-1)
                    Cline = Trim(Cline)
                  End If 
                  If Cline <> "" Then Print #f,Cline
                Loop  
                Close #FMyPar
              End Scope  
            End If
          End If      
          If EOscale <> 1 Then
            Print #f, " Even-odd effect at scission scaled with a factor ";Eoscale;"."
          End If
          If D_Par_Fac <> 1 Then
            Print #f, " Variation of perturbed parameters scaled by a factor ";D_Par_Fac;"."
          End If
    
          If Bmulti = 1 And Imulti = 0 Then
            Print #f, " "
            Print #f, "******************************************************************"
            Print #f, " Due to low fission probability, the fission chances could not be determined."
            Print #f, " Therefore, only first-chance fission is calculated!"
            Print #f, " (The validity of this assumption should be checked.)"
            Print #f, "******************************************************************"
          End If
          If EMode = 3 Then
            If I_Warning = 1 Then
              Print #f, " "
              Print #f, "****************************************************************"
              Print #f, "Note: Only first-chance fission is calculated "
              Print #f, "      when an excitation-energy distribution is given on input."
              Print #f, "****************************************************************"
            End If
          End If
       
          If Bcov or Bcor Then
            Print #f," "
            Print #f,"The program ReadCorr may be used to convert the output of"
            Print #f,"the covariance and correlation matrices in this file into"
            Print #f,"a simpler format!"
          End If   
    
          Print #f,"  </Title>"
       
          Print #f,"  <Prompt_results>"
       
     '    If Bmulti = 1 Then

          Print #f,"    <Non-fission_results>"
                Scope
                  Dim As Double Rnorm_N,Rnorm_P
                  Rnorm_N = 0
                  For J = 0 To Ubound(NNCNtot)
                    Rnorm_N = Rnorm_N + NNCNtot(J)
                  Next J 
                  Rnorm_P = 0 
                  For J = 0 To Ubound(NPCNtot)
                    Rnorm_P = Rnorm_P + NPCNtot(J)
                  Next J 
                  If Rnorm_N > 0 Then 
                    For J = 0 To Ubound(NNCNtot)
                      NNCNtot(J) = NNCNtot(J) / Rnorm_N
                    Next J
                    Print #f," "
                    Print #f,"Probabilities of the number of neutrons emitted from 1. minimum"
                    Print #f," (only non-fission events):"
                    Print #f,"Number of neutrons        Probability (values > 0)"
                    For J = 0 To Ubound(NNcntot,1)
                      If NNCNtot(J) > 0 Then
                        Print #f, J, ,Round(NNCNtot(J),3)
                      End If
                    Next J
                    Print #f," "
                  End If
                  If Rnorm_P > 0 Then
                    For J = 0 To Ubound(NPCNtot)
                      NPCNtot(J) = NPCNtot(J) / Rnorm_P
                    Next J
                    If NPCNtot(0) < 1 Then
                      Print #f," "
                      Print #f,"Probabilities of the number of protons emitted from 1. minimum"
                      Print #f," (only non-fission events):"
                      Print #f,"Number of protons        Probability (values > 0)"
                      For J = 0 To Ubound(NPcntot,1)
                        If NPCNtot(J) > 0 Then
                          Print #f,J, ,Round(NPCNtot(J),3)
                        End If
                      Next J
                      Print #f," "
                    End If  
                  End If
                End Scope       
          Print #f,"    </Non-fission_results>"
     
          Print #f, "    <P_fission>"
          Print #f, "--------------------------------------------------"
          Print #f, "--- Fission probability P_f (sum over all chances) ---"
          Print #f, "--------------------------------------------------"
          If Bmulti = 1 Then
            If Imulti > 0 Then
              Print #f, "P_f ="; Imulti ;"(fission events) /"; N_multi_sample ; _
                    "(all events) ="; Imulti/N_multi_sample 
            Else
              Print #f, " P_f smaller than";1.0 / N_multi_sample
            End If
            If Emode = 13 Then
              Scope
                Dim As Single Pfis_local,DPfisrel_local
                Print #f," "
                Print #f,"Energy-dependent fission probability for E* distribution from file"
                Print #f," "
                Print #f,"E*/MeV   Calculated events   Fission events   P_f   Statistical uncertainty (%)"
                For I = 1 To Ichannel
                  Pfis_local = Csng(NE_fis(I))/Csng(NE_all(I))
                  DPfisrel_local = 100.0 * sqr( (1.0 / Csng(NE_fis(I))) + _
                                          (1.0 / Csng(NE_all(I))) )
                  Print #f,E_spectrum(I),NE_all(I),NE_fis(I),Round(Pfis_local,3),Round(DPfisrel_local,3)
                Next I
              End Scope 
            End If
          Else
            Print #f, "P_f was not calculated." 
            Print #f, "('GS' option provides P_f above E* = 2 MeV.)"
          End If
          If C_pfis <> "" Then
            Print #f," "
            Print #f,"Related information:"
            Print #f,"===================="
            Print #f,"The probabilities for first-chance fission and the emission"
            Print #f,"of gammas and neutrons for E* >= 3 MeV can be found in the files"
            Print #f,C_pfis;" (for the specific angular momentum) and"
            Print #f,C_pfis2;" (for a statistical angular-momentum distribution)."
          End If
          Print #f, "    </P_fission>"
       
          If Inofirst = 0 Then
            Print #f, "    <Multi_chance>" 
            Print #f, "Probability of first-chance fission: 100%." 
            Print #f, "    </Multi_chance>"
          End If
       
          If Inofirst > 0 Then
            Print #f, "    <Multi_chance>"  
            If Emode = 2 Then
              Print #f, "Pre-compound neutron emission is considered."
            Else
              Print #f, "Calculation starts with the assumed formation of a compound nucleus." 
              Print #f, "(Pre-compound processes are not considered.)" 
            End If
            Print #f, "Fission after eventual emission of neutrons and protons"
            Print #f, "(multi-chance fission) is included."
            Print #f, " "
            Print #f, "---------------------------------------------------------------"
            Print #f, "--- Relative contributions of the different fission chances ---"
            Print #f, "---------------------------------------------------------------"
            Print #f, " "
            Print #f, " pre-saddle neutrons      protons      contribution" 
            For I = 0 To 10
              For J = 0 To 2
                If W_chances(I,J) > 0 Then
                  Print #f, "      ",I,J,W_chances(I,J)
                End If
              Next J  
            Next I 
            Print #f, " "
            Print #f, " "
            Dim As Integer Imax,Jmax,Kmin,Kmax
         
        /'  For J = 0 To 400
              Print Using "####.#";J*0.1;
              For I = 0 To 5
                Print Using " #.#####";E_multi_chance(I,J);
              Next
              Print " "
            Next'/ 
         
            For I = 0 To Ubound(E_multi_chance,1)
              For J = 0 To Ubound(E_multi_chance,2)
                For K = 0 To Ubound(E_multi_chance,3) 
                  If E_multi_chance(I,J,K) > 0 Then 
                    Imax = I
                    Nmax_multi_chance = I
                  End If
                Next    
              Next
            Next
            For J = 0 To Ubound(E_multi_chance,2) 
              For I = 0 To Ubound(E_multi_chance,1)
                For K = 0 To Ubound(E_multi_chance,3)
                  If E_multi_chance(I,J,K) > 0 Then 
                    Jmax = J
                    Pmax_multi_chance = J
                  End If 
                Next  
              Next
            Next
            For K = 0 To Ubound(E_multi_chance,3) 
              For I = 0 To Ubound(E_multi_chance,1) 
                For J = 0 To Ubound(E_multi_chance,2) 
                  If E_multi_chance(I,J,K) > 0 Then 
                    Kmax = K
                     Emax_multi_chance = K
                  End If  
                Next  
              Next
            Next
            For K = Ubound(E_multi_chance,3) To 0 Step -1 
              For I = 0 To Ubound(E_multi_chance,1) 
                For J = 0 To Ubound(E_multi_chance,2) 
                  If E_multi_chance(I,J,K) > 0 Then 
                    Kmin = K
                  End If  
                Next  
              Next
            Next
         
            If Imax > 0 Or Jmax > 0 Then
              Print #f, "--- Number of events with E* (normalized to all fission events) ---"
              Print #f, "(E* = excitation energy above nuclear ground state at fission)"
              Print #f, "Separately given for # of pre-saddle neutrons / protons"
              If Imax + Jmax > 11 Then
                Print #f, "Only 11 first chances given."
              End If
              Print #f, " "
              Print #f, " E*/MeV ";
              For I = 0 To Min(10,Imax)
                For J = 0 To Min(2,Jmax)
                  If I + J <= 10 Then
                    Print #f, "  ";I;" /";J;"   ";
                  End If  
                Next  
              Next
              Print #f, " "
              For K = Kmin To Kmax
                Print #f, Using "####.#";K * 0.1;" ";
                For I = 0 To Min(10,Imax)
                  For J = 0 To Min(2,Jmax)
                    If I + J <= 10 Then
                      Print #f, Using "    #.#####";E_multi_chance(I,J,K);
                    End If   
                  Next  
                Next  
                Print #f, " "
              Next
              Print #f, " "
              Print #f, " "
              Print #f, "The energies of the pre-saddle neutrons are included in the"
              Print #f, "list-mode output file, if the list-mode option is activated."
            End If
            Print #f, "    </Multi_chance>"  
          End If
    
          If Emode < 3 And Inofirst = 0 Then
            Print #f,"    <Fission_channels>"
         
            Print #f,"----------------------------------------------------------"
            Print #f,"--- Relative yields of fission channels (exact values) ---"
            Print #f,"----------------------------------------------------------"
            Print #f," "
            Print #f,"Yield of SL (super long) Channel = ", 100*Round(Yield_Mode_0,4) ;" %"         /' Relative yield of SL '/
            Print #f,"Yield of S1 (standard I) Channel = ", 100*Round(Yield_Mode_1,4) ;" %"         /' Relative yield of S1 '/
            Print #f,"Yield of S2 (standard II) Channel = ", 100*Round(Yield_Mode_2,4) ;" %"        /' Relative yield of S2 '/
            Print #f,"Yield of SA (superasymmetric) Channel = ", 100*Round(Yield_Mode_3,4) ;" %"    /' Relative yield of S3 '/
            Print #f,"Yield of Channel near Z=82 = ", 100*Round(Yield_Mode_4,4) ;" %"    /' Relative yield of S4 '/
            Print #f,"Yield of channel near Z=38 = "," ", 100*Round(Yield_Mode_5,4) ;" %"                /' Relative yield of S5 '/
            Print #f,"Yield of S1 Channel in both fragments = ", 100*Round(Yield_Mode_11,4) ;" %"   /' Relative yield of S11 '/
            Print #f,"Yield of S2 Channel in both fragments = ", 100*Round(Yield_Mode_22,4) ;" %"   /' Relative yield of S22 '/
        
            If I_Mode_selected > -1 Then
              Print #f," "
              Print #f,"The following calculations are restricted to the contribution of the selected fission channel "; _
                     Trim(Str(I_Mode_selected));"!"
            End If           
    
            Print #f,"    </Fission_channels>"
          End If
            Print #f,"    <Fission_channels_MC>"
    
            Print #f,"------------------------------------------------------------------"
            Print #f,"--- Relative yields of fission channels (Monte-Carlo sampling) ---"
            Print #f,"------------------------------------------------------------------"
            Print #f," "
            Print #f,"Yield of SL (super long) Channel = ", 100*Round(Mode_Events(0)/Mode_Events(10),4) ;" %"         /' Relative yield of SL '/
            Print #f,"Yield of S1 (standard I) Channel = ", 100*Round(Mode_Events(1)/Mode_Events(10),4) ;" %"         /' Relative yield of S1 '/
            Print #f,"Yield of S2 (standard II) Channel = ", 100*Round(Mode_Events(2)/Mode_Events(10),4) ;" %"        /' Relative yield of S2 '/
            Print #f,"Yield of SA (superasymmetric) Channel = ", 100*Round(Mode_Events(3)/Mode_Events(10),4) ;" %"    /' Relative yield of S3 '/
            If P_A_CN < 220 And Mode_Events(4) > 0 Then _
              Print #f,"Yield of channel near Z=82 = "," ", 100*Round(Mode_Events(4)/Mode_Events(10),4) ;" %"                /' Relative yield of S4 '/
            If Mode_Events(5) > 0 Then _
              Print #f,"Yield of channel near Z=38 = "," ", 100*Round(Mode_Events(5)/Mode_Events(10),4) ;" %"                /' Relative yield of S4 '/
            If Mode_Events(6) > 0 Then _
              Print #f,"Yield of S1 Channel in both fragments = ", 100*Round(Mode_Events(6)/Mode_Events(10),4) ;" %"   /' Relative yield of S11 '/
            If Mode_Events(7) > 0 Then _
              Print #f,"Yield of S2 Channel in both fragments = ", 100*Round(Mode_Events(7)/Mode_Events(10),4) ;" %"   /' Relative yield of S22 '/
    
            If I_Mode_selected > -1 Then
              Print #f," "
              Print #f,"The following calculations are restricted to the contribution of the selected fission channel "; _
                     Trim(Str(I_Mode_selected));"!"
            End If         
    
            Print #f,"    </Fission_channels_MC>"
         
    
    
          Dim As Single Dplus,Dminus
       
          Scope
            Dim As Single YZeven,YZodd
    
            Print #f,"    <FF>"  
            Print #f,"      <FF_Z>"
            Print #f,"        <Element_yields>"
            Print #f,"----------------------------------"
            Print #f,"--- Element-yield distribution ---"
            Print #f,"----------------------------------"
            Print #f," "
            If B_Error_On = 1 And B_Error_Analysis = 0 Then
              Print #f,"  Z         Yield          Uncertainty(+-)"
            Else
              Print #f,"  Z         Yield"
            End If  
            Print #f," "
            For I = 20 To 70
              If ZPost(I) > 0 Then
                If B_Error_On = 1 And B_Error_Analysis = 0 Then
                  Dplus = d_ZPost(0,I) 
                  Dminus = -d_ZPost(0,I)
                  Print #f,Using "####    ###.#####   &###.#####   &###.#####";I;ZPost(I);"  ";Dplus;" ";Dminus
                Else   
                  Print #f,Using "####    ###.#####";I;ZPOST(I)
           	    End If
              End If    
            Next I
            Print #f,"        </Element_yields>"
       
            YZeven = 0
            YZodd = 0
            For I = 20 To 70 Step 2
              YZeven = YZeven + ZPost(I)
            Next
            For I = 21 To 69 Step 2
              YZodd = YZodd + ZPost(I)
            Next 
            Print #f,"        <Z_even_odd>"
            ZEO_GEF = (YZeven-YZodd) / (YZeven + YZodd) * 100  ' in percent
            Print #f,"Global even-odd effect in Z yields: "; Round(ZEO_GEF,3);" %"
            Print #f,"        </Z_even_odd>"
        
        
            If B_Error_On = 1 And B_Error_Analysis = 0 Then    
              Dim As Integer Inl
              If Bcov = 1 Then
                Print #f,"        <Z_covariances>"
                Print #f,"--- Covariance matrix of Z yields ---"
                Print #f," "
                Print #f,"  Header for loop structure: (For Z1 =";Zmin;" to";Zmax;") (For Z2 =";Zmin;" to";Zmax;")" 
                Print #f," "
                Inl = 0  
                For I = Zmin To Zmax 
                  For J = Zmin To Zmax
                    Inl = Inl + 1
                    Print #f, Round(SZCovar(I,J).Rval,4);" ";
                    If Inl = 20 Then
                      Inl = 0
                      Print #f," "
                    End If  
                  Next J
                Next I
                Print #f," "
                Print #f,"        </Z_covariances>"
              End If
              If Bcor = 1 Then  
                Print #f,"        <Z_correlations>"
                Print #f,"--- Corrrelation matrix of Z yields ---"
                Print #f," "
                Print #f,"  Header for loop structure: (For Z1 =";Zmin;" to";Zmax;") (For Z2 =";Zmin;" to";Zmax;")" 
                Print #f," "
                Inl = 0  
                For I = Zmin To Zmax 
                  For J = Zmin To Zmax
                    Inl = Inl + 1
                    Print #f, Round(SZCorr(I,J).Rval,4);" ";
                    If Inl = 20 Then
                      Inl = 0
                      Print #f," "
                    End If  
                  Next J
                Next I
                Print #f," "
                Print #f,"        </Z_correlations>"
              End If  
         
              If B_Double_Covar = 1 And I_Double_Covar = 2 Then
                If Bcov = 1 Then
                  Print #f,"        <Z_covariances_2_systems>"
                  Print #f,"--- Covariance matrix of Z yields for the two fissioning systems ---"
                  Print #f," "
                  Print #f,"  Header for loop structure: (For Z1 (first system) =";Z_Double_min;" to";Z_Double_max; _
                           ") (For Z2 (second system) =";Z_Double_min;" to";Z_Double_max;")" 
                  Print #f," "
                  Dim As Integer Inl 
                  Inl = 0  
                  For I = Z_Double_min To Z_Double_max 
                    For J = Z_Double_min To Z_Double_max
                      Inl = Inl + 1
                      Print #f, Round(SZ_Double_Covar(I,J).Rval,4);" "; 
                      If Inl = 20 Then
                        Inl = 0
                        Print #f," "
                      End If  
                    Next J
                  Next I
                  Print #f," "
                  Print #f,"        </Z_covariances_2_systems>"
                End If
                If Bcor = 1 Then  
                  Print #f,"        <Z_correlations_2_systems>"
                  Print #f,"--- Correlation matrix of Z yields for the two fissioning systems ---"
                  Print #f," "
                  Print #f,"  Header for loop structure: (For Z1 (first system) =";Z_Double_min;" to";Z_Double_max; _
                            ") (For Z2 (second system) =";Z_Double_min;" to";Z_Double_max;")" 
                  Print #f," "
                  Inl = 0  
                  For I = Z_Double_min To Z_Double_max 
                    For J = Z_Double_min To Z_Double_max
                      Inl = Inl + 1
                      Print #f, Round(SZ_Double_Corr(I,J).Rval,4);" "; 
                      If Inl = 20 Then
                        Inl = 0
                        Print #f," "
                      End If  
                    Next J
                  Next I
                  Print #f," "
                  Print #f,"        </Z_correlations_2_systems>"
                End If
              End If  
            End If  
            Print #f,"      </FF_Z>"     
       
            Dim As Single NYsum,Ysum,NoverZ
            Print #f,"      <N_over_Z>"
            Print #f,"--------------------------------------------------------"
            Print #f,"--- N_mean/Z over Z (before prompt-neutron emission) ---"
            Print #f,"--------------------------------------------------------"
            Print #f," "
            Print #f,"  Z         N_mean/Z (pre-neutron)"
            For I = 20 To P_Z_CN - 20
              Nysum = 0
              Ysum = 0
              If ZPost(I) > 0 Then
                For J = 30 to 120
                  Nysum = Nysum + J * NZpre(J,I)
                  Ysum = Ysum + NZpre(J,I)
                Next J  
                NoverZ = (Nysum/Ysum) / I
                Print #f, I, NoverZ
              End If
            Next I        
    
       
            Print #f," "
            Print #f," "
            Print #f,"-------------------------------------------------------"
            Print #f,"--- N_mean/Z over Z (after prompt-neutron emission) ---"
            Print #f,"-------------------------------------------------------"
            Print #f," "
            Print #f,"  Z         N_mean/Z (post-neutron)"
            For I = 20 To P_Z_CN - 20   ' I is Z
              Nysum = 0
              Ysum = 0
              If ZPost(I) > 0 Then
                 For J = 30 to 120     ' J is N
                   Nysum = Nysum + J * NZpost(J,I)
                   Ysum = Ysum + NZpost(J,I)
                 Next J  
                 NoverZ = (Nysum/Ysum) / I
                 Print #f, I, NoverZ
              End If
            Next    
            Print #f,"      </N_over_Z>"    
    
       
          End Scope
       
          Print #f,"      <FF_N>"
          Print #f,"        <Isotonic_yields>"
          Print #f,"----------------------------------------------------------------------------"
          Print #f,"--- Isotonic yield distribution before and after prompt-neutron emission ---"
          Print #f,"----------------------------------------------------------------------------"
          Print #f," "
          Print #f,"  N         Yield(pre-neutron)     Yield(post-neutron)"
          Print #f," "
          For I = 20 To 120
            If Npre(I) > 0 Or Npost(I) > 0 Then
    '         Print #f, I, Npre(I),, Npost(I)
              Print #f,Using "####         ###.#####              ###.#####";_
        	              I;NPre(I);NPost(I)        
            End If
          Next
          Print #f,"        </Isotonic_yields>"
          Print #f,"      </FF_N>"
    
          Print #f,"      <FF_A>"
          Print #f,"        <Mass_yields>"
          Print #f,"------------------------------------------------------------------------"
          Print #f,"--- Mass-yield distribution before and after prompt-neutron emission ---"
          Print #f,"------------------------------------------------------------------------"
          Print #f," "
          If B_Error_On = 1 And B_Error_Analysis = 0 Then
            Print #f,"  A"," Yield","    Yield","     Uncertainty(+-)"
          Else
            Print #f,"  A"," Yield","    Yield"
          End If  
          Print #f," "," pre-neutron","    post-neutron"
          Print #f," "
          For I = 20 To 190
            If APost(I) > 0 Or APre(I) > 0 Then 
              If B_Error_On = 1 And B_Error_Analysis = 0 Then
                Dplus = d_APost(0,I) 
                Dminus = -d_APost(0,I)
                Print #f,Using "####          ###.######       ###.######   &###.#####   &###.##### "; _
                       I;Apre(I);APost(I);"  ";Dplus;" ";Dminus
              Else
        	    Print #f,Using "####          ###.######       ###.######";_
        	              I;APre(I);APost(I)
              End If  
            End If  
          Next
          Print #f,"        </Mass_yields>"
    
    
          If B_Error_On = 1 And B_Error_Analysis = 0 Then   
            Dim As Integer Inl 
            If Bcov = 1 Then
              Print #f,"        <Apre_covariances>"
              Print #f,"--- Covariance matrix of A yields before prompt-neutron emission ---"
              Print #f," "
              Print #f,"  Header for loop structure: (For A1 =";Apremin;" to";Apremax; _
                                               ") (For A2 =";Apremin;" to";Apremax;")" 
              Print #f," "
              Inl = 0
              For I = Apremin To Apremax 
                For J = Apremin To Apremax
                  Print #f, Round(SApreCovar(I,J).Rval,4);" ";
                  Inl = Inl + 1
                  If Inl >= 20 Then
                    Inl = 0
                    Print #f, " "
                  End If
                Next
              Next
              Print #f," "
              Print #f,"        </Apre_covariances>"
            End If
            If BCor = 1 Then  
              Print #f,"        <Apre_correlations>"
              Print #f,"--- Correlation matrix of A yields before prompt-neutron emission ---"
              Print #f," "
              Print #f,"  Header for loop structure: (For A1 =";Apremin;" to";Apremax; _
                                               ") (For A2 =";Apremin;" to";Apremax;")" 
              Print #f," "
              Inl = 0
              For I = Apremin To Apremax 
                For J = Apremin To Apremax
                  Print #f, Round(SApreCorr(I,J).Rval,4);" ";
                  Inl = Inl + 1
                  If Inl >= 20 Then
                    Inl = 0
                    Print #f, " "
                  End If
                Next
              Next
              Print #f," "
              Print #f,"        </Apre_correlations>"
            End If
            If Bcov = 1 Then  
              Print #f,"        <Apost_covariances>"
              Print #f,"--- Covariance matrix of A yields after prompt-neutron emission ---"
              Print #f," "
              Print #f,"  Header for loop structure: (For A1 =";Apostmin;" to";Apostmax; _
                                               ") (For A2 =";Apostmin;" to";Apostmax;")" 
              Print #f," "
              Inl = 0
              For I = Apremin To Apremax 
                For J = Apremin To Apremax
                  Inl = Inl + 1
                  Print #f, Round(SApostCovar(I,J).Rval,4);" ";
                  If Inl >= 20 Then
                    Inl = 0
                    Print #f," "
                  End If  
                Next
              Next 
              Print #f," "
              Print #f,"        </Apost_covariances>"
            End If
            If Bcor = 1 Then       
              Print #f,"        <Apost_correlations>"
              Print #f,"--- Correlation matrix of A yields after prompt-neutron emission ---"
              Print #f," "
              Print #f,"  Header for loop structure: (For A1 =";Apostmin;" to";Apostmax; _
                                               ") (For A2 =";Apostmin;" to";Apostmax;")" 
              Print #f," "
              Inl = 0
              For I = Apremin To Apremax 
                For J = Apremin To Apremax
                  Inl = Inl + 1
                  Print #f, Round(SApostCorr(I,J).Rval,4);" ";
                  If Inl >= 20 Then
                    Inl = 0
                    Print #f," "
                  End If  
                Next
              Next
              Print #f," "
              Print #f,"        </Apost_correlations>"
            End If
         
            If B_Double_Covar = 1 And I_Double_Covar = 2 Then
              If Bcov = 1 Then
                Print #f," "
                Print #f,"        <Apre_covariances_2_systems>"
                Print #f,"--- Covariance matrix of A yields before neutron emission for the two fissioning systems ---"
                Print #f," "
                Print #f,"  Header for loop structure: (For A1 (first system) =";Apre_Double_min;" to";Apre_Double_max; _
                            ") (For A2 (second system) =";Apre_Double_min;" to";Apre_Double_max;")" 
                Print #f," "
                Dim As Integer Inl 
                Inl = 0  
                For I = Apre_Double_min To Apre_Double_max 
                  For J = Apre_Double_min To Apre_Double_max
                    Inl = Inl + 1
                    Print #f, Round(SApre_Double_Covar(I,J).Rval,4);" "; 
                    If Inl = 20 Then
                      Inl = 0
                      Print #f," "
                    End If  
                  Next
                Next
                Print #f," "
                Print #f,"        </Apre_covariances_2_systems>"
              End If
              If Bcor = 1 Then  
                Print #f,"        <Apre_correlations_2_systems>"
                Print #f,"--- Correlation matrix of A yields before neutron emission for the two fissioning systems ---"
                Print #f," "
                Print #f,"  Header for loop structure: (For A1 (first system) =";Apre_Double_min;" to";Apre_Double_max; _
                            ") (For A2 (second system) =";Apre_Double_min;" to";Apre_Double_max;")" 
                Print #f," "
                Inl = 0  
                For I = Apre_Double_min To Apre_Double_max 
                  For J = Apre_Double_min To Apre_Double_max
                    Inl = Inl + 1
                    Print #f, Round(SApre_Double_Corr(I,J).Rval,4);" "; 
                    If Inl = 20 Then
                      Inl = 0
                      Print #f," "
                    End If  
                  Next
                Next
                Print #f," "
                Print #f,"        </Apre_correlations_2_systems>"
              End If         
              If Bcov = 1 Then
                Print #f,"        <Apost_covariances_2_systems>"
                Print #f,"--- Covariance matrix of A yields after neutron emission for the two fissioning systems ---"
                Print #f," "
                Print #f,"  Header for loop structure: (For A1 (first system) =";Apost_Double_min;" to";Apost_Double_max; _
                            ") (For A2 (second system) =";Apost_Double_min;" to";Apost_Double_max;")" 
                Print #f," "
                Inl = 0  
                For I = Apost_Double_min To Apost_Double_max 
                  For J = Apost_Double_min To Apost_Double_max
                    Inl = Inl + 1
                    Print #f, Round(SApost_Double_Covar(I,J).Rval,4);" "; 
                    If Inl = 20 Then
                      Inl = 0
                      Print #f," "
                    End If  
                  Next
                Next  
                Print #f," "
                Print #f,"        </Apost_covariances_2_systems>"
              End If
              If Bcor = 1 Then
                Print #f,"        <Apost_correlations_2_systems>"
                Print #f," "
                Print #f,"--- Correlation matrix of A yields after neutron emission for the two fissioning systems ---"
                Print #f," "
                Print #f,"  Header for loop structure: (For A1 (first system) =";Apost_Double_min;" to";Apost_Double_max; _
                          ") (For A2 (second system) =";Apost_Double_min;" to";Apost_Double_max;")" 
                Print #f," "
                Inl = 0  
                For I = Apost_Double_min To Apost_Double_max 
                  For J = Apost_Double_min To Apost_Double_max
                    Inl = Inl + 1
                    Print #f, Round(SApost_Double_Corr(I,J).Rval,4);" "; 
                    If Inl = 20 Then
                      Inl = 0
                      Print #f," "
                    End If  
                  Next
                Next
                Print #f," "       
                Print #f,"        </Apost_correlations_2_systems>"
              End If       
            End If
          End If  
          Print #f,"      </FF_A>"    
    
    
          Dim As Single RS,RS0,RS1,RS2,RZUCD
    
          /' Normalization to 200 % '/
          RS0 = 0
          For I = 1 To 300
            For J = 1 To 100
              RS0 = RS0 + ZISOPRE(I,J)
            Next
          Next
          IF RS0 > 0 Then
            For I = Lbound(_ZISOPRE,1) To Ubound(_ZISOPRE,1)
              For J = Lbound(_ZISOPRE,2) To Ubound(_ZISOPRE,2)
                RS = ZISOPRE(I,J) / RS0 * 200.E0 * P_selected  
                  ' P_selected: Scaling with the yield of the selected fission channel
                _ZISOPRE(I,J) = RS
              Next
            Next
          EndIf
    
       /' Charge polarization '/
          For I = 1 To 300  /' Loop over masses '/
            RS0 = 0
            RS1 = 0
            For J = 1 To 100   /' Loop over Z '/
              RS0 = RS0 + ZISOPRE(I,J)
              RS1 = RS1 + J * ZISOPRE(I,J)
            Next
            RZUCD = I / P_A_CN * P_Z_CN
            IF RS0 > 0 Then
              RS = RS1 / RS0 - RZUCD
              ZPOLARPRE(I) = RS
            EndIf
          Next
    
       /' Width of isobaric charge distribution'/
          For I = 1 To 300
            RS0 = 0
            RS2 = 0
            RZUCD = I / P_A_CN * P_Z_CN
            For J = 1 To 100
              RS0 = RS0 + ZISOPRE(I,J)
              RS2 = RS2 + (J - ZPOLARPRE(I) - RZUCD)^2 * ZISOPRE(I,J)
            Next
            IF RS0 > 0 Then
              RS = RS2 / RS0
              SIGMAZPRE(I) = sqr(RS)
            EndIf
          Next
    
    
       /' Normalization to 200 % '/
          RS0 = 0
          For I = 1 To 300
            For J = 1 To 100
              RS0 = RS0 + ZISOPOST(I,J)
            Next
          Next
          IF RS0 > 0 Then
            For I = Lbound(_ZISOPOST,1) To Ubound(_ZISOPOST,1)
              For J = Lbound(_ZISOPOST,2) To Ubound(_ZISOPOST,2)
                RS = ZISOPOST(I,J) / RS0 * 200.E0 * P_selected
                _ZISOPOST(I,J) = RS
              Next
            Next
          EndIf
    
    
       /' Charge polarization '/
          For I = 1 To 300  /' Loop over masses '/
            RS0 = 0
            RS1 = 0
            For J = 1 To 100   /' Loop over Z'/
              RS0 = RS0 + ZISOPOST(I,J)
              RS1 = RS1 + J * ZISOPOST(I,J)
            Next
            RZUCD = I / P_A_CN * P_Z_CN
            IF RS0 > 0 Then
              RS = RS1 / RS0 - RZUCD
              ZPOLARPOST(I) = RS
            EndIf
          Next
    
       /' Width of isobaric charge distribution'/
          For I = 1 To 300
            RS0 = 0
            RS2 = 0
            RZUCD = I / P_A_CN * P_Z_CN
            For J = 1 To 100
              RS0 = RS0 + ZISOPOST(I,J)
              RS2 = RS2 + (J - ZPOLARPOST(I) - RZUCD)^2 * ZISOPOST(I,J)
            Next
            IF RS0 > 0 Then
              RS = RS2 / RS0
              SIGMAZPOST(I) = sqr(RS)
            EndIf
          Next
    
          Dim As Single RL(5)
          Dim As Single REO
          Dim As Single SumEven,SumOdd
          Dim As Single EvenOdd
          SumEven = 0
          SumOdd = 0
       /' Local even-odd effect '/
          For I = 9 To 84
            For J = 1 To 5
              RL(J) = ZPOST(I+J)
              If RL(J) = 0 Then GOTO NEXTIP
              RL(J) = LOG(RL(J))
            Next
            REO = 0.125E0 * (-1)^(I+J+1) * (RL(1) - 3.E0*RL(2) + 3.E0*RL(3) - RL(4))
            DPLOCAL(I+2) = REO
    NEXTIP:
            If I Mod 2 = 0 Then
              SumEven = SumEven + ZPost(I)
            Else
              SumOdd = SumOdd + ZPost(I)
            EndIf
          Next
          EvenOdd = (SumEven-SumOdd) / (SumEven+SumOdd)
    
          For I = 9 To 150
            For J = 1 To 5
              RL(J) = NPOST(I+J)
              If RL(J) = 0 Then GOTO NEXTIN
              RL(J) = LOG(RL(J))
            Next
            REO = 0.125E0 * (-1)^(I+J+1) * (RL(1) - 3.E0*RL(2) + 3.E0*RL(3) - RL(4))
            DNLOCAL(I+2) = REO
    NEXTIN:
          Next
        
          Dim As Integer Ilast  ' For inserting blank line between different Z
          Print #f,"      <FF_AZ>"
          Print #f,"        <Independent_yields>"
          Print #f,"------------------------------------------------------------------------------"
          Print #f,"--- Independent nuclide yields before and after prompt-neutron emission ---"
          Print #f,"------------------------------------------------------------------------------"
          Print #f,"    (Isomeric ratios are given in another table below -> 'FF_spin -> Isomeric_yields'.)"
          Print #f," "
          If B_Error_On = 1 And B_Error_Analysis = 0 Then
            Print #f,"  A    Z        Yield              Yield          Uncertainty(+-)"
          Else
            Print #f,"  A    Z        Yield              Yield"
          End If     
          Print #f,"                pre-neutron        post-neutron"
          For I = 20 To P_A_CN - 20
            For J = 10 To P_Z_CN - 10
              If ZISOPRE(I,J) > 0 Or ZISOPOST(I,J) > 0 Then
           	    If I > Ilast Then
           	      Print #f," "
                  Ilast = I
         	    End If
         	    If B_Error_On = 1 And B_Error_Analysis = 0 Then
         	      Dplus = d_ZISOPOST(0,I,J)   
         	      Dminus = -d_ZISOPOST(0,I,J)
         	      Print #f,Using "####  ###     ###.######         ###.######   &###.######  &###.######";_
         	         I;J;ZISOPRE(I,J);ZISOPOST(I,J);"  ";Dplus;" ";Dminus
                Else
         	      Print #f,Using "####  ###     ###.######         ###.######";_
         	           I;J;ZISOPRE(I,J);ZISOPOST(I,J)
         	    End If  
         	  End If
            Next
          Next
       
    '     For I = 10 To P_Z_CN - 10
    '       For J = 10 To P_A_CN - P_Z_CN - 10
    '         If NZpre(J,I) > 0 Then
    '           Print #f, I, I+J, NZpre(J,I) * 100 / 1.E5
    '         End If 
    '       Next J  
    '     Next I   
       
          Print #f,"        </Independent_yields>"
    
          Dim As Integer Inewline 
          Inewline = 0
          Dim As Single Rout
          If B_Error_On = 1 And B_Error_Analysis = 0 Then    
            If Bcov = 1 Then
              Print #f,"        <ZApre_covariances>"
              Print #f,"--- Covariance matrix of independent yields before prompt-neutron emission ---"
              Print #f," "
              Print #f,"  Key table of Amin and Amax values: (Z,Amin(Z),Amax(Z))"                                     
              For I = Zmin to Zmax
                If VAprelim(I,2) > 0 Then _
                  Print #f, I;" ";VAprelim(I,1);" ";VAprelim(I,2)
              Next                                     
              Print #f," "                                      
              Print #f,"  Header for loop structure: (For Z1 =";Zmin;" to";Zmax; _
                                                ") (For A1 = Amin(Z1) to Amax(Z1)"; _
                                                ") (For Z2 =";Zmin;" to";Zmax; _
                                                ") (For A2 = Amin(Z2) to Amax(Z2))"
              Print #f," "
              Print #f,"The data are written according to the loop structure specified above."
              Print #f,"The last loop is the inner-most one."
              Print #f,"A line break is inserted with a new Z2 value."
              Print #f," "
              Inewline = 0
              For I = Zmin To Zmax 
                For J = VAprelim(I,1) To VAprelim(I,2)
                  For K = Zmin To Zmax
                    For L = VAprelim(K,1) To VAprelim(K,2)
                      Rout = SZApreCovar(I,J-VAprelim(I,1)+1,K,L-VAprelim(K,1)+1).Rval
                   /' Inewline = Inewline + Len(Str(Round(Rout,4))) + 1
                      If Inewline >= 500 Then
                        Print #f, " "
                        Inewline = 0
                      End If '/
                      Print #f,Trim(Str(Round(Rout,4)));" ";
                    Next
                  Next    
                  Print #f, " "
                Next
              Next
              Print #f," "
              Print #f,"        </ZApre_covariances>"
            End If
            If Bcor = 1 Then
              Print #f,"        <ZApre_correlations>"
              Print #f,"--- Correlation matrix of independent yields before prompt-neutron emission ---"
              Print #f," "
              Print #f,"  Key table of Amin and Amax values: (Z,Amin(Z),Amax(Z))"                                     
              For I = Zmin to Zmax
                If VAprelim(I,2) > 0 Then _
                  Print #f, I;" ";VAprelim(I,1);" ";VAprelim(I,2)
                Next                                     
              Print #f," "                                      
              Print #f,"  Header for loop structure: (For Z1 =";Zmin;" to";Zmax; _
                                                ") (For A1 = Amin(Z1) to Amax(Z1)"; _
                                                ") (For Z2 =";Zmin;" to";Zmax; _
                                                ") (For A2 = Amin(Z2) to Amax(Z2))"
              Print #f," "
              Print #f,"The data are written according to the loop structure specified above."
              Print #f,"The last loop is the inner-most one."
              Print #f,"A line break is inserted with a new Z2 value."
              Print #f," "
              Inewline = 0
              For I = Zmin To Zmax 
                For J = VAprelim(I,1) To VAprelim(I,2)
                  For K = Zmin To Zmax
                    For L = VAprelim(K,1) To VAprelim(K,2)
                      Rout = SZApreCorr(I,J-VAprelim(I,1)+1,K,L-VAprelim(K,1)+1).Rval
                   /' Inewline = Inewline + Len(Str(Round(Rout,4))) + 1
                      If Inewline >= 500 Then
                        Print #f, " "
                        Inewline = 0
                      End If '/
                      Print #f,Trim(Str(Round(Rout,4)));" ";
                    Next
                  Next    
                  Print #f, " "
                Next
              Next
              Print #f," "
              Print #f,"        </ZApre_correlations>"
            End If
            If Bcov = 1 Then  
              Print #f,"        <ZApost_covariances>"
              Print #f,"--- Covariance matrix of independent yields after prompt-neutron emission ---"
              Print #f," "
              Print #f,"  Key table of Amin and Amax values: (Z,Amin(Z),Amax(Z))"                                     
              For I = Zmin to Zmax
                If VApostlim(I,2) > 0 Then _
                  Print #f, I;" ";VApostlim(I,1);" ";VApostlim(I,2)
                Next                                     
              Print #f," "                                      
              Print #f,"  Header for loop structure: (For Z1 =";Zmin;" to";Zmax; _
                                                  ") (For A1 = Amin(Z1) to Amax(Z1)"; _
                                                ") (For Z2 =";Zmin;" to";Zmax; _
                                                ") (For A2 = Amin(Z2) to Amax(Z2))"
              Print #f," "
              Print #f,"The data are written according to the loop structure specified above."
              Print #f,"The last loop is the inner-most one."
              Print #f,"A line break is inserted with a new Z2 value."
              Print #f," "
              Inewline = 0
              For I = Zmin To Zmax 
                For J = VApostlim(I,1) To VApostlim(I,2)
                  For K = Zmin To Zmax
                    For L = VApostlim(K,1) To VApostlim(K,2)
                      Rout = SZApostCovar(I,J-VApostlim(I,1)+1,K,L-VApostlim(K,1)+1).Rval
                   /' Inewline = Inewline + Len(Str(Round(Rout,4))) + 1
                      If Inewline >= 500 Then
                        Print #f, " "
                        Inewline = 0
                      End If '/
                      Print #f,Trim(Str(Round(Rout,4)));" ";
                    Next
                  Next    
                  Print #f, " "
                Next
              Next 
              Print #f," "
              Print #f,"        </ZApost_covariances>"
            End If  
            If Bcor = 1 Then  
              Print #f,"        <ZApost_correlations>"
              Print #f,"--- Correlation matrix of independent yields after prompt-neutron emission ---"
              Print #f," "
              Print #f,"  Key table of Amin and Amax values: (Z,Amin(Z),Amax(Z))"                                     
              For I = Zmin to Zmax
                If VApostlim(I,2) > 0 Then _
                  Print #f, I;" ";VApostlim(I,1);" ";VApostlim(I,2)
              Next                                     
              Print #f," "                                      
              Print #f,"  Header for loop structure: (For Z1 =";Zmin;" to";Zmax; _
                                                  ") (For A1 = Amin(Z1) to Amax(Z1)"; _
                                                  ") (For Z2 =";Zmin;" to";Zmax; _
                                                  ") (For A2 = Amin(Z2) to Amax(Z2))"
              Print #f," "
              Print #f,"The data are written according to the loop structure specified above."
              Print #f,"The last loop is the inner-most one."
              Print #f,"A line break is inserted with a new Z2 value."
              Print #f," "
              Inewline = 0
              For I = Zmin To Zmax 
                For J = VApostlim(I,1) To VApostlim(I,2)
                  For K = Zmin To Zmax
                    For L = VApostlim(K,1) To VApostlim(K,2)
                      Rout = SZApostCorr(I,J-VApostlim(I,1)+1,K,L-VApostlim(K,1)+1).Rval
                   /' Inewline = Inewline + Len(Str(Round(Rout,4))) + 1
                      If Inewline >= 500 Then
                        Print #f, " "
                        Inewline = 0
                      End If '/
                      Print #f,Trim(Str(Round(Rout,4)));" ";
                    Next
                  Next    
                  Print #f, " "
                Next
              Next 
              Print #f," "
              Print #f,"        </ZApost_correlations>"
            End If
          
            If B_Double_Covar = 1 And I_Double_Covar = 2 Then
              If Bcov = 1 Then
                Print #f,"        <ZApre_covariances_2_systems>"
                Print #f,"--- Covariance matrix of the nuclide pre-neutron yields for the two fissioning systems ---"
                Print #f," "     
                Print #f,"  Key table of Amin and Amax values: (Z,Amin(Z),Amax(Z))"                                     
                For I = Z_Double_min to Z_Double_max
                  If VApre_Double_lim(I,2) > 0 Then _
                    Print #f, I;" ";VApre_Double_lim(I,1);" ";VApre_Double_lim(I,2)
                Next                                     
                Print #f," "                                      
                Print #f,"  Header for loop structure: (For Z1 =";Z_Double_min;" to";Z_Double_max; _
                                                    ") (For A1 = Amin(Z1) to Amax(Z1)"; _
                                                    ") (For Z2 =";Z_Double_min;" to";Z_Double_max; _
                                                    ") (For A2 = Amin(Z2) to Amax(Z2))"
                Print #f," "
                Print #f,"The data are written according to the loop structure specified above."
                Print #f,"The last loop is the inner-most one."
                Print #f,"A line break is inserted with a new Z2 value."
                Print #f," "
                Inewline = 0
                For I = Z_Double_min To Z_Double_max 
                  For J = VApre_Double_lim(I,1) To VApre_Double_lim(I,2)
                    For K = Z_Double_min To Z_Double_max
                      For L = VApre_Double_lim(K,1) To VApre_Double_lim(K,2)
                        Rout = SZApre_Double_Covar(I,J-VApre_Double_lim(I,1)+1,K,L-VApre_Double_lim(K,1)+1).Rval
                     /' Inewline = Inewline + Len(Str(Round(Rout,4))) + 1
                        If Inewline >= 500 Then
                          Print #f, " "
                          Inewline = 0
                        End If '/
                        Print #f,Trim(Str(Round(Rout,4)));" ";
                      Next
                    Next    
                    Print #f, " "
                  Next
                Next 
                Print #f," "
                Print #f,"        </ZApre_covariances_2_systems>"
              End If
              If Bcor = 1 Then  
                Print #f,"        <ZApre_correlations_2_systems>"
                Print #f,"--- Correlation matrix of the nuclide pre-neutron yields for the two fissioning systems ---"
                Print #f," "     
                Print #f,"  Key table of Amin and Amax values: (Z,Amin(Z),Amax(Z))"                                     
                For I = Z_Double_min to Z_Double_max
                  If VApre_Double_lim(I,2) > 0 Then _
                   Print #f, I;" ";VApre_Double_lim(I,1);" ";VApre_Double_lim(I,2)
                Next                                     
                Print #f," "                                      
                Print #f,"  Header for loop structure: (For Z1 =";Z_Double_min;" to";Z_Double_max; _
                                                    ") (For A1 = Amin(Z1) to Amax(Z1)"; _
                                                    ") (For Z2 =";Z_Double_min;" to";Z_Double_max; _
                                                    ") (For A2 = Amin(Z2) to Amax(Z2))"
                Print #f," "
                Print #f,"The data are written according to the loop structure specified above."
                Print #f,"The last loop is the inner-most one."
                Print #f,"A line break is inserted with a new Z2 value."
                Print #f," "
                Inewline = 0
                For I = Z_Double_min To Z_Double_max 
                  For J = VApre_Double_lim(I,1) To VApre_Double_lim(I,2)
                    For K = Z_Double_min To Z_Double_max
                      For L = VApre_Double_lim(K,1) To VApre_Double_lim(K,2)
                        Rout = SZApre_Double_Corr(I,J-VApre_Double_lim(I,1)+1,K,L-VApre_Double_lim(K,1)+1).Rval
                     /' Inewline = Inewline + Len(Str(Round(Rout,4))) + 1
                        If Inewline >= 500 Then
                          Print #f, " "
                          Inewline = 0
                        End If '/
                        Print #f,Trim(Str(Round(Rout,4)));" ";
                      Next
                    Next    
                    Print #f, " "
                  Next
                Next 
                Print #f," "
                Print #f,"        </ZApre_correlations_2_systems>"
              End If
              If Bcov = 1 Then   
                Print #f,"        <ZApost_covariances_2_systems>"
                Print #f,"--- Covariance matrix of the nuclide post-neutron yields for the two fissioning systems ---"
                Print #f," "     
                Print #f,"  Key table of Amin and Amax values: (Z,Amin(Z),Amax(Z))"                                     
                For I = Z_Double_min to Z_Double_max
                  If VApost_Double_lim(I,2) > 0 Then _
                   Print #f, I;" ";VApost_Double_lim(I,1);" ";VApost_Double_lim(I,2)
                Next                                     
                Print #f," "                                      
                Print #f,"  Header for loop structure: (For Z1 =";Z_Double_min;" to";Z_Double_max; _
                                                    ") (For A1 = Amin(Z1) to Amax(Z2)"; _
                                                    ") (For Z2 =";Z_Double_min;" to";Z_Double_max; _
                                                    ") (For A2 = Amin(Z2) to Amax(Z2))"
                Print #f," "
                Print #f,"The data are written according to the loop structure specified above."
                Print #f,"The last loop is the inner-most one."
                Print #f,"A line break is inserted with a new Z2 value."
                Print #f," "
                Inewline = 0
                For I = Z_Double_min To Z_Double_max 
                  For J = VApost_Double_lim(I,1) To VApost_Double_lim(I,2)
                    For K = Z_Double_min To Z_Double_max
                      For L = VApost_Double_lim(K,1) To VApost_Double_lim(K,2)
                        Rout = SZApost_Double_Covar(I,J-VApost_Double_lim(I,1)+1,K,L-VApost_Double_lim(K,1)+1).Rval
                     /' Inewline = Inewline + Len(Str(Round(Rout,4))) + 1
                        If Inewline >= 500 Then
                          Print #f, " "
                          Inewline = 0
                        End If '/
                        Print #f,Trim(Str(Round(Rout,4)));" ";
                      Next
                    Next    
                    Print #f, " "
                  Next
                Next 
                Print #f," "
                Print #f,"        </ZApost_covariances_2_systems>"
              End If
              If Bcor = 1 Then  
                Print #f,"        <ZApost_correlations_2_systems>"
                Print #f,"--- Correlation matrix of the nuclide post-neutron yields for the two fissioning systems ---"
                Print #f," "     
                Print #f,"  Key table of Amin and Amax values: (Z,Amin(Z),Amax(Z))"                                     
                For I = Z_Double_min to Z_Double_max
                  If VApost_Double_lim(I,2) > 0 Then _
                    Print #f, I;" ";VApost_Double_lim(I,1);" ";VApost_Double_lim(I,2)
                Next                                     
                Print #f," "                                      
                Print #f,"  Header for loop structure: (For Z1 =";Z_Double_min;" to";Z_Double_max; _
                                                   ") (For A1 = Amin(Z1) to Amax(Z1)"; _
                                                   ") (For Z2 =";Z_Double_min;" to";Z_Double_max; _
                                                   ") (For A2 = Amin(Z2) to Amax(Z2))"
                Print #f," "
                Print #f,"The data are written according to the loop structure specified above."
                Print #f,"The last loop is the inner-most one."
                Print #f,"A line break is inserted with a new Z2 value."
                Print #f," "
                Inewline = 0
                For I = Z_Double_min To Z_Double_max 
                  For J = VApost_Double_lim(I,1) To VApost_Double_lim(I,2)
                    For K = Z_Double_min To Z_Double_max
                      For L = VApost_Double_lim(K,1) To VApost_Double_lim(K,2)
                        Rout = SZApost_Double_Corr(I,J-VApost_Double_lim(I,1)+1,K,L-VApost_Double_lim(K,1)+1).Rval
                     /' Inewline = Inewline + Len(Str(Round(Rout,4))) + 1
                        If Inewline >= 500 Then
                          Print #f, " "
                          Inewline = 0
                        End If '/
                        Print #f,Trim(Str(Round(Rout,4)));" ";
                      Next
                    Next    
                    Print #f, " "
                  Next
                Next 
             
               /'
              ' Testoutput
             
                Dim As Integer Ftest
                Ftest = freefile
                Open "Test" For Append As #Ftest  
                For I = Z_Double_min To Z_Double_max 
                  For J = VApost_Double_lim(I,1) To VApost_Double_lim(I,2)
                    For K = Z_Double_min To Z_Double_max
                      For L = VApost_Double_lim(K,1) To VApost_Double_lim(K,2)
                        Rout = SZApost_Double_Corr(I,J-VApost_Double_lim(I,1)+1,K,L-VApost_Double_lim(K,1)+1).Rval
                        Print #Ftest,I,J,K,L,Round(Rout,4)
                      Next
                    Next    
                  Next
                Next 
                Close #Ftest  '/
    
                Print #f," "
                Print #f,"        </ZApost_correlations_2_systems>"
              End If     
            End If
          End If
       
       
    
          Print #f,"        <Z_mean>"
          Print #f,"-----------------------------------------------------------------"
          Print #f,"--- Moments of Z-yield distributions for given mass (pre-neutron) ---"
          Print #f,"-----------------------------------------------------------------"
          Print #f," "
          Print #f,"  A_pre        Z_mean       Z_mean-Z_UCD    sigma_Z"
          Print #f," "
          For I = 20 To P_A_CN - 20
            If Apre(I) > 0 Then
              Print #f, Using " ####         ###.####     ###.####        ###.####"; _
               I; ZPOLARPRE(I)+I*P_Z_CN/P_A_CN; ZPOLARPRE(I); sigmaZPRE(I)
            End If
          Next
       
    
          Print #f," "
          Print #f," "
          Print #f,"------------------------------------------------------------------"
          Print #f,"--- Moments of Z-yield distributions for given mass (post-neutron) ---"
          Print #f,"------------------------------------------------------------------"
          Print #f," "
          Print #f,"  A_post       Z_mean       Z_mean-Z_UCD    sigma_Z"
          Print #f," "
          For I = 20 To P_A_CN - 20
            If Apost(I) > 0 Then
              Print #f, Using " ####         ###.####     ###.####        ###.####"; _
               I; ZPOLARPOST(I)+I*P_Z_CN/P_A_CN; ZPOLARPOST(I); sigmaZPOST(I)
            End If
          Next
          Print #f,"        </Z_mean>"
          Print #f,"      </FF_AZ>"
          Print #f,"    </FF>"
    
    
    
    '     Print #f," "
    '     Print #f," "
    '     Print #f,"--- Mean deformation of fragments from macroscopic model ---"
    '     Print #f," "
    '     Print #f,"   Z1          beta1     Edef1/MeV       Z2         beta2     Edef2/MeV"
    '     Print #f," "
    '     For I = 10 To P_Z_CN - 10
    '       Print #f, Using " ####        ###.###      ####.##       ####       ###.###     ####.##"; _
    '        I; Beta(0,1,I); Edefo(0,1,I); P_Z_CN-I; Beta(0,2,P_Z_CN-I); Edefo(0,2,P_Z_CN-I) 
    '     Next   
       
    
          Scope
            Dim As Double Rmean,Zaehler,Nenner
       
            Print #f,"    <Gammas>"
            Print #f,"      <Gamma_multiplicity>"
            Print #f,"----------------------------------------------------------"
            Print #f,"--- Mass-dependent gamma multiplicity (from fragments) ---"
            Print #f,"----------------------------------------------------------"
            Print #f," "
            Print #f,"Apost  Nmean"," Multiplicity distribution, unnormalized (0 to 20)"
            For I = 20 To P_A_CN - 20
              If APost(I) > 0 Then
              Zaehler = 0
              Nenner = 0
              For J = 0 To 20
                Zaehler = Zaehler + J * NgammaA(I,J)
                Nenner = Nenner + NgammaA(I,J)
                Rmean = Zaehler / Nenner 
              Next
                Print #f, Using "#### ###.###";I;RMean;
                For J = 0 To 19
                  Print #f, Using " #########";NgammaA(I,J);
                Next
                Print #f, Using " #########";NgammaA(I,20)
              End If
            Next  
            Print #f," "
          End Scope
    
          Scope
            Dim As Double Norm=0,Zaehler,Nenner
            Dim As Integer Imax
            Print #f, " "
            Print #f, " "
            Print #f, "-----------------------------------------------------------------------"
            Print #f, "--- Total gamma-multiplicity distribution (emission from fragments) ---"
            Print #f, "-----------------------------------------------------------------------"
            Print #f, " "
            Print #f, " N             Probability "
           
            For I = 0 To 50
              Norm = Norm + Ngammatot(I)
              If Ngammatot(I) > 0 Then Imax = I
              Zaehler = Zaehler + I * Ngammatot(I)
            Next  
            For I = 0 To Imax
              Print #f, I,Round(Ngammatot(I)/Norm,4)
            Next
            Print #f, " "
            If B_Error_On = 1 And B_Error_Analysis = 0 Then 
              Print #f, "Mean gamma multiplicity: ";Round(Zaehler/Norm,4);" +-";Round(d_Ng(0),4)
            Else     
              Print #f, "Mean gamma multiplicity: ";Round(Zaehler/Norm,4)
            End If
            Print #f,"      </Gamma_multiplicity>"
     
       
    
       '    Output of gamma spectrum
            Print #f,"      <E_entrance>"
            Print #f, " "
            Print #f, " "
            print #f, "---------------------------------------------------------------------------"
            print #f, "--- Distribution of E_entrance (E* after last neutron) above yrast line ---"
            print #f, "---------------------------------------------------------------------------"
            Print #f, " "
            Print #f, "Binsize = 100 keV."
            print #f, "The energy values mark the lower limit of the corresponding energy bins:"
            print #f, " e.g  channel '0.1 MeV' contains the spectrum between 0.1 and 0.2 MeV."
            Print #f, " "
            Print #f, " E / MeV","   Counts"
            Scope
              Redim Eentrance100keV(Ubound(_Eentrance)/100) As Single
              For I = 1 To Ubound(_Eentrance)
                Eentrance100keV(Int(I/100)) = Eentrance100keV(Int(I/100)) + _Eentrance(I) 
              Next I
              For I = Lbound(Eentrance100keV,1) to Ubound(Eentrance100keV,1)
                If Eentrance100keV(I) > 0 Then
                  Print #f, Using "####.#    ############"; I*0.1; Eentrance100keV(I)  
                End If
              Next I
            End Scope  
            Print #f,"      </E_entrance>"
            Print #f,"      <E_gammas>"
            Print #f, " "
            Print #f, " "
            print #f, "---------------------------------------------------------------"
            print #f, "--- Spectrum of prompt individual gammas from the fragments ---"
            print #f, "---------------------------------------------------------------"
            Print #f, " "
            Print #f, "Binsize = 100 keV."
            print #f, "The energy values mark the lower limit of the corresponding energy bins:"
            print #f, " e.g  channel '0.1 MeV' contains the spectrum between 0.1 and 0.2 MeV."
            Print #f, "(The dmp folder provides spectra with 1 keV resolution."
            Print #f, " There is also a spectrum of pre-saddle gammas.)"
            Print #f, " "
            Print #f, "The energy spectrum shows the energies of the nuclear gamma transitions."
            Print #f, "Measured gamma spectra are smeared out by the doppler shift due to the"
            Print #f, "emission from the moving fragments."
            Print #f, " "
            Print #f, "E_gamma / MeV","  Counts(total)     Counts(E2 only)"
    
            Scope
              Redim Egamma100keV(Ubound(_Egamma)/100) As Single
              For I = 0 To Ubound(_Egamma)
                Egamma100keV(Int(I/100)) = Egamma100keV(Int(I/100)) + _Egamma(I) 
              Next I     
              Redim EgammaE2100keV(Ubound(_EgammaE2)/100) As Single
              For I = 0 To Ubound(_EgammaE2)
                EgammaE2100keV(Int(I/100)) = EgammaE2100keV(Int(I/100)) + _EgammaE2(I) 
              Next I     
              Dim As Double Norm,Zaehler,Nenner
              Dim As Integer Imin,Imax,I
              Dim As single Rwork
              Norm = 0
              Zaehler = 0
              Nenner = 0
              For I = Lbound(_Egamma) To Ubound(_Egamma)
                Zaehler = Zaehler + I*0.001*_Egamma(I)
                Nenner = Nenner + _Egamma(I)
              Next I
              For I = Lbound(_Egamma) To Ubound(Egamma100keV)
                If Egamma100keV(I) > 0 Then Imax = I
              Next I
              For I = Ubound(Egamma100keV) To Lbound(Egamma100keV) Step -1
                If Egamma100keV(I) > 0 Then Imin = I
              Next I  
              For I = Imin To Imax
                If Egamma100keV(I) > 0 Then
                  If I >= Lbound(EgammaE2100keV,1) And I <= Ubound(EgammaE2100keV) Then
                    Rwork = EgammaE2100keV(I)
                  Else
                    Rwork = 0
                  End If
     '            Print #f,Using "####.#    ############      ############";I*0.1;Egamma100keV(I);EgammaE2100keV(I)
                  Print #f,Using "####.#    ############      ############";I*0.1;Egamma100keV(I);Rwork
                End If
              Next
              Print #f," "
              If B_Error_On = 1 And B_Error_Analysis = 0 Then
                Print #f,"Mean gamma energy: (";Round(Zaehler/Nenner,4);" +-";Round(d_Eg(0),4);" ) MeV" 
              Else
                Print #f,"Mean gamma energy: ";Round(Zaehler/Nenner,4);" MeV"
              End If  
              Print #f,"(Calculated from a spectrum with 1 keV resolution.)"
            End Scope 
            Print #f,"      </E_gammas>"
    
            Dim As Integer Imin 
            Print #f,"      <Sum_gamma_energy>"
            Print #f, " "
            Print #f, " "
            Print #f, "----------------------------------------------------------------------"
            Print #f, "--- Distribution of total gamma energy per fission (from fragments) --"
            Print #f, "----------------------------------------------------------------------"
            Print #f, " "
            Print #f, "Binsize = 100 keV; bins with zero content suppressed."
            print #f, "The energy values mark the lower limit of the corresponding energy bins:"
            print #f, " e.g  channel '0.1 MeV' contains the spectrum between 0.1 and 0.2 MeV."
            Print #f, "(The dmp folder provides a spectrum with 1 keV resolution.)"
            Print #f, " "
            Print #f, " Egamma / MeV     Counts "
            Redim Egammatot100keV(Ubound(_Egammatot)/100) As Single
            For I = 1 To Ubound(_Egammatot)
              Egammatot100keV(Int(I/100)) = Egammatot100keV(Int(I/100)) + _Egammatot(I) 
            Next I  
            Norm = 0
            Zaehler = 0
            Nenner = 0
            For I = Lbound(_Egammatot,1) To Ubound(_Egammatot,1)
              Zaehler = Zaehler + Csng(I)*0.001*_Egammatot(I)
              Nenner = Nenner + _Egammatot(I)
            Next I
            For I = Lbound(Egammatot100keV,1) To Ubound(Egammatot100keV,1)
              If Egammatot100keV(I) > 0 Then Imax = I
            Next
            For I = Ubound(Egammatot100keV,1) To Lbound(Egammatot100keV,1) Step -1
              If Egammatot100keV(I) > 0 Then Imin = I
            Next
            For I = Imin To Imax
              If Egammatot100keV(I) > 0 Then _
              Print #f,Using "####.#    ############";I*0.1;Egammatot100keV(I)
            Next I
            Print #f," "
            If B_Error_On = 1 And B_Error_Analysis = 0 Then 
              Print #f,"Mean total gamma energy per fission: (";Round(Zaehler/Nenner,4);" +-";Round(d_Egtot(0),4);" ) MeV"
            Else
              Print #f,"Mean total gamma energy per fission: ";Round(Zaehler/Nenner,4);" MeV"
            End If
            Print #f, "(Calculated from a spectrum with 1 keV resolution.)"
            Print #f,"      </Sum_gamma_energy>"
            Print #f,"    </Gammas>"
          End Scope  
        
    
          Scope
            Dim As Integer I,J
            Print #f,"    <Neutrons>"
            Print #f,"      <NmultA>"
            Print #f,"----------------------------------------------------------"
            Print #f,"---     Mass-dependent prompt-neutron multiplicity     ---"
            Print #f,"--- as a function of pre-neutron and post-neutron mass ---"
            Print #f,"... (Mean values from CN and from fragments,           ---"
            Print #f,"---full distribution only for emission from fragments.)---"
            Print #f,"----------------------------------------------------------"
            Print #f," "
            Print #f," Apre  Nmean  Nmean"," Multiplicity distribution, unnormalized (0 to 16)"
            Print #f,"       (CN)   (frag ->)"
            For I = 20 To P_A_CN - 20
              If NmultiApre(I) > 0 Or NAPre(I) > 0  Then
                Print #f, Using "#### ###.###";I;NmultiApre(I);
                Print #f, Using "###.###";NApre(I);
                For J = 0 To 15
                  Print #f, Using " #########";N2dpre(I,J);
                Next
                Print #f, Using " #########";N2dpre(I,16)
              End If
            Next  
            Print #f," "
            Print #f," Apost  Nmean  Nmean"," Multiplicity distribution, unnormalized (0 to 16)"
            Print #f,"       (CN)   (frag ->)"
            For I = 20 To P_A_CN - 20
              If NmultiApost(I) > 0 Or NApost(I) > 0 Then
                Print #f, Using "#### ###.###";I;NmultiApost(I);
                Print #f, Using "###.###";NApost(I);
                For J = 0 To 15
                  Print #f, Using " #########";N2Dpost(I,J);
                Next
                Print #f, Using " #########";N2Dpost(I,16)
              End If
              Next  
            Print #f,"      </NmultA>"
          End Scope
     
    
      '   Calculate moments of neutron-multiplicity distributions
          Dim As Double Nmean, NCNmean, Nscimean, Nfrmean
          Scope
            Dim As Double Nsum, Nsigma2, NCNsum, NCNsigma2, Nscisum, Nscisigma2, Nfrsum, Nfrsigma2
            Dim As Double Nlightsum, Nlightmean, Nlightsigma2
            Dim As Double Nheavysum, Nheavymean, Nheavysigma2
         
        '   CN  
            NCNsum = 0
            For I = 0 To Ubound(NNCN)
              NCNsum = NCNsum + NNCN(I)
            Next
            For I = 0 To Ubound(NNCN)
              NNCN(I) = NNCN(I) / NCNsum
            Next
            NCNmean = 0
            For I = 0 To Ubound(NNCN)
              NCNmean = NCNmean + NNCN(I) * I
            Next
            NCNsigma2 = 0
            For I = 0 To Ubound(NNCN)
              NCNsigma2 = NCNsigma2 + NNCN(I) * (I - NCNmean)^2  
            Next  
         
       '    between saddle and scission
            Nscisum = 0
            For I = 0 To Ubound(NNsci)
              Nscisum = Nscisum + NNsci(I)
            Next
            If Nscisum = 0 Then
              Nscimean = 0
              Nscisigma2 = 0
            Else
              For I = 0 To Ubound(NNsci)
                NNsci(I) = NNsci(I) / Nscisum
              Next
              Nscimean = 0
              For I = 0 To Ubound(NNsci)
                Nscimean = Nscimean + NNsci(I) * I
              Next
              Nscisigma2 = 0
              For I = 0 To Ubound(NNsci)
                Nscisigma2 = Nscisigma2 + NNsci(I) * (I - Nscimean)^2  
              Next
            End If  
         
       '    fragments
            Nfrsum = 0
            For I = 0 To Ubound(NNfr)
              Nfrsum = Nfrsum + NNfr(I)
            Next
            For I = 0 To Ubound(NNfr)
              NNfr(I) = NNfr(I) / Nfrsum
            Next
            Nfrmean = 0
            For I = 0 To Ubound(NNfr)
              Nfrmean = Nfrmean + NNfr(I) * I
            Next
            Nfrsigma2 = 0
            For I = 0 To Ubound(NNfr)
              Nfrsigma2 = Nfrsigma2 + NNfr(I) * (I - Nfrmean)^2  
            Next  
         
       '    total  
            Nsum = 0
            For I = 0 To Ubound(NN)
              Nsum = Nsum + NN(I)
            Next
            For I = 0 To Ubound(NN)
              NN(I) = NN(I) / Nsum
            Next
            Nmean = 0
            For I = 0 To Ubound(NN)
              Nmean = Nmean + NN(I) * I
            Next
            Nsigma2 = 0
            For I = 0 To Ubound(NN)
              Nsigma2 = Nsigma2 + NN(I) * (I - Nmean)^2  
            Next  
         
        '   light fragments
            Nlightsum = 0
            For I = 0 To Ubound(NNlight)
              Nlightsum = Nlightsum + NNlight(I)
            Next
            For I = 0 To Ubound(NNlight)
              NNlight(I) = NNlight(I) / Nlightsum
            Next
            Nlightmean = 0
            For I = 0 To Ubound(NNlight)
              Nlightmean = Nlightmean + NNlight(I) * I
            Next
            Nlightsigma2 = 0
            For I = 0 To Ubound(NNlight)
              Nlightsigma2 = Nlightsigma2 + NNlight(I) * (I - Nlightmean)^2  
            Next     
       
       '    heavy fragments
            Nheavysum = 0
            For I = 0 To Ubound(NNheavy)
              Nheavysum = Nheavysum + NNheavy(I)
            Next
            For I = 0 To Ubound(NNheavy)
              NNheavy(I) = NNheavy(I) / Nheavysum
            Next
            Nheavymean = 0
            For I = 0 To Ubound(NNheavy)
              Nheavymean = Nheavymean + NNheavy(I) * I
            Next
            Nheavysigma2 = 0
            For I = 0 To Ubound(NNheavy)
              Nheavysigma2 = Nheavysigma2 + NNheavy(I) * (I - Nheavymean)^2  
            Next     
    
            Print #f,"      <Nmult>"
            Print #f," "
            Print #f,"-------------------------------------------------------------------------------------"
            Print #f,"--- Multiplicity distribution of prompt neutrons (only fission events considered) ---"
            Print #f,"-------------------------------------------------------------------------------------"
            Print #f," "
            Print #f," N       pre-saddle      saddle-scission from fragments     total"
            Scope
              Dim As Integer NNmax
              For I = Ubound(NN) To 0 Step -1
                If NN(I) > 0 Then
                  NNmax = I
                  Exit For
                End If
              Next 
              For I = 0 To NNmax
                Print #f, I, Csng(NNCN(I)), Csng(NNsci(I)), Csng(NNfr(I)), Csng(NN(I))
              Next
            End Scope  
            If B_Error_On = 1 And B_Error_Analysis = 0 Then 
              Print #f," "
              Print #f,"Mean value (pre-saddle):             ",NCNmean;" +-";Csng(d_NCN(0))
              Print #f,"Width (standard deviation):    ",Csng(sqr(NCNsigma2))
              Print #f," "   
              Print #f,"Mean value (from saddle to scission):",Nscimean;" +-";Csng(d_Nsci(0))
            ' Print #f,"Width (standard deviation):",Csng(sqr(Nscisigma2))
              Print #f," "   
              Print #f,"Mean value (from fragments):         ",Nfrmean;" +-";Csng(d_Nfr(0))
              Print #f,"Width (standard deviation): ",Csng(sqr(Nfrsigma2))
              Print #f," "   
              Print #f,"Mean value (total):                  ",Nmean;" +-";Csng(d_Ntot(0))
              Print #f,"Width (standard deviation):          ",Csng(sqr(Nsigma2))
              Print #f," "   
            Else
              Print #f," "
              Print #f,"Mean value (pre-saddle):             ",NCNmean
              Print #f,"Width (standard deviation):    ",Csng(sqr(NCNsigma2))
              Print #f," "   
              Print #f,"Mean value (from saddle to scission):",Nscimean
            ' Print #f,"Width (standard deviation):",Csng(sqr(Nscisigma2))
              Print #f," "   
              Print #f,"Mean value (from fragments):         ",Nfrmean
              Print #f,"Width (standard deviation): ",Csng(sqr(Nfrsigma2))
              Print #f," "   
              Print #f,"Mean value (total):                  ",Nmean
              Print #f,"Width (standard deviation):          ",Csng(sqr(Nsigma2))
              Print #f," "   
            End If
    
       
            Print #f," "
            Print #f," "
            Print #f,"---------------------------------------------------------------------"
            Print #f,"--- Multiplicity distribution of prompt neutrons (light fragment) ---"
            Print #f,"---------------------------------------------------------------------"
            Print #f," "
            For I = 0 To Ubound(NNlight)
              If NNlight(I) > 0 Then
                Print #f, I, Csng(NNlight(I))
              End If
            Next I
            Print #f," " 
            If B_Error_On = 1 And B_Error_Analysis = 0 Then 
              Print #f,"Mean value: ",Nlightmean;" +-";Csng(d_Nlight(0))
            Else 
              Print #f,"Mean value: ",Nlightmean
            End If  
            Print #f,"Width (standard deviation): ",Csng(Nlightsigma2)  
         
       
            Print #f," "
            Print #f," "
            Print #f,"---------------------------------------------------------------------"
            Print #f,"--- Multiplicity distribution of prompt neutrons (heavy-fragment) ---"
            Print #f,"---------------------------------------------------------------------"
            Print #f," "
            For I = 0 To Ubound(NNheavy)
              If NNheavy(I) > 0 Then
                Print #f, I, Csng(NNheavy(I))
              End If
            Next I
            Print #f," "
            If B_Error_On = 1 And B_Error_Analysis = 0 Then 
              Print #f,"Mean value: ",Nheavymean;" +-";Csng(d_Nheavy(0))
            Else  
              Print #f,"Mean value: ",Nheavymean
            End If  
            Print #f,"Width (standard deviation): ",Csng(Nheavysigma2)  
          End Scope
        
       
          Print #f," "
          Print #f," "
          Print #f,"---------------------------------------------------------------------"
          Print #f,"--- Neutron multiplicity versus neutron direction relative to LF  ---"
          Print #f,"--- (Only neutrons from fragments with En >= 0.4 MeV considered.) ---"
          Print #f,"---------------------------------------------------------------------"
          Print #f," "
          Print #f," Cos(alpha)             Counts"
          For I = -100 To 99
            Print #f, Using " ##.###        ##############"; I/100+0.005;Ndirlight(I)
          Next I
    
          Scope
            Dim As Integer First_output, Last_output
            Dim As Double Zaehler,Nenner
            Dim As Single nu_mean
            Dim As Single TKE_pre_vec(0 To 250)
            Dim As Single TKE_post_vec(0 To 250)
            Print #f," "
            Print #f," "
            Print #f,"---------------------------------------------------"
            Print #f,"--- Neutron multiplicity versus pre-neutron TKE ---"
            Print #f,"--        Only neutrons from fragments          ---"
            Print #f,"---------------------------------------------------"
            Print #f," "
            Print #f,"  TKE   events  nu_mean   nu distribution (nu = 0 to 20)"
            Print #f," "  
            For I = 0 to 250 
              For J = 0 to 20
                If nuTKEpre(I,J) > 0 Then
                  First_output = I
                  Exit For, For 
                End If
              Next J
            Next I    
            For I = 250 To 0 Step -1
              For J = 0 to 20
                If nuTKEpre(I,J) > 0 Then
                  Last_output = I
                  Exit For, For 
                End If
              Next
            Next
            For I = First_output To Last_output Step 1
              Zaehler = 0
              Nenner = 0
              For J = 0 To 20
                Zaehler = Zaehler + nuTKEpre(I,J)*J
                Nenner = Nenner + nuTKEpre(I,J)
                TKE_pre_vec(I) = TKE_pre_vec(I) + nuTKEpre(I,J)
              Next J
              If Zaehler  = 0 Then nu_mean = 0 Else _
                nu_mean = Zaehler/Nenner
              Print #f, Using "#####  #######  ###.##";I;TKE_pre_vec(I);nu_mean;
              For J = 0 To 19 
                Print #f, Using "#########"; nuTKEpre(I,J);  
              Next
              Print #f, Using "#########"; nuTKEpre(I,20)
            Next I
       
            Print #f," "
            Print #f," "
            Print #f,"----------------------------------------------------"
            Print #f,"--- Neutron multiplicity versus post-neutron TKE ---"
            Print #f,"---        Only neutrons from fragments          ---"
            Print #f,"----------------------------------------------------"
            Print #f," "
            Print #f,"  TKE   events  nu_mean   nu distribution (nu = 0 to 20)"
            Print #f," "     
            For I = 0 to 250 
              For J = 0 to 20
                If nuTKEpost(I,J) > 0 Then
                  First_output = I
                  Exit For, For 
                End If
              Next J
            Next I     
            For I = 250 To 0 Step -1
              For J = 0 to 20
                If nuTKEpost(I,J) > 0 Then
                  Last_output = I
                  Exit For, For 
                End If
              Next J
            Next I
            For I = First_output To Last_output Step 1
              Zaehler = 0
              Nenner = 0
              For J = 0 To 20
                Zaehler = Zaehler + nuTKEpost(I,J)*J
                Nenner = Nenner + nuTKEpost(I,J)
                TKE_post_vec(I) = TKE_post_vec(I) + nuTKEpost(I,J)
              Next
              If Zaehler  = 0 Then nu_mean = 0 Else _
                nu_mean = Zaehler/Nenner
              Print #f, Using "#####  #######  ###.##";I;TKE_post_vec(I);nu_mean;
              For J = 0 To 19 
                Print #f, Using "#########"; nuTKEpost(I,J);  
              Next
                Print #f, Using "#########"; nuTKEpost(I,20)
            Next I  
            Print #f,"      </Nmult>"
          End Scope 
     
    
    
    
      '   Rebin spectrum  1 keV -> 100 keV and more
          Scope
            Dim As Double Zaehlerfr, Nennerfr, Zaehlersci, Nennersci, ZaehlerCN, NennerCN
            Dim As Double Zaehler, Nenner
            Dim As Single EnCNmean, Enscimean, Enfrmean, Enmean
            Dim As Single Energy
        '   Compound nucleus (pre-saddle):
    '       Redim EnCN100keV(Lbound(_EnCN)/100 To Ubound(_EnCN)/100) As Single
            Redim EnCN100keV(1000) As Double
            ZaehlerCN = 0
            NennerCN = 0
            For I = Lbound(_EnCN,1) To Ubound(_EnCN,1)
              EnCN100keV(Int(I/100)) = EnCN100keV(Int(I/100)) + EnCN(I) 
              Energy = I * 0.001 + 0.0005     ' in MeV         
              ZaehlerCN = ZaehlerCN + Energy * EnCN(I)
              NennerCN = NennerCN + EnCN(I)
            Next I  
            If NennerCN > 0 Then
              EnCNmean = ZaehlerCN / NennerCN
            Else
              EnCNmean = 0
            End If
            If Imulti > 0 Then
              For I = Lbound(EnCN100keV) To Ubound(EnCN100keV)  ' normalize prefission spectrum to fission spectrum
                EnCN100keV(I) = EnCN100keV(I) * NEVTtot / Imulti
              Next I
            End If  
          ' Between saddle and scission
    '       Redim Ensci100keV(Lbound(_Ensci)/100 To Ubound(_Ensci)/100) As Single
            Redim Ensci100keV(1000) As Double
            Zaehlersci = 0
            Nennersci = 0
            For I = Lbound(_Ensci) To Ubound(_Ensci)
              Ensci100keV(Int(I/100)) = Ensci100keV(Int(I/100)) + Ensci(I) 
              Energy = I * 0.001 + 0.0005     ' in MeV         
              Zaehlersci = Zaehlersci + Energy * Ensci(I)
              Nennersci = Nennersci + Ensci(I)
            Next I  
            If Nennersci > 0 Then
              Enscimean = Zaehlersci / Nennersci
            Else
              Enscimean = 0
            End If
        '   Fragments:
    '       Redim Enfr100keV(Lbound(_Enfr)/100 To Ubound(_Enfr)/100) As Single
            Redim Enfr100keV(1000) As Double
            For I = Lbound(_Enfr) To Ubound(_Enfr)
              Enfr100keV(Int(I/100)) = Enfr100keV(Int(I/100)) + Enfr(I) 
            Next I  
    '       Redim En100keV(Ubound(EnCN100keV)) As Single ' En100keV from sum of EnCN100keV and Enfr100keV
            Redim En100keV(1000) As Double
            For I = 0 To Ubound(En100keV)
              En100keV(I) = EnCN100keV(I) + ENsci100keV(i) + Enfr100keV(I)
            Next I 
    '       Redim EnfrC100keV(Ubound(_ENfrC,1),Ubound(_ENfrC,2),Ubound(_ENfrC,3)/100) As Single
            Redim EnfrC100keV(Ubound(_ENfrC,1),Ubound(_ENfrC,2),1000) As Double
      '     For J = 0 To I_N_Multi_Max
      '       For K = 0 To I_Z_Multi_Max
            For J = 0 To Ubound(_ENfrC,1)       ' limited by dimensions of ENfrC and ENfrC100keV
              For K = 0 To Ubound(_ENfrC,2)
                For I = 0 To Ubound(_EnfrC,3)
                  ENfrC100keV(J,K,Int(I/100)) = ENfrC100keV(J,K,Int(I/100)) + ENfrC(J,K,I)
                Next I                          
              Next K
            Next J
        '   All emitted neutrons
            Zaehler = 0
            Nenner = 0
            For I = Lbound(_Enfr) To Ubound(_Enfr)
              Energy = I * 0.001 + 0.0005     ' in MeV         
              Zaehler = Zaehler + Energy * (Ensci(I) + Enfr(I) + EnCN(I) * NEVTtot/Imulti)
              Nenner = Nenner + Ensci(I) + Enfr(I) + EnCN(I) * NEVTtot / Imulti 
            Next I
            If Nenner > 0 Then
              Enmean = Zaehler / Nenner  
            Else
              Enmean = 0
            End If
        '   Enmean = (EnCNmean * NennerCN * NEVTtot / Imulti + Enmean * Nenner) / (NennerCN * NEVTtot / Imulti + Nenner)
         
        '   Normalize spectrum of prompt neutrons and divide by Maxwell distribution
            Dim As Integer I,J,K
            Dim As Double SumN = 0
            Dim As Double SumMaxwell = 0
            Dim As Double Norm
            Dim As Single YMaxwell
            Dim As Single Tnorm = 1.32
            For I = 1 To UBound(EN100keV)
              Energy = I * 0.1 + 0.05        
              SumN = SumN + EN100keV(I)
              SumMaxwell = SumMaxwell + Sqr(Energy) * Exp(-Energy/Tnorm)
            Next 
            Norm = SumMaxwell / SumN
          
       
        '   Output of overall neutron spectrum
            Print #f,"      <Nspectrum>"
            print #f, "------------------------------------------------------------------------"
            print #f, "--- Spectra and mean energy values of prompt neutrons                ---"
            print #f, "... in cm system of the fissioning nucleus.                          ---"
            print #f, "--- pre-saddle, between saddle and scission and from fragments       ---"
            print #f, "--- after emssion of DN neutrons and DZ protons.                     ---"
            print #f, "------------------------------------------------------------------------"
            Print #f, " "
            print #f, "The energy values mark the lower limit of the corresponding energy bins:"
            print #f, "e.g  channel '0.1 MeV' contains the spectrum between 0.1 and 0.2 MeV."
            Print #f, "The dmp folder provides spectra with 1 keV resolution."
            Print #f, "The spectrum of pre-saddle neutrons is calculated with a different"
            Print #f, "number of events than the saddle-scission or post-scission values."
            Print #f, "In the following table, the counts of this spectrum are up- or down-scaled"
            Print #f, "in order to make the spectra comparable."
            Print #f, " "
    
            Print #f, "E_neutron","   Counts","   Counts",
            If I_N_Multi_Max <= Ubound(_ENfrC,1) And I_Z_Multi_Max <= Ubound(_ENfrC,2) Then
              For I = 0 To I_N_Multi_Max
                For J = 0 To I_Z_Multi_Max
                  Print #f, "    Counts",
                Next 
              Next  
            End If
            Print #f, "    Counts","    Counts","Yield norm. to Maxwellian"
    
            Print #f, "   MeV "," "," ",
            If I_N_Multi_Max <= Ubound(_ENfrC,1) And I_Z_Multi_Max <= Ubound(_ENfrC,2) Then
              For I = 0 To I_N_Multi_Max
                For J = 0 To I_Z_Multi_Max
                  Print #f, "  DN / DZ ",
                Next
              Next
            End If
            Print #f, "    DN / DZ ","  ","Yield / (sqrt(En)*exp(-En/1.32MeV))"
         
            Print #f, " "," "," ",
            If I_N_Multi_Max <= Ubound(_ENfrC,1) And I_Z_Multi_Max <= Ubound(_ENfrC,2) Then
              For I = 0 To I_N_Multi_Max
                For J = 0 To I_Z_Multi_Max
                  Print #f,"  ";I;" /";J,
                Next
              Next
            End If
            Print #f,"    all/all (summed over all DN and DZ values)"
    
            Print #f, "       ","pre-saddle","saddle-scission ";"from fragments";
            If I_N_Multi_Max <= Ubound(_ENfrC,1) And I_Z_Multi_Max <= Ubound(_ENfrC,2) Then
              Print #f," ...";
              For I = 0 To I_N_Multi_Max
                For J = 0 To I_Z_Multi_Max
                  Print #f," ",
                Next
              Next
            End If  
            Print #f, "    total"
    
            For I = 0 To UBound(EN100keV)
              Energy = I * 0.1 + 0.05   
               ' "+ 0.05" is the centre of the energy bin. 
               ' This is the value to be compared with the Maxwellian!
               ' The spectrum EN itself is listed in SATAN convention (x value = lower bin limit)
              If EN100keV(I) >0 Then
                YMaxwell = sqr(Energy) * exp(-Energy/Tnorm)
                Print #f, Using "####.#      ##########      ##########"; _
                               I*0.1; ENCN100keV(I); ENsci100keV(I); 
                If I_N_Multi_Max <= Ubound(_ENfrC,1) And I_Z_Multi_Max <= Ubound(_ENfrC,2) Then
                  For J = 0 To I_N_Multi_Max
                    For K = 0 To I_Z_Multi_Max
                      Print #f, Using "    ##########";ENfrC100keV(J,K,I);                          
                    Next
                  Next
                End If
                If YMaxwell > 1.E-10 Then 
                  Print #f, Using "     ##########    ########## ########.######"; _
                                 ENfr100keV(I); EN100keV(I); EN100keV(I) * Norm / YMaxwell
                Else                   
                  Print #f, Using "     ##########    ##########      Overflow"; _
                                 ENfr100keV(I); EN100keV(I)
                End If                 
              End If
            Next   
        '   Mean neutron energy
            Zaehler = 0
            Nenner = 0
            For I = Lbound(_ENfr,1) To UBound(_ENfr,1)  
              Energy = I * 0.001 + 0.0005     ' in MeV  
              Zaehler = Zaehler + ENfr(I) * Energy
              Nenner = Nenner + ENfr(I)
            Next I
            If Nenner > 0 Then
              Enfrmean = Zaehler / Nenner
            Else
              Enfrmean = 0  
            End If
            Print #f, " "
            Print #f, " "
            Print #f, "---  Prompt-neutron spectrum (emission from fragments) with variable bin size  ---"
            Print #f, " "
            Print #f, "            E_neutrons            E_neutrons              Counts"
            Print #f, "                eV                     eV "
            Print #f, "        lower channel limit   upper channel limit"
            Print #f, " "
            For I = 1 To Ubound(ENfrvar)
              Print #f, Using "  ############.######    ############.######   ##################"; _
                      ENfrvar_lim(I-1); ENfrvar_lim(I); ENfrvar(I)
            Next I
            Print #f, " "
            Print #f, "      </Nspectrum>"
            Print #f, "      <Enmean>"
            Print #f, " "
            If B_Error_On = 1 And B_Error_Analysis = 0 Then 
              Print #f, "Mean neutron energy  = (";Csng(Enfrmean);" +-";Csng(d_ENfr(0));" ) MeV"
            Else
              Print #f, "Mean neutron energy  = ";Csng(Enfrmean);" MeV"
            End If
            Print #f, "(Includes only neutrons emitted from fragments.)" 
            Print #f, " "
            If EnCNmean > 0 Then
              Print #f, "Mean energy of pre-saddle neutrons = ";Csng(EnCNmean);" MeV"
            Else
              Print #f, "No pre-saddle neutrons emitted."
            End If  
            If Enscimean > 0 Then
              Print #f, "Mean energy of neutrons emitted between saddle and scission = ";Csng(Enscimean);" MeV"
            Else
              Print #f, "No neutrons emitted between saddle and scission."
            End If  
            If EnCNmean > 0 Or Enscimean > 0 THen
              Print #f, "Mean energy of all emitted neutrons = ";Csng(Enmean);" MeV"
            End If  
            Print #f, "(All mean energies are calculated from the corresponding neutron spectrum with 1 keV resolution.)"
            Print #f, "      </Enmean>"
            Print #f, "    </Neutrons>"
          End Scope
    
    
       
    /'    special-purpuse file
          Dim As Integer IFIAEA
          Dim As Single Energy
          If B_Error_Analysis = 0 Then
            IFIAEA = Freefile
            Open "out\Work.dat" For Append As #IFIAEA
            Print #IFIAEA, P_Z_CN, P_A_CN-1,Nmean 
            For I = 1 To 200
              Energy = I * 0.1  
            Print #IFIAEA, Round(Energy,4), EN(I)  
            Next
            Print #IFIAEA," "
            Close #IFIAEA
          End If
    '/   
       
    
          Dim As Single JNJ,NJ,Jmean 
          Dim As Single Jadd
       
          Print #f,"    <FF_spin>"
          Print #f,"      <A_Z_spin>"
          Print #f,"----------------------------------------------"
          Print #f,"--- Fragment angular-momentum distribution ---"
          Print #f,"---   before emission of prompt neutrons   ---"
          Print #f,"----------------------------------------------"
          Print #f," "
          Print #f," A  Z   Jmean  J distribution, unnormalized (0 to 25 (1/2 to 51/2) for even (odd) Apre)"
        ' JFRAGpre stores the angular momentum in steps of 1 hbar steps  
          For I = 20 To P_A_CN - 20
            For J = 10 To P_Z_CN - 10
              If I Mod 2 = 0 Then
                Jadd = 0
              Else
                Jadd = 1/2
              End If
              If ZISOPRE(I,J) > 0 Then
                NJ = 0
                JNJ = 0
                For K = 0 To 50
                  NJ = NJ + JFRAGpre(I-J,J,K)
                  JNJ = JNJ + (K+Jadd) * JFRAGpre(I-J,J,K)
                Next
                If NJ > 4 Then
                  Jmean = JNJ / NJ
                  Print #f, Using "### ## ##.## ########";I;J;Jmean;JFRAGpre(I-J,J,0);
                  For K = 1 To 24
                    Print #f, Using "########";JFRAGpre(I-J,J,K);
                  Next
                    Print #f, Using "########";JFRAGpre(I-J,J,25)
                End If 
              End If
            Next J
          Next I
    
    
          Print #f," "
          Print #f," "
          Print #f,"-----------------------------------------------------"
          Print #f,"---    Fragment angular-momentum distribution     ---"
          Print #f,"--- after the emission of the last prompt neutron ---"
          Print #f,"-----------------------------------------------------"
          Print #f," "
          Print #f," A  Z   Jmean  J distribution, unnormalized (0 to 25 (1/2 to 51/2) for even (odd) Apost)"
        ' JFRAGpost stores the angular momentum in steps of 1 hbar  
          For I = 20 To P_A_CN - 20
            For J = 10 To P_Z_CN - 10
              If I Mod 2 = 0 Then
                Jadd = 0
              Else
                Jadd = 1/2
              End If
              If ZISOPOST(I,J) > 0 Then
                NJ = 0
                JNJ = 0
                For K = 0 To 50
                  NJ = NJ + JFRAGpost(I-J,J,K)  ' N,Z,Spin
                  JNJ = JNJ + (K+Jadd) * JFRAGpost(I-J,J,K)
                Next
                If NJ > 4 Then
                  Jmean = JNJ / NJ
                  Print #f, Using "### ## ##.## ########";I;J;Jmean;JFRAGpost(I-J,J,0);
                  For K = 1 To 24
                    Print #f, Using "#########";JFRAGpost(I-J,J,K);
                  Next
                  Print #f, Using "#########";JFRAGpost(I-J,J,25)
                End If 
              End If
            Next J
          Next I
          Print #f, "      </A_Z_spin>"
    
     
          Dim As Integer Niso,Iiso,MATnmbr,Itest
          Dim As Single RJ
          Dim As Single Rnorm
       
          Ilast = 0
          Print #f,"      <Isomeric_yields>"
          Print #f,"--------------------------------------------"
          Print #f,"--- Relative independent isomeric yields ---"
          Print #f,"--------------------------------------------"
          Print #f," "
          Print #f,"The calculation is based on spin and energy values from ";ISOSOURCE;"."
          Print #f," "
          Print #f,"J and E* are the spin and the excitation energy of the state."
          Print #f,"Yield is the relative production yield of that state."
          Print #f,"The number of events allows to estimate the statistical uncertainty."
          Print #f,"The 'upper limit' is an internal parameter to calculate the yield."
          #If ISOSOURCE = "NUBASE-2016" Or ISOSOURCE = "NUBASE-2020" 
            Print #f,"Finally, the half-life of the state is listed."
          #ENDIF
          Print #f," "
          Print #f,"The listed yield values only include the first population"
          Print #f,"of the state (ground state or one of the isomeric states)"
          Print #f,"by the emission of 'prompt' neutrons and gammas."
          Print #f,"Note that measured yields may include the population"
          Print #f,"by the delayed consecutive decay from higher-lying isomers,"
          Print #f,"depending on the conditions of the experiment!"
          Print #f," "
          Print #f," A"," Z"," J"," E*","Yield","Events","Upper limit"
          For I = 20 To P_A_CN - 20   ' loop over mass
            For J = 10 To P_Z_CN - 10 '  loop over Z
              If I - J >= 10 And I - J <= I_N_CN - 10 Then   ' limited range of N
                Itest = 0
           '    If I = 120 And J = 47 Then Itest = 1
                If ZISOPOST(I,J) > 0 Then
            	  MATnmbr = I_MAT_ENDF(J,I) ' MAT number of nucleus in ground state 
          	      Niso = N_ISO_MAT(MATnmbr) ' Number of isomeric states
          	      Iiso = ISO_for_MAT(MATnmbr)
     '            Print "Z,A,Mat#,Niso,Iiso";J;I;Matnmbr;Niso,Iiso     	   
         	      If Niso > 0 Then 
    '    	        If Itest = 1 Then Print
                    Redim As Single R_yield_iso(Niso + 1)  ' Number of states
                    For K = 1 To Niso + 1
                      If Isotab(Iiso).R_lim(K) > 50 Then
                        Isotab(Iiso).R_lim(K) = 50
                      End If
                    Next
                    For RJ = 0 To Isotab(Iiso).R_lim(1) Step 1   ' Sum over spin range feeding the lowest-spin state
                      R_yield_iso(1) = R_yield_iso(1) + JFRAGpost(I-J,J,RJ)
          '           If Itest = 1 Then Print IR,JFRAGpost(I-J,J,RJ),R_yield_iso(1)
                    Next
         	        For K = 2 To Niso + 1
         	          For RJ = Isotab(Iiso).R_lim(K-1) _
         	            To Isotab(Iiso).R_lim(K) Step 1   ' Sum over spin range feeding the higher-spin states
         	            R_yield_iso(K) = R_yield_iso(K) + JFRAGpost(I-J,J,RJ)
         '              If Itest = 1 Then Print IR,JFRAGpost(I-J,J,RJ),R_yield_iso(K)
         	          Next
         	        Next
          	        Rnorm = 0
          	        For K = 1 to Niso + 1
         	          Rnorm = Rnorm + R_yield_iso(K)
         	        Next
         	        For K = 1 To Niso + 1
                      If Rnorm <> 0 Then      ' D. Rochman
           	            Isotab(Iiso).R_Prob(K) = R_yield_iso(K) / Rnorm   ' Normalize population of all states in the fragment (Z,A)
    '                   Print "13917 A,Z,IIso,K,Prob ";I,J,Iiso,K,Isotab(Iiso).R_Prob(K)      	      
                      Else
           	            Isotab(Iiso).R_Prob(K) = 0
                      End If
         	        Next
         	        For K = 1 to Niso + 1
                      If I+J*100 <> Ilast Then Print #f," "
         	          Print #f,I,J, _
         	            Isotab(Iiso).R_SPI(K), _
         	            Isotab(Iiso).R_EXC(K), _
         	            Cast(Single, Isotab(Iiso).R_Prob(K) * 100.E0);" %", _
         	            R_yield_iso(K), _
         	            Isotab(Iiso).R_lim(K),
         	          #If ISOSOURCE = "NUBASE-2016" Or ISOSOURCE = "NUBASE-2020"
         	            Print #f,Isotab(Iiso).C_Lifetime(K)
         	          #Else
         	            Print #f," "
         	          #EndIf  
                      Ilast = I+J*100
         	        Next
         	      End If
         	    End If   
              End If
            Next
          Next  
          Print #f,"      </Isomeric_yields>"
          Print #f,"    </FF_spin>"
    
      '   Output of Q-value spectrum
          Scope 
            Dim As Double Zaehler,Nenner
            Print #f,"    <Q_value>"
            Print #f,"------------------------------------------------------------"
            Print #f,"--- Q value spectrum (bins with zero content suppressed) ---"
            Print #f,"------------------------------------------------------------"
            Print #f," "
            Print #f,"   Q/MeV        Counts"
            Zaehler = 0
            Nenner = 0
            For I = Lbound(Qvalues) To Ubound(Qvalues)
              If Qvalues(I) > 0 Then
                Print #f,Using "########   ###########";I;Qvalues(I)
                Zaehler = Zaehler + I*Qvalues(I)
                Nenner = Nenner + Qvalues(I)
              End If 
            Next
            If B_Error_On = 1 And B_Error_Analysis = 0 Then
              Print #f,"Mean value: Q-bar =";Zaehler/Nenner; _
                                " MeV +-"; Csng(d_Q(0));" MeV" 
            Else 
              Print #f,"Mean value: Q-bar =";Zaehler/Nenner;" MeV" 
            End If  
            Print #f,"    </Q_value>"
          End Scope
       
    
    
      '   Output of TKE spectrum
          Dim As Double TKEmean_pre,TKEmean_post
          Scope 
            Dim As Double Zaehler_pre,Zaehler_post,Nenner_pre,Nenner_post,sqrsum_pre,sqrsum_post
            Print #f,"    <TKE>"
            Print #f,"--------------------------------------------------------------------------------"
            Print #f,"--- TKE spectrum (pre- and post-neutron) (bins with zero content suppressed) ---"
            Print #f,"--------------------------------------------------------------------------------"
            Print #f," "
            Print #f,"   TKE/MeV     Counts(pre)   Counts(post) "
            Zaehler_pre = 0
            sqrsum_pre = 0
            Nenner_pre = 0
            Zaehler_post = 0
            sqrsum_post = 0
            Nenner_post = 0
            For I = lbound(TKEpre) To ubound(TKEpre)
              If TKEpre(I) > 0 or TKEpost(I) > 0 Then
                Print #f,Using "########   ###########   ###########";I;TKEpre(I);TKEpost(I)
                Zaehler_pre = Zaehler_pre + I*TKEpre(I)
                Nenner_pre = Nenner_pre + TKEpre(I)
                Zaehler_post = Zaehler_post + I*TKEpost(I)
                Nenner_post = Nenner_post + TKEpost(I)
              End If 
            Next
            TKEmean_pre = Zaehler_pre/Nenner_pre
            TKEmean_post = Zaehler_post/Nenner_post
            If B_Error_On = 1 And B_Error_Analysis = 0 Then
              Print #f,"Mean values: TKE_pre =";Csng(TKEmean_pre); _
                                " MeV +-"; Csng(d_TKEpre(0));" MeV," 
              Print #f,"             TKE_post =";Csng(TKEmean_post); _
                                " MeV +-";Csng(d_TKEpost(0));" MeV"
            Else 
              Print #f,"Mean values: TKE_pre =";Csng(TKEmean_pre); _
                              " MeV, TKE_post =";Csng(TKEmean_post);" MeV" 
            End If     
            For I = lbound(TKEpre) To ubound(TKEpre)
              If TKEpre(I) > 0 or TKEpost(I) > 0 Then
                sqrsum_pre = sqrsum_pre + TKEpre(I) * (I - TKEmean_pre)^2
                sqrsum_post = sqrsum_post + TKEpost(I) * (I - TKEmean_post)^2
              End If
            Next I                   
            If sqrsum_pre > 0 and sqrsum_post > 0 then                       
              Print #f,"Standard deviation: sigma_TKE_pre =";Csng(sqr(sqrsum_pre/Nenner_pre));" MeV,"; _
                                      " sigma_TKE_post =";Csng(sqr(sqrsum_post/Nenner_post)); " MeV"       
            End If                                              
            Print #f,"    </TKE>"                    
          End Scope
    
    
      '   Output of TXE spectrum
          Scope 
            Dim As Double Zaehler,Nenner
            Print #f,"    <TXE>"
            Print #f,"---------------------------------------------------------"
            Print #f,"--- TXE spectrum (bins with zero content suppressed) ---"
            Print #f,"---------------------------------------------------------"
            Print #f," "
            Print #f,"   TXE/MeV      Counts"
            Zaehler = 0
            Nenner = 0
            For I = lbound(TotXE) To ubound(TotXE)
              If TotXE(I) > 0 Then
                Print #f,Using "########   ###########";I;TotXE(I)
                Zaehler = Zaehler + I*TotXE(I)
                Nenner = Nenner + TotXE(I)
              End If 
            Next
            If B_Error_On = 1 And B_Error_Analysis = 0 Then
              Print #f,"Mean value: TXE =";Csng(Zaehler/Nenner); _
                                 " MeV +-"; Csng(d_TKEpre(0));" MeV," 
            Else   
              Print #f,"Mean value: TXE =";Csng(Zaehler/Nenner);" MeV"
            End If   
            Print #f,"    </TXE>"
          End Scope
      
      '   Determine limits of AEkin
          Scope
            Dim As Integer Imin,Imax,Jmin,Jmax
            For I = 20 To 200
              For J = 1 To 300
                If AEkinpre(I,J) > 0 or AEkinpost(I,J) > 0 Then
                  Imin = I
                  Exit For, For
                End If
              Next
            Next 
            For I = 200 To 20 Step -1
              For J = 1 To 300
                If AEkinpre(I,J) > 0 or AEkinpost(I,J) > 0 Then
                  Imax = I
                  Exit For, For
                End If
              Next
            Next
            For J = 1 To 300
              For I = 20 To 200
                If AEkinpre(I,J) > 0 or AEkinpost(I,J) > 0 Then
                  Jmin = J
                  Exit For, For
                End If     
              Next
            Next 
            For J = 300 To 1 Step -1
              For I = 20 To 200 
                If AEkinpre(I,J) > 0 or AEkinpost(I,J) > 0 Then
                  Jmax = J
                  Exit For, For
                End If         
              Next
            Next    
          
      '     Output of AEkinpre
            Print #f,"    <A_Ekin>"
            Print #f,"------------------------------------"
            Print #f,"--- A-Ekin spectrum (pre-neutron)---"
            Print #f,"------------------------------------"
            Print #f," "
            Print #f,"2-dim. array: (A = ";Imin;" To ";Imax; _
                        " Step 1) (E = ";Jmin;" To ";Jmax;" Step 1)"  
            Print #f," "
            Print #f,"(The data are written according to the loop structure specified above."
            Print #f,"The last loop is the inner-most one. Line breaks are not related to the data structure!"
            Print #f," "
            K = 0
            For I = Imin To Imax
              For J = Jmin To Jmax
                K = K + 1
           '    IF AEkinpre(I,J) > 0 Then
                Print #f, AEkinpre(I,J);
                If K = 50 Then
                  K = 0
                  Print #f, " "
                End If
           '  End If 
              Next
            Next   
    
        
       '    Output of AEkinpost 
       '    (AEkinpost is not exact, neutron evaporation is only considered on average.)
            Print #f," "
            Print #f," "
            Print #f,"-------------------------------------"
            Print #f,"--- A-Ekin spectrum (post-neutron)---"
            Print #f,"-------------------------------------"
            Print #f," "
            Print #f,"2-dim. array: (A = ";Imin;" To ";Imax; _
                         " Step 1) (E = ";Jmin;" To ";Jmax;" Step 1)"  
            Print #f," "
            Print #f,"(The data are written according to the loop structure specified above."
            Print #f,"The last loop is the inner-most one. Line breaks are not related to the data structure!"
            Print #f," "
            K = 0
            For I = Imin To Imax
              For J = Jmin To Jmax
                K = K + 1
             '  IF AEkinpost(I,J) > 0 Then
                Print #f, AEkinpost(I,J);
                If K = 50 Then
                  K = 0
                  Print #f, " "
                End If
            '   End If 
              Next
            Next   
            Print #f," "
            Print #f,"    </A_Ekin>"
    
    
         '  Determine limits of ATKE
            For I = 20 To 300
              For J = 1 To 300
                If ATKEpre(I,J) > 0 or ATKEpost(I,J) > 0 Then
                  Imin = I
                  Exit For, For
                End If
              Next
            Next 
            For I = 300 To 20 Step -1
              For J = 1 To 300
                If ATKEpre(I,J) > 0 or ATKEpost(I,J) > 0 Then
                  Imax = I
                  Exit For, For
                End If
              Next
            Next
            For J = 1 To 300
              For I = 20 To 300
                If ATKEpre(I,J) > 0 or ATKEpost(I,J) > 0 Then
                  Jmin = J
                  Exit For, For
                End If     
              Next
            Next 
            For J = 300 To 1 Step -1
              For I = 20 To 300 
                If ATKEpre(I,J) > 0 or ATKEpost(I,J) > 0 Then
                  Jmax = J
                  Exit For, For
                End If         
              Next
            Next    
       
      '     Output of ATKEpre
            Print #f,"    <A_TKE>"
            Print #f,"------------------------------------"
            Print #f,"--- A-TKE spectrum (pre-neutron)---"
            Print #f,"------------------------------------"
            Print #f," "
            Print #f,"2-dim. array: (A = ";Imin;" To ";Imax; _
                          " Step 1) (E = ";Jmin;" To ";Jmax;" Step 1)"  
            Print #f," "
            Print #f,"(The data are written according to the loop structure specified above."
            Print #f,"The last loop is the inner-most one. Line breaks are not related to the data structure!"
            Print #f," "
            K = 0
            For I = Imin To Imax
              For J = Jmin To Jmax
                K = K + 1
           '    IF ATKEpre(I,J) > 0 Then
                Print #f, ATKEpre(I,J);
                If K = 50 Then
                  K = 0
                  Print #f, " "
                End If
           '    End If 
              Next J
            Next I   
    
        
      '     Output of ATKEpost 
      '     (ATKEpost is not exact, neutron evaporation is only considered on average.)
            Print #f," "
            Print #f," "
            Print #f,"-------------------------------------"
            Print #f,"--- A-TKE spectrum (post-neutron)---"
            Print #f,"-------------------------------------"
            Print #f," "
            Print #f,"2-dim. array: (A = ";Imin;" To ";Imax; _
                          " Step 1) (E = ";Jmin;" To ";Jmax;" Step 1)"  
            Print #f," "
            Print #f,"(The data are written according to the loop structure specified above."
            Print #f,"The last loop is the inner-most one. Line breaks are not related to the data structure!"
            Print #f," "
            K = 0
            For I = Imin To Imax
              For J = Jmin To Jmax
                K = K + 1
               'IF ATKEpost(I,J) > 0 Then
                Print #f, ATKEpost(I,J);
                If K = 50 Then
                  K = 0
                  Print #f, " "
                End If
         '      End If 
              Next
            Next   
            Print #f," "   
       
            Print #f,"    </A_TKE>"
       
            Print #f,"  </Prompt_results>"
          End Scope
    
    
    
          Dim As Integer ICHECK = 1
          If ICHECK = 1 Then
     /'     Control parameters '/
            Print #f, "  <Control>"
            Print #f, "Control parameters:"
            Print #f, "R_E_exc_Eb = ",R_E_exc_Eb      /' Energy above outer barrier '/
            Print #f, "Delta_S0 = ",Delta_S0          /' Shell at symmetry '/    
            Print #f, "P_Z_Mean_S1 = ",P_Z_Mean_S1    /' Mean Z of Mode 1 '/
            Print #f, "P_Z_Mean_S2 = ",P_Z_Mean_S2    /' Mean Z of Mode 2 '/
            Print #f, "P_Z_Mean_S3 = ",P_Z_Mean_S3    /' Mean Z of Mode 3 '/
            Print #f, "P_Z_Mean_S4 = ",P_Z_Mean_S4    /' Mean Z of Mode 4 '/
            Print #f, "P_Z_Mean_S5 = ",P_Z_Mean_S5    /' Mean Z of Mode 5 '/
            Print #f, "SigZ_Mode_0 = ",SigZ_Mode_0
            Print #f, "SigZ_Mode_1 = ",SigZ_Mode_1
            Print #f, "SigZ_Mode_2 = ",SigZ_Mode_2
            Print #f, "SigZ_Mode_3 = ",SigZ_Mode_3
            Print #f, "SigZ_Mode_4 = ",SigZ_Mode_4
            Print #f, "SigZ_Mode_5 = ",SigZ_Mode_5
            Print #f, "NC_Mode_0 = ", NC_Mode_0       /' Mean N of symm. Mode '/
            Print #f, "NC_Mode_1 = ", NC_Mode_1       /' Mean N of Mode 1 '/
            Print #f, "NC_MODE_2 = ", NC_Mode_2       /' Mean N of Mode 2 '/
            Print #f, "NC_Mode_3 = ", NC_Mode_3       /' Mean N of Mode 3 '/
            Print #f, "NC_Mode_4 = ", NC_Mode_4       /' Mean N of Mode 4 '/
            Print #f, "NC_Mode_5 = ", NC_Mode_5       /' Mean N of Mode 4 '/
            Print #f, "AC_Mode_0 = ", AC_Mode_0
            Print #f, "AC_Mode_1 = ", AC_Mode_1
            Print #f, "AC_Mode_2 = ", AC_Mode_2
            Print #f, "AC_Mode_3 = ", AC_Mode_3
            Print #f, "AC_Mode_4 = ", AC_Mode_4
            Print #f, "AC_Mode_5 = ", AC_Mode_5
            Print #f, "B_S1 = ", B_S1                 /' Barrier S1, relative to SL '/
            Print #f, "B_S2 = ", B_S2                 /' Barrier S2, relative to SL '/
            Print #f, "B_S3 = ", B_S3                 /' Barrier S3, relative to SL '/
            Print #f, "B_S4 = ", B_S4                 /' Barrier S4, relative to SL '/
            Print #f, "B_S5 = ", B_S5                 /' Barrier S5, relative to SL '/
            Print #f, "B_S11 = ", B_S11               /' Barrier S11, relative to SL '/
            Print #f, "B_S22 = ", B_S22               /' Barrier S22, relative to SL '/
            Print #f, "DES11ZPM = ", DES11ZPM         /' Mod. of eff. barrier due to ZPM in overlap '/ 
            Print #f, "Delta_NZ_Pol = ", Delta_NZ_Pol      /' Polarization for 132Sn '/
            Print #f, "Yield_Mode_0 = ", Yield_Mode_0    /' Relative yield of SL '/
            Print #f, "Yield_Mode_1 = ", Yield_Mode_1    /' Relative yield of S1 '/
            Print #f, "Yield_Mode_2 = ", Yield_Mode_2    /' Relative yield of S2 '/
            Print #f, "Yield_Mode_3 = ", Yield_Mode_3    /' Relative yield of S3 '/
            Print #f, "Yield_Mode_4 = ", Yield_Mode_4    /' Relative yield of S4 '/
            Print #f, "Yield_Mode_5 = ", Yield_Mode_5    /' Relative yield of S5 '/
            Print #f, "Yield_Mode_11 = ", Yield_Mode_11  /' Relative yield of S11 '/
            Print #f, "Yield_Mode_22 = ", Yield_Mode_22  /' Relative yield of S22 '/
            Print #f, "P_Pol_Curv_S0 = ", P_Pol_Curv_S0  /' Stiffness in N/Z '/
            Print #f, "T_Coll_Mode_0 = ", T_Coll_Mode_0  /' Effective collective temperature '/
            Print #f, "E_Exc_S0 = ", E_Exc_S0            /' Energy over eff. barrier of symmetric channel '/
            Print #f, "E_Exc_S1 = ", E_Exc_S1            /' Energy over eff. barrier of S1 channel '/
            Print #f, "E_Exc_S2 = ", E_Exc_S2            /' Energy over eff. barrier of S2 channel '/
            Print #f, "E_Exc_S3 = ", E_Exc_S3            /' Energy over eff. barrier of S3 channel '/
            Print #f, "E_Exc_S4 = ", E_Exc_S4            /' Energy over eff. barrier of S4 channel '/
            Print #f, "E_Exc_S5 = ", E_Exc_S5            /' Energy over eff. barrier of S5 channel '/
            Print #f, "E_exc_S11 = ", E_exc_S11          /' Energy over eff. barrier of S11 channel '/
            Print #f, "E_exc_S22 = ", E_exc_S22          /' Energy over eff. barrier of S22 channel '/
            Print #f, "E_POT_Scission = ", E_Pot_Scission /' Potential energy gain saddle-scission '/
            Print #f, "EINTR_Scission = ", EINTR_SCISSION   /' Intrinsic excitation energy at scission '/
            Print #f, "EEFFS1 = ", EEFFS1                /' Responsible for S1 reduction by pairing '/
            Print #f, "Sigpol_Mode_0 = ", Sigpol_Mode_0     /' Width of isobaric Z distribution '/
            Print #f, "Even-odd effect = ",EvenOdd       /' Enhanced production of even elements '/
            Print #f, "  </Control>"
    
          End If
    
    
    /'
          Scope
            Restore PU240T
            Dim As Integer Afirst, Alast, I, N
            Dim As Single Diff,Logdiff , Chilin, Chilog
            Read Afirst
            Read Alast
            Redim As Single VYA(Afirst to Alast)
            Redim As Single VDYA(Afirst to Alast)
            For I = Afirst to Alast
              Read VYA(I)
            Next
            For I = Afirst to Alast
              Read VDYA(I)
            Next    
            Chilin = 0
            Chilog = 0
            N = 0
            Print #f," A    ((Y_ENDF - Y_calc)/DY_ENDF)^2)"    
            For I = Afirst to Alast
              If Apost(I) > 0.01 And VYA(I) > 0.01 Then
                Diff = (VYA(I) - Apost(I)) / VDYA(I)
                Print #f, I, Diff^2        
                Chilin = Chilin + Diff^2
                Logdiff = 0.5 * Log(VYA(I)/Apost(I)) / Log( (VYA(I) + VDYA(I)) / (VYA(I) - VDYA(I)) )
                Chilog = Chilog + Logdiff^2
                N = N + 1
              End If
            Next
            Print #f, "Chi^2 = ", Chilin
            Print #f, "Chi^2 / N = ", Chilin/N 
             Chilin = Chilin / N
            Chilog = Chilog / N
          End Scope
     '/
          #ifdef B_delayed
            #Include "Branchings.bas"   ' Decay branchings for cumulative yields from JEFF3.3
                                       ' (some data updated but not extended)
           '#Include "Branchingsx.bas"  ' Decay branchings extended and updated
          #endif
    
          #If defined(B_delayed)
            If B_ENDF = 1 Then
              #Include "ENDF.bas" 
            End If
          #endif  
    
          If B_Error_Analysis = 0 And B_Fit = 0 Then   ' Not compatible with fit option
            B_Print_Chisquare = 1  ' Used in Plotting.bas
            Scope   
              Dim As Integer IENDFmem
              Dim As Integer Idone
              IENDFmem = IENDFall   ' temporary memory
              Print #f,"  <CHI_square>"
              Print #f,"Reduced CHI_square (GEF against evaluations and LOHENGRIN experiments)"
              Print #f,"FF post-neutron mass distribution"
              Print #f," "
              Print #f,"Masses with any yield smaller than ";Yield_threshold;"% not included."
              Idone = 0
              For IENDFall = 0 To 3
                #Include "Plotting.bas"
                If Chilin > 0 Then
                  If Idone = 0 Then Print #f," "
                  If Idone = 0 Then Print #f,"Uncertainties taken from evaluation/experiment"
                  Idone = 1
                  If IENDFall = 0 Then Print #f,"GEF --- ENDF/B-VII"
                  If IENDFall = 1 Then Print #F,"GEF --- JEFF 3.1.1"
                  If IENDFall = 2 Then Print #f,"GEF --- JEFF 3.3"
                  If IENDFall = 3 Then Print #f,"GEF --- LOHENGRIN experiment"
                  Print #f, "Chi-square = ";Chilin
                End If
              Next IENDFall  
              Idone = 0
              For IENDFall = 0 To 3
                #Include "Plotting.bas"
                If ChiGEFlin > 0 Then
                  If Idone = 0 Then Print #f," "
                  If Idone = 0 Then Print #f,"Uncertainties taken from GEF"
                  Idone = 1
                  If IENDFall = 0 Then Print #f,"GEF --- ENDF/B-VII"
                  If IENDFall = 1 Then Print #F,"GEF --- JEFF 3.1.1"
                  If IENDFall = 2 Then Print #f,"GEF --- JEFF 3.3"
                  If IENDFall = 3 Then Print #f,"GEF --- LOHENGRIN experiment"
                  Print #f, "Chi-square = ";ChiGEFlin
                End If
              Next IENDFall
              Print #f,"  </CHI_square>"
              IENDFall = IENDFmem
            End Scope   
            B_Print_Chisquare = 0  
          End If
    
          Printcomments
       
          If B_Double_Covar = 1 Then
            If I_Double_Covar = 1 Then
              Print #f," </GEF1>"
         '    Output of first system for option with correlations between 2 systems:
         '    The <GEF> block remains open.
            End If
            If I_Double_Covar = 2 Then
              Print #f," </GEF2>" ' Close <GEF2> block (2nd system)
              Print #f,"</GEF>"  ' Close <GEF> block
            End If  
          Else
            Print #f,"</GEF>"  ' Close <GEF> block.
          End If  
       
       /'*** Cumulation of external post-neutron nuclide yields: ***'/
          #ifdef B_delayed   
            CHDIR("External")
            Dim As Integer f_external
            Scope
              Dim As Integer N_count, I1, I2
              Dim As Integer I_Skip, I_Z, I_A, I_N
              Dim As Single R_yield
              Dim As String C_read
              Dim As UByte B_do = 0
              I_Skip = 0
      '       Print Csystem+".dat"
              If Fileexists(Csystem+".dat") Then
                Print "File "+Csystem+".dat with external post-neutron fragment yields found."
                Print "Reading data ..."
                Print " Z             A            Yield "
                f_external = Freefile
                Open  Csystem+".dat" for Input as #f_external
                Line Input #f_external, C_read
                Do While Left(Trim(C_read),1) = "'"
                  Print C_read
                  I_Skip = I_Skip + 1
                  Line Input #f_external, C_read
                Loop
                N_Count = CC_Count(C_read," ")
                If N_Count = 3 Then
                  For I1 = Lbound(_NZPOST,1) To Ubound(_NZPOST,1)
                    For I2 = Lbound(_NZPOST,2) To Ubound(_NZPOST,2)
                      _NZPOST(I1,I2) = 0
                    Next I2
                  Next I1  
                  Close #f_external
                  f_external = Freefile
                  Open  Csystem+".dat" for Input as #f_external
                  For I = 1 To I_Skip
                    Line Input #f_external, C_read
                  Next I
                  Do
                    Input #f_external, I_Z, I_A, R_Yield
                    Print I_Z, I_A, R_Yield
                    I_N = I_A - I_Z
                 '  NZPOST(I_N,I_Z) = R_Yield
                    Acc_NZPOST(I_N,I_Z,R_Yield)
                  Loop Until EOF(f_external)
                  B_do = -1
                Else 
                  B_do = 0
                  Print "<E> Format error in "+C_read          
                End If  
                Close #f_external
              End If
              CHDIR("..")
              If B_do Then ' calculate and print cumulative yields
                Print #f, "<External>"
                Print #f, "-----------------------------------------------------------------------------"
                Print #f, "--- Cumulation process starting from external post-neutron nuclide yields ---"
                Print #f, "-----------------------------------------------------------------------------"
                Print #f, "The initial population of isomeric states is taken from the isomeric ratios"
                Print #f, "of the GEF calculation."
                Print #f, " "
                #Include "Branchings.bas"
                Print #f, "</External>"
              End If
            End Scope
          #endif  
       
          Close #f
    
          /' *** Filling dmp folder with SATAN analyzer dumps *** '/
          Dim As Single Rsum
          If B_Error_Analysis = 0 Then
            Dim As Integer I,J

         /'   CdmpFolder = "Z"+Trim(Str(P_Z_CN))+"_A"+Trim(Str(P_A_CN))
            If I_E_iso > 0 Then
              If Abs(Emode) = 1 Then CdmpFolder = CdmpFolder + "f" + Trim(Str(I_E_iso))
              If Emode = 2 Then CdmpFolder = Cdmpfolder + "m" + Trim(Str(I_E_iso))
            End If
            If Emode = 2 Then CdmpFolder = CdmpFolder + "_n"
            If Emode = 12 Then CdmpFolder = CdmpFolder + "_p"
            If Abs(Emode) = 1 Then
              If P_E_exc = 0 Then
                CdmpFolder = Cdmpfolder + "_sf"
              Else
                If Emode = -1 Then
                  CdmpFolder = Cdmpfolder + "_fc"
                Else
                  CdmpFolder = Cdmpfolder + "_cf"
                End If
              End If
            End If
            If Emode = 3 Then
              CdmpFolder = CdmpFolder + "_ed"  ' energy distribution
            Else
              CdmpFolder = CdmpFolder + "_E"+Trim(Str(P_E_exc))+"MeV"
            End If  '/

            CdmpFolder = Csystem

            CHDIR("dmp")
            If CHDIR(CdmpFolder) Then
              MKDIR(CdmpFolder)
              Print "Subfolder \dmp\";CdmpFolder;" created."
            Else
              CHDIR("..")
            End If
            CHDIR("..")

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\EMpot.dmp" for Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: Potential energy close to the outer saddle"
            Print #DMPFile,"C: in the different fission-mode pockets."
            Redim A_Work(Lbound(EMpot,2) To Ubound(EMpot,2)) As Double
            For I = Lbound(EMpot,1) TO Ubound(EMpot,1)
              For J = Lbound(EMpot,2) To UBound(EMpot,2)
                A_Work(J) = EMpot(I,J)
              Next
              U_DMP_1D(A_Work(),"EMpot("+Trim(Str(I))+")", _
                    "Potential energy for mode "+Str(I))
            Next
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\Multichance.dmp" for Append As #DMPFile
            If Nmax_multi_chance > 0 Or Pmax_multi_chance > 0 Then
              Print #DMPFile,"GEF analyzer dump: Multi-chance fission (fission after the emission of gammas, neutrons and protons)"
              For I = 0 To Nmax_multi_chance
                For J = 0 To Pmax_multi_chance
                  Print #DMPFile,"C: Relative probability for fission after the emission of ";I;" neutrons and ";J;" protons: ";W_Chances(I,J)
                  For K = 0 To Emax_multi_chance
                    Emultichance(K) = E_multi_chance(I,J,K)
                  Next K
                  U_DMP_1D(Emultichance(),"Emultichance("+Trim(Str(I))+","+Trim(Str(J))+")", _
                    "E* at fission after the emission of "+Trim(Str(I))+" neutrons and "+Trim(Str(J))+" protons, " + _
                    Str(IEVTtot)+" fission events")
                Next J
              Next I
            Else
              Print #DMPfile,"C: Only first-chance fission occured."
            End If
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\Aprov.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: provisional pre-neutron mass distributions"
            U_DMP_1D(APROV(),"APROV"," Provisional pre-neutron mass distribution,"+Str(IEVTtot)+" fission events")
            Redim A_Work(Lbound(AMPROV,2) To Ubound(AMPROV,2)) As Double
            For I = Lbound(AMPROV,1) TO Ubound(AMPROV,1)
              For J = Lbound(AMPROV,2) To UBound(AMPROV,2)
                A_Work(J) = AMPROV(I,J)
              Next
              U_DMP_1D(A_Work(),"AMPROV("+Trim(Str(I))+")", _
                    "Provisional pre-neutron mass distribution per mode,"+Str(IEVTtot)+" fission events")
            Next
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\Apre.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: pre-neutron mass distributions"
            U_DMP_1D(APRE(),"APRE","Pre-neutron mass distribution,"+Str(IEVTtot)+" fission events")
            Redim A_Work(Lbound(AMPRE,2) To Ubound(AMPRE,2)) As Double
            For I = Lbound(AMPRE,1) TO Ubound(AMPRE,1)
              For J = Lbound(AMPRE,2) To UBound(AMPRE,2)
                A_Work(J) = AMPRE(I,J)
              Next
              U_DMP_1D(A_Work(),"AMPRE("+Trim(Str(I))+")", _
                    "Pre-neutron mass distribution per mode,"+Str(IEVTtot)+" fission events")
            Next
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\Apost.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: post-neutron mass distributions"
            U_DMP_1D(APOST(),"APOST","Post-neutron mass distribution, "+Str(IEVTtot)+" fission events")
         '   If B_Error_On Then U_DMP_1D(Err_APOST(),"Err_APOST","Post-neutron mass distribution, uncertainties")
            Redim A_Work(Lbound(AMPOST,2) To Ubound(AMPOST,2)) As Double
            For I = Lbound(AMPOST,1) TO Ubound(AMPOST,1)
              For J = Lbound(AMPOST,2) To UBound(AMPOST,2)
                A_Work(J) = AMPOST(I,J)
              Next
              U_DMP_1D(A_Work(),"AMPOST("+Trim(Str(I))+")", _
                    "Post-neutron mass distribution per mode, "+Str(IEVTtot)+" fission events")
            Next
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\Ekin.dmp" For Append As #DMPfile

            Print #DMPFile,"GEF analyzer dump: Energies of fission fragments"
            U_DMP_1D(Ekinpre(),"Ekinpre","Pre-neutron fragment kinetic energy, "+ _
                  Str(IEVTtot)+" fission events")
            Redim A_Work(Lbound(EkinpreM,2) To Ubound(EkinpreM,2)) As Double
            For I = Lbound(EkinpreM,1) TO Ubound(EkinpreM,1)
              For J = Lbound(EkinpreM,2) To UBound(EkinpreM,2)
                A_Work(J) = EkinpreM(I,J)
              Next
              U_DMP_1D(A_Work(),"EkinpreM("+Trim(Str(I))+")", _
                    "Pre-neutron fragment kinetic energy per mode, "+Str(IEVTtot)+" fission events")
            Next
            U_DMP_1D(EkinApre(),"EkinApre","Pre-neutron mean Ekin vs Apre, "+_
                  Str(IEVTtot)+" fission events")

            U_DMP_1D(Ekinpost(),"Ekinpost","Post-neutron fragment kinetic energy,"+ _
                  Str(IEVTtot)+" fission events")
            Redim A_Work(Lbound(EkinpostM,2) To Ubound(EkinpostM,2)) As Double
            For I = Lbound(EkinpostM,1) TO Ubound(EkinpostM,1)
              For J = Lbound(EkinpostM,2) To UBound(EkinpostM,2)
                A_Work(J) = EkinpostM(I,J)
              Next
              U_DMP_1D(A_Work(),"EkinpostM("+Trim(Str(I))+")", _
                    "Post-neutron fragment kinetic energy per mode, "+Str(IEVTtot)+" fission events")
            Next
            U_DMP_1D(EkinApost(),"EkinApost","Post-neutron mean Ekin vs Apost, "+_
                  Str(IEVTtot)+" fission events")

            U_DMP_1D(TKEpre(),"TKEpre","Pre-neutron total-kinetic-energy distribution,"+ _
                     Str(IEVTtot)+" fission events")
            Redim A_Work(Lbound(TKEpreM,2) To Ubound(TKEpreM,2)) As Double
            For I = Lbound(TKEpreM,1) TO Ubound(TKEpreM,1)
              For J = Lbound(TKEpreM,2) To UBound(TKEpreM,2)
                A_Work(J) = TKEpreM(I,J)
              Next
              U_DMP_1D(A_Work(),"TKEpreM("+Trim(Str(I))+")", _
                    "Pre-neutron TKE distribution per mode, "+Str(IEVTtot)+" fission events")
            Next

            U_DMP_1D(TKEpost(),"TKEpost","Post-neutron fragment total-kinetic-energy distribution,"+ _
                  Str(IEVTtot)+" fission events")
            Redim A_Work(Lbound(TKEpostM,2) To Ubound(TKEpostM,2)) As Double
            For I = Lbound(TKEpostM,1) TO Ubound(TKEpostM,1)
              For J = Lbound(TKEpostM,2) To UBound(TKEpostM,2)
                A_Work(J) = TKEpostM(I,J)
              Next
              U_DMP_1D(A_Work(),"TKEpostM("+Trim(Str(I))+")", _
                    "Post-neutron TKE distribution per mode, "+Str(IEVTtot)+" fission events")
            Next

            U_DMP_1D(TKEApre(),"TKEApre","Mean TKE versus Af, pre-neutron, "+ _
                  Str(IEVTtot)+" fission events")
            U_DMP_1D(TKEApost(),"TKEApost","Mean TKE versus Af, post-neutron, "+ _
                  Str(IEVTtot)+" fission events")
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\ZApre.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: nuclide distribution, pre-neutron (Zpre(Apre) and Npre(Z))"
            Rdatetime = Now
            Print #DMPFile,"C: Written on ";
            Print #DMPFile, Format( Rdatetime, "dd.mm.yyyy, hh:mm:ss")
            Print #DMPFile,"C: Calculation performed with GEF";C_GEF_Version
            Print #DMPFile,"C: Z distributions for fixed Ap$r$e$"
            For I = 20 To P_A_CN - 20
              IF APRE(I) > 0 Then
                Print #DMPFile,"S: Analyzer(Zpre(";Trim(Str(I));"))"
                Print #DMPFile,"C: Ap$r$e$ = ";Trim(Str(I))
                Print #DMPFile,"X: Zp$r$e$"
                Print #DMPFile,"Y: Yield (%)"
                Print #DMPFile,"A:  X     Y,LTR1"
                For J = 10 To P_Z_CN - 10
                  If ZISOPRE(I,J) > 0 Then
                    Print #f,Using "####    ###.######";_
            	             J;ZISOPRE(I,J)
                  End If
                Next J
              End If
            Next I
            Print #DMPFile," "
            Print #DMPFile,"C: Ap$r$e$ distributions for fixed Z"
            Rsum = 0
            For I = 10 To P_Z_CN - 10
              For J = 10 To P_A_CN - P_Z_CN - 10
                Rsum = Rsum + NZPRE(J,I)
              Next J
            Next I
            Rnorm = 200. / Rsum
            For I = 10 To P_Z_CN - 10
              IF ZPOST(I) > 0 Then
                Print #DMPFile,"S: Analyzer(Apre(";Trim(Str(I));"))"
                Print #DMPFile,"C: Z = ";Trim(Str(I))
                Print #DMPFile,"X: Ap$r$e$"
                Print #DMPFile,"Y: Yield (%)"
                Print #DMPFile,"A:  X+";Trim(Str(I));"     Y,LTR1"
                For J = 10 To P_A_CN - P_Z_CN - 10
                  IF NZPRE(J,I) > 0 Then
                    Print #f,Using "####    ###.######";_
            	             J;NZPRE(J,I) * Rnorm
                  End If
                Next J
              End If
            Next I
            Print #DMPFile," "
            Print #DMPFile,"C: Np$r$e$ distributions for fixed Z"
            For I = 10 To P_Z_CN - 10
              IF ZPOST(I) > 0 Then
                Print #DMPFile,"S: Analyzer(Npre(";Trim(Str(I));"))"
                Print #DMPFile,"C: Z = ";Trim(Str(I))
                Print #DMPFile,"X: Np$r$e$"
                Print #DMPFile,"Y: Yield (%)"
                Print #DMPFile,"A:  X     Y,LTR1"
                For J = 10 To P_A_CN - P_Z_CN - 10
                  IF NZPRE(J,I) > 0 Then
                    Print #f,Using "####    ###.######";_
            	             J;NZPRE(J,I) * Rnorm
                  End If
                Next J
              End If
            Next I
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\ZApost.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: nuclide distribution, post-neutron (Zpost(A) and Apost(Z))"
            Rdatetime = Now
            Print #DMPFile,"C: Written on ";
            Print #DMPFile, Format( Rdatetime, "dd.mm.yyyy, hh:mm:ss")
            Print #DMPFile,"C: Calculation performed with GEF";C_GEF_Version
            Print #DMPFile,"C: Z distributions for fixed Ap$o$s$t$"
            For I = 20 To P_A_CN - 20
              If APOST(I) > 0 Then
                Print #DMPFile,"S: Analyzer(Zpost(";Trim(Str(I));"))"
                Print #DMPFile,"C: Ap$o$s$t$ = ";Trim(Str(I))
                Print #DMPFile,"X: Zp$o$s$t$"
                Print #DMPFile,"Y: Yield (%)"
                Print #DMPFile,"A:  X     Y,LTBR1"
                For J = 10 To P_Z_CN - 10
                  If ZISOPOST(I,J) > 0 Then
                    Print #f,Using "####    ###.######";_
            	             J;ZISOPOST(I,J)
                  End If
                Next J
              End If
            Next I
            Print #DMPFile," "
            Print #DMPFile,"C: Ap$o$s$t$ distributions for fixed Z"
            Rsum = 0
            For I = 10 To P_Z_CN - 10
              For J = 10 To P_A_CN - P_Z_CN - 10
                Rsum = Rsum + NZPOST(J,I)
              Next J
            Next I
            Rnorm = 200. / Rsum
            For I = 10 To P_Z_CN - 10
              If ZPOST(I) > 0 Then
                Print #DMPFile,"S: Analyzer(Apost(";Trim(Str(I));"))"
                Print #DMPFile,"C: Z = ";Trim(Str(I))
                Print #DMPFile,"X: Ap$o$s$t$"
                Print #DMPFile,"Y: Yield (%)"
                Print #DMPFile,"A:  X+";Trim(Str(I));"     Y,LTBR1"
                For J = 10 To P_A_CN - P_Z_CN - 10
                  IF NZPOST(J,I) > 0 Then
                    Print #f,Using "####    ###.######";_
            	             J;NZPOST(J,I) * Rnorm
                  End If
                Next J
              End If
            Next I
            Print #DMPFile," "
            Print #DMPFile,"C: Np$o$s$t$ distributions for fixed Z"
         /'   Rsum = 0
            For I = 10 To P_Z_CN - 10
              For J = 10 To P_A_CN - P_Z_CN - 10
                Rsum = Rsum + NZPOST(J,I)
              Next J
            Next I
            Rnorm = 200. / Rsum  '/
            For I = 10 To P_Z_CN - 10
              If ZPOST(I) > 0 Then
                Print #DMPFile,"S: Analyzer(Npost(";Trim(Str(I));"))"
                Print #DMPFile,"C: Z = ";Trim(Str(I))
                Print #DMPFile,"X: Np$o$s$t$"
                Print #DMPFile,"Y: Yield (%)"
                Print #DMPFile,"A:  X      Y,LTBR1"
                For J = 10 To P_A_CN - P_Z_CN - 10
                  IF NZPOST(J,I) > 0 Then
                    Print #f,Using "####    ###.######";_
            	             J;NZPOST(J,I) * Rnorm
                  End If
                Next J
              End If
            Next I
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\Zpost.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: element distributions"
            U_DMP_1D(ZPOST(),"ZPOST","Fragment element distribution, "+ _
                  Str(IEVTtot)+" fission events,")
    '       If B_Error_On Then U_DMP_1D(Err_ZPOST(),"Err_ZPOST","Fragment element distribution, uncertainties")
            Redim A_Work(Lbound(ZMPOST,2) To Ubound(ZMPOST,2)) As Double
            For I = Lbound(ZMPOST,1) TO Ubound(ZMPOST,1)
              For J = Lbound(ZMPOST,2) To UBound(ZMPOST,2)
                A_Work(J) = ZMPOST(I,J)
              Next
              U_DMP_1D(A_Work(),"ZMPOST("+Trim(Str(I))+")", _
                    "Fragment element distribution per mode, "+Str(IEVTtot)+" fission events")
            Next
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\Npre.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: pre-neutron neutron-number distributions"
            U_DMP_1D(NPRE(),"NPRE","Fragment neutron distribution before prompt-neutron emission, "+ _
                  Str(IEVTtot)+" fission events")
            Redim A_Work(Lbound(NMPRE,2) To Ubound(NMPRE,2)) As Double
            For I = Lbound(NMPRE,1) TO Ubound(NMPRE,1)
              For J = Lbound(NMPRE,2) To UBound(NMPRE,2)
                A_Work(J) = NMPRE(I,J)
              Next
              U_DMP_1D(A_Work(),"NMPRE("+Trim(Str(I))+")", _
                    "Fragment neutron distribution before prompt-neutron emission per mode, "+ _
                       Str(IEVTtot)+" fission events")
            Next
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\Npost.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: post-neutron neutron-number distributions"
            U_DMP_1D(NPOST(),"NPOST","Fragment neutron distribution after prompt-neutron emission, "+ _
                Str(IEVTtot)+" fission events")
            Redim A_Work(Lbound(NMPOST,2) To Ubound(NMPOST,2)) As Double
            For I = Lbound(NMPOST,1) TO Ubound(NMPOST,1)
              For J = Lbound(NMPOST,2) To UBound(NMPOST,2)
                A_Work(J) = NMPOST(I,J)
              Next
              U_DMP_1D(A_Work(),"NMPOST("+Trim(Str(I))+")", _
                    "Fragment neutron distribution after prompt-neutron emission per mode, "+ _
                 Str(IEVTtot)+" fission events")
            Next
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\ZPolarpre.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: pre-neutron charge polarization"
            U_DMP_1D(ZPolarpre(),"ZPolarpre","<Z|Apre> - Apre*ZCN/ACN, "+ _
                  Str(IEVTtot)+" fission events")
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\ZPolarpost.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: post-neutron charge polarization"
            U_DMP_1D(ZPolarpost(),"ZPolarpost", _
                  "<Z|Apost> - Apost*ZCN/ACN, "+Str(IEVTtot)+" fission events")
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\SigmaZpre.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: pre-neutron width of charge polarization"
            U_DMP_1D(SigmaZpre(),"SigmaZpre", _
                  "Width (standard deviation) of Zpolarpre, "+Str(IEVTtot)+" fission events")
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\SigmaZpost.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: post-neutron width of charge polarization"
            U_DMP_1D(SigmaZpost(),"SigmaZpost", _
                  "Width (standard deviation) of Zpolarpost, "+Str(IEVTtot)+" fission events")
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\NA.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: neutron multiplicity vs. fragment mass"
            U_DMP_1D(NmultiApre(),"NmultiApre","Prompt-neutron multiplicity (from CN) vs. pre-neutron mass, "+ _
                  Str(IEVTtot)+" fission events")
            U_DMP_1D(NmultiApost(),"NmultiApost","Prompt-neutron multiplicity (from CN) vs. post-neutron mass, "+ _
                  Str(IEVTtot)+" fission events")
            U_DMP_1D(NApre(),"NApre","Prompt-neutron multiplicity (from fragments) vs. pre-neutron mass, "+ _
                  Str(IEVTtot)+" fission events")
            U_DMP_1D(NApost(),"NApost","Prompt-neutron multiplicity (from fragments) vs. post-neutron mass, "+ _
                  Str(IEVTtot)+" fission events")
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\EN.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: prompt-neutron energy spectra"
          /'If IEVTtot = Imulti Or Imulti = 0 Then
              U_DMP_1D(EN(),"EN","Total spectrum of prompt neutrons, "+Str(IEVTtot)+" fission events")
            End If'/
            If Imulti > 0 Then
              U_DMP_1D(_ENCN(),"ENCN","Spectrum of prompt neutrons before fission, "+ _
                  Str(Imulti)+" fission events")
              U_DMP_1D(_EPCN(),"EPCN","Spectrum of prompt protons before fission, "+ _
                  Str(Imulti)+" fission events")
            End If
            U_DMP_1D(_ENsci(),"ENsci","Spectrum of prompt neutrons emitted between saddle and scission, "+ _
                  Str(IEVTtot)+" fission events")
            U_DMP_1D(_ENfr(),"ENfr","Spectrum of prompt neutrons from fragments, "+ _
                  Str(IEVTtot)+" fission events")
            U_DMP_1D(ENlight(),"ENlight","Spectrum of prompt neutrons from light fragments, "+ _
                  Str(IEVTtot)+" fission events")
            U_DMP_1D(ENheavy(),"ENheavy","Spectrum of prompt neutrons from heavy fragments, "+ _
                  Str(IEVTtot)+" fission events")
            U_DMP_1D(ENApre(),"ENApre","Mean energy per fragment mass, pre-neutron, "+ _
                  Str(IEVTtot)+" fission events")
            U_DMP_1D(ENApost(),"ENApost","Mean energy per fragment mass, post-neutron, "+ _
                  Str(IEVTtot)+" fission events")
            U_DMP_1D(_ENfrfs(),"ENfrfs","Spectrum of prompt neutrons from fragments, "+ _
                  Str(IEVTtot)+" fission events")
            U_DMP_1D(ENAprefs(),"ENAprefs","Mean energy per fragment mass, pre-neutron, "+ _
                  Str(IEVTtot)+" fission events")
            U_DMP_1D(ENApostfs(),"ENApostfs","Mean energy per fragment mass, post-neutron, "+ _
                  Str(IEVTtot)+" fission events")
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\NP.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: multiplicity of prompt protons"
            U_DMP_1D(NP(),"NP","Multiplicity distribution of prompt protons, "+ _
                  Str(IEVTtot)+" fission events")
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\NN.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: multiplicity of prompt neutrons"
            U_DMP_1D(NN(),"NN","Multiplicity distribution of prompt protons, "+ _
                  Str(IEVTtot)+" fission events")
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\DPlocal.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: proton even-odd effect"
            U_DMP_1D(DPlocal(),"DPlocal","Fission-fragment even-odd effect in Z distribution, "+ _
                  Str(IEVTtot)+" fission events")
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\DNlocal.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: neutron even-odd effect after prompt-neutron emission"
            U_DMP_1D(DNlocal(),"DNlocal","Fission-fragment even-odd effect in Z distribution, "+ _
                  Str(IEVTtot)+" fission events")
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\Egamma.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: energies of prompt gammas"
            Print #DMPFile, "C: The energy spectrum shows the energies of the nuclear gamma transitions."
            Print #DMPFile, "C: Measured gamma spectra are smeared out by the doppler shift due to the"
            Print #DMPFile, "C: emission from the moving fragments."
            If Imulti > 0 Then
              U_DMP_1D(_EgammaCN(),"EgammaCN","Pre-saddle prompt-gamma spectrum, "+ _
                    Str(Imulti)+" fission events")
            End If
            U_DMP_1D(_Egamma(),"Egamma","Prompt-gamma spectrum from fragments, "+ _
                  Str(IEVTtot)+" fission events")
            U_DMP_1D(_EgammaL(),"EgammaL","Prompt-gamma spectrum from light fragments, "+ _
                  Str(IEVTtot)+" fission events")
            U_DMP_1D(_EgammaH(),"EgammaH","Prompt-gamma spectrum from heavy fragments, "+ _
                  Str(IEVTtot)+" fission events")
            U_DMP_1D(_EgammaE2(),"EgammaE2","Non-statistical prompt-gamma spectrum, "+ _
                  Str(IEVTtot)+" fission events")
            U_DMP_1D(_Egammatot(),"Egammatot","Spectrum of total gamma energy from fragments per fission, "+ _
                  Str(IEVTtot)+" fission events")
            Close #DMPFile
            #Ifdef B_delayed
              DMPFile = Freefile
              Open "dmp\"+CdmpFolder+"\Decay.dmp" For Append As #DMPFile
              U_DMP_1D(Qbeta(),"Qbeta","Distribution of Q beta values, "+ _
                  Str(IEVTtot)+" fission events")
              Close #DMPFile
            #Endif

            #Ifdef B_EgammaA
              DMPFile = Freefile
              Open "dmp\"+CdmpFolder+"\EgammaA.dmp" For Append As #DMPFile
              Print #DMPFile,"GEF analyzer dump: energies of prompt gammas with conditions on fragment mass"
              Print #DMPFile,"C: The gamma spectra are divided in different sections with different binsizes."
              Redim A_Work(Lbound(EgammaA2,1) To Ubound(EgammaA2,1)) As Double   ' range in Egamma
              For I = Lbound(EgammaA2,2) TO Ubound(EgammaA2,2)  ' range in A-pre
                If Apre(I) > 0 Then
                  For J = Lbound(EgammaA2,1) To Ubound(EgammaA2,1)  ' range in Egamma
                    A_Work(J) = EgammaA2(J,I)
                  Next J
                  U_DMP_1D(A_Work(),"EgammaA2("+Trim(Str(I))+")", _
                      "Prompt gamma spectrum emitted from fragments with mass A ="+Str(I)+", "+ _
                  Str(IEVTtot)+" fission events")
                End If
              Next I
              Redim A_Work(Lbound(EgammaA10,1) To Ubound(EgammaA10,1)) As Double
              For I = Lbound(EgammaA10,2) TO Ubound(EgammaA10,2)  ' range in A-pre
                If Apre(I) > 0 Then
                  For J = Lbound(EgammaA10,1) To Ubound(EgammaA10,1)  ' range in Egamma
                    A_Work(J) = EgammaA10(J,I)
                  Next J
                  U_DMP_1D(A_Work(),"EgammaA10("+Trim(Str(I))+")", _
                      "Prompt gamma spectrum emitted from fragments with mass A ="+Str(I)+", "+ _
                   Str(IEVTtot)+" fission events")
                End If
              Next I
              Redim A_Work(Lbound(EgammaA100,1) To Ubound(EgammaA100,1)) As Double
              For I = Lbound(EgammaA100,2) TO Ubound(EgammaA100,2)  ' range in A-pre
                If Apre(I) > 0 Then
                  For J = Lbound(EgammaA100,1) To Ubound(EgammaA100,1)  ' range in Egamma
                    A_Work(J) = EgammaA100(J,I)
                  Next J
                  U_DMP_1D(A_Work(),"EgammaA100("+Trim(Str(I))+")", _
                      "Prompt gamma spectrum emitted from fragments with mass A ="+Str(I)+", "+ _
                   Str(IEVTtot)+" fission events")
                End If
              Next I
              Redim A_Work(Lbound(EgammaA1000,1) To Ubound(EgammaA1000,1)) As Double
              For I = Lbound(EgammaA1000,2) TO Ubound(EgammaA1000,2)  ' range in A-pre
                If Apre(I) > 0 Then
                  For J = Lbound(EgammaA1000,1) To Ubound(EgammaA1000,1)  ' range in Egamma
                    A_Work(J) = EgammaA1000(J,I)
                  Next J
                  U_DMP_1D(A_Work(),"EgammaA1000("+Trim(Str(I))+")", _
                      "Prompt gamma spectrum emitted from fragments with mass A ="+Str(I)+", "+ _
                   Str(IEVTtot)+" fission events")
                End If
              Next I
              Close #DMPFile
            #EndIf

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\Ngammatot.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: gamma multiplicity per fission"
            U_DMP_1D(Ngammatot(),"Ngammatot","Gamma multiplicity per fission, "+ _
                  Str(IEVTtot)+" fission events")
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\Eexc.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: entrance energy above yrast line"
            U_DMP_1D(_Eentrance(),"Eentrance", _
                  "Energy of entrance line for gamma emission minus E(yrast line), "+ _
                  Str(IEVTtot)+" fission events")
            Redim A_Work(Lbound(EexcL2dlight,1) To Ubound(EexcL2dlight,1)) As Double
            For I = Lbound(EexcL2dlight,1) To Ubound(EexcL2dlight,1)    ' angular momentum
              For J = Lbound(EexcL2dlight,2) To Ubound(EexcL2dlight,2)
                A_Work(J) = EexcL2dlight(I,J)
              Next J
              U_DMP_1D(A_Work(),"EexcL2dlight("+Trim(Str(I))+")","Intrinsic excitation energy, "+_
              "over angular momentum")
            Next I
            Redim A_Work(Lbound(ErotL2dlight,1) To Ubound(ErotL2dlight,1)) As Double
            For I = Lbound(ErotL2dlight,1) To Ubound(ErotL2dlight,1)    ' angular momentum
              For J = Lbound(ErotL2dlight,2) To Ubound(ErotL2dlight,2)
                A_Work(J) = ErotL2dlight(I,J)
              Next J
              U_DMP_1D(A_Work(),"ErotL2dlight("+Trim(Str(I))+")","Rotational excitation energy, "+_
              "over angular momentum")
            Next I
            For I = Lbound(EexcL2dheavy,1) To Ubound(EexcL2dheavy,1)    ' angular momentum
              For J = Lbound(EexcL2dheavy,2) To Ubound(EexcL2dheavy,2)
                A_Work(J) = EexcL2dheavy(I,J)
              Next J
              U_DMP_1D(A_Work(),"EexcL2dheavy("+Trim(Str(I))+")","Intrinsic excitation energy, "+_
              "over angular momentum")
            Next I
            Redim A_Work(Lbound(ErotL2dheavy,1) To Ubound(ErotL2dheavy,1)) As Double
            For I = Lbound(ErotL2dheavy,1) To Ubound(ErotL2dheavy,1)    ' angular momentum
              For J = Lbound(ErotL2dheavy,2) To Ubound(ErotL2dheavy,2)
                A_Work(J) = ErotL2dheavy(I,J)
              Next J
              U_DMP_1D(A_Work(),"ErotL2dheavy("+Trim(Str(I))+")","Rotational excitation energy, "+_
              "over angular momentum")
            Next I
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\Qvalues.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: distribution of Q values"
            U_DMP_1D(Qvalues(),"Qvalues","Distribution of Q values,"+Str(IEVTtot)+" fission events")
            U_DMP_1D(QA(),"QA","Mean Q value over Ap$r$e$,"+Str(IEVTtot)+" fission events")
            Close #DMPFile

            DMPFile = Freefile
            Open "dmp\"+CdmpFolder+"\XE.dmp" For Append As #DMPFile
            Print #DMPFile,"GEF analyzer dump: excitation energies of final fragments"
            U_DMP_1D(TotXE(),"TotXE","Distribution of total excitation energies of final fragments, "+ _
             Str(IEVTtot)+" fission events")
            U_DMP_1D(EintrA(),"EintrA","Mean intrinsic energy per fragment at scission over Apre, "+ _
             Str(IEVTtot)+" fission events")
            U_DMP_1D(EdefoA(),"EdefoA","Mean deformation energy per fragment at scission over Apre, "+ _
             Str(IEVTtot)+" fission events")
            U_DMP_1D(EcollA(),"EcollA","Mean collective energy per fragment at scission over Apre, "+ _
             Str(IEVTtot)+" fission events")
            Redim A_Work(Lbound(Epart,3) To Ubound(Epart,3)) As Double
            For I = Lbound(Epart,1) To Ubound(Epart,1)  ' mode
              For J = Lbound(Epart,2) To Ubound(Epart,2)  ' light, heavy
                For K = Lbound(Epart,3) To Ubound(Epart,3)  ' pre-neutron mass
                  A_Work(K) = Epart(I,J,K)
                Next K
                U_DMP_1D(A_Work(),"Epart("+Trim(Str(I))+","+Trim(Str(J))+")","Partition of excitation energy at scission, "+_
                 "mode = "+Str(I)+", light(1)/heavy(2) fragment = "+Str(J)+" over Apre")
              Next J
            Next I
            Close #DMPFile
          End If  ' If B_Error_Analysis = 0

    
          If Bfilein Then
            await(I_thread,I_thread_max)   ' Protect reading and writing from/to file #fsync for 0.1 second
            fsync = freefile
            Open "ctl\sync.ctl" For Output As #fsync
            Print #fsync,0
            Close #fsync
          End If     
     
    NewPlot:
          If Bfilein = 0 And BGUI = 0 And B_Error_Analysis = 0 Then
            Print
      '     Print "Press 'ENTER' to continue or 'Q' to quit!" 
            If B_Double_Covar = 1 And I_Double_Covar = 1 Then
              Print "Calculation of the first system finished."
              If Bplot Then
                Print "Press 'ENTER' to calculate the second system!"
                Print "(Focus must be on graphic window.)"
              End If  
            Else
              If Bplot Then
                If BGUI Then
                Else
                  Print "GEF is in the loop for graphic output with the following steps:"
                  Print " 1. The first plot shows the mass yields on logarithmic scale."
                  Print " 2. Press 'ENTER' to proceed to linear scale."
                  Print " 3. Enter a number to chose other data for new plot:"
                  Print "    JEFF3.3=0,ENDF=1,JEFF3.1.1=2,LOHENGRIN=3, if available,"
                  Print "               and press 'ENTER',"
                  Print "    or enter 'Q' and press 'ENTER' to leave the plotting loop!"
                End If
                Print "Press 'ENTER' to continue!" 
                Print "(Focus must be on the graphic window.)"
              Else 
                End
              End If  
            End If  
          End If
          If B_fit = 0 Then
            #ifdef B_plotting 
              Dim As Integer Icontinue
              If Bplot Then
                P_Ylog = 1
                #Include "Plotting.bas"
                If BGUI Or (B_Double_Covar = 1) Then 
                Else
                  If B_Error_Analysis = 0 And I_E_Step = N_E_Steps Then
                    Input " ",Icontinue
                    P_Ylog = 0
                    #Include "Plotting.bas"
                    Input " ",kin
                    If Left(Ucase(kin),1) <> "Q" Then
                      If kin <> "" Then IENDFall = Val(kin)
                      Goto Newplot
                    End If
                  End If
                End If   
 '               Input " ",Icontinue
 '               Screen 0
              End If   
            #endif
          
      /'    Loop for error analysis '/
            If B_error_On = 1 Then
              I_Error = I_Error + 1
              If I_Error = N_Error_Max Then
                B_Error_Analysis = 0
              End If
              If I_Error <= N_Error_Max Then
                #ifdef B_plotting 
                  IF BPlot Then
                    Sleep 4000,1
                    Screen 0
                  End If
                #endif  
    
                If Bfilein Then
                  await(I_thread,I_thread_max)  ' Protect reading and writing from/to file #fsync for 0.1 second 
                  fsync = freefile
                  Open "ctl\sync.ctl" For Output As #fsync
                  Print #fsync,0
                  Close #fsync
                End If    
                        
                GoTo calcstart
              End If
            End If
            If CFileoutlmd <> "" Then
    '         Print "List-mode data written to ";CFileoutlmd_full  
    '         Close #foutlmd
            End If
          Else
            #ifdef B_plotting
              If Bplot Then
                P_Ylog = 0
                #Include "Plotting.bas"
              End If
            #endif    
          End If
          If Bfilein = -1 Then
            #ifdef B_plotting
              If Bplot Then
                Sleep 4000,1
                Screen 0
              End If
            #endif
          End If  
    
          If Bfilein Then
            await(I_thread,I_thread_max) ' protect file #fsync  
            fsync = freefile
            Open "ctl\sync.ctl" For Output As #fsync
            Print #fsync,0
            Close #fsync
          End If     
          
    
        Next I_E_step  ' I_E_step


 /'     #ifdef B_ENDF  
          If B_Error_Analysis = 1 Then Goto Skip4_ENDF_EOT
          #include "ENDF_EOT.bas"
          Skip4_ENDF_EOT:
        #endif '/
'       Print "Next I_Double_Covar"   
      Next I_Double_Covar   ' I_Double_Covar
'     Print "Next Iline"   
Next_Iline_label:
    Next Iline  ' Iline
'   Print "Next Ifilein"   
  Next Ifilein  'Ifilein
  If B_Fit Then
    If N_iter > 0 And I_Fitloop = N_iter Then
    ' End GEF 
    Else 
      
      If Bfilein Then
        await(I_thread,I_thread_max) ' protect file #fsync  
        fsync = freefile
        Open "ctl\sync.ctl" For Output As #fsync
        Print #fsync,0
        Close #fsync
      End If           

      GoTo Nextfitloop  
    End If
  End If    
' Print "Exit"
  /' Exit the code '/
 
 '  Dim As String kin
   
  If Bfilein Then
    kin = "Q"
  Else
    Do
      If BGUI = 0 Then
        kin = Inkey
      Else
        kin = "R"   
      End If
      If Ucase(kin) = "Q" Then Exit Do
      If kin <> "" Then Exit Do
      Sleep 1,1
    Loop
  End If
   
  #ifdef __FB_WIN32__
    If BGUI = 0 Then 
      #ifdef B_Plotting
        If BPlot Then
          SCREEN 0
        End If  
      #endif
    Else
      WaitSynch_GUI   ' Timing with GUI (wait for full second)
      fMutex = FreeFile
      Open "GUI\Mutex.ctl" For Output As #fMutex
      Print #fMutex, "0"    ' Allow input from GUI 
      Close #fMutex
    End If
  #else
    #ifdef B_Plotting
      If BPlot then
        SCREEN 0
      End If  
    #endif
  #endif
  If Ucase(kin) <> "Q" Then 
    If B_Error_Analysis = 1 Then
      B_Error_On = 1
    End If
    I_Error = 0  
    Goto StartAgain
  End If  
' Print "End of GEF, 'END' command"
' Sleep

  If Bfilein = -1 Then
    Print "GEF is terminated."
    Print "Press ENTER to close this window!"
    Sleep
  End If  
End

/'
/'<'/
  End SUB
/'>'/  
'/
/'<'/



  /' Subroutines '/       
       
       


/'<FO Include "BEexp.FOR" FO>'/
/'<FO Include "BEldmTF.FOR" FO>'/
/'<FO Include "ShellMO.FOR" FO>'/


/'>'/
     Function Find_IAnl(CAnl As String) As Integer
       Dim As Integer I
       Dim As Integer Ifound = 0
       Dim As String CAnl_short
       If Instr(CAnl,"(") > 0 Then
         CAnl_short = Left(CAnl,Instr(CAnl,"(")-1)
       Else
         CAnl_short = CAnl
       End If
       For I = 1 To N_Anl
         If Trim(Ucase(CAnl_short)) = Trim(Ucase(Anl_Par(I).C_Name)) Then
           Ifound = I
           Exit For
         End If 
       Next
       Find_IAnl = Ifound
     End Function

     Sub U_DMP_1D(Array() As Double,CName As String,Ccmt As String)
       Dim As Integer I_Anl
       Dim As String CLine
       Dim As String Cxloop
       Dim As Integer I,Imin,Imax
       Dim As Double Rdatetime
     
       Imax = Min(Lbound(Array)+10,Ubound(Array))
       For I = Ubound(Array) To Lbound(Array) + 1 Step -1
         If Array(I) <> 0 Then
           Imax = I
           Exit For
         End If  
       Next I
       Imin = Max(Lbound(Array),Ubound(Array)-10)
       For I = Lbound(Array) To Ubound(Array) - 1 Step 1
         If Array(I) <> 0 Then
           Imin = I
           Exit For
         End If  
       Next I  
              
       If Imax > 0.8 * Ubound(Array) Then Imax = Ubound(Array)
       If Imin < Lbound(Array) + 0.1 * (Ubound(Array)-Lbound(Array)) Then Imin = 0
       
       If Imin > Imax Then
         Imin = Lbound(Array)
         Imax = Lbound(Array) + 1
       End If
       
       Rdatetime = Now
       Print #DMPFile,"C: Written on ";
       Print #DMPFile, Format( Rdatetime, "dd.mm.yyyy, hh:mm:ss")
       Print #DMPFile,"C: Calculation performed with GEF";C_GEF_Version 
       I_Anl = Find_IAnl(CName)
       Print #DMPFile,"S: ANALYZER(";Trim(CName);")"
       Print #DMPFile,"S: TITLE(";Trim(Anl_Par(I_Anl).C_Title);")"
       Print #DMPFile,"S: COMMENT(";CdmpFolder;")"
       Print #DMPFile,"S: COMMENT(";Ccmt;")"
       If  Anl_Par(I_Anl).C_Type = "analog" Then
        Print #DMPFile,"C: Y_{i}(X_{i}) contains the integral over the spectrum between X_{i} and X_{i+1}."
       End If
       Print #DMPFile,"X: ";Trim(Anl_Par(I_Anl).C_xaxis)
       Print #DMPFile,"Y: ";Trim(Anl_Par(I_Anl).C_yaxis)
       Cxloop = "(X = "+Str(Imin*Anl_Par(I_Anl).R_ALim(1,3))+" TO " _
                +Str(Imax*Anl_Par(I_Anl).R_Alim(1,3))+" BY "_
                +Str(Anl_Par(I_Anl).R_ALim(1,3))+")"
       Print #DMPFile,"A: "+Cxloop+" Y,"+Trim(Anl_Par(I_Anl).C_Linesymbol) 
       CLine = Trim(Str(Csng(Array(Imin)))) + ","
       For I = Imin+1 To Imax
         CLine = CLine + Trim(Str(Csng(Array(I)))) 
         If I < Ubound(Array) Then CLine = CLine + ","  
         If Len(CLine) >=128 Then 
           Print #DMPFile,CLine
           CLine = ""
         End If  
       Next
       If CLine <> "" Then Print #DMPFile,CLine
       Print #DMPFile," "     
     End Sub
     
     Sub U_DMP_1D_S(Array() As Single,CName As String,Ccmt As String)
       Dim As Integer I_Anl
       Dim As String CLine
       Dim As String Cxloop
       Dim As Integer I,Imax
       Dim As Double Rdatetime
     
       Imax = Min(10,Ubound(Array))
       For I = Ubound(Array) To Lbound(Array) + 1 Step -1
         If Array(I) <> 0 Then
           Imax = I
           Exit For
         End If  
       Next I
       
       Rdatetime = Now
       Print #DMPFile,"C: Written on ";
       Print #DMPFile, Format( Rdatetime, "dd.mm.yyyy, hh:mm:ss")
       Print #DMPFile,"C: Calculation performed with GEF";C_GEF_Version 
       I_Anl = Find_IAnl(CName)
       Print #DMPFile,"S: ANALYZER(";Trim(CName);")"
       Print #DMPFile,"S: TITLE(";Trim(Anl_Par(I_Anl).C_Title);")"
       Print #DMPFile,"S: COMMENT(";CdmpFolder;")"
       Print #DMPFile,"S: COMMENT(";Ccmt;")"
       Print #DMPFile,"C: Y_{i}(X_{i}) contains the spectrum between X_{i} and X_{i+1}, when X continuous."
       Print #DMPFile,"X: ";Trim(Anl_Par(I_Anl).C_xaxis)
       Print #DMPFile,"Y: ";Trim(Anl_Par(I_Anl).C_yaxis)
       Cxloop = "(X = "+Str(Lbound(Array)*Anl_Par(I_Anl).R_ALim(1,3))+" TO " _
                +Str(Imax*Anl_Par(I_Anl).R_Alim(1,3))+" BY "+Str(Anl_Par(I_Anl).R_ALim(1,3))+")"
       Print #DMPFile,"A: "+Cxloop+" Y,"+Trim(Anl_Par(I_Anl).C_Linesymbol) 
       CLine = Trim(Str(Array(Lbound(Array)))) + ","
       For I = Lbound(Array) + 1 To Imax
         CLine = CLine + Trim(Str(Array(I))) 
         If I < Ubound(Array) Then CLine = CLine + ","  
         If Len(CLine) >=128 Then 
           Print #DMPFile,CLine
           CLine = ""
         End If  
       Next
       If CLine <> "" Then Print #DMPFile,CLine
       Print #DMPFile," "     
     End Sub 

/'<'/
   Function U_Valid(I_Z As Integer,I_A As Integer) As Ubyte
     Dim As Ubyte Ivalid
     /'<FO REAL*4 AME2020 FO>'/       
     Ivalid = 1
     If I_A / I_Z < 160.E0 / 76.E0 _
       Or I_A / I_Z > 289.E0/90.E0 _
       Then
       Ivalid = 0
     End If
     If I_Z < 76 Or I_Z > 120 Then
       Ivalid = 0  
     End If
     If AME2020(I_Z,I_A-1) - AME2020(I_Z,I_A) < 0.0 Then
       ' System is not bound.
       Ivalid = 0
     End If
     U_Valid = Ivalid  
' U_Valid = 1
   End Function     


   ' I_Z and I_A refer to the fissioning nucleus
   Function U_Delta_S0(I_Z As Integer,I_A As Integer) As Single
     Dim As Single Delta
     Delta = 0
     
  /'   If I_Z = 89 Then
       If I_A = 226 Then Delta = -0.3
     End If

     If I_Z = 90 Then
       If I_A = 228 Then Delta = 0.2
       If I_A = 229 Then Delta = 0.4
       If I_A = 230 Then Delta = 0.7
       If I_A = 231 Then Delta = 0.8
       If I_A = 232 Then Delta = 0.9
       If I_A = 233 Then Delta = 0.9 
     End If
     
   If I_Z = 92 Then Delta = 0.2    
     If I_Z = 92 And I_A = 233 Then Delta = 0.4    
     If I_Z = 92 And I_A = 234 Then Delta = 0.4     
          
     If I_Z >= 93 Then Delta = -0.3   '/
     U_Delta_S0 = Delta    
   End Function       


  Function Getyield(E_rel As Single,E_ref As Single,E_shell As Single, dE_defo As Single, _
                   T_low As Single,T_high As Single, T_high_mac As Single,I_Mode As Integer) As Single
         /' E_rel: Energy relative to the fission-channel-specific barrier. '/
         /' E_ref: technical quantity, avoids numerical problems. '/
         /' E_shell: microscopic shell effect (washed out at high E*) '/
         /' T_low: Effective temperature below barrier '/
         /' T_high: Effective temperature above barrier '/
         Dim As Single Exp1
         Dim As Single Yield
         Dim As Single E_trans = 8.0 ' Transition energy from CT to FG
         Dim As Single E_backshift = 3 
         Dim As Single F_trans, F_mod
         Dim As Single Rho_mac
         Dim As Single S_mac_CT, S_mac_FG, S_CT, S_FG, S_mac_trans, S_trans, DS_trans, DS

     Exp1 = E_rel/T_low - E_ref/0.4   ' energy far below barrier
                     ' Subtraction of E_ref/0.4 to prevent numerical problems.
     If Exp1 < -50 Then
       Yield = 0
     Else
       Yield = Exp(E_rel / T_high - E_ref/0.4) * 1.E0 / _
          (1.E0 + Exp(-E_rel/ (T_high*T_low/(T_high-T_low) ) ) )
     End If
     ' The following block was an attempt to use a matching Fermi-gas level density
     ' above the critical pairing energy. It is not used, because it was not possible
     ' to match the temperatures (below and above) at the matching energy sufficiently well.
/'     If I_Mode = 4 Then
       If E_rel > E_trans Then
         S_trans = E_trans/T_high            ' const. T entropy (with shell) at transition energy from real g.s.
         S_mac_trans = (E_trans + E_shell)/T_high_mac  ' const. T entropy (without shell) from macrosc. g.s.
         DS_trans = S_trans - S_mac_trans    ' remaining shell effect at transition energy in const. T. regime
                    ' (difference in S = ratio in level density)
         DS = DS_trans _
           * exp(- (E_rel - E_trans) / 18.5 ) _    ' washing out with increasing E*
           * (TRusanov(E_trans+E_shell,I_A_CN) / TRusanov(E_rel+E_shell,I_A_CN) )  

         S_mac_FG = 2 * sqr(0.094 * I_A_CN * (E_rel + E_shell)) _
                      + S_mac_trans - 2 * sqr(0.094 * I_A_CN * (E_trans + E_shell)) _
                      - E_ref/0.4

         S_FG = S_mac_FG + DS
         
'Print "*", DS_trans,DS         
'S_FG = S_mac_FG + DS_trans

' print "*"; E_rel;E_shell;E_backshift       
' print "*";  2 * sqr(0.094 * I_A_CN *(E_rel + E_shell - E_backshift)); _
'              2 * sqr(0.094 * I_A_CN * (E_trans + E_shell - E_backshift));"*" 
' print E_rel;" ";E_shell;T_high;T_high_mac;S_trans;S_mac_trans;DS;DS_trans;S_mac_FG;S_FG; _
'   (TRusanov(E_trans - E_backshift,I_A_CN) / TRusanov(E_rel - E_backshift,I_A_CN) )  
' Print E_backshift;I_A_CN;E_trans;E_shell
' sleep 
 Print "*", Yield, exp(S_FG)
         Yield = exp(S_FG) 
       End If
 '    End If   '/
     Getyield = Max(Yield,0.0)

  End Function


    Function F1(Z_S_A As Single) As Single
      /' Fit to the lower part of the data '/
      Dim As Single Result
      Result = exp(-9.05E0 + 4.58E0 * Log(Z_S_A/2.3E0))
      F1 = Result
    End Function
    Function F2(Z_S_A As Single) As Single
      /' Fit to the upper part of the data '/
      Dim As Single Result
      Result = exp(12.08E0 - 3.27E0 * Log(Z_S_A/2.3E0))
      F2 = Result
    End Function

  Function Masscurv(Z As Single, A As Single, RL As Single, kappa As Single, _
                       kappa4 As Single) As Single
     /'  Fit to  Data of Fig. 7 of                                             '/
     /'  "Shell effect in the symmetric-modal fission of pre-actinide nuclei"  '/
     /'  S. I. Mulgin, K.-H. Schmidt, A. Grewe, S. V. Zhdanov                  '/
     /'  Nucl. Phys. A 640 (1998) 375 '/
     /' (From fit of the width of the mass distributions.) '/                                         
    Dim As Single RI, Result1, Result2, Result
    Dim As Single RIref  
    Dim Z_square_over_A As Single
    Dim ZsqrA As Single
    Dim As Single c_rot = 600.0
    /'<FO REAL*4 F1 FO>'/
    /'<FO REAL*4 F2 FO>'/

    Z_square_over_A = Z^2/A
    RI = (A - 2*Z)/A
    RIref = (226.0 - 2*91.0)/226.0
    ZsqrA = Z_square_over_A * (1.E0 - kappa * RI^2- kappa4 * RI^4) / _
       (1.E0 - kappa * RIref^2 - kappa4 * RIref^4) _
        + c_rot * RL^2 / A^(7.0/3.0)  /' Hasse & Myers '/
 /'     + 0.0017 * RL^2 '/

    Result1 = F1(ZsqrA)
    Result2 = F2(ZsqrA) 
    Result = Min(Result1,Result2)
    Masscurv = Result
  End Function

  Function Masscurv1(Z As Single, A As Single, RL As Single, kappa As Single, _
               kappa4 As Single) As Single
     /'  Fit to  Data of Fig. 7 of                                             '/
     /'  "Shell effect in the symmetric-modal fission of pre-actinide nuclei"  '/
     /'  S. I. Mulgin, K.-H. Schmidt, A. Grewe, S. V. Zhdanov                  '/
     /'  Nucl. Phys. A 640 (1998) 375 '/
     /' (The left part assumed to be valid for the yields of the fission channels.) '/ 
    Dim As Single RI,Result1, Result2, Result 
    Dim As Single RIref
'    Dim As Single A,A_central,Z
    Dim Z_square_over_A As Single
    Dim ZsqrA As Single
    Dim As Single c_rot = 600.0
    Dim As Single SNmac,SPmac
    /'<FO REAL*4 F1 FO>'/
    /'<FO REAL*4 F2 FO>'/
    /'<FO REAL*4 LYMASS FO>'/
    

'A_central = -28.8156 + Z * 2.86587  ' Stability line for heavy nuclei        

    Z_square_over_A = Z^2/A
    RI = (A - 2*Z)/A
    ZsqrA = Z_square_over_A * (1.E0 - kappa * RI^2)  
    SNmac = Lymass(Z,A-1.0,0.0) - Lymass(Z,A,0.0)
    SPmac = Lymass(Z-1.0,A-1.0,0.0) - Lymass(Z,A,0.0)
    ZsqrA = ZsqrA + c_rot * RL^2 / A^(7.0/3.0)  
 
    If ZsqrA < 36.0 Then   ' adjusted to Y(S2) in light nuclei (80<Z<92)
      ZsqrA = ZsqrA + 0.9 * (36.0 - ZsqrA)  
    End If   

    Result1 = F1(ZsqrA) 
    ZsqrA = Z_square_over_A * (1.E0 - kappa * RI^2)  
    Result2 = F2(ZsqrA) 
    Result = Min(Result1,Result2)
    Result = Result * Exp(0.26 * Abs(Snmac - Spmac))    ' fits 226Th(em,f)
    Masscurv1 = Result 
  End Function 

  Function Masscurv2(Z As Single, A As Single, RL As Single, kappa As Single, _
               kappa4 As Single) As Single
     /'  Fit to  Data of Fig. 7 of                                             '/
     /'  "Shell effect in the symmetric-modal fission of pre-actinide nuclei"  '/
     /'  S. I. Mulgin, K.-H. Schmidt, A. Grewe, S. V. Zhdanov                  '/
     /'  Nucl. Phys. A 640 (1998) 375 '/
     /' (The left part assumed to be valid for the yields of the fission channels.) '/ 
     /' Special phenomenological version, only for fission channel around Z=36 '/
    Dim As Single RI,Result1, Result2, Result 
    Dim As Single RIref
'    Dim As Single A,A_central,Z
    Dim Z_square_over_A As Single
    Dim ZsqrA As Single
    Dim As Single c_rot = 600.0
    Dim As Single SNmac,SPmac
    /'<FO REAL*4 F1 FO>'/
    /'<FO REAL*4 F2 FO>'/
    /'<FO REAL*4 LYMASS FO>'/
    

'A_central = -28.8156 + Z * 2.86587  ' Stability line for heavy nuclei        

    Z_square_over_A = Z^2/A
    RI = (A - 2*Z)/A
    ZsqrA = Z_square_over_A * (1.E0 - kappa * RI^2)  
 /' SNmac = Lymass(Z,A-1.0,0.0) - Lymass(Z,A,0.0)
    SPmac = Lymass(Z-1.0,A-1.0,0.0) - Lymass(Z,A,0.0)
    ZsqrA = ZsqrA + 0.6*(Snmac - Spmac) '/
    ZsqrA = ZsqrA + c_rot * RL^2 / A^(7.0/3.0)  
 
    If ZsqrA < 36.0 Then   ' adjusted to Y(S2) in light nuclei (80<Z<92)
      ZsqrA = ZsqrA + 0.9 * (36.0 - ZsqrA)  
    End If   

    Result1 = F1(ZsqrA) 
    ZsqrA = Z_square_over_A * (1.E0 - kappa * RI^2)  
    Result2 = F2(ZsqrA) * 2  ' fits 180Hg, E*=10 MeV
 '   Result2 = F2(ZsqrA) 
    Result = Min(Result1,Result2)
    Masscurv2 = Result 
  End Function 

  Function De_Saddle_Scission(Z_CN_in As Single,A_CN_in As Single, _
       ESHIFTSASCI As Single) As Single
    /' Energy release between saddle and scission '/
    /' M. Asghar, R. W. Hasse, J. Physique C 6 (1984) 455 '/
    Dim As Single Zsquare_over_Athird
    Dim As Single Result
    Dim As Single R_odd_even
    Zsquare_over_Athird = Z_CN_in^2 / A_CN_in^0.333333
    Result = (31.E0 - 11.E0) / (1550.E0 - 1300.E0) * _
             (Zsquare_over_Athird - 1300.E0 + ESHIFTSASCI) + 11.E0
       ' This formula with ESHIFTSASCI = 0 is the parameterisation of the results
       ' of Ashgar and Hasse, JPC 6 (1984) 455, see 
       ' F. Rejmund, A. V. Ignatyuk, A. R. Junghans, K.-H. Schmidt
       ' Nucl. Phys. A 678 (2000) 215  
    Result = max(Result,0.0)
    De_Saddle_Scission = Result
  End Function

  Function TKE_Viola(Z_CN As Single, A_CN As Single) As Single
    /' TKE fit from Viola et al.,,Phys. Rev. C 31 (1985) 1550 '/
    Dim As Single Result
    Result = 0.1189 * Z_CN^2 / A_CN^0.333333 + 7.3  ' Formula from Viola, 1985
    TKE_Viola = Result 
  End Function

  Function TEgidy(A As Single,DU As Single,Fred As Single) As Single
    /' Temperature parameter of the constant-temperature formula for the
       nuclear level density.
       Input parameters: A = Mass number of nucleus
                         DU = Shell effect (corrected for pairing:P=0 for odd-A nuclei)
       From "Correlations between the nuclear level density parameters"
         Dorel Bucurescu, Till von Egidy
         Phys. Rev. C 72 (2005) 067304    and
            "Systematics of nuclear level density parameters"
         Dorel Bucurescu, Till von Egidy
         J. Phys. G: Nucl. Part. Phys. 31 (2005) S1675 and
            "Systematics of nuclear level density parameters"
         Till von Egidy, Dorel Bucurescu
         Phys. Rev. C 72 (2005) 044311 '/
    Dim As Single Temp_smooth,Temp,T_Fac
    Dim As Single F_damping = 0.8  ' 0.8 adjusted to A-yields 235U(n,f), En=14MeV
  ' Temp_smooth = 17.45E0 / (A^0.666667E0)   
  ' Temp = (17.45E0 - 0.51E0 * DU + 0.051 * DU^2) / (A^0.666667E0)
    Temp_smooth = 1.0 / (0.0570 * A^0.6666667)
    Temp = 1.0 / ( (0.0570 + 0.00193*F_damping*DU) * A^0.6666667)  ' from  PRC 80 (2009) 054310 
    T_Fac = Temp / Temp_smooth
    Temp = Temp * Fred  /' (For influence of deformation) '/
    TEgidy = Temp
  End Function


  Function TRusanov(E As Single, A As Single) As Single
     /' Fermi-gas level density, parameterisation of Rusanov et al. '/
     Dim As Single Emin = 8  ' critical pairing energy
     Dim As Single Eeff 
       If E < Emin Then 
         Eeff = Emin    ' Introduced Sept. 2021
       Else 
         Eeff = E
       EndIf  
       TRusanov = sqr(E / (0.094E0 * A) )
  End Function

  Function LyMass(Z As Single,A As Single,beta As Single) As Single

     /' liquid-drop mass, Myers & Swiatecki, Lysekil, 1967  '/
     /' pure liquid drop, without pairing and shell effects '/

     /' On input:    Z     nuclear charge of nucleus        '/
     /'              N     number of neutrons in nucleus    '/
     /'              beta  deformation of nucleus           '/
     /' On output:   binding energy of nucleus              '/
 
     /'<FO Const As Single pi = 3.14159 FO>'/
     Dim As Single N
     Dim As Single alpha
     Dim As Single XCOM,XVS,XE,EL

     N = A - Z
     alpha = sqr(5.E0/(4.E0*pi)) * beta
     XCOM = 1.E0 - 1.7826E0 * ((A - 2.E0*Z)/A)^2
            /' factor for asymmetry dependence of surface and volume term '/
     XVS = - XCOM * (15.4941E0*A _
                   - 17.9439E0*A^(2.E0/3.E0)*(1.E0+0.4E0*Alpha^2))
            /' sum of volume and surface energy '/
     XE = Z^2 * (0.7053E0/A^(1.E0/3.E0)*(1.E0-0.2E0*Alpha^2) _
                  - 1.1529E0/A)
     EL = XVS + XE
  /'   EL = EL + LyPair(Z,A); '/
     LyMass = EL
   END Function


   Function LyPair(Z As Integer,A As Integer) As Single
     /' Calculates pairing energy '/
     /' odd-odd nucleus:   Lypair = 0 '/
     /' even-odd nucleus:  Lypair = -12/sqr(A) '/
     /' even-even nucleus: Lypair = -2*12/sqr(A) '/
    Dim As Single E_PAIR

     E_PAIR = - 12.E0 / sqr(Csng(A)) _
          * Csng( ( (Z+1) Mod 2 + (A-Z+1) Mod 2) )

     Lypair = E_PAIR
   END Function


   Function TFPair(Z As Integer,A As Integer) As Single
     /' Pairing energy from Thomas-Fermi model of Myers and Swiatecki '/
     /' Shifted that TFPair is zero for odd-odd nuclei '/
     Dim As Integer N
     Dim As Single E_Pair
     N = A - Z
     IF Z Mod 2 = 0 And N Mod 2 = 0 Then /' even-even '/
        E_Pair = - 4.8E0 / Z^0.333333E0 - 4.8E0 / N^0.333333E0 + 6.6E0 / A^0.666666E0
     EndIf
     If Z Mod 2 = 0 And N Mod 2 = 1 Then /' even Z, odd N '/
        E_Pair = - 4.8E0 / Z^0.333333E0 + 6.6E0 / A^0.666666E0
     EndIf
     If Z Mod 2 = 1 And N Mod 2 = 0 Then /' odd Z, even N '/
        E_Pair = - 4.8E0 / N^0.333333E0 + 6.6E0 / A^0.666666E0
     EndIf
     If Z Mod 2 = 1 And N Mod 2 = 1 Then /' odd N, odd N '/
        E_Pair = 0.0
     EndIf
     TFPair = E_Pair
   End Function


   Function Pmass(Z As Single,A As Single,beta As Single) As Single
    /' Liquid-drop model of Pearson, 2001 '/
     Dim As Single N,EA,BE
     Dim As Single avol = -15.65
     Dim As Single asf = 17.63
     Dim As Single r0 = 1.233
     Dim As Single asym = 27.72
     Dim As Single ass = -25.60
     Dim As Single alpha
     /'<FO Const As Single pi = 3.14159 FO>'/     

      N = A - Z
      alpha = sqr(5.E0/(4.E0*pi)) * beta
      EA = avol + asf * A^(-0.333333)*(1.E0+0.4E0*Alpha^2) _
           + 0.6E0 * 1.44E0 * Z^2 / (A^1.333333 * r0 )*(1.E0-0.2E0*Alpha^2) _
           + (asym + ass * A^(-0.333333)) * (N-Z)^2 / A^2
      BE = EA * A
      Pmass = BE
   End Function


   Function FEDEFOP(Z As Single,A As Single,beta As Single) As Single
     /' According to liquid-drop model of Pearson 2001 '/
      Dim As Single asf = 17.63
      Dim As Single r0 = 1.233
      Dim As Single N,Alpha
     /'<FO Const As Single pi = 3.14159 FO>'/      

      N = A - Z
      alpha = sqr(5.E0/(4.E0*pi)) * beta
      FEDEFOP = asf * A^(0.666667)*(0.4E0*Alpha^2) _
              - 0.6E0 * 1.44E0 * Z^2 / (A^0.333333 * r0 )*(0.2E0*Alpha^2)
   End Function

   
   Function FEDEFOLys(Z As Single,A As Single,beta As Single) As Single
       /'<FO REAL*4 LYMASS FO>'/
       FEDEFOLys = Lymass(Z,A,beta) - Lymass(Z,A,0.0)
   End Function


   Function LDMass(Z As Single,A As Single,beta As Single) As Single
     Dim As Single N,BEtab
     /'<FO REAL*4 LYMASS FO>'/
     /'<FO REAL*4 FEDEFOLYS FO>'/
     /'<FO REAL*4 BEldmTF FO>'/
     /'<FO REAL*4 BEexp FO>'/
       N = A - Z
       If BEexp(CInt(N),CInt(Z)) > -1.E10 Then
           ' Take only values from BEldmTF, where experimental masses are available, because
           ' the values for exotic nuclei seem not to be reliable.
         BEtab = BEldmTF(CInt(N),CInt(Z))  ' Values from Thomas-Fermi model (Myers+Swiatecki)
           ' The values in BEtab are the negative binding energies! 
           ' Pairing in Thomas Fermi masses is zero for Z,N even ! 
         BEtab = BEtab + FEDEFOLys(Z,A,beta)     
       Else   
          BEtab = Lymass(Z,A,beta)
       End If
       Betab = Betab + 2.0 * 12.0 / sqr(Csng(A)) - 0.00001433*Z^2.39
       LDMass = Betab
   End Function

   Public Function AME2020(IZ As Integer,IA As Integer) As Single
      ' Masses from the 2020 mass evaluation, complemented by TF masses
      ' and Lysekil masses.
      Dim As Single BEexpval
      Dim As Single Z,A,N
      Dim As Integer INeu
      Static As Integer Izaehl
      /'<FO REAL*4 LYPAIR FO>'/
      /'<FO REAL*4 U_SHELL FO>'/
      /'<FO REAL*4 LDMASS FO>'/
      /'<FO REAL*4 BEexp FO>'/
      INeu = IA - IZ
      A = Csng(IA)
      Z = Csng(IZ)
      N = A - Z
      BEexpval = BEexp(INeu,IZ) 
      If BEexpval > -1.E10 Then
        AME2020 = BEexpval
      Else
        AME2020 = Ldmass(Z,A,0.0) + U_SHELL(IZ,IA) + Lypair(IZ,IA)
      End If  
   End Function

   Function U_SHELL(Z As Integer,A As Integer) As Single
      Dim As Integer N
      Dim As Single Res
      /'<FO REAL*4 ShellMO FO>'/
      N = A - Z
      Res = ShellMO(N,Z)  
      If Res > 0.0 Then Res = 0.3 * Res     ' KHS (12. Feb. 2012)
     '      ' The positive shell effects for deformed nuclei seem to be too positive
            ' This gives too many high-energetic prompt neutrons.
     U_SHELL = Res
   End Function

   Function U_SHELL_exp(IZ As Integer, IA As Integer) As Single
      Dim Res As Single
      Dim As Single Z,A
      /'<FO REAL*4 LDMASS FO>'/
      /'<FO REAL*4 LYPAIR FO>'/
      /'<FO REAL*4 AME2020 FO>'/
      Z = Csng(IZ)
      A = Csng(IA)
   '   Res = 2.0 * ( AME2020(IZ,IA) - Lypair(IZ,IA) - LDMass(Z,A,0.0) ) _
   '          - 0.25 * ( AME2020(IZ,IA-1) - Lypair(IZ,IA-1) - LDMass(Z,A-1.0,0.0) ) _
   '          - 0.25 * ( AME2020(IZ,IA+1) - Lypair(IZ,IA+1) - LDMass(Z,A+1.0,0.0) ) _
   '          - 0.25 * ( AME2020(IZ+1,IA+1) - Lypair(IZ+1,IA+1) - LDMass(Z+1.0,A+1.0,0.0) ) _
   '          - 0.25 * ( AME2020(IZ-1,IA-1) - Lypair(IZ-1,IA-1) - LDMass(Z-1.0,A-1.0,0.0) )
      Res = 0.5 * ( AME2020(IZ,IA) - Lypair(IZ,IA) - LDMass(Z,A,0.0) ) _
             + 0.125 * ( AME2020(IZ,IA-1) - Lypair(IZ,IA-1) - LDMass(Z,A-1.0,0.0) ) _
             + 0.125 * ( AME2020(IZ,IA+1) - Lypair(IZ,IA+1) - LDMass(Z,A+1.0,0.0) ) _
             + 0.125 * ( AME2020(IZ+1,IA+1) - Lypair(IZ+1,IA+1) - LDMass(Z+1.0,A+1.0,0.0) ) _
             + 0.125 * ( AME2020(IZ-1,IA-1) - Lypair(IZ-1,IA-1) - LDMass(Z-1.0,A-1.0,0.0) )
      U_SHELL_exp = Res             
   End Function

 Function U_SHELL_EO_exp(IZ As Integer, IA As Integer) As Single
     ' Returns experimental shell and even-odd staggering,
     ' just the difference of experimental and macroscopic mass.
      Dim Res As Single
      Dim As Single Z,A
      /'<FO REAL*4 LDMASS FO>'/
      /'<FO REAL*4 LYPAIR FO>'/
      /'<FO REAL*4 AME2020 FO>'/
      Z = Csng(IZ)
      A = Csng(IA)
      Res = AME2020(IZ,IA) - LDMass(Z,A,0.0) 
      U_SHELL_EO_exp = Res             
   End Function



   Function U_MASS(Z As Single,A As Single) As Single
     /' LD + congruence energy + shell (no pairing) '/
     Dim As Single BE
     /'<FO REAL*4 U_SHELL FO>'/
     /'<FO REAL*4 LDMASS FO>'/
     If Z < 0 Or A < 0 Then
       Print "U_Mass: Z, A",Z,A
     End If
     BE = Ldmass(Z,A,0.0)  + U_SHELL(CInt(Z),CInt(A))
  '    BE = AME2020(Cint(Z),Cint(A)) - Lypair(Z,A)
  '    BE = Lymass(Z,A,0.0) + U_Shell(CInt(Z),CInt(A))     
  '    BE = Lymass(Z,A,0.0)  
     U_MASS = BE
   End Function


   Function ECOUL(Z1 As Single,A1 As Single,beta1 As Single,Z2 As Single,A2 As Single, _
                     beta2 As Single,d As Single) _
                     As Single

      /' Coulomb potential between two nuclei                    '/
      /' surfaces are in a distance of d                         '/
      /' in a tip to tip configuration                           '/

      /' approximate formulation                                 '/
      /' On input: Z1      nuclear charge of first nucleus       '/
      /'           A1      mass number of irst nucleus   '/
      /'           beta1   deformation of first nucleus          '/
      /'           Z2      nuclear charge of second nucleus      '/
      /'           A2      mass number of second nucleus  '/
      /'           beta2   deformation of second nucleus         '/
      /'           d       distance of surfaces of the nuclei    '/

       Dim As Single N1,N2,recoul
       Dim As Single dtot
       Dim As Single r0 = 1.16

      N1 = A1 - Z1
      N2 = A2 - Z2
      dtot = r0 *( (Z1+N1)^0.3333333E0 * (1.E0+0.6666667E0*beta1) _
             + (Z2+N2)^0.3333333E0 * (1.E0+0.6666667E0*beta2) ) _
             + d
      REcoul = Z1 * Z2 * 1.44E0 / dtot

      ECOUL = REcoul
   END Function


   Function beta_light(Z As Integer,betaL0 As Single,betaL1 As Single) As Single
      /' Deformation of light fission fragment for S1 and S2 '/
      /' Systematic correlation Z vs. beta for deformed shells '/
      /' Z of fission fragment '/
     Dim As Single beta
     beta = (Z - betaL0) * betaL1/20.E0 
     beta_light = beta
   End Function


   Function beta_heavy(Z As Integer,betaH0 As Single,betaH1 As Single) As Single
      /' Deformation of heavy fission fragment for S2 '/
      /' Systematic correlation Z vs. beta for deformed shells '/
      /' Z of fission fragment '/
     Dim As Single beta
     beta = (Z - betaH0) * betaH1/20.E0 
     beta_heavy = beta
   End Function



   Function Z_equi(ZCN As Integer,A1 As Integer,A2 As Integer, _
           beta1 As Single,beta2 As Single,d As Single,Imode As Integer) _
           As Single
    /' Determines the minimum potential of the scission-point configuration
       represented by two deformed nuclei divided by a tip distance d.
       A1, A2, beta1, beta2, d are fixed, Z1 is searched for and returned on output.  '/

       /' ZCN: Z of fissioning nucleus '/
       /' A1: A of first fission fragment '/
       /' A2: A of second fission fragment '/
       /' beta1: deformation of first fission fragment '/
       /' beta2: deformation of second fission fragment '/
       /' d: tip distance '/

             Dim As Single RZ_equi
             Dim As Single RA1,RA2,RZCN,RACN
             Dim As Single Z1UCD,Z2UCD
             Dim As Single re1,re2,re3,eps1,eps2,DZ_Pol /' help variables '/
             /'<FO REAL*4 ECOUL FO>'/
             /'<FO REAL*4 LYMASS FO>'/

          RA1 = Csng(A1)
          RA2 = Csng(A2)
          RZCN = Csng(ZCN)       
          RACN = RA1 + RA2
          Z1UCD = RA1 / (RA1 + RA2) * RZCN
          Z2UCD = RZCN - Z1UCD
          re1 = LyMass( Z1UCD-1.E0, RA1, beta1 ) + _
                LyMass( Z2UCD+1.E0, RA2, beta2 ) + _
                ECoul( Z1UCD-1.E0, RA1, beta1, _
                       Z2UCD+1.E0, RA2, beta2, d )
          re2 = LyMass( Z1UCD, RA1, beta1) + _
                LyMass( Z2UCD, RA2, beta2) + _
                ECoul( Z1UCD, RA1, beta1, _
                       Z2UCD, RA2, beta2, d )
          re3 = LyMass( Z1UCD+1.E0, RA1, beta1 ) + _
                LyMass( Z2UCD-1.E0, RA2, beta2 ) + _
                ECoul( Z1UCD+1.E0, RA1, beta1, _
                       Z2UCD-1.E0, RA2, beta2, d )
          eps2 = ( re1 - 2.E0*re2 + re3 ) / 2.E0
          eps1 = ( re3 - re1 ) / 2.E0
          DZ_Pol = -eps1 / ( 2.E0 * eps2 )
          
          If DZ_Pol > 2 Or DZ_Pol < -2 Then DZ_Pol = 0

          RZ_equi = Z1UCD + DZ_POL   
          Z_equi = RZ_equi
   End Function


   Sub Beta_opt_light(A1 As Single,A2 As Single,Z1 As Single,Z2 As Single, _
             d As Single,beta2_imposed As Single,ByRef beta1_opt As Single)
    /' Determines the optimum deformation of the light fragment when the deformation of the
       heavy fragment is imposed. '/

       Dim As Single beta1,dbeta1,beta1_prev,beta1_next
       Dim As Single Uguess,Uplus,Uminus,Uprev,Unext
       Dim As Integer I
       /'<FO REAL*4 ECOUL FO>'/
       /'<FO REAL*4 LYMASS FO>'/

    /' List('Beta_opt_light called with ');
       List(A1,A2,Z1,Z2,d,beta2_imposed,beta1_opt);
      DCL Byes Bit(1) aligned;
       Call GPYES('Continue',Byes); '/
       beta1 = 0.5
       dbeta1 = 0.01
       Uguess = LyMass(Z1, A1, beta1) + _
                Lymass(Z2, A2, beta2_imposed) + _
                ECoul(Z1, A1, beta1, Z2, A2, beta2_imposed, d)
       Uplus  = LyMass(Z1, A1, beta1 + dbeta1) + _
                Lymass(Z2, A2, beta2_imposed) + _
                ECoul(Z1, A1, beta1 + dbeta1, Z2, A2, beta2_imposed, d)
       Uminus = LyMass(Z1, A1, beta1 - dbeta1) + _
                Lymass(Z2, A2, beta2_imposed) + _
                ECoul(Z1, A1, beta1 - dbeta1, Z2, A2, beta2_imposed, d)
       If Uplus > Uguess And Uminus > Uguess then
         beta1_opt = beta1
       Else
         If Uplus < Uguess then dbeta1 = 0.01
         If Uminus < Uguess then dbeta1 = -0.01
         Unext = Uguess
         beta1_next = beta1
         For I = 1 to 10000
           beta1_prev = beta1_next
           Uprev = Unext
           beta1_next = beta1_prev + dbeta1
           Unext = LyMass(Z1, A1, beta1_next) + _
                   Lymass(Z2, A2, beta2_imposed) + _
                   ECoul(Z1, A1, beta1_next, Z2, A2, beta2_imposed, d)
           If Unext >= Uprev Then Exit For
/'>'/           
           If I = 10000 Then Print "Loop overflow in Beta_opt_light"
/'<'/           
         Next
         beta1_opt = beta1_prev
       EndIf

   End Sub


   Sub Beta_Equi(A1 As Single,A2 As Single,Z1 As Single,Z2 As Single,d As Single, _
                  beta1prev As Single,beta2prev As Single, _
                  ByRef beta1opt As Single,ByRef beta2opt As Single)
    /' Determines the minimum potential of the scission-point configuration
       represented by two deformed nuclei, divided by a tip distance d.
       A1, A2, Z1, Z2, d are fixed, beta1 and beta2 are searched for and returned on output '/

       Dim As Integer B_analytical = 0
        ' Switch to use the analytical approximation 
        ' that replaces the long numerical calculation.
       Dim As Single x,y,xcoul
       Dim As Single xcoul236U = 1369.64

       Dim As Single beta1,beta2
       
 '      Dim As Double U,Uprev,Ulast,Ubest,Uopt
       Dim As Single U,Uprev,Ulast,Ubest,Uopt

 '      Dim As Double sbeta1,sbeta2
       Dim As Single sbeta1 = 0
       Dim As Single sbeta2 = 0

       Dim As Integer N,N1,N2
       Dim As Integer Nopt = 0

 '      Dim As Double eps = 5.E-4
       Dim As Single eps = 5.E-4

       Dim As Integer I
       /'<FO REAL*4 LYMASS FO>'/       
       /'<FO REAL*4 ECOUL FO>'/       
       
       If B_analytical = 0 Then  ' Numerical algorithm

         beta1 = beta1prev
         beta2 = beta2prev
         Uprev = LyMass(Z1,A1,beta1) + LyMass(Z2,A2,beta2) + ECoul(Z1,A1,beta1,Z2,A2,beta2,d)
         Uopt = Uprev

         /' Test slope of variation of U '/
         beta1 = beta1prev + eps
         U = 1.E30

         beta2 = beta2prev
 '       For beta2 = beta2prev to 0 Step -eps
         For I = 1 To Int(beta2prev/eps)
           beta2 = beta2 - eps
           Ulast = U
           U = LyMass(Z1,A1,beta1) + LyMass(Z2,A2,beta2) + ECoul(Z1,A1,beta1,Z2,A2,beta2,d)
           If U > Ulast Then
             Exit For
           Else
             Ubest = U
           EndIf
         Next
         If Ubest < Uopt Then
           Uopt = Ubest
           sbeta1 = eps
           sbeta2 = -eps
         EndIf

         U = 1.E30
         beta2 = beta2prev
   '     For beta2 = beta2prev To 1 Step eps
         For I = 1 To Int((1 - beta2prev)/eps)
           beta2 = beta2 + eps
           Ulast = U
           U = LyMass(Z1,A1,beta1) + LyMass(Z2,A2,beta2) + ECoul(Z1,A1,beta1,Z2,A2,beta2,d)
           If U > Ulast Then
              Exit For
           Else
             Ubest = U
           EndIf
         Next
         If Ubest < Uopt Then
           Uopt = Ubest
           sbeta1 = eps
           sbeta2 = eps
         End If
  
         beta1 = beta1prev - eps
         U = 1.E30
         beta2 = beta2prev
     '   For beta2 = beta2prev To 0 Step -eps
         For I = 1 To Int(beta2prev/eps)
           beta2 = beta2 - eps
           Ulast = U
           U = LyMass(Z1,A1,beta1) + LyMass(Z2,A2,beta2) + ECoul(Z1,A1,beta1,Z2,A2,beta2,d)
           If U > Ulast Then
             Exit For
           Else
             Ubest = U
           End If
         Next
         If Ubest < Uopt Then
           Uopt = Ubest
           sbeta1 = -eps
           sbeta2 = -eps
         EndIf

         U = 1.E30
         beta2 = beta2prev
   '     For beta2 = beta2prev To 1 Step eps
         For I = 1 To Int((1-beta2prev)/eps)
           beta2 = beta2 + eps
           Ulast = U
           U = LyMass(Z1,A1,beta1) + LyMass(Z2,A2,beta2) + ECoul(Z1,A1,beta1,Z2,A2,beta2,d)
           If U > Ulast Then
              Exit For
           Else
             Ubest = U
           EndIf
         Next
         If Ubest < Uopt Then
           Uopt = Ubest
           sbeta1 = -eps
           sbeta2 = eps
         EndIf

         Ubest = Lymass(Z1,A1,beta1prev) + Lymass(Z2,A2,beta2prev) _
               + ECoul(Z1,A1,beta1prev,Z2,A2,beta2prev,d)
         U = Lymass(Z1,A1,beta1prev+Csng(sbeta1)) + _
            Lymass(Z2,A2,beta2prev+Csng(sbeta2)) + _
            ECoul(Z1,A1,beta1prev+sbeta1,Z2,A2,beta2prev+Csng(sbeta2),d)

'   L1:
         For N = 1 To 1000

'   L2:
           For N1 = 1 To N
             N2 = N-N1
             beta1 = beta1prev + sbeta1*N1
             beta2 = beta2prev + sbeta2*N2
             U = LyMass(Z1,A1,beta1) + _
                 LyMass(Z2,A2,beta2) + _
                 ECoul(Z1,A1,beta1,Z2,A2,beta2,d)
             If U < Ubest Then
               Ubest = U
               beta1opt = beta1
               beta2opt = beta2
               Nopt = N
             EndIf
           Next
           If N-Nopt > 2 Then Exit For
         Next

/'>'/
         If N > 998 Then Print #f,"Beta_Equi not converged: ",Z1,N
/'<'/

       Else  ' Analytical approximation
        ' Must be adapted if the relevant parameters of GEF are modified!
         xcoul = (Z1 + Z2)^2 / (A1 + A2)^(1.0/3.0)
         x = (Z1 / (Z1 + Z2))^(xcoul/xcoul236U)
         y = 1.2512E-4 + 0.00122851*x - 0.00267707*x^2 _
                       + 0.00372901*x^3 - 0.00219903*x^4       
         beta1opt = y * xcoul 

         x = (Z2 / (Z1 + Z2))^(xcoul/xcoul236U)
         y = 1.2512E-4 + 0.00122851*x - 0.00267707*x^2 _
                       + 0.00372901*x^3 - 0.00219903*x^4       
         beta2opt = y * xcoul 
       
       End If

   End Sub

/'>'/

   Sub Eva(Ilh As Integer,Z_CN As Single,A_CN As Single,E_INIT As Single, _
       T As Single, J_Frag As Single, _
       Byref Z_RES As Single,ByRef A_RES As Single, ByRef E_FINAL As Single,  _
       Array_En() As Single, Array_Tn() As Single, Array_Eg0() As Single)
       
            /' Energies in EVA do not include Erot. '/
            /' Z_CN,A_CN,E_init       Parameters of initial nucleus '/
            /' Z_RES,A_RES,E_FINAL    after evaporation '/
            /' T temperature coefficient of level density (not used) '/
            /' Array_En       kinetic energies of neutrons '/
            /' Array_Tn       neutron emission time after scission '/
            /' Array_Eg0      energies of statistical gammas '/
            Static As Single E_MIN = 0   /' Final energy for evaporation chain '/
            Dim As Single SN,SNeff,SNmean,SNexp,SNld        /' Neutron separation energy '/
            Dim As Single RShell
            Dim As Integer ITry,Ifold
            Dim As Single Ai,Af,Zi,Zf,Ni,Nf,Ei,Ef
            Dim As Single bshift,bshiftm
            Dim As Single Tm, Td, Tf, Tmean, TCT
            Dim As Single Gamma_n,Gamma_g,Pgamma
            Dim As Single rho,rhom
            Dim As Single alev
            Dim As Single g_koeff
            Dim As Single E_kin
            Dim As Single Tn,Tn_acc
            Dim As Single J_crit  ' critical angular momentum (disappearance of pairing)
            Dim As Single J_crit_shell
            Dim As Single Fred   ' reduction of pairing gap by ang. momentum
            Dim As Single Fred_shell  ' reduction of shell
            Dim As Integer In_gamma  ' counts gammas for Array_Eg0()
            Dim As Ubyte B_Expmass = 1  ' use mass model or empirical masses

          E_min = E_Final
            
          In_gamma = 0       
            
          Tn_acc = 0  
' Tn_acc = 60
          Ifold = 1

          Ai = A_CN
          Zi = Z_CN
          Ei = E_INIT
          
          J_crit = 12. * sqr(Ai/100.0) ' L. G. Moretto, Nucl. Phys. A 185 (1972) 145
      
          J_crit_shell = 30.
          
          If J_frag >= J_crit Then
            Fred = 0
          Else
            Fred = 0.65 * sqr(1.0 - J_frag/J_crit) ' L. G. Moretto, Nucl. Phys. A 185 (1972) 145
          End If
          
          If J_frag >= J_crit_shell Then
            Fred_shell = 0
          Else
            Fred_shell = 0.9 - J_frag/J_crit_shell
          End If  

          /' Shell effects included '/
          If B_Expmass = 0 Then
            SN = U_Mass(Zi,Ai-1.E0) + Fred * Lypair(Zi,Ai-1.E0) _
              - (U_Mass(Zi,Ai) + Fred * Lypair(Zi,Ai)) 
            SNeff = U_Mass(Zi,Ai-1.E0) - U_Mass(Zi,Ai)    ' with shells, without pairing
        '   SNmean = 0.5E0 * (U_Mass(Zi,Ai-2.E0) - U_Mass(Zi,Ai))
          Else
            SNexp = ( AME2020(Zi,Ai-1) - AME2020(Zi,Ai) )  ' empirical
            SNeff = U_Mass(Zi,Ai-1.E0) - U_Mass(Zi,Ai)    ' with shells, without pairing
            SNld = LDMass(Zi,Ai-1.E0,0.0) - LDmass(Zi,Ai,0.0) ' no shells, no pairing
            SN = Fred_shell * (Fred * SNexp + (1.0 - Fred) * SNeff) + (1.0 - Fred_shell) * SNld      
          End If 
     
          /' Shell effects excluded '/
      '   SN = LDMass(Zi,Ai-1.E0,0.0) + Lypair(Zi,Ai-1.E0) _
      '     - (LDMass(Zi,Ai,0.0) + Lypair(Zi,Ai)) 
      '   SNeff = LDMass(Zi,Ai-1.E0,0.0) - LDMass(Zi,Ai,0.0)  
          

          Zf = Zi
          Af = Ai
          Ef = Ei
          
          If Ei < SN Then Goto Raus

          Do
          
        /' Treat gamma competition '/
            Tm = U_temp(Zi,Ai,Ei,1,1,Tscale,Econd,Etrans)       ' emitting nucleus
            Td = U_temp(Zi,Ai-1,Ei-SNeff,1,1,Tscale,Econd,Etrans)

            If Ilh > 0 Then  ' Emission from fragments
              Gamma_g = 0.624 * Ai^1.6 * Tm^5    ' in meV (Ignatyuk, Bologna)
              Gamma_g = Gamma_g * 1.E-9        ' in MeV
            Else             ' Emission between saddle and scission
              Gamma_g = 0
            End If  
                        
            Tmean = (Tm + Td)/2
            
 '          Gamma_n = (Ai-1)^0.66667 * 0.0302 * Td^2 / exp(SNeff/Tmean)   ' in MeV (Moretto)
            Gamma_n = (Ai-1)^0.66667 * 0.13 * Td^2 / exp(SNeff/Td)  ' in MeV (Mor. PRC 54,3062)
            ' Cut the distribution at the ground-state energy:    
            Gamma_n = Gamma_n - (Ai-1)^0.66667 * 0.13 * Td^2 / exp((SNeff+Ei)/Td)   

            Tn = Pexp(0.658 / Gamma_n)   ' in units of 10^-21 s (hbar=0.658zs*MeV)
  ' ? Tn = Tn * 2      ' Due to pre-exponential factor of Maxwellian, Tn is about 2 times to large   
            Tn_acc = Tn_acc + Tn
            
            ' Influence on lev.dens. of pairing at low E*
            ' (Constant temperature assumed) -> moved to function
            If Ei-Sn < Abs(Fred * Lypair(Zi,Ai-1)) Then  ' rest energy below mean g.s. of odd-odd nuclei
              If Zi Mod 2 < 0.5 or (Ai-Zi-1) Mod 2 < 0.5 Then  ' even Z or even N
                Gamma_n = exp(-12.E0/sqr(Ai)/Td) * Gamma_n
              End If 
              If Zi Mod 2 < 0.5 and (Ai-Zi-1) Mod 2 < 0.5 Then  'n Z and even N
              ' For low level density below pairing gap in even-even nuclei
                Gamma_n = exp(-12.E0/sqr(Ai)/Td) * Gamma_n  
              End If    
            End If             
              /' Reduces the even-odd effect in neutron number 
                 due to low level density below the pairing gap '/

            Pgamma = Gamma_g / (Gamma_g + Gamma_n)   
  
            If RND < Pgamma Then  ' gamma will be emitted
              In_gamma = In_gamma + 1
              Scope
                Dim As Integer N
                Dim As Single Eg

                Eg = P_Egamma_high(Zi,Ai,Ei)      
   
                Array_Eg0(In_gamma) = Eg
   
                ' Accumulate E1 gammas
                N = CInt(Eg*1000)
                If N > 0 Then
                  Ngtot = Ngtot + 1
                  If Ilh = 1 Then Nglight = Nglight + 1
                  If Ilh = 2 Then Ngheavy = Ngheavy + 1
                  Egtot1000 = Egtot1000 + EG*1000
                  If N <= Ubound(_Egamma) Then    
            '        Egamma(N) = Egamma(N) + 1 
                    #Ifdef B_EgammaA 
                      StoreEgammaA(N,A_CN)
                    #Endif  
                  End If
                  Acc_Egamma(N,1)  
                End If  
                Ei = Ei - Eg        
              End Scope
            End If
              
            IF Ei-Sn <= E_MIN THEN
              Zf = Zi
              Af = Ai
              Ef = Ei
              Goto Raus
            End If

            ITry = 0
          Too_Low:
            ITry = ITry + 1
            If ITry < 99 Then
               Td = U_Temp(Zi,Ai-1,Ei-SNeff,1,1,Tscale,Econd,Etrans)
                  ' maximum residual energy of daughter nucleus (for En_kin = 0)
                
               E_kin = PMaxwellMod(Td,Ai-1)   /' Maxwell, with partial 1/v behaviour '/
               
               Tf = U_temp(Zi,Ai-1,Ei-E_kin-SNeff,1,1,Tscale,Econd,Etrans)
                  ' final energy of daughter nucleus with En_kin considered 
               
         '     If Ei-E_kin-2*Td > 10 Then   ' In Fermi-gas regime
              If Ei-E_kin-Td > 5 Then   ' to avoid Tf at negative energies
                If RND > sqr( Exp(E_kin/Td)/ Exp(E_kin/Tf) ) Then goto Too_low
     '           If RND > ( Exp(E_kin/Td)/ Exp(E_kin/Tf) ) Then goto Too_low
     '           If RND > ( Exp(E_kin/Td)/ Exp(E_kin/Tf) )^0.33333 Then goto Too_low   
     '           If RND > ( Exp(E_kin/Td)/ Exp(E_kin/Tf) )^0.25 Then goto Too_low
                 ' Modified Maxwell that adapts to the Fermi-gas regime

     '           If RND > ( Exp(E_kin/Td)^2/ Exp(E_kin/Tf) )^0.25 Then goto Too_low
                 ' adjusted to data, justification not clear
              End If   
 
            Else
              /' E_kin too high after several attemps '/
              /' no neutron emitted '/
              Af = Ai
              Zf = Zi
              Ef = Ei
                
              GOTO Raus
            EndIf

            If E_kin > Ei-SN Then
              /' E_kin from PMaxwell is not available '/
              /' Try again '/
              Goto Too_Low
            End If

            Af = Ai - 1
            Zf = Zi
            Ef = Ei - E_kin - SN

           /' ANAL(EN,E_kin);
              ANAL(ENM(I_MODE),E_kin); '/

            /' Shell effects included '/  
            If B_Expmass = 0 Then
              SN = (U_Mass(Zf,Af-1.E0) + Fred * Lypair(Zf,Af-1.E0)) _
                     - (U_Mass(Zf,Af) + Fred * Lypair(Zf,Af)) 
              SNeff = U_Mass(Zf,Af-1.E0) - U_Mass(Zf,Af)  
           '  SNmean = 0.5E0 * (U_Mass(Zf,Af-2.E0) - U_Mass(Zf,Af))
            Else
              SNexp = ( AME2020(Zf,Af-1) - AME2020(Zf,Af) )  ' empirical
              SNeff = U_Mass(Zf,Af-1.E0) - U_Mass(Zf,Af)    ' with shells, without pairing
              SNld = LDMass(Zi,Ai-1.E0,0.0) - LDmass(Zi,Ai,0.0) ' no shells, no pairing
              SN = Fred_shell * (Fred * SNexp + (1.0 - Fred) * SNeff) + (1.0 - Fred_shell) * SNld      
            End If
        
            /' Shell effects excluded '/  
         '   SN = LDMass(Zf,Af-1.E0,0.0) + Lypair(Zf,Af-1.E0) _
         '     - (LDMass(Zf,Af,0.0) + Lypair(Zf,Af)) 
         '   SNeff = LDMass(Zf,Af-1.E0,0.0) - LDMass(Zf,Af,0.0)          

            Ai = Af
            Zi = Zf
            Ei = Ef

            If Ifold < Lbound(Array_En) Or Ifold > Ubound(Array_En) Then
              Print "<W> Array_En out of bounds, Ifold = ";Ifold
            Else              
              Array_En(Ifold) = E_kin * (Af-1.E0) / Af
            End If  
            
            If Ifold < Lbound(Array_En) Or Ifold > Ubound(Array_En) Then
              Print "<W> Array_Tn out of bounds, Ifold = ";Ifold
            Else              
              Array_Tn(Ifold) = Tn_acc
            End If  
            Ifold = Ifold + 1
              

          Loop While Ei-SN > E_min
            
        Raus:  
          A_RES = Af
          Z_RES = Zf
          E_FINAL = MAX(Ef,0.0) 

   End Sub
   
   
  
   Function u_accel(A1 As Single,Z1 As Single,A2 As Single,Z2 As Single, _
      TKE As Single,E0 As Single,Tn As Single) As Single 
      ' returns the velocity of the fragment 1 after time Tn

      'Acceleration of fission fragments by their Coulomb field    

     ' natural constants
     Static As Single e2 = 1.44   ' MeV
     Static As Single u = 931.5  ' MeV / c^2 
     Static As Single hbarc = 197  ' MeV fm

     ' variables
     Dim As Single Ared,d0,v0
     Dim As Single d, t, dt, a, v, v1, E
     Dim As Single vinf         ' relative velocity at infinity

     Ared = A1 * A2 / (A1 + A2)
     vinf = sqr(TKE/Ared)         ' sqr(E/A), Ekin asymmptotic in MeV
     If t > 100 or TKE < E0 Then 
       v = vinf
       goto match
     End If

     d0 = e2 * Z1 * Z2 / (TKE-E0) ' fm   
     v0 = sqr(E0)   ' sqr(E/A), Ekin at scission in MeV

     d = d0
     v = 0
     dt = 0.01
     For t = 0 To 1 Step dt   ' in  10^-21 s
       if t >= Tn Then Goto match
       E = E0 + e2 * Z1 * Z2 * (1/d0 - 1/d)   ' MeV
       v = sqr(E/Ared)         ' sqr(E/A), E in MeV
       d = d + v * 14 * dt             ' in fm
     Next
     dt = 0.1
     For t = 1.1 To 10 Step dt   ' in  10^-21 s
       if t >= Tn Then Goto match
       E = E0 + e2 * Z1 * Z2 * (1/d0 - 1/d)   ' MeV
       v = sqr(E/Ared)         ' sqr(E/A), E in MeV
       d = d + v * 14 * dt             ' in fm
     Next
     dt = 1
     For t = 11 To 100 Step dt   ' in  10^-21 s
       if t >= Tn Then Goto match
       E = E0 + e2 * Z1 * Z2 * (1/d0 - 1/d)   ' MeV
       v = sqr(E/Ared)         ' sqr(E/A), E in MeV
       d = d + v * 14 * dt             ' in fm
     Next
     match:
     v1 = v * A2/(A1+A2)
     u_accel = v1  
   End Function
   
   
   Function P_Egamma_low(Zi as Single, Ai As Single, Ei As Single) As Single
   ' Random function, returns gamma energy in MeV
   ' For energies below Sn: no competition with neutrons
     Dim As Single Rres
     Dim As Integer N
     Dim As Single sigMax, Eg, Erest, rhorest, fg
     Dim As Single xran, yran
     Dim As Single Tm
     Dim As Single GammaExp
     
     Dim As Single betadef = 0
     Dim As Single gammadef = 0

     Dim As Single G0(3),E0(3)
     Dim As Integer I
     
     Dim As Single alev
     
     N = Int(Ei*10 + 0.5) 
     If N <= 0 Then N = 1
     ReDim As Single sigma(N)  ' sigma is not normalized!
                               ' (Normalization is done by Monte-Carlo procedure.)
     
     Tm = U_temp(Zi,Ai,Ei,1,1,Tscale,Econd,Etrans)
     
     betadef = DEFOtab(Ai-Zi,Zi)       ' ground-state deformation
     gammadef = -120 * betadef + 47.4  ' A. Junghans
     
   ' Print Tm
   ' Tm = Tm / 2 ' + 0.1 * (1.0 / U_I_Shell(Zi,Ai) - 1)
   ' Print Tm
   ' sleep  
   ' For eventual specific behaviour of gamma strength in magic nuclei
' betadef = 0
' gammadef = 0   
     If betadef = 0 And gammadef = 0 Then 
       E0(2) = E0_GDR(Zi,Ai)
       G0(2) = Width_GDR(E0(2))
     
     ' Establish distribution
       sigMax = 0
       For Eg = 0.1 To Ei Step 0.1
          N = CInt(Eg*10)
/'       sigma(N) = exp(-Eg/Tm) * Eg^2 '/ ' for testing shape of gamma-strength function
         sigma(N) = exp(-Eg/Tm) * _
            Eg^3 * (G0(2) * Eg) / ( (Eg^2 - E0(2)^2)^2 + G0(2)^2 * E0(2)^2 )  
           ' + 0.7 * G0(2) * 4 * pi^2 * Tm^2 / E0(2)^5 )  
           ' last line: correction for low gamma energy (PRC 41 (190) 1941)
         if sigma(N) > sigMax then sigMax = sigma(N)
       Next Eg
'Print "Tm,E0,G0)";Tm,E0(2),G0(2)       
'For Eg = 0.1 To Ei Step 0.1
'         N = CInt(Eg*10)
'         Print Eg,sigma(N) / sigMax
'Next Eg
     Else
       sigMax = 0
       For I = 1 To 3
         E0(I) = E0_GDR(Zi,Ai) * Efac_def_GDR(betadef,gammadef,I)
         G0(I) = Width_GDR(E0(I))
      ' Establish distribution
         For Eg = 0.1 To Ei Step 0.1
            N = CInt(Eg*10)
'            sigma(N) = sigma(N) + exp(-Eg/Tm) * Eg^3 *_
'                (G0(I) * Eg) / ( (Eg^2 - E0(I)^2)^2 + G0(I)^2 * E0(I)^2 )
                
            sigma(N) = sigma(N) + exp(-Eg/Tm) * Eg^3 *_
               ( (G0(I) * Eg) / ( (Eg^2 - E0(I)^2)^2 + G0(I)^2 * E0(I)^2 )  _
              /' +  0.001 * exp(-0.5) '/  _  
              /' + 0.7 * G0(I) * 4 * pi^2 * Tm^2 / E0(I)^5 '/ ) 
             ' exponential: M1 strength at low energy, PRL 111, 232504 (2013)    
             ' last line: correction for low gamma energy (PRC 41 (1990) 1941)
           if sigma(N) > sigMax then sigMax = sigma(N)
         Next         
       Next
     End If     
     
 /' ' Weisskopf approximation
     sigMax = 0
     For Eg = 0.1 To Ei Step 0.1
       N = Cint(Eg*10)
       sigma(N) = exp(-Eg/Tm) * Eg^3 * 1.E14 * Ai^0.666667 
       If sigma(N) > sigMax Then sigMax = sigma(N)
     Next Eg '/     
     
    ' Dice gamma energy from distribution
     diceagain_gamma_low:
     xran = rnd * Ei * 10   ' in units of 100 keV
     yran = rnd * sigMax
     if yran > sigma(Cint(xran)) then goto diceagain_gamma_low
     
     P_Egamma_low = xran/10     ' convert to MeV 
   End Function       
  
     Function P_Egamma_high(Zi as Single, Ai As Single, Ei As Single) As Single
   ' Random function, returns gamma energy in MeV 
   ' From PRL 49 (1982) 434
   ' For energies above Sn: competition with neutrons included
     Dim As Integer N
     Dim As Single sigMax, Eg
     Dim As Single xran, yran
     Dim As Single Tm
     Dim As Single G0,E0
     
     N = Int(Ei*10 + 0.5) 
     If N <= 0 Then N = 1
     ReDim As Single sigma(N)  ' sigma is not normalized
                               ' (Normalization is done by Monte-Carlo procedure.)
     
     E0 = E0_GDR(Zi,Ai)
     G0 = Width_GDR(E0)
     Tm = U_temp(Zi,Ai,Ei,1,1,Tscale,Econd,Etrans)
     
     ' Establish distribution
     sigMax = 0
     For Eg = 0.1 To Ei Step 0.1
        N = CInt(Eg*10.0)
        sigma(N) = Eg^3 / Tm^2 * exp(-Eg/Tm) * _
           (G0 * Eg) / ( (Eg^2 - E0^2)^2 + G0^2 * E0^2 )
       if sigma(N) > sigMax then sigMax = sigma(N)
     Next   
     
    ' Dice gamma energy from distribution
     diceagain_gamma_high:
     xran = rnd * Ei * 10   ' in units of 100 keV
     yran = rnd * sigMax
     if yran > sigma(Cint(xran)) then goto diceagain_gamma_high  
     
     P_Egamma_high = xran/10     ' convert to MeV 
   End Function   

/'<'/    
  Function U_Ired(Z As Single,A As Single) As Single
    ' Effective moment of inertia by pairing with correction for excitation energy
      Dim As Single IU_rigid_spher,IfragEff
      
  '   /'<FO REAL*4 U_SHELL FO>'/
      
      IU_rigid_spher = 1.16E0^2 * A^1.6667E0 / 103.8415E0 
  '   IfragEff = I_rigid_spher + 0.003 * A^(4.0/3.0) * U_shell(Cint(Z),Cint(A))
  '   IfragEff = I_rigid_spher + 0.005 * A^(4.0/3.0) * U_shell(Cint(Z),Cint(A))
                      ' reduction due to shell (Deleplanque et al. PRC 69 (2004) 044309)
      IfragEff = 0.45 * IU_rigid_spher ' Effect of superfluidity 
  '   IfragEff = 0.65 * IfragEff   ' Average effect of superfluidity and deformation 

     U_Ired = IfragEff     
   End Function
   
  Function U_IredFF(Z As Single,A As Single) As Single
    ' Effective moment of inertia by pairing with correction for excitation energy
    ' of final fission fragments
    
      /'<FO REAL*4 U_Ired FO>'/    
      /'<FO REAL*4 U_I_Shell FO>'/    

     U_IredFF = U_Ired(Z,A) * U_I_Shell(Z,A)    
   End Function
   
   Function U_I_Shell(Z As Single,A As Single) As Single
      Dim As Integer N_shells(6)
      ' Shell effect on the effective moment of inertia
      Dim As Integer I 
      Dim As Single dNmin, dZmin, dNsubmin
      Dim As Single Inv_add = 0
      Dim As Single I_inv_add_Z = 0
      Dim As Single I_inv_add_N = 0
      Dim As Single I_inv_add_Nsub = 0
      N_shells(1) = 20
      N_shells(2) = 28
      N_shells(3) = 50
      N_shells(4) = 82
      N_shells(5) = 126
      N_shells(6) = 56
      dNmin = 100
      dZmin = 100
      dNsubmin = 100
      For I = 1 To 5
        dZmin = Min(dZmin,Abs(N_shells(I) - Z))
      Next I
      
      For I = 1 To 5
        dNmin = Min(dNmin,Abs(N_shells(I) - (A-Z))) 
      Next I  
      
      dNsubmin = Abs(N_shells(6) - (A-Z))
  
     ' Effect of shells:
      If dZmin < 10.0 Then
'        I_inv_add_Z = 0.33 * (6.0 * sqr(A/140.) - dZmin) * sqr(140./A)
        I_inv_add_Z = 0.33 * (6.0 * sqr(A/140.0) - dZmin) * (140.0/A)^1.5
        ' A^(-1/3) dependence: "A simple phenomenology for 2gamma+ states",
        ' N. V. Zamfir, D. Bucurescu, R. F. Casten, M. Ivascu,
        ' Phys. Lett. B 241 (1990) 463
        I_inv_add_Z = Max(I_inv_add_Z,0.0)
      End If
      If dNmin < 10.0 Then
'        I_inv_add_N = 0.42 * (8.0 * sqr(A/140.) - dNmin) * sqr(140./A)
        I_inv_add_N = 0.42 * (8.0 * sqr(A/140.0) - dNmin) * (140.0/A)^1.5
        I_inv_add_N = Max(I_inv_add_N,0.0)
      End If    
      If DNsubmin < 6.0 Then
   '    I_inv_add_Nsub = 1.7 * (4.0 - dNsubmin) * (1.0 - 0.32 * Abs(40.0-Z))
        I_inv_add_Nsub = 1.7 * (4.0 - dNsubmin) * (1.0 - 0.18 * Abs(40.0-Z))
            ' N = 56 subshell only around Z = 40
        I_inv_add_Nsub = Max(I_inv_add_Nsub,0.0)
      End If      
      U_I_shell = 1.0 / (1.0 + Max(I_inv_add_N,I_inv_add_Nsub) + I_inv_add_Z)
'Print "*",I_inv_add_Z, I_inv_add_N, I_inv_add_Nsub,1.0 / (1.0 + Max(I_inv_add_N,I_inv_add_Nsub) + I_inv_add_Z)  
   End Function
   

   Function U_alev_ld(Z As Single, A As Single) As Single
    '  U_alev_ld = 0.073 * A + 0.095 * A^0.666667  'Ignatyuk (1970's)
       U_alev_ld = 0.078 * A + 0.115 * A^0.6666667  ' Ignatyuk (Bologna 2000) 
    '  U_alev_ld = 0.089 * A    ' only volume term
   End Function
   
/'>'/     
   Function U_levdens_old(Z As Integer, A As Integer, E As Single, Ishell As Integer, _
               Ipair As Integer, Tscale As Single, Econd As Single, Etrans As Single, af_an As Single) As Double
               '  Not used any more !!!
      ' This routine is replaced by the new "U_levdens.bas" below!         
      ' Comment valid for U_levdens_old: The normalization of the CT level density to the FG level density
      '          reduces the jump in Pf around 16 MeV and leads to a more regular
      '          evolution of Pf with N_CN and Z_CN. The absolute values of Pf are not
      '          modified very much.
   '  Dim As Single Etrans = 8.0  ' Transition from CT to Fermi gas
     Dim As Double rho, rho1, rho2
     If E < Etrans Then
       rho1 = U_levdens_FG(Z,A,Etrans,Ishell,Ipair,Tscale,Econd,Etrans,af_an)
       rho2 = U_levdens_Egidy(Z,A,Etrans,Ishell,Ipair,Tscale,Econd,Etrans,af_an)
       rho = U_levdens_Egidy(Z,A,E,Ishell,Ipair,Tscale,Econd,Etrans,af_an) * rho1 / rho2
   '    rho = U_levdens_Egidy(Z,A,E,Ishell,Ipair,Tscale,Econd,af_an) 
     Else 
  '     rho1 = U_levdens_FG(Z,A,Etrans,Ishell,Ipair,Tscale,Econd,af_an)
  '     rho2 = U_levdens_Egidy(Z,A,Etrans,Ishell,Ipair,Tscale,Econd,af_an)
  '     rho = U_levdens_FG(Z,A,E,Ishell,Ipair,Tscale,Econd,af_an) * rho2 / rho1
          ' normalized to FG formula at Etrans
       rho = U_levdens_FG(Z,A,E,Ishell,Ipair,Tscale,Econd,Etrans,af_an) 
     End If
     U_levdens_old = rho 
   End Function                
   
   Function U_levdens(Z As Integer, A As Integer, E As Single, Ishell As Integer, _
            Ipair As Integer, Tscale As Single, Econd As Single, _ 
            Etrans As Single, af_an As Single) As Double
      ' Comment: The matching of const.-temperature and Fermi-gas regime is performed by
      '          adjusting the effective shell effect of the Fermi-gas formula in U_levdens_FG.
    '  Dim As Single Etrans = 7.0  ' Transition from CT to Fermi gas
     Dim As Double rho
     If E < Etrans Then
       rho = U_levdens_Egidy(Z,A,E,Ishell,Ipair,Tscale,Econd,Etrans,af_an)
     Else 
       rho = U_levdens_FG(Z,A,E,Ishell,Ipair,Tscale,Econd,Etrans,af_an)
     End If
 /'  If Ipair = 1 Then
       If Z Mod 2 = 0 And (A-Z) Mod 2 = 0 Then    ' motivated by E_n spectra 235U(n,f), Taieb 2024
         If E < 2 * 12 / sqr(A) Then rho = 1     ' only the ground state
       End If
     End If '/
     U_levdens = rho 
   End Function                    
   
   Function U_levdens_Egidy(Z As Integer, A As Integer, E As Single, Ishell As Integer, _
             Ipair As Integer, Tscale As Single, Econd As Single, _
             Etrans As Single, af_an As Single) As Double
     ' E may be given above ground state or above the macroscopic ground state         
     Dim As Single Temp, DU, Ered, Rmicro, Rshell    
     If Ishell = 1 Then
       DU = U_SHELL_exp(Z,A)   ' For ground state (only shell effect)
       If Z > 92 Then  ' hypothetical deviation in the macroscopic masses
         DU = DU + 0.1 * (Z - 92)
       End If
     Else
       DU = 0   ' for barrier (no shell effect at all)
     End If   
     If Ipair = 1 Then
       Rmicro = - U_SHELL_EO_exp(Z,A)   ' microscopic effects (shell and pairing)
       Rshell = - U_SHELL_exp(Z,A)   ' only shell effect
       If Z > 92 Then  ' hypothetical deviation in the macroscopic masses
         Rmicro = Rmicro - 0.1 * (Z - 92)
         Rshell = Rshell - 0.1 * (Z - 92)
       End If
       Ered = E + Rshell - Rmicro  + 2.0 * 12.0 / sqr(A)  ' shift from odd-odd to even-even basis (exp)
         ' compatibility with Egidy's formula is tested (Ered = E for even-even nuclei)
    '   Ered = E + Lypair(Z,A) + 2.0 * 12.0 / sqr(A)  ' shift from odd-odd to even-even basis (schematic)
     Else
       Ered = E + 2.0 * 12.0 / sqr(A)     ' energy is given above the macr. ground state
     End If       
' If Z > 92 Then    ' hypothetical shift of macr. masses -> lower shell effect
'   DU = DU + 0.33 * (Z - 92)     
' End If
' DU = DU + Econd    

     Temp = 1.0 / ( (0.0570 + 0.00193*DU) * A^0.6666667)  ' from  PRC 80 (2009) 054310 
     U_levdens_Egidy = 1.0 / Temp * Exp(Ered/Temp)     

   End Function   
   
   Function U_levdens_FG(Z As Integer, A As Integer, E As Single, Ishell As Integer, _
              Ipair As Integer, Tscale As Single, Econd As Single, Etrans As Single, _
              af_an As Single) As Double
     ' This function calculates the level density in the FG regime,
     ' taking a high-energy value as reference,
     ' starting from the macroscopic masses with an imposed Econd.
     ' This destroys all structural effects at high E* in a well controlled way.  
     ' E on input is the excitation energy above the "real" ground state 
   '  Dim As Single Etrans = 7.0  ' Transition from CT to Fermi gas in MeV
     Dim As Single Ered,Ered_trans,DU  ' energy above the fictive macroscopic ground state     
     Dim As Single alev,Eshift_shell,Rmicro,Rshell 
     Dim As Double Rho1,rho1_trans
     Static As Single fgamma = 0.055 
     Dim As Single F_enhance = 1.0             
     alev = U_alev_ld(Z,A)
     If Ishell = 1 Then
       If Ipair = 0 Then
         Rshell = - U_SHELL_exp(Z,A)
         If Z > 92 Then  ' hypothetical deviation in the macroscopic masses
           Rshell = Rshell - 0.1 * (Z - 92)
         End If
         Rmicro = Rshell
       Else
         Rmicro = - U_SHELL_EO_exp(Z,A)   ' microscopic effects (shell and pairing)
         Rshell = - U_SHELL_exp(Z,A)   ' only shell effect
         If Z > 92 Then  ' hypothetical deviation in the macroscopic masses
           Rshell = Rshell - 0.1 * (Z - 92)
           Rmicro = Rmicro - 0.1 * (Z - 92)
         End If
       End If
       
       Ered_trans = Etrans + Rshell - Rmicro - Econd
       Ered = E + Rshell - Rmicro - Econd
       rho1_trans = U_levdens_Egidy(Z,A,Etrans,Ishell,Ipair,Tscale,Econd,Etrans,af_an) 
       ' Shell effect DU in FG regime adjusted to match the const. temp level density at Etrans:
       DU = (Ered_trans - 1/(alev * af_an) * ( log(rho1_trans * Ered_trans^1.25 * 0.5/sqr(3.141) _
               * (alev * af_an)^0.25) / 2)^2 ) / (1 - exp(-fgamma * Etrans) ) 
       Eshift_shell = DU * (1.0 - exp(-fgamma * E)) 
       Rho1 = sqr(3.141) * 2.0/( (alev * af_an)^0.25 * Ered^1.25) * exp(2.E0 _
               * sqr(alev * af_an * (Ered - Eshift_shell))) 
       ' Factor 2.0 instead of 1/12 keeps approximately the shell effect of the Egidy systematics. 
       ' The relative enhancement of a factor 24 may represent the average collective enhancement.
     Else
       If Ipair = 0 Then
         Rshell = - U_SHELL_exp(Z,A)
         If Z > 92 Then  ' hypothetical deviation in the macroscopic masses
           Rshell = Rshell - 0.1 * (Z - 92)
         End If
         Rmicro = Rshell
       Else
         Rmicro = - U_SHELL_EO_exp(Z,A)   ' microscopic effects (shell and pairing)
         Rshell = - U_SHELL_exp(Z,A)   ' only shell effect
         If Z > 92 Then  ' hypothetical deviation in the macroscopic masses
           Rshell = Rshell - 0.1 * (Z - 92)
           Rmicro = Rmicro - 0.1 * (Z - 92)
         End If
       End If  
       Ered = E + Rshell - Rmicro - Econd  ' origin of the FG without pairing   
       Ered_trans = Etrans + Rshell - Rmicro - Econd
       rho1_trans = U_levdens_Egidy(Z,A,Etrans,Ishell,Ipair,Tscale,Econd,Etrans,af_an) 
       ' Shell effect DU in FG regime adjusted to match the const. temp level density at Etrans:
       DU = (Ered_trans - 1/(alev * af_an) * ( log(rho1_trans * Ered_trans^1.25 * 0.5/sqr(3.141) _
               * (alev * af_an)^0.25) / 2)^2 ) / (1 - exp(-fgamma * Etrans) ) 
       Eshift_shell = DU * (1.0 - exp(-fgamma * E)) 
       Rho1 = sqr(3.141) * 2.0/( (alev * af_an)^0.25 * Ered^1.25) * exp(2.E0 _ 
               * sqr(alev * af_an * (Ered - Eshift_shell))) 
       ' Factor 2.0 instead of 1/12 keeps approximately the shell effect of the Egidy systematics. 
       ' The relative enhancement of a factor 24 may represent the average collective enhancement.
     End If   
     U_levdens_FG = F_enhance * Rho1
   End Function        
    
/'<'/   
    
   Function U_Temp(Z As Single, A As Single, E As Single, Ishell As Integer, _
           Ipair As Integer, Tscale As Single,Econd As Single,Etrans As Single) As Single
       ' Temperature (modified Gilbert-Cameron composite level density)    
       ' Version with switch for shell and pairing (either ground-state values or zero)
       ' KHS (10. 2. 2012)       
       Dim As Single alev  
       Dim As Single Eeff0,Eeff1,E1,Rho0,Rho1,TCT,TFG 
       Static As Single fgamma = 0.055      
       Dim As Single RShell,RPair,Res
       /'<FO REAL*4 U_ALEV_LD FO>'/
       /'<FO REAL*4 U_SHELL FO>'/
       /'<FO REAL*4 LYPAIR FO>'/
       /'<FO REAL*4 TEGIDY FO>'/ 
       ' Used global parameters: Tscale
'      alev = U_alev_ld(Z,A) * 1.1   ' Factor adjusted to high-energy prompt neutrons in U235(nth,f)
       alev = U_alev_ld(Z,A) * 0.95  ' " with the correction for non-constant T (FG range)
'      alev = U_alev_ld(Z,A) * 0.85  ' Factor 0.85 adjusted to high-energy prompt-neutrons in 252Cf(sf)
       
       If Ishell = 1 Then
         RShell = U_Shell(Cint(Z),Cint(A))
       Else
         RShell = 0.0
       End If    
       TCT = TEgidy(A,RShell,Tscale)  
       
       If Ipair = 1 Then
         RPair = Lypair(CInt(Z),CInt(A))
       Else
         Rpair = 0.0
       End If    
       Eeff0 = E - Econd + RPair + Rshell*(1.0 - exp(-fgamma * E))
       
       If Eeff0 > 0.5 Then
  '       Eeff1 = Eeff0 + 0.1
         E1 = E + 0.1
         Eeff1 = E1 - Econd + RPair + Rshell*(1.0 - exp(-fgamma * E1))
         Rho0 = 1.E0/Eeff0^1.25 * exp(2.E0 * sqr(alev * Eeff0))
         Rho1 = 1.E0/Eeff1^1.25 * exp(2.E0 * sqr(alev * Eeff1))
'         Rho0 = 1.E0/Eeff0 * exp(2.E0 * sqr(alev * Eeff0))
'         Rho1 = 1.E0/Eeff1 * exp(2.E0 * sqr(alev * Eeff1))
         TFG = 0.1E0 / (log(Rho1) - log(Rho0))
       Else 
         TFG = 0.0
       End If
       Res = TCT
       If TFG > Res Then Res = TFG

' If Res > 1.4 Then Res = 1.4

       U_Temp = Res
   End Function
/'>'/   

   Function U_Temp2(Z As Single, A As Single, E As Single, Rshell As Single, _
          Rpair As Single, Tscale As Single,Econd As Single,Etrans As Single) As Single
       ' Temperature (modified Gilbert-Cameron composite level density)    
       ' Version with numerical input of shell correction and pairing
       ' KHS (10. 2. 2012)       
       Dim As Single alev  
       Dim As Single Eeff0,Eeff1,Rho0,Rho1,TCT,TFG 
       Static As Single fgamma = 0.055      
       Dim As Single Res
       ' Used global parameters: Tscale
    '  alev = U_alev_ld(Z,A) * 1.1   ' Factor adjusted to high-energy prompt neutrons in U235(nth,f)
       alev = U_alev_ld(Z,A) * 0.95  ' " with the correction for non-constant T (FG range)
    '  alev = U_alev_ld(Z,A)
       
       TCT = TEgidy(A,RShell,Tscale)  
       
       Eeff0 = E - Econd + RPair + Rshell*(1.0 - exp(-fgamma * E))
   '    Eeff0 = E - Econd + Lypair(CInt(Z),CInt(A)) + Rshell*(1.0 - exp(-fgamma * E))
       
       If Eeff0 > 0.5 Then
         Eeff1 = Eeff0 + 0.1
         Rho0 = 1.E0/Eeff0^1.25 * exp(2.E0 * sqr(alev * Eeff0))
         Rho1 = 1.E0/Eeff1^1.25 * exp(2.E0 * sqr(alev * Eeff1))
'         Rho0 = 1.E0/Eeff0 * exp(2.E0 * sqr(alev * Eeff0))
'         Rho1 = 1.E0/Eeff1 * exp(2.E0 * sqr(alev * Eeff1))
         TFG = 0.1E0 / (log(Rho1) - log(Rho0))
       Else 
         TFG = 0.0
       End If
       Res = TCT
       If TFG > Res Then Res = TFG
       U_Temp2 = Res
   End Function
   
 /'  Function U_levdens(Z As Single, A As Single, E As Single, Econd As Single, Ishell As Integer) _
           As Single
     ' Calculates the level density at excitation energy E
     Dim As Single DU
     If Ishell = 1 Then
       DU = U_Shell(Z,A)
     Else
       DU = 0
     End If   
     If TEgidy(A,DU,Tscale) > U_Temp(Z,A,E,Ishell,Ipair,DU,Econd) Then
       Levdens = Exp(E/TEgidy)
     Else
       Levdens = 1.E0/E^1.25 * exp(2.E0 * sqr(alev * E))
     End If 
   
   End Function '/
   
   Function E0_GDR(Z As Single, A As Single) As Single
     ' Calculates the centroid energy of the GDR for spherical nucleus
     ' according to the FRDM (ADNDT 59 (1995) 185 and PLB 670 (2008) 200)
     Static As Single epsilon = 0.0768
     Static As Single J = 32.7
     Static As Single Q = 29.2
     Static As Single R0 = 1.16
     Static As Single mstar = 874
     Static As Single hbar = 197.3
     Dim As Single Aonethird,u,N,E0
   
     ' according to [9] in Phys. Lett. B 690 (2010) 473:
      E0_GDR = 18.0/A^0.333333 + 25.0 / A^0.1666667
   
     ' according to the FRDM (ADNDT 59 (1995) 185 and PLB 670 (2008) 200):
  '    Aonethird = A^0.333333
  '    N = A - Z
  '    u = (1-epsilon)/Aonethird * 3*J/Q
  '    E0_GDR = hbar /(R0*Aonethird)*sqr(8*J*A^2/ (mstar*4*N*Z) ) * _
  '      (1 + u - epsilon * (1+epsilon+3*u)/(1+epsilon+u))^(-1/2) 
   End Function
   
   Function Width_GDR(E0 As Single) As Single
     ' Spreading width of the GDR (Nucl. Phys. A 531 (1991) 27)
      Width_GDR = 1.99 * (E0/10)^1.6
   End Function
   
   Function Efac_def_GDR(Beta As Single,Gamma As Single,K As Single) As Single
     ' Modification factors of the resonance energy due to triaxial deformation
     ' Hill-Wheeler parameterisation (PRC 89 (1953) 1102)
     ' Possible values for K:  K-2 = -1, 0, 1
     If beta = 0 and gamma = 0 then
       Efac_def_GDR = 1
     Else  
       Efac_def_GDR = 1/(exp(sqr(5/(4*pi))*Beta * cos(gamma - 0.666667*(K-2)*pi)))
     End If   
   End Function  
   
   Function GgGtot(Z As Single, A As Single, E As Single, Egm As Single) As Single
     ' From PRL 49 (1982) 434
     ' Probability to emit a gamma of energy Egamma in competition to neutron emission
      Dim As Single EG, GG, T, SN
      EG = E0_GDR(Z,A)
      GG = Width_GDR(EG)
      T = U_Temp(Z,A,E,1,1,Tscale,Econd,Etrans)
      SN = U_Mass(Z,A-1.E0) + Lypair(Z,A-1.E0) _
        - (U_Mass(Z,A) + Lypair(Z,A)) 
      GgGtot = Egm^3 / T^2 * exp((Sn-Egm)/T) _
          * GG * EG / ((Egm^2 - EG^2)^2 + GG^2 * EG^2)
   End Function

   Function E_next(T1 As Single,T2 As Single,E1 As Single,E2 As Single,A1 As Single,A2 As Single) _
                     As Single
       /' Samples the energy transfer in one step between two nuclei '/
       /' in thermal contact '/
       /' The energy transfer is only determined by the available phase space. '/
       /' Only one kind of nucleons considered! '/

        /' T1,T2 Temperatures of the two nuclei '/
        /' E1,E2 Initial energies of the two nuclei '/
        /' A1, A2 Mass numbers of the two nuclei '/

        Dim As Single E12
        Dim As Single Delta1,Delta2 /' Pairing gaps '/
        Dim As Single Delta_E1,Delta_E2
        Dim As Single E1final       /' Energy 1 after transfer '/
        Dim As Single E1mod,E2mod
        /'<FO REAL*4 PEXPLIM FO>'/

        /' Assumed level densities: '/
        /' Even number of nucleons:
           1 ground state at energy E = - 2 Delta not considered,
           continuous level density above E = 0 : rho1,2 = a1,2 * exp(E1,2/T1,2) '/

      E12 = E1 + E2 /' Total energy '/

      E1mod = E1
      E2mod = E2
      If (E1mod > E2mod) Then
        Delta_E1 = Pexplim(-1.E0/T1,0.0,E1mod)
        E1mod = E1mod - Delta_E1
        E2mod = E2mod + Delta_E1
        Delta_E2 = Pexplim(-1.E0/T2,0.0,E2mod)
        E2mod = E2mod - Delta_E2
        E1mod = E1mod + Delta_E2
      Else
        Delta_E2 = Pexplim(-1.E0/T2,0.0,E2mod)
        E2mod = E2mod - Delta_E2
        E1mod = E1mod + Delta_E2
        Delta_E1 = Pexplim(-1.E0/T1,0.0,E1mod)
        E1mod = E1mod - Delta_E1
        E2mod = E2mod + Delta_E1
      EndIf
      E1final = E1mod

   /' Select;
        When (E1 > E2) Do;
        L3:
          Delta_E1 = Pexplim(-1.E0/T1,0.0,E1);
          E1final = E1 - Delta_E1;
          Delta_E1 = Pexplim(-1.E0/T2,0.0,E12-E1final);
          E1final = E1final + Delta_E1;
        End;
        When (E1 <= E2) Do;
        L4:
          Delta_E1 = Pexplim(-1.E0/T2,0.0,E12-E1);
          E1final = E1 + Delta_E1;
          Delta_E1 = Pexplim(-1.E0/T1,0.0,E1final);
          E1final = E1final - Delta_E1;
        End;
        Otherwise Do;
          List('This should not happen.');
        End;
      End; '/

      E_next = E1final

   End Function


   Function Pexplim(R_lambda As Single,xmin As Single,xmax As Single) As Single
      /' random number from an exponential between xmin and xmax '/
         /' decay constant: f(x) = exp(lambda * x) !!! '/
         /' xmin, xmax: limits for sampling '/
        Dim As Single umin, umax  /' xmin, xmax transformed '/
        Dim As Single u  /' help variable '/
        Dim As Single R_res  /' sampled value '/

      If ABS(R_lambda) < 1.E-30 Then
        R_res = xmin + Rnd * (xmax-xmin)
      Else
        umin = exp(xmin*R_lambda)
        umax = exp(xmax*R_lambda)
        u = umin + Rnd * (umax-umin)
        R_res = 1.E0/R_lambda * log(u)
        Pexplim = R_res
      EndIf
   End Function

/'<'/

 Function U_Even_Odd(I_Channel As Integer,PEO As Single) As Single
   ' Creates even-odd fluctuations 
   Dim As Single R
   If I_Channel Mod 2 = 0 Then
     R = 1.0 + PEO
   Else
     R = 1.0 - PEO
   End If
   U_Even_Odd = R   
 End Function
 
/'>'/ 

   Function EVEN_ODD(R_ORIGIN As Single,R_EVEN_ODD As Single) As Integer

     /' Procedure to calculate I_OUT from R_IN in a way that         '/
     /' on the average a flat distribution in R_IN results in a      '/
     /' fluctuating distribution in I_OUT with an even-odd effect as '/
     /' given by R_EVEN_ODD                                          '/

     /' ------------------------------------------------------------ '/
     /' EXAMPLES :                                                   '/
     /' ------------------------------------------------------------ '/
     /'    If R_EVEN_ODD = 0 :                                       '/
     /'           CEIL(R_IN)  ----                                   '/
     /'                                                              '/
     /'              R_IN ->                                         '/
     /'            (somewhere in between CEIL(R_IN) and FLOOR(R_IN)) '/
     /'                                                              '/
     /'           FLOOR(R_IN) ----       --> I_OUT                   '/
     /' ------------------------------------------------------------ '/
     /'    If R_EVEN_ODD > 0 :                                       '/
     /'      The interval for the above treatment is                 '/
     /'         larger for FLOOR(R_IN) = even and                    '/
     /'         smaller for FLOOR(R_IN) = odd                        '/
     /'    For R_EVEN_ODD < 0 : just opposite treatment              '/
     /' ------------------------------------------------------------ '/

     /' ------------------------------------------------------------ '/
     /' On input:   R_ORIGIN    nuclear charge (real number)         '/
     /'             R_EVEN_ODD  requested even-odd effect            '/
     /' Intermediate quantity: R_IN = R_ORIGIN + 0.5                 '/
     /' On output:  I_OUT       nuclear charge (integer)             '/
     /' ------------------------------------------------------------ '/


     Dim As Single R_IN,R_REST,R_HELP
     Dim As Single R_FLOOR
     Dim As Single R_MIDDLE
     Dim As Integer I_OUT

     R_EVEN_ODD = MIN(R_EVEN_ODD,1)
     R_IN = R_ORIGIN + 0.5E0
     R_FLOOR = FLOOR(R_IN)
     If Abs(R_EVEN_ODD) < 1.E-3 Then
       I_OUT = R_FLOOR	
     Else
       R_REST = R_IN - R_FLOOR
       R_MIDDLE = R_FLOOR + 0.5E0
       IF R_FLOOR Mod 2 = 0 THEN  /' even before modif. '/
         R_HELP = R_MIDDLE + (R_REST - 0.5E0) _
           * 1.E0 / Max(0.01,(1.E0 + R_EVEN_ODD))
         R_HELP = Min(R_HELP,R_MIDDLE+1)
         R_HELP = Max(R_HELP,R_MIDDLE-1)
       ELSE  /' odd before modification '/
         R_HELP = R_MIDDLE + (R_REST - 0.5E0) _
           * 1.E0 / Max(0.01,(1.E0 - R_EVEN_ODD))
         R_HELP = Min(R_HELP,R_MIDDLE+1)
         R_HELP = Max(R_HELP,R_MIDDLE-1)
       EndIf
       I_OUT = FLOOR(R_HELP)
     EndIf
     Even_odd = I_OUT
   End Function

/'<'/

   Function BFTF(RZ As Single,RA As Single,I_Switch As Integer) As Single
    /' Fission barriers from Myers and Swiatecki, Thomas-Fermi model '/
    /'  I_Switch: 0: liquid-drop; 1: with shells and pairing, 
        2: averaged over pairing, 3: with shell and pairing + pairing gap at barrier '/
      ' 4: liquid-drop + g.s. shell, no Z correction
      Dim As Single RN,RI,Rkappa,RS,RF,RX
      Dim As Single RX0 = 48.5428
      Dim As Single RX1 = 34.15
      Dim As Single RB 
      Dim As Integer IZ,IA
   '  /'<FO REAL*4 U_SHELL FO>'/
     /'<FO REAL*4 U_SHELL_EXP FO>'/
     /'<FO REAL*4 U_SHELL_EO_EXP FO>'/
     /'<FO REAL*4 LYPAIR FO>'/
     
     IZ = Cint(RZ)
     IA = Cint(RA)
     RN = RA - RZ
     RI = (RN-RZ) / RA
     Rkappa = 1.9E0 + (RZ - 80.E0) / 75.E0
     RS = RA^0.666667E0 * (1.E0 - Rkappa * RI^2)
     RX = RZ^2 / (RA * (1.E0 - Rkappa * RI^2))
     If RX < 30 Then   /' out of range '/
       RF = 1.E10
     End If
     If RX > RX0 Then  /' out of range '/
       RF = 0.0
     End If
     If RX < RX1 And RX > 30 Then 
       RF = 0.595553E0 - 0.124136E0 * (RX - RX1)
     End If
     If RX >= RX1 And RX <= RX0 Then 
       RF = 0.000199749 * (RX0 - RX)^3
     End If
     RB = RF * RS

     Select Case I_Switch
       Case 0  ' no shell, no pairing
         BFTF = RB
       Case 1 ' including even-odd staggering due to increased pairing strength at barrier
         ' Tentative modification from comparison with experimental fission barriers
         ' Adding the ground-state shell effect
         ' (shell correction at the barrier?)
         If RZ > 86.5 Then RB = RB - 0.15 * (RZ - 86.5)
     '    If RZ > 90 Then RB = RB + 0.3 * (RZ - 90.0)
     '    If RZ > 98 Then RB = RB - 0.15 * (RZ - 98.0) 
         If RZ > 90 Then RB = RB + 0.35 * (RZ - 90.0)
         If RZ > 93 Then RB = RB + 0.15 * (RZ - 93.0)
         If RZ > 95 Then RB = RB - 0.25 * (RZ - 95.0) 
     '    BFTF = RB - U_Shell(IZ,IA)
     '    BFTF = RB - U_Shell_exp(IZ,IA)
          BFTF = RB - U_Shell_EO_exp(IZ,IA) + Lypair(IZ,IA) * 14.0/12.0
   '   BFTF = RB - U_Shell_EO_exp(RZ,RA) - 14.E0 / sqr(Csng(RA)) _
   '       * Csng( ( (RZ+1) Mod 2 + (RA-RZ+1) Mod 2) )
       Case 2 ' averaged over even-odd staggering
         If RZ > 86.5 Then RB = RB - 0.15 * (RZ - 86.5)
         If RZ > 90 Then RB = RB + 0.35 * (RZ - 90.0)
         If RZ > 93 Then RB = RB + 0.15 * (RZ - 93.0)
         If RZ > 95 Then RB = RB - 0.25 * (RZ - 95.0) 
         BFTF = RB - U_Shell_exp(IZ,IA)
       Case 3 ' like Case 1 but without increased pairing gap at barrier
         If RZ > 86.5 Then RB = RB - 0.15 * (RZ - 86.5)
         If RZ > 90 Then RB = RB + 0.35 * (RZ - 90.0)
         If RZ > 93 Then RB = RB + 0.15 * (RZ - 93.0)
         If RZ > 95 Then RB = RB - 0.25 * (RZ - 95.0) 
         BFTF = RB - U_Shell_EO_exp(IZ,IA) 
       Case 4 ' with shell (like case 3, but without Z correction)
       ' This is the direct description from the topographic theorem.
         BFTF = RB - U_Shell_exp(IZ,IA)
       Case 5 ' with shell and enhanced pairing (like case 1, but without Z correction)
         BFTF = RB - U_Shell_exp(IZ,IA) + Lypair(IZ,IA) * (14.0-12.0)/12.0
       Case 6 ' macrosc. with enhanced pairing   
         BFTF = Max( RB + Lypair(IZ,IA) * (14.0-12.0)/12.0 , 0.0 )
       Case Else
         Print "Undefined option in BFTF"
'         Sleep
     End Select  
 /'  If I_Switch = 0 Then 
       BFTF = RB
     Else 
      ' Tentative modification from comparison with experimental fission barriers
      ' (shell correction at the barrier?)
       If RZ > 86.5 Then RB = RB - 0.15 * (RZ - 86.5)
   '    If RZ > 90 Then RB = RB + 0.3 * (RZ - 90.0)
   '    If RZ > 98 Then RB = RB - 0.15 * (RZ - 98.0) 
       If RZ > 90 Then RB = RB + 0.35 * (RZ - 90.0)
       If RZ > 93 Then RB = RB + 0.15 * (RZ - 93.0)
       If RZ > 95 Then RB = RB - 0.25 * (RZ - 95.0) 
          
   '    BFTF = RB - U_Shell(IZ,IA)
   '    BFTF = RB - U_Shell_exp(IZ,IA)
       BFTF = RB - U_Shell_EO_exp(IZ,IA) + Lypair(IZ,IA) * 14.0/12.0
     End If '/
   End Function

   Function BFTFA(RZ As Single,RA As Single,I_Switch As Integer) As Single
    /' inner barrier height '/
     Dim As Single EA,BF0,Z4A,Z3A,DB 
     Dim As Single coeff = 0.5
     /'<FO REAL*4 BFTF FO>'/
     BF0 = BFTF(RZ,RA,I_Switch)
   ' Z4A = RZ^4 / RA
     '  EB - EA from fit to Smirenkin barriers:
     '  V. M. Kupriyanov, K. K. Istekov, B. I. Fursov, G. N. Smirenkin
     '  Sov. J. Nucl. Phys. 32 (1980) 184
   '  DB = -10.3517 + 1.6027E-5 * Z4A + 5.4945E-11 * Z4A^2  ' EA - EB
   
     '  EB - EA from fit to data from Dahlinger et al. (KHS, 21. Dec. 2012)
     Z3A = RZ^3 / RA
     DB = -(5.40101 - 0.00666175*Z3A + 1.52531E-6*Z3A^2)
     If DB > 0.0 Then
       EA = BF0 - DB
     Else
       EA = BF0 
     End If 
     BFTFA = EA
   End Function

   Function BFTFB(RZ As Single,RA As Single,I_Switch As Integer) As Single
    /' outer barrier height '/
     Dim As Single EB,BF0,Z4A,Z3A,DB 
     Dim As Single coeff = 0.5
     /'<FO REAL*4 BFTF FO>'/
     BF0 = BFTF(RZ,RA,I_Switch)
   ' Z4A = RZ^4 / RA
     '  EB - EA from fit to Smirenkin barriers:
     '  V. M. Kupriyanov, K. K. Istekov, B. I. Fursov, G. N. Smirenkin
     '  Sov. J. Nucl. Phys. 32 (1980) 184
  '   DB = -10.3517 + 1.6027E-5 * Z4A + 5.4945E-11 * Z4A^2  ' EA - EB
  
     '  EB - EA from fit to data from Dahlinger et al. (KHS, 21. Dec. 2012)
     Z3A = RZ^3 / RA
     DB = -(5.40101 - 0.00666175*Z3A + 1.52531E-6*Z3A^2)  
     If DB < 0.0 Then
       EB = BF0 + DB
     Else
       EB = BF0 
     End If 
     BFTFB = EB
   End Function
   
   Function Acentral(Z As Single) As Single
     Dim As Single A_central
     A_central = -28.8156 + Z * 2.86587  ' Stability line for heavy nuclei 
     Acentral = A_central
   End Function


   /' Utility functions '/


   Function Gaussintegral(R_x As Single,R_sigma As Single) As Single
     /' Smoothed step function. Grows from 0 to 1 around R_x
        with a Gauss-integral function with given sigma'/
     Dim As Single R_ret
     ' Note: The variable R_sigma = standard deviation / sqr(2) !
     /'<FO REAL*4 ERF FO>'/
       R_ret = 0.5E0 + 0.5E0 * Erf(R_x / R_sigma)
       Gaussintegral = R_ret
   End Function
   
   Public Function Bell(xpos As Single, xleft As Single, xright As Single) As Single
   ' Bell-shaped curve, maximum = 1, zero for x < xleft and x > xright
     Dim As Single x,y
     If xpos - xleft > 1.E-3 And xright - xpos > 1.E-3 Then
       x = (xpos - xleft) / (xright - xleft)
       y = (x^2 * (1-x)^2)/0.0625
     Else
       y = 0
     End If    
     Bell = y
   End Function     

   Function U_Box(x As Single,sigma As Single, _
         length As Single) As Single
     Dim As Single y
     ' Note: The variable sigma = standard deviation / sqr(2) !
     /'<FO REAL*4 GAUSSINTEGRAL FO>'/      
     y = Gaussintegral(x+0.5*length,sigma) - Gaussintegral(x-0.5*length,sigma)
     U_Box = y/length
   End Function
   
   Function U_Box2(x As Single,sigma1 As Single, sigma2 As Single, _
         length As Single,slope As Single) As Single
     Dim As Single y,y2
     ' Note: The variable sigma = standard deviation / sqr(2) !
     /'<FO REAL*4 GAUSSINTEGRAL FO>'/      
     y = Gaussintegral(x+0.5*length,sigma2) - Gaussintegral(x-0.5*length,sigma1)
     U_Box2 = y/length * (1 - (x/length - 0.5) * 0.25 * slope)  ' multiplication with linear function
                   ' factor 0.25 checked against the Monte-Carlo version of GEF 2025/1.2
   End Function
   
   Function U_Gauss(x As Single,sigma As Single) As Single
     Dim As Single y
     /'<FO Const As Single pi = 3.14159 FO>'/      
     
     y = 1.0 / (sqr(2.0 * pi) * sigma) * exp(-x^2/ ( 2.0 * sigma^2 ) )
     U_Gauss = y
   End Function  
   
   Function U_Gauss_abs(x As Single,sigma As Single) As Single
     Dim As Single y
     /'<FO Const As Single pi = 3.14159 FO>'/      
     
     y = exp(-x^2/ ( 2.0 * sigma^2 ) )
     U_Gauss_abs = y
   End Function  

   Function U_Gauss_mod(x As Single,sigma As Single) As Single
    ' Gaussian with Sheppard correction
     Dim As Single y
     Dim As Single sigma_mod
     /'<FO Const As Single pi = 3.14159 FO>'/      
     sigma_mod = sqr(sigma^2 + 1./12.)
     
     y = 1.0 / (sqr(2.0 * pi) * sigma_mod) * exp(-x^2/ ( 2.0 * sigma_mod^2 ) )
     U_Gauss_mod = y
   End Function  

/'>'/   
   
Public Function PBox(Mean As Single,Sigma As Single, _
              Bottom As Single) As Single
   ' Rectangular distribution folded with a Gaussian distribution   
   Dim As Single R
   R = PGauss(Mean,Sigma)
   R = R + (Rnd-0.5)*Bottom
   PBox = R
End Function

Public Function PBox2(Mean As Single,Sigma1 As Single,Sigma2 As Single, _
              Length As Single,Rslope As Single) As Single
   ' Rectangular distribution folded with a Gaussian distribution. 
   ' One wing is steeper.  
   ' Sigma1 = lower side, Sigma2 = upper side
   ' Multiplied by a linear funcction with slope Rslope (influence of 3. fission barrier)
   Dim As Single Sigma,R
   Dim As Single RGauss, Rbox
   Sigma = Max(Sigma1,Sigma2)
  Pbox_Repeat: 
   RGauss = PGauss(Mean,Sigma)  ' Gaussian: first function for convolution
   Rbox = (Rnd - 0.5)*Length    ' Box: second function for convolution
   If Rbox < 0 Then  ' Inner Wing of S2 distribution
     If Rnd < Abs(Rbox/Length * Rslope) Then
       Rbox = - Rbox
     End If
   End If
   R = RGauss + Rbox  ' convolution by adding Gaussian and Box values

   If Sigma1 < Sigma2 Then
     If R < Mean - 0.5*Length Then
       If RND > Exp( -(R - Mean + 0.5*Length)^2 / (2.0 * Sigma1^2) ) _
               / Exp( -(R - Mean + 0.5*Length)^2 / (2.0 * Sigma2^2) ) Then
         R = Mean - 0.5*Length + (Mean - 0.5*Length - R)
       End If
     End If
   End If
   If Sigma2 <= Sigma1 Then
     If R > Mean + 0.5*Length Then
       If RND > Exp( -(R - Mean - 0.5*Length)^2 / (2.0 * Sigma2^2) ) _ 
               / Exp( -(R - Mean - 0.5*Length)^2 / (2.0 * Sigma1^2) ) Then
         R = Mean + 0.5*Length - (R - Mean - 0.5*Length)
       End If
     End If
   End If
   PBox2 = R
End Function

Public Function PPower(Order As Integer, Rmin As Single, Rmax As Single) As Single
 ' Random generator of a power function: (y = x^Order -> x_random = RND^(1/(Order+1))
 ' PPower = 0 at Rmin to PPower = Ymax at Rmax 
   Dim As Single R
   R = Rmin + (Rmax-Rmin) * Rnd^(1.0/(Order+1))  
   PPower = R 
End Function

Public Function PPower_Griffin_v(Order As Integer, Rmin As Single, Rmax As Single) As Single
 ' Random generator of a power function: (y = x^Order -> x_random = RND^(1/(Order+1))
 ' PPower = 0 at Rmin to PPower = Ymax at Rmax 
   Dim As Single R,v_particle,RRND
   Repeat_Griffin:
   R = Rmin + (Rmax-Rmin) * Rnd^(1.0/(Order))  
   v_particle = sqr(Abs((R-Rmax)/(Rmin-Rmax)))
   RRND = RND
   If RRND > v_particle Then 
     Goto Repeat_Griffin
   End If  
   PPower_Griffin_v = R
End Function

Public Function PPower_Griffin_E(Order As Integer, Rmin As Single, Rmax As Single) As Single
 ' Random generator of a power function: (y = x^Order -> x_random = RND^(1/(Order+1))
 ' PPower = 0 at Rmin to PPower = Ymax at Rmax 
   Dim As Single R,E_particle
   Repeat_Griffin:
   R = Rmin + (Rmax-Rmin) * Rnd^(1.0/(Order))  
   E_particle = (R-Rmax)/(Rmin-Rmax)
   If Rnd > E_particle Then Goto Repeat_Griffin
   PPower_Griffin_E = R
End Function

Public Function PGauss(Mean As Single,Sigma As Single) As Single
  ' Box-Mueller method
  Static As Integer ISet = 0
  Dim As Single V1,V2,R,Fac,GasDev,Result
  Static As Single GSet
  If ISet = 0 then
    Repeat:
    V1 = 2.E0 * Rnd - 1.E0
    V2 = 2.E0 * Rnd - 1.E0
    R = V1^2 + V2^2
    If R >= 1.E0 or R = 0.0 Then Goto Repeat
    Fac = Sqr(-2.E0 * Log(R)/R)
    GSet = V1 * Fac
    GasDev = V2 * Fac
    ISet = 1
  Else
    GasDev = GSet
    ISet = 0
  End If
  Result = Sigma * GasDev
  PGauss = Mean + Result
End Function

Public Function PLinGauss(R_Sigma As Single) As Single
  /' Random-number generator for linear * Gaussian function '/
  /' Distribution of nuclear angular momenta '/
  Dim As Single R_Res,B_rms
  B_rms = R_Sigma / sqr(2.0) ' Because 
    ' the sum of two PGauss functions increases the width.
  R_Res = Abs(PGauss(0,B_rms)) + Abs(PGauss(0,B_rms))
  R_Res = R_Res + B_rms/4.E0 * (1.E0 - exp(-R_Res/R_Sigma))
    ' correction of shape (approximative)
  PLinGauss = R_Res
End Function

/'<'/
Public Function U_LinGauss(x As Single, R_Sigma As Single) As Single
  /' Gaussian times a linear function '/
  /' Not normalized! '/
  Dim As Single R_Res
  If R_Sigma > 0.0 Then
    R_Res = x * exp(-x^2/(2.0 * R_Sigma^2))
  Else
    R_Res = 0.0
  End If    
  U_LinGauss = R_Res
End Function
 
/'>'/

Public Function PExp(R_Tau As Single) As Single
  /' Random-number generator for an exponential distribution '/
  Dim As Single X1,R_Res
  Again:
  X1 = RND
  If X1 > 1.E-10 And X1 < 0.99999E0 Then  ' for avoiding numerical problems
     R_Res = - R_Tau * Log(X1)
  Else
     Goto Again
  End If
  PExp = R_Res
End Function

Public Function PMaxwell(R_T As Single) As Single
   /' Random-number generator for a surface Maxwell distribution '/
   /' y = x * exp(-x/T) '/
   Dim As Double R_Res,R_T_int
   R_T_int = R_T
   R_Res = -R_T_int * (Log(Rnd) + Log(Rnd))
   PMaxwell = R_Res
End Function

Public Function PMaxwellv(R_T As Single) As Single
  /' Random generator according to a distribution similar to a '/
  /' Maxwell distribution with quantum-mech. x-section for neutrons '/ 
  /' (approximation by KHS) '/
  /' Y = SQRT(X) * EXP(-X/T) '/
      Dim As Single EN
      EN = 2.E0 * R_T * Sqr(Log(Rnd) * Log(Rnd))
      PMaxwellv = EN
End Function      

Public Function PMaxwellMod(R_T As Single,R_A As Single) As Single
  /' Random generator according to a distribution similar to a '/
  /' Maxwell distribution with quantum-mech. x-section for neutrons '/ 
  /' (approximation by KHS) '/
  /' Y = SQRT(X) * EXP(-X/T) '/
      Dim As Single EN
      If RND < 3.3 / sqr(R_A) Then  ' according to PR-116-683 (Dostrowsky et al.)
        EN = 2.E0 * R_T * Sqr(Log(Rnd) * Log(Rnd))
      Else
        EN = -R_T * (Log(Rnd) + Log(Rnd))
      End If  
      PMaxwellMod = EN
End Function

Public Function Floor(R As Single) As Single
	Floor = Int(R)
End Function

Public Function Ceil(R As Single) As Single
    If R > Floor(R) Then 
      Ceil = Floor(R) + 1
    Else 
      Ceil = R
    End If  
End Function

Public Function Round(R As Single, N As Integer) As Single
 ' R   Input value
 ' N   Number of significant digits
  Dim As Single RN10, Rred, Rextended, Rrounded, Rout, Rabs
  Dim As Integer N10,Isign
  If R = 0 Then
    Round = 0
  Else
    Isign = Sgn(R)
    Rabs = Abs(R)
    N10 = Int(Log10(Rabs))
    RN10 = 10^N10
    Rred = Rabs / RN10
    Rextended = Rred * 10^(N-1)
    Rrounded = Fix(Rextended + 0.5)
    Rout = Rrounded / 10^(N-1) * RN10
    Round = Isign * Rout
  End If  
End Function

Function Modulo(I As ULongint, J As ULongint) As Longint
  Dim As ULongint Iratio,Iresult
  Iratio = I \ J
  Iresult = I - J * Iratio
  Modulo = Iresult
End Function

Function PLoss(IL As Ulongint) As Integer
  ' Extracts and returns number of prompt protons 
  Dim As String Ctest
  Dim As Integer I,NP
  Ctest = Oct(IL)
  NP = 0
  For I = 1 To Len(Ctest)
    If Mid(Ctest,I,1) = "2" Or Mid(Ctest,I,1) = "4" Then NP = NP + 1
  Next
  PLoss = NP
End Function

#Ifdef B_EgammaA
Sub StoreEgammaA(Egamma1keV As Integer,Apre As Integer)
  ' Accumulate 2-dimensional E-gamma vs. A-pre (different bin sizes)
  Dim As Integer Ichannel
  Ichannel = Int(Egamma1keV * 0.5)
  If Apre >= Lbound(EgammaA2,2) And Apre <= Ubound(EgammaA2,2) Then
    If Ichannel >= Lbound(EgammaA2,1) And Ichannel <= Ubound(EgammaA2,1) Then 
      EgammaA2(Ichannel,Apre) = EgammaA2(Ichannel,Apre) + 1
    End If  
    Ichannel = Int(Egamma1keV * 0.1)
    If Ichannel >= Lbound(EgammaA10,1) And Ichannel <= Ubound(EgammaA10,1) Then 
      EgammaA10(Ichannel,Apre) = EgammaA10(Ichannel,Apre) + 1
    End If  
    Ichannel = Int(Egamma1keV * 0.01)
    If Ichannel >= Lbound(EgammaA100,1) And Ichannel <= Ubound(EgammaA100,1) Then 
      EgammaA100(Ichannel,Apre) = EgammaA100(Ichannel,Apre) + 1
    End If  
    Ichannel = Int(Egamma1keV * 0.001)
    If Ichannel >= Lbound(EgammaA1000,1) And Ichannel <= Ubound(EgammaA1000,1) Then 
      EgammaA1000(Ichannel,Apre) = EgammaA1000(Ichannel,Apre) + 1
    End If
  End If    
End Sub
#Endif

Sub Printcomments
   Dim As Integer IZ,IA

   Print #f,"  <Comments>"
   Print #f,"Further comments:"
   Print #f," "
   Print #f,"Yields are given in percent, normalized to 200%."
   Print #f,"The lowest yields from this Monte-Carlo calculation"
   Print #f,"are unavoidably subject to large statistical fluctuations."
   Print #f," "
   If B_Error_On = 1 Then 
   Print #f,"Uncertainties and covariances or correlation coefficients,"
   Print #f,"if required, are determined by calculations with perturbed"
   Print #f,"parameters. They only consider the uncertainties of the"
   Print #f,"description of the fission process. Uncertainties of more" 
   Print #f,"general ingredients, for example the description of the "
   Print #f,"level density, the gamma strength function and others that"
   Print #f,"are common to all systems are not included. Therefore, the" 
   Print #f,"uncertainties given above are suited for comparing different"
   Print #f,"systems, but they may be underestimated on an absolute scale."
   Print #f," "
   End If
   Print #f,"Small shell effects in the symmetric fission channel influence"
   Print #f,"the relative weight of this channel in the lighter actinides."
   Print #f,"Values different from zero were deduced for several nuclei from measured"
   Print #f,"mass distributions. They are included in the code."
   Print #f," "
 '  Print #f," Z            A_CN     Shell effect at symmetry"
 /'  For IZ = 80 To 100
     For IA = 160 To 300
       If Abs(U_Delta_S0(IZ,IA) - 0.1) > 0.001 Then
         Print #f, IZ, IA, U_Delta_S0(IZ,IA)
       End If       
     Next IA
   Next IZ '/
 /' Print #f, "Global value of the shell effect at symmetry: -0.3 MeV"
   Print #f, " with the following exceptions:"
   Print #f, " Z_CN = 90 :  +0.9 MeV"
   Print #f, " Z_CN = 91 :  +0.6 MeV"
   Print #f, " Z_CN = 92 :  +0.2 MeV, except Z_CN = 92, A_CN = 233 and A_CN = 234: +0.4 MeV"
   Print #f, " "
   Print #f, "Note that A_CN denotes the mass of the compound nucleus!"
   Print #f, "In the case of neutron- (or proton-) induced fission, this differs"
   Print #f, " from the mass of the target nucleus." '/
   Print #f,"  </Comments>"


	
End Sub
