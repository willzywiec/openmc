/' ENDF.bas is the central formatting routine for producing    '/
/' tables of GEF-based fission-fragment yields in ENDF format. '/

/' Karl-Heinz Schmidt, 2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,
                       2021,2022,2023,2024,2025 '/       

/' Modifications: '/
/' Calculation of cumulative yields corrected and extended (e.g. beta-plus) (31/March/2013) KHS '/
/' Alpha decay included in calculation of cumulative yields 20=<Z<=88 (10/April/2013) KHS '/
/' Uncertainties of cumulative yields consider covariances (29/May/2014) KHS '/    
/' Output of random files added (1/March/2016) KHS '/
/' Q-value limit for calculation of cumulative yields corrected (18/March/2019) KHS '/
                       

/' Other files that are included in ENDF.bas:                  '/
/'             - Branchings.bas (Table of decay branches,      '/
/'                   and computing of cumulative yields)       '/
/'             - ENDF_EOT.bas (Writes EOT mark on ENDF file.)  '/
/'             - ENDF_tape_description (Text of tape description.) '/

/' External values from GEF.bas used in ENDF.bas:              '/
/'               EMode (1: sf; 2: n,f)                         '/ 
/'               P_A_CN (Mass number of compound nucleus)      '/
/'               P_Z_CN (Atomic number of compound nucleus)    '/
/'               P_E_exc (Energy value in MeV)                 '/
/'               (energy above ground state or neutron energy) '/
/'               NZPOST(N,Z) (Table of independent yields)     '/
/'               d_NZPOST(i,N,Z) (Table of uncertainties)        '/

/' Angular-momentum distribution and population of isomers is  '/
/' calculated in NucPropx.bas.                                 '/


/' Rules for using ENDF.bas:                                   '/

/' Spontaneous fission: One call of ENDF.bas for one fissioning system '/
/' produces the tables of independent and cumulative yields.           '/

/' Neutron-induced fission: ENDF.bas is called N+3 times, if N is the  '/
/' number of energy steps.                                             '/
/' 1: One calculation with the lowest neutron energy.                  '/
/' 2. One calculation with the highest neutron energy.                 '/
/'   (These two calculations define the population of nuclides on the  '/
/'    chart of the nuclides, independent and cumulative yields.)       '/
/' 3 to N+2: A series of calculations over all energy steps.           '/
/' N+3: One calculation with the lowest neutron energy.                '/ 
/'   (This last calculation serves to finalize the yield tables.)      '/


/' Important note for the format in neutron-induced fission: '/
/' The number of energy points must be known in advance.     '/
/' Therefore, the number of energy steps in (n,f) must be adapted to the variable E_steps! '/
/' R_Emax must be set to the highest energy value (in eV). '/


Dim As String C_GEFY_Version = "GEFY 10.2"
Dim As String C_GEFY_Distribution = "DIST-JEB26"

Dim As Ubyte B_acc_limits = 0
Dim As Ubyte B_find_limits = 0
Dim As Ubyte B_spon_header = 0
Dim As UByte B_n_header = 0
Dim As UByte B_IY = 0
Dim As Ubyte B_CY_direct = 0
Dim As Ubyte B_CY_write = 0
Dim As Ubyte B_CY_read = 0
Dim As Ubyte B_write_EOT = 0
Static As Ubyte Empty_FCUMU 
B_acc_limits = 0
B_find_limits = 0
B_spon_header = 0
B_n_header = 0
B_IY = 0
B_CY_direct = 0
B_CY_write = 0
B_CY_read = 0
B_write_EOT = 0

If B_ENDF = 1 Then 

If B_Random_On = 1 Then
  If (Emode = 1) Then
    Print "Random files are not supported for spontaneous fission."
    B_Random_On = 0
  End If
  If (Emode = 2 And N_E_steps = 1) Then  ' This should not happen, because N_E_steps is set to 2 in GEF.bas for random-file option.
    Print "Random files only supported for n-induced fission with more than one energy"
    B_Random_On = 0
  End If
End If

If B_Error_Analysis = 0 Or B_Random_On = 1 Then

Print "Start ENDF routine."

If CHDIR("ENDF") Then
  MKDIR("ENDF")
  Print "Subfolder /ENDF created for output of GEF."
Else
  CHDIR("..")
End If  

Static as Integer E_steps
Static as Single R_Emax
Static as Integer A_target
If EMode = 1 Then  ' spontaneous fission
  E_steps = 1
  R_Emax = 0
  A_target = P_A_CN
End If  
If EMode = 2 Then  ' neutron-induced fission
  If N_E_Steps = 1 Then
    E_steps = 1
  ElseIf N_E_Steps = 2 Then
    E_steps = 1  
  Else  
    E_steps = N_E_steps - 3  ' number of energy values in ENDF file
  End If  
  R_Emax = 1.E6 * En_max  ' convert from MeV to eV
  A_target = P_A_CN - 1
End If  
/' e.g. Thermal, 0.4 MeV, 1 MeV, 2 MeV, 3 MeV, 4 MeV, 5 MeV, 6 MeV, ... '/

If Emode = 2 Then   ' neutron-induced fission
  E_ev = E_EXC_TRUE * 1.E6   ' energy in units of eV
   ' E_ev: True energy of incoming neutron, also for isomeric states.
   ' P_E_exc is the fictive neutron energy for capture on g.s. !
Else
  E_ev = E_EXC_TRUE * 1.E6
   ' E_ev: True excitation energy above g.s or isomeric state.
   ' P_E_exc is the excitation energy above the ground state!
End If    

#Include Once "vbcompat.bi"  ' provides FORMAT 
#Include Once "string.bi"

                                 ' Calculate cumulative yields:
Static As String CFCUMU  ' name of intermediate file for cumulative yields

Scope

Static I_ENDF_Mode As Integer

Static I_ENDF_Mode_last As Integer

Dim As Double R_AWR  ' atomic mass of fissioning nucleus
R_AWR = R_AWR_ENDF(Int(P_Z_CN),Int(A_target))

Static As Integer IA_NC(1 To 10)     ' Number of lines in file
Static As Integer IA_NFP(1 To 10)    ' Number of yield values

Static As Integer IN,IZ,IM
Static As Integer INfirst_independent(100), INlast_independent(100)
Static As Integer INfirst_cumulative(100), INlast_cumulative(100)
Static As Integer IZfirst_independent, IZlast_independent
Static As Integer IZfirst_cumulative, IZlast_cumulative
Static As Single R_Norm

Static As Integer I_MAT   ' Material information (Z, isotope and isomeric state)

Static As Integer I_MAT_last  ' Last unsed material

    /' Variables, which depend on the amount of data: '/
    IA_NC(1) = 42 ' Number of lines of first "file" in dataset (fixed)

    /' I_NFP(2) ' Number of fission-product independent yields (<= 2500) '/  
    /' IA_NC(2) ' Number of lines of second "file" in dataset '/
    /' IA_NC(2) = 2 + Ceil(I_NFP(2) * 4 / 6) '/

    /' I_NFP(3) ' Number of fission-product cumulative yields (<= 2500)  '/ 
    /' IA_NC(3) ' Number of lines of second "file" in dataset '/
    /' IA_NC(3) = 2 + Ceil(I_NFP(3) * 4 / 6) '/


    Dim As String C_Out

    Dim As Integer I_NLIB
    I_NLIB = 99  ' non-standard for GEF, tentative 
    Dim As String C_NLIB
    C_NLIB = CInteger(I_NLIB,11)

    Dim As Integer I_NMOD    ' modification version
    I_NMOD = 1
    Dim As String C_NMOD
    C_NMOD = CInteger(I_NMOD,11)

    Dim As Integer I_IPART  ' incident particle
    Dim As Integer I_ITYPE 
    ' Sub-library numbers and names:            NSUB    IPART   ITYPE
    ' Spontaneous fussion product yields:       5       0       5    
    ' Neutron-induced fission product yields:   11      1       1

    Dim As Integer I_MF   ' File number

    Dim As Integer I_MT
    ' I_MT = 19   ' first-chance fission
    ' I_MT = 451  ' descriptive data 
    ' I_MT = 454  ' independent yields 
    ' I_MT = 456  ' total number of prompt neutrons
    ' I_MT = 459  ' cumulative yields 

    ' ENDF units
    ' energies                eV
    ' cross sections          barns
    ' energy distributions    probability per eV
    ' half life               seconds

    Static As Double R_ZA   ' Z and A of fissioning nucleus
    R_ZA = 1000.0 * P_Z_CN + A_target
    Dim As String C_ZA
    C_ZA = CDouble(R_ZA)

    Dim As String C_AWR
    C_AWR = CDouble(R_AWR)

    Static As Integer I_INT = 4  ' 1-dimensional interpolation scheme
    ' I_INT = 1 ' y is constant in x
    ' I_INT = 2 ' y is linear in x
    ' I_INT = 3 ' y is linear in ln(x)
    ' I_INT = 4 ' ln(y) is linear in x
    ' I_INT = 5 ' ln(y) is linear in ln(x) 
    Dim As String C_INT

    Static As Integer I_NS,I_NSC    ' Line counter
    Static As Integer I_NS_mem   ' keeps I_NS while random files are written
    Dim As String C_NS     ' Line counter

'    Dim As Integer I_MAT   ' Material information (Z, isotope and isomeric state)

    Static As Integer I_LRP   ' Flag on resonance parameters
    Dim As String C_LRP

    Static As Integer I_LFI   ' Flag if this material fissions (0 or 1)
    Dim As String C_LFI

    Dim As String C_HL     ' File information

    Dim As Single R_ELIS   ' Excitation energy above the ground state
    Dim As String C_ELIS

    Static As Single R_STA    ' Target stability flag (0=stable, 1=unstable)   
    Dim As String C_STA

    Static As Integer I_LIS   ' State number of the target. (Ground state = 0)
    Dim As String C_LIS

    Static As Integer I_LISO  ' Isomeric state number (I_LIS >= I_LISO)
    Dim As String C_LISO

    Static As Integer I_NFOR  ' Format identifier (ENDF = 6)
    Dim As String C_NFOR

    Dim As String C_INULL
    Dim As String C_RNULL

    Static As Double R_AWI    ' Mass of projectile in neutron mass units
    Dim As String C_AWI

'   Static As Double R_EMAX   ' Upper limit of energy range for evaluation
    Dim As String C_EMAX

    Static As Integer I_LREL=1  ' Library release number
    Dim As String C_LREL 

    Static As Integer I_NSUB  ' Sub-libary number
    Dim As String C_NSUB

    Static As Integer I_NVER=1  ' Libary version number
    Dim As String C_NVER 

    Static As Double R_TEMP   ' Target temperature 
    Dim As String C_TEMP

    Static As Integer I_LDRV  ' 0: primary evaluation, >=1 special evaluation
    Dim As String C_LDRV

    Static As Integer I_NWD   ' Number of records with descriptive text 
    Dim As String C_NWD

    Static As Integer I_NXC   ' Number of records in the directory for this material 
    Dim As String C_NXC

    Dim As String C_ZSYMAM  ' Material
    Dim As String C_ALAB    ' Laboratory
    Dim As String C_EDATE   ' Date
    Dim As String C_AUTH    ' Author

    Dim As String C_REF     ' Primary reference
    Dim As String C_DDATE   ' Original distribution date
    Dim As String C_RDATE   ' Date and number of last revision 
    Dim As String C_ENDATE  ' Master file entry data

    Dim As String C_HSUB    ' Identifier for the library

    Static As Integer IA_MF(1 To 10)
    Dim As String CA_MF(1 To 10)
    Static As Integer IA_MT(1 To 10)
    Dim As String CA_MT(1 To 10)

    Dim As String CA_NC(1 To 10)
    Static As Integer IA_MOD(1 To 10)
    Dim As String CA_MOD(1 To 10)

    Static As Double R_E(1 To 10)
    Dim As String C_E(1 To 10)

    Dim As String C_LEplus1 

    Dim AS String CA_NFP(1 To 10)

    Static As Integer I_NN
    Dim As String C_NN

    Static As Integer I_LE
    Dim As String C_LE
    
    Static As Integer I_Print_Title_Line = 1

    Static NZPOSTSUM(250,100) As Single
                       /'  Title('Nuclide distribution, post-neutron')
                           Cxaxis('Neutron number')
                           Cyaxis('Proton number')
                           T ype(Float);  '/

    Static NZCUMUSUM(250,100) As Single      ' used to determine comnon limites for ENDF output covering several neutron energies
                       /'  Title('Nuclide distribution, post-neutron')
                           Cxaxis('Neutron number')
                           Cyaxis('Proton number')
                           T ype(Float);  '/

  
    I_MAT =  I_MAT_ENDF(Int(P_Z_CN),Int(A_target)) + I_E_iso

 ' The following text is outdated! (I_ENDF_Mode is used for interpolation scheme, only.)
  ' I_ENDF_Mode = 0 : Write yields immediately to file (spontaneous fission)
  ' I_ENDF_Mode = 1 : Accumulate data from different energies (neutron-induced fission)
  ' I_ENDF_Mode = 2 : Write yields (neutron-induced fission) (independent and cumulative on different files)
  ' I_ENDF_Mode = 3 : Like 2, but not the first energy point.
  ' I_ENDF_Mode = 4 : Copy cumulative yields behind the independent yields
  ' Before writing the yields with I_ENDF_Mode = 2, at least two calculations with
  ' the lowest and the highest energy, eventually with low statistics, 
  ' must be performed with I_ENDF_MODE = 1.
  I_ENDF_Mode = 0


  ' The ENDF files are structured in the following way:
  
  ' A. Spontaneous fission:
  ' 1. Fissioning nucleus
  ' 1.1. Independent yields
  ' 1.2. Cumulative yields
  ' 2. Fissioning nucleus
  ' 2.1. Independent yields
  ' 2.2. Cumulative yields
  ' ...
  
  ' -> Cumulative yields can be written immedeately after the 
  ' indenpendent yields with one call of GEF.
  
  
  ' B. Neutron-induced fission:
  ' 1. Fissioning nucleus
  ' 1.1. Independent yields
  ' 1.1.1. Lowest neutron energy
  ' 1.1.2. Next neutron energy
  ' 1.1.3. Next neutron energy
  ' ...
  ' 1.2. Cumulative yields
  ' 1.2.1. Lowest neutron energy
  ' 1.2.2. Next neutron energy
  ' 1.2.3. Next neutron energy
  ' ...
  ' 2. Fissioning nucleus
  ' 2.1. Independent yields
  ' 2.1.1. Lowest neutron energy
  ' 2.2.2. Next neutron energy
  ' ...
 
  ' -> Cumulative yields must be written independently to another file.
  ' Later they are moved behind the independent yields in the same file.

  

  Static As Integer A_target_last, P_Z_CN_last
  Static As Single P_E_exc_last

  If Emode = 1 Then                  ' Write independent and cumulative yields directly
    I_ENDF_Mode = 0
    B_acc_limits = -1
    B_find_limits = -1
    B_spon_header = -1                                  ' (spontaneous fission)
    B_IY = -1
    B_CY_direct = -1    ' Write cumulative yields directly to the ENDF output file
    B_write_EOT = -1
  End If
  
 
  If Emode = 2 Then                   ' Neutron-induced fission 
    If N_E_steps = 1 Then
      I_ENDF_Mode = 0
      B_acc_limits = -1
      B_find_limits = -1
      B_n_header = -1
      B_IY = -1
      B_CY_direct = -1
      B_Write_EOT = -1
    End If
    If N_E_steps = 2 Then
      If I_E_step = 1 Then
        B_acc_limits = -1
        B_find_limits = -1
      End If
      If I_E_step = 2 Then
        B_n_header = -1
        B_IY = -1
        B_CY_direct = -1
        B_write_EOT = -1
      End If
    End If
    If N_E_steps > 2 Then
      IF I_E_Step = 1 Then B_acc_limits = -1    ' Determine limits
      If I_E_Step = 2 Then 
         B_acc_limits = -1
         B_find_limits = -1
      End If   
      If I_E_Step = 3 Then                  ' First energy  
        I_ENDF_Mode = 2
        B_n_header = -1
        B_IY = -1
        If B_Error_Analysis Then
          B_CY_direct = -1
        Else 
          B_CY_write = -1                  ' Write cumulative yields to buffer file
        End If  
      End If   
      If I_E_Step > 3 And I_E_Step < N_E_Steps Then
        I_ENDF_Mode = 3
        B_IY = -1
        If B_Error_Analysis Then
          B_n_header = -1       
          B_CY_direct = -1
        Else 
          B_CY_write = -1                 ' Write cumulative yields to buffer file
        End If  
      End If
      If I_E_Step = N_E_Steps Then          ' Copy cumulative yields and close file 
        I_ENDF_Mode = 4
        If B_Error_Analysis = 0 Then B_CY_read = -1
        B_write_EOT =  -1         
      End If  
    End If
  End If

  A_target_last = A_target
  P_Z_CN_last = P_Z_CN
  P_E_exc_last = P_E_exc


  '*****************************************************
  '*** Sum up yields from different neutron energies ***
  '*****************************************************
/'
scope  
Dim As Single Ztest(100)
For IZ = 1 To 100
For IN = 1 To 200
  Ztest(IZ) = Ztest(IZ) + NZPOST(IN,IZ)
Next IN
Next IZ
Print 467,"B_ac_limits",B_acc_limits
Print 477,"B_find_limits";B_find_limits

For IZ = 1 To 100
If Ztest(IZ) > 0 Then Print 470,IZ,Ztest(IZ)
Next IZ  
end scope
'/

  If B_acc_limits Then
    For IN = 1 To 200
      For IZ = 1 To 100
        NZPOSTSUM(IN,IZ) = NZPOSTSUM(IN,IZ) + NZPOST(IN,IZ)
      Next
    Next  
    For IN = 1 To 200
      For IZ = 1 To 100
        For IM = 0 To 2
          NZCUMUSUM(IN,IZ) = NZCUMUSUM(IN,IZ) + NZIcumu(IN,IZ,IM)
        Next  
      Next
    Next  
  End If   
  
  
    ' Normalize yields to 2 
  R_Norm = 0
  For IZ = 1 To 100
    For IN = 1 To 200
      R_Norm = R_Norm + NZPOST(IN,IZ)
    Next
  Next
  R_Norm = R_Norm * P_selected / 2.0   ' P_selected for filter on selected fission channel   
'  R_Norm = 100.0


  '************************************   
  '*** Determine array limits       ***
  '************************************  

  If B_find_limits Then     
    Dim As Single Threshold = 1.5   
       ' at least 2 counts requested for avoiding data with excessive error bars
    '-----------------------------------------
    '--- Independent and cumulative yields ---
    '-----------------------------------------
  
     ' Determine limits with yields > Threshold
    For IZ = 1 To 100
      INfirst_independent(IZ) = 0
      INlast_independent(IZ) = -1
      INfirst_cumulative(IZ) = 0
      INlast_cumulative(IZ) = -1
    Next
    IZfirst_independent = 0
    IZlast_independent = -1
    IZfirst_cumulative = 0
    IZlast_cumulative = -1

    For IZ = 1 To 100
      For IN = 1 To 200
        If NZPOSTSUM(IN,IZ) > Threshold*Racc Then
' print IZ,IN,NZPOSTSUM(IN,IZ)
          INlast_independent(IZ) = IN
        End If
      Next  
      For IN = 200 To 1 Step -1
        If NZPOSTSUM(IN,IZ) > Threshold*Racc Then
          INfirst_independent(IZ) = IN
        End If
      Next
    Next
    
    For IZ = 1 To 100
      For IN = 1 To 200
        If NZCUMUSUM(IN,IZ) > Threshold*Racc Then
          INlast_cumulative(IZ) = IN
        End If
      Next
      For IN = 200 To 1 Step -1  
        If NZCUMUSUM(IN,IZ) > Threshold*Racc Then
          INfirst_cumulative(IZ) = IN
        End If
      Next  
    Next

    For IZ = 100 To 1 Step -1
      If INfirst_independent(IZ) <= INlast_independent(IZ) Then
        IZfirst_independent = IZ
      End If
      If INfirst_cumulative(IZ) <= INlast_cumulative(IZ) Then
        IZfirst_cumulative = IZ
      End If
    Next
    For IZ = 1 To 100
      If INfirst_independent(IZ) <= INlast_independent(IZ) Then
        IZlast_independent = IZ
      End If
      If INfirst_cumulative(IZ) <= INlast_cumulative(IZ) Then
        IZlast_cumulative = IZ
      End If
    Next    
    
    
    ' Extend limits for independent yields to the 
    ' limits of cumulative yields (ENDF rule)
    
 /'   IZfirst_independent = Min(IZfirst_independent,IZfirst_cumulative)
    IZlast_independent = Max(IZlast_independent,IZlast_cumulative)
    For IZ = 1 To 100
      INfirst_independent(IZ) = Min(INfirst_independent(IZ),INfirst_cumulative(IZ))
      INlast_independent(IZ) = Max(INlast_independent(IZ),INlast_cumulative(IZ))
    Next IZ
    IZfirst_cumulative = IZfirst_independent
    IZlast_cumulative = IZlast_independent
    For IZ = 1 To 100
      INfirst_cumulative(IZ) = INfirst_independent(IZ)
      INlast_cumulative(IZ) = INfirst_independent(IZ)
    Next IZ '/

/'
Scope  
Dim As Single Ztest(100)
For IZ = IZfirst_independent To IZlast_independent
  For IN = INfirst_independent(IZ) To INlast_independent(IZ)
    Ztest(IZ) = Ztest(IZ) + NZPOST(IN,IZ) 
  Next IN  
Next IZ  
For IZ = IZfirst_independent To IZlast_independent
  Print 594,IN+IZ,IZ,Ztest(IZ)
Next IZ  
End Scope
'/
     
    ' Clear arrays of summed yields
    For IZ = Lbound(NZPOSTSUM,2) To Ubound(NZPOSTSUM,2)
      For IN = Lbound(NZPOSTSUM,1) To Ubound(NZPOSTSUM,1)
        NZPOSTSUM(IN,IZ) = 0
      Next
    Next
    For IZ = Lbound(NZCUMUSUM,2) To Ubound(NZCUMUSUM,2)
      For IN = Lbound(NZCUMUSUM,1) To Ubound(NZCUMUSUM,1)
        NZCUMUSUM(IN,IZ) = 0
      Next
    Next
     
     ' Calculate number of yield data 
    IA_NFP(2) = 0 
    For IZ = IZfirst_independent To IZlast_independent
      If INlast_independent(IZ) > 0 And INfirst_independent(IZ) > 0 Then
    '   IA_NFP(2) = IA_NFP(2) + INlast(IZ) - INfirst(IZ) + 1
        For IN = INfirst_independent(IZ) To INlast_independent(IZ)
          IA_NFP(2) = IA_NFP(2) + NStates_for_ZA(IZ,IZ+IN)
        Next 
      End If    
    Next 
  
    IA_NFP(3) = 0 
    For IZ = IZfirst_cumulative to IZlast_cumulative
      If INlast_cumulative(IZ) > 0 And INfirst_cumulative(IZ) > 0 Then
    '   IA_NFP(3) = IA_NFP(3) + INlast(IZ) - INfirst(IZ) + 1
        For IN = INfirst_cumulative(IZ) To INlast_cumulative(IZ)
          IA_NFP(3) = IA_NFP(3) + NStates_for_ZA(IZ,IZ+IN)
        Next 
      End If    
    Next 
  
  End If

  
  '************************************   
  '*** Write on File                ***
  '************************************  
  
  CGEFY_new = "ENDF\"
  CGEFY_new = CGEFY_new+"GEFY_"+Trim(Str(P_Z_CN))+"_"+Trim(Str(A_target))
  If I_E_iso > 0 Then
    If Emode = 1 Then CGEFY_new = CGEFY_new + "f" + Trim(Str(I_E_iso))
    If Emode = 2 Then CGEFY_new = CGEFY_new + "m" + Trim(Str(I_E_iso))
  End If  
  If EMode = 1 Then CGEFY_new = CGEFY_new + "_s"
  If EMode = 2 Then CGEFY_new = CGEFY_new + "_n"
  CGEFY_part = CGEFY_new 
  CGEFY_new = CGEFY_part + ".dat"
  
  
  CGEFY_last = CGEFY
  CGEFY = CGEFY_new
  
  Print "Determining cumulative yields."
  Print "Independent and cumulative yields will be written to file"
  Print CGEFY
  
'Print "ENDF 1"  
  

  CFCUMU = "tmp/CUMU"+ Trim(Str(I_thread)) + ".dat"
  If I_E_Step = 1 Then 
    Empty_FCUMU = -1
    I_NS_mem = 0
  End If  

  fENDF = Freefile
  If B_Error_Analysis = 1 Then
    CGEFY_random = CGEFY_part + "_E"+Trim(Str(I_E_step-2 + I_First_E_step-1))+ _
                            "_R"+Trim(Str(I_Error+1))+".rnd"
    Open CGEFY_random For Append As #fENDF
  Else   
    Open CGEFY For Append As #fENDF
  End If


  ' Spontaneous fission
  If B_spon_header Then

    '****************************************
    '*** File 1: General information      ***
    '****************************************

    If I_Print_Title_Line = 1 Or B_Error_Analysis Then
      If B_Error_Analysis = 0 Then I_Print_Title_Line = 0

      ' TITLE line                                                              "
      C_HL = " GEFY-10.2  SPONTANEOUS FISSION PRODUCT YIELDS FILE February 2026 "
            ' (length of C_HL: 67 characters)
      I_MAT =  I_MAT_ENDF(Int(P_Z_CN),Int(A_target))              
      I_MF = 0    ' File number 
      I_MT = 0
      I_NS = 0    ' Line counter 
       C_out = C_HL + CTrailer(I_MAT,I_MF,I_MT,I_NS)
      Print #fENDF,C_out
    End If  
    
    ' HEAD line
    I_LRP = -1   ' -1: No resonance parameters
    I_LFI = 1    ' 1: Fissionable material
    I_MF = 1     ' File number 
    I_MT = 451   ' 451: General information 
    I_NS = 1

    C_LRP = CInteger(I_LRP,11)
    C_LFI = CInteger(I_LFI,11)

    C_out = C_ZA + C_AWR + C_LRP + C_LFI + C_NLIB + C_NMOD _
             + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out

    'CONT line
    R_ELIS = 0      ' Excitation energy relative to the ground state
    R_STA = 1       ' Preliminary    
    I_LIS = 0       ' State number of the target nucleus (ground state = 0)
    I_LISO = 0      ' 0: No isomeric state 
    I_NFOR = 6      ' 6: ENDF6 format
    I_NS = I_NS + 1

  /' For isomeric states: '/
    R_ELIS = E_EXC_ISO * 1.E6
    I_LIS = I_E_ISO  
    I_LISO = I_LIS 

    C_ELIS  = CDouble(R_ELIS)
    C_STA   = CDouble(R_STA)    
    C_LIS   = CInteger(I_LIS,11)
    C_LISO  = CInteger(I_LISO,11)
    C_INULL = CInteger(0,11)
    C_NFOR  = CInteger(I_NFOR,11)

    C_out = C_ELIS + C_STA + C_LIS + C_LISO + C_INULL + C_NFOR _
             + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out             


    ' CONT line 
    R_AWI  = 0   ' Mass of projectile in neutron mass units
'   R_EMAX = 0
'   I_LREL = 1   ' Library release number
    I_NSUB = 5   ' Spontaneous fission
'   I_NVER = 0   ' Version number
    I_NS = I_NS + 1

    C_AWI   = CDouble(R_AWI)
    C_EMAX  = CDouble(R_EMAX)
    C_LREL  = CInteger(I_LREL,11)
    C_INULL = CInteger(0,11)
    C_NSUB  = CInteger(I_NSUB,11)
    C_NVER  = CInteger(I_NVER,11)

    C_out = C_AWI + C_EMAX + C_LREL + C_INULL + C_NSUB + C_NVER _ 
             + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out
            
            
    ' CONT line             
    R_TEMP = 0
    I_LDRV = 0
    I_NWD = 35 
    I_NXC = 3  
    I_NS = I_NS + 1

    C_TEMP  = CDouble(R_TEMP)
    C_RNULL = CDouble(0.0)
    C_LDRV  = CInteger(I_LDRV,11)
    C_INULL = CInteger(0,11)     
    C_NWD   = CInteger(I_NWD,11)
    C_NXC   = CInteger(I_NXC,11)      

    C_out = C_TEMP + C_RNULL + C_LDRV + C_INULL + C_NWD + C_NXC _
             + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out
             
             
    C_ZSYMAM = CInteger(Int(P_Z_CN),3) + "-" _
             + Mid(CElement(Int(P_Z_CN)) + " ",1,2) + "-" _
             + CInteger(Int(A_target),3) 
    If I_E_ISO > 0 Then
      C_ZSYMAM = C_ZSYMAM + "M"
    Else
      C_ZSYMAM = C_ZSYMAM + " "
    End If         
    C_ALAB  = "CENBG      " 
    C_EDATE = "EVAL-FEB26 "
    C_AUTH  = "K.H.SCHMIDT"
    I_NS = I_NS + 1
    C_out = C_ZSYMAM + C_ALAB + C_EDATE + C_AUTH + String(22," ") _     
               + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out


    C_REF    = "                      "   ' Primary reference 
    C_DDATE  = "DIST-AUG11 "   ' Original distribution data
    C_RDATE  = "DIST-FEB26 "   ' Date and number of last revision 
    C_ENDATE = "           "   ' Master file entry data
    I_NS = I_NS + 1
    C_out = C_REF + C_DDATE + C_RDATE + String(11," ") + C_ENDATE _
               + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out

    If B_Error_Analysis Then
      C_HSUB = "----GEFY-10.2 RANDOM  " + "MATERIAL " + CInteger(I_MAT,4) _
           + String(40," ")
    Else
      C_HSUB = "----GEFY-10.2         " + "MATERIAL " + CInteger(I_MAT,4) _
           + String(40," ")
    End If       
    C_HSUB = MID(C_HSUB,1,66)     
    I_NS = I_NS + 1
    C_out = C_HSUB + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out        
         
     
    C_HSUB = "-----SPONTANEOUS FISSION PRODUCT YIELDS     " _
           + String(22," ")
    I_NS = I_NS + 1
    C_out = C_HSUB + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out      
         
         
    C_HSUB = "------ENDF-6 FORMAT   " + String(44," ")
    I_NS = I_NS + 1
    C_out = C_HSUB + CTrailer(I_MAT,I_MF,I_MT,I_NS)         
    Print #fENDF,C_out      

    #Include "ENDF_tape_description.bas"

    ' CONT line
    IA_MF(1) = 1
    IA_MT(1) = 451     ' General information
    IA_MOD(1) = 0            
    I_NS = I_NS + 1    ' Line counter 

    CA_MF(1)  = CInteger(IA_MF(1),11)
    CA_MT(1)  = CInteger(IA_MT(1),11)
    CA_NC(1)  = CInteger(IA_NC(1),11)
    CA_MOD(1) = CInteger(IA_MOD(1),11)
    C_out = String(22," ") + CA_MF(1) + CA_MT(1) + CA_NC(1) + CA_MOD(1)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out                 
              

    ' CONT line             
    IA_MF(2) = 8
    IA_MT(2) = 454   ' Independent yields
    Dim R As Single
    R = Ceil(IA_NFP(2) * 4/6)
    IA_NC(2) = 1 + (1 + R) * E_steps ' Number of lines in file
    IA_MOD(2) = 0            
    I_NS = I_NS + 1  ' Line counter

    CA_MF(2) = CInteger(IA_MF(2),11)
    CA_MT(2) = CInteger(IA_MT(2),11)
    CA_NC(2) = CInteger(IA_NC(2),11)
    CA_MOD(2) = CInteger(IA_MOD(2),11)
    C_out = String(22," ") + CA_MF(2) + CA_MT(2) + CA_NC(2) + CA_MOD(2)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out                 
              
     
    ' CONT line             
    IA_MF(3) = 8
    IA_MT(3) = 459   ' Cumulative yields
    IA_NC(3) = 1 + (1 + Ceil(IA_NFP(3) * 4 / 6)) * E_steps  
    IA_MOD(3) = 0            
    I_NS = I_NS + 1  ' Line counter

    CA_MF(3) = CInteger(IA_MF(3),11)
    CA_MT(3) = CInteger(IA_MT(3),11)
    CA_NC(3) = CInteger(IA_NC(3),11)
    CA_MOD(3) = CInteger(IA_MOD(3),11)
    C_out = String(22," ") + CA_MF(3) + CA_MT(3) + CA_NC(3) + CA_MOD(3)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out                 
              

    ' SEND line
    I_MF = 1
    I_MT = 0
    I_NS = 99999 
    C_out = " 0.000000+0 0.000000+0          0          0          0          0"
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)              
    Print #fENDF,C_out                 
          
          
    I_MF = 0
    I_MT = 0          
    I_NS = 0             
    C_out = String(66," ") + CTrailer(I_MAT,I_MF,I_MT,I_NS) 
    Print #fENDF,C_out  
             
             
    ' HEAD line
    I_LE = 0         ' No energy dependent yields given
    ' I_MAT =  I_MAT_ENDF(Int(P_Z_CN),Int(A_target))     ' I_MAT is already set 
    I_MF = 8         ' File number (reaction products)
    I_MT = 454       ' 454: Independent yields
    I_NS = I_NS + 1  ' Line counter

    C_LEplus1 = CInteger(I_LE + 1,11)
    C_LFI = CInteger(I_LFI,11)
    C_INull = CInteger(0,11)

    C_out = C_ZA + C_AWR + C_LEplus1+ C_INull + C_INull + C_INull _
               + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out           

             
  End If ' Spontaneous fission     
  
             
' print "ENDF 2"     
              
  If B_n_header Then  ' neutron-induced fission         
             
  ' Neutron-induced fission
'  Print "ENDF.bas: I_Print_Title_Line, B_Error_Analysis",I_Print_Title_line,B_Error_Analysis

    If I_Print_Title_Line = 1 Or B_Error_Analysis Then
      If B_Error_Analysis = 0 Then I_Print_Title_Line = 0
      ' This part only at the beginning of the dataset.
      ' Data for other systems are written into the same dataset
      ' without repeating this title line.
    
      ' File 1: General information                                             "
      C_HL = " GEFY-10.2  N-INDUCED FISSION PRODUCT YIELDS FILE February 2026   "
           ' (length of C_HL: 67 characters)
      I_MAT =  I_MAT_ENDF(Int(P_Z_CN),Int(A_target)) + I_E_iso
      I_MF = 0    ' File number 
      I_MT = 0
      I_NS = 0    ' Line counter 

      C_out = C_HL + CTrailer(I_MAT,I_MF,I_MT,I_NS)
      Print #fENDF,C_out
    End If  

   
    ' HEAD line
    I_LRP = -1   ' -1: No resonance parameters
    I_LFI = 1    ' 1: Fissionable material
    I_MF = 1     ' File number 
    I_MT = 451   ' 451: General information 
  ' I_NS = 1  ???
    I_NS = I_NS + 1
      
    C_LRP = CInteger(I_LRP,11)
    C_LFI = CInteger(I_LFI,11)

    C_out = C_ZA + C_AWR + C_LRP + C_LFI + C_NLIB + C_NMOD _
           + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out


    ' CONT line
    R_ELIS = 0      ' Excitation energy relative to the ground state
    R_STA = 1       ' Preliminary    
    I_LIS = 0       ' State number of the target nucleus (ground state = 0)
    I_LISO = 0      ' 0: No isomeric state 
    I_NFOR = 6      ' 6: ENDF6 format
    I_NS = I_NS + 1

  /' For isomeric states: '/
    R_ELIS = E_EXC_ISO * 1.E6
    I_LIS = I_E_ISO  
    I_LISO = I_LIS 

    C_ELIS  = CDouble(R_ELIS)
    C_STA   = CDouble(R_STA)    
    C_LIS   = CInteger(I_LIS,11)
    C_LISO  = CInteger(I_LISO,11)
    C_INULL = CInteger(0,11)
    C_NFOR  = CInteger(I_NFOR,11)

    C_out = C_ELIS + C_STA + C_LIS + C_LISO + C_INULL + C_NFOR _
           + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out                 
    
    
    ' CONT line 
    R_AWI  = 1   ' Mass of projectile in neutron mass units
'   R_EMAX = 0   ' preliminary (maximum energy of series) 
'   I_LREL = 1   ' library release number 
    I_NSUB = 11  ' neutron-induced fission 
'   I_NVER = 0   ' version number
    I_NS = I_NS + 1

    C_AWI   = CDouble(R_AWI)
    C_EMAX  = CDouble(R_EMAX)
    C_LREL  = CInteger(I_LREL,11)
    C_INULL = CInteger(0,11)
    C_NSUB  = CInteger(I_NSUB,11)
    C_NVER  = CInteger(I_NVER,11)

    C_out = C_AWI + C_EMAX + C_LREL + C_INULL + C_NSUB + C_NVER _ 
           + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out    


    ' CONT line             
    R_TEMP = 0
    I_LDRV = 0
    I_NWD = 35  
    I_NXC = 3   
    I_NS = I_NS + 1

    C_TEMP  = CDouble(R_TEMP)
    C_RNULL = CDouble(0.0)
    C_LDRV  = CInteger(I_LDRV,11)
    C_INULL = CInteger(0,11)     
    C_NWD   = CInteger(I_NWD,11)
    C_NXC   = CInteger(I_NXC,11)      

    C_out = C_TEMP + C_RNULL + C_LDRV + C_INULL + C_NWD + C_NXC _
           + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out    
    
    
    C_ZSYMAM = CInteger(Int(P_Z_CN),3) + "-" _
           + Mid(CElement(Int(P_Z_CN)) + " ",1,2) + "-" _
           + CInteger(Int(A_target),3) 
    If I_E_ISO > 0 Then
      C_ZSYMAM = C_ZSYMAM + "M"
    Else
      C_ZSYMAM = C_ZSYMAM + " "
    End If         
    C_ALAB  = "CENBG      " 
    C_EDATE = "EVAL-FEB26 "
    C_AUTH  = "K.H.SCHMIDT"
    I_NS = I_NS + 1
    C_out = C_ZSYMAM + C_ALAB + C_EDATE + C_AUTH + String(22," ") _     
           + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out    
        
        
    C_REF    = "                      "   ' Primary reference 
    C_DDATE  = "DIST-AUG11 "   ' Original distribution data
    C_RDATE  = "DIST-FEB26 "   ' Date and number of last revision 
    C_ENDATE = "           "   ' Master file entry data
    I_NS = I_NS + 1
    C_out = C_REF + C_DDATE + C_RDATE + String(11," ") + C_ENDATE _
           + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out

    If B_Error_Analysis Then
      C_HSUB = "----GEFY-10.2 RANDOM  " + "MATERIAL " + CInteger(I_MAT,4) _
           + String(40," ")
    Else
      C_HSUB = "----GEFY-10.2         " + "MATERIAL " + CInteger(I_MAT,4) _
           + String(40," ")
    End If       
    C_HSUB = MID(C_HSUB,1,66)     
    I_NS = I_NS + 1
    C_out = C_HSUB + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out        
    
    
    C_HSUB = "-----NEUTRON-INDUCED FISSION PRODUCT YIELDS " _
          + String(22," ")
    I_NS = I_NS + 1
    C_out = C_HSUB + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out      


    C_HSUB = "------ENDF-6 FORMAT   " + String(44," ")
    I_NS = I_NS + 1
    C_out = C_HSUB + CTrailer(I_MAT,I_MF,I_MT,I_NS)         
    Print #fENDF,C_out      

    #Include "ENDF_tape_description.bas"


    ' CONT line
    IA_MF(1) = 1
    IA_MT(1) = 451     ' General information
    IA_MOD(1) = 0            
    I_NS = I_NS + 1    ' Line counter 

    CA_MF(1)  = CInteger(IA_MF(1),11)
    CA_MT(1)  = CInteger(IA_MT(1),11)
    CA_NC(1)  = CInteger(IA_NC(1),11)
    CA_MOD(1) = CInteger(IA_MOD(1),11)
    C_out = String(22," ") + CA_MF(1) + CA_MT(1) + CA_NC(1) + CA_MOD(1)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out                 
             

    ' CONT line             
    IA_MF(2) = 8
    IA_MT(2) = 454   ' Independent yields
    Dim R As Single
    R = Ceil(IA_NFP(2) * 4/6)
    IA_NC(2) = 1 + (1 + R) * E_steps ' Number of lines in file
    IA_MOD(2) = 0            
    I_NS = I_NS + 1  ' Line counter

    CA_MF(2) = CInteger(IA_MF(2),11)
    CA_MT(2) = CInteger(IA_MT(2),11)
    CA_NC(2) = CInteger(IA_NC(2),11)
    CA_MOD(2) = CInteger(IA_MOD(2),11)
    C_out = String(22," ") + CA_MF(2) + CA_MT(2) + CA_NC(2) + CA_MOD(2)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out                 
              
     
    ' CONT line             
    IA_MF(3) = 8
    IA_MT(3) = 459   ' Cumulative yields
    IA_NC(3) = 1 + (1 + Ceil(IA_NFP(3) * 4 / 6)) * E_steps   
    IA_MOD(3) = 0            
    I_NS = I_NS + 1  ' Line counter

    CA_MF(3) = CInteger(IA_MF(3),11)
    CA_MT(3) = CInteger(IA_MT(3),11)
    CA_NC(3) = CInteger(IA_NC(3),11)
    CA_MOD(3) = CInteger(IA_MOD(3),11)
    C_out = String(22," ") + CA_MF(3) + CA_MT(3) + CA_NC(3) + CA_MOD(3)
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)  
    Print #fENDF,C_out                 
               

    ' SEND line
    I_MF = 1
    I_MT = 0
    I_NS = 99999 
    C_out = " 0.000000+0 0.000000+0          0          0          0          0"
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)              
    Print #fENDF,C_out                 
         
          
    I_MF = 0
    I_MT = 0          
    I_NS = 0             
    C_out = String(66," ") + CTrailer(I_MAT,I_MF,I_MT,I_NS) 
    Print #fENDF,C_out  
                        
           
    ' HEAD line
    If B_Error_Analysis Then
      I_LE = 0
    Else
      I_LE = E_steps - 1  ' E_steps energy dependent yields given
    End If
    ' I_MAT =  I_MAT_ENDF(Int(P_Z_CN),Int(A_target))     ' I_MAT is already set 
    I_MF = 8         ' File number (reaction products)
    I_MT = 454       ' 454: Independent yields
    I_NS = I_NS + 1  ' Line counter

    C_LEplus1 = CInteger(I_LE + 1,11)
    C_LFI = CInteger(I_LFI,11)
    C_INull = CInteger(0,11)

    C_out = C_ZA + C_AWR + C_LEplus1+ C_INull + C_INull + C_INull _
             + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out           
        
  End If   ' neutron-induced fission



'Print "ENDF 3"


  ' Independent yields
  If B_IY Then  
        
    If B_Error_Analysis = 0 And I_NS_mem > 0 Then 
      I_NS = I_NS_mem
    End If       
        
  ' LIST line   
  ' I_NFP(2)      ' Number of fission-product nuclide states (<= 2500)   
    R_E(1) = E_ev
    I_NN = 4 * IA_NFP(2)   ' Number of numerical values
    I_MF = 8
    I_MT = 454   ' Independent yields    
    I_NS = I_NS + 1    ' Line counter

    C_E(1) = CDouble(R_E(1)) 
    C_RNull = CDouble(0)
    If I_Endf_Mode = 3 Then 
      C_LE = CInteger(I_INT,11)  ' Interpolation scheme (C_LE is misused!)
    Else
      C_LE = CInteger(I_LE,11)   ' Energy values - 1
    End If  
    C_INull = CInteger(0,11)
    C_NN = CInteger(I_NN,11)
    CA_NFP(2) = CInteger(IA_NFP(2),11)   
           
    C_Out = C_E(1) + C_RNull + C_LE + C_INull + C_NN + CA_NFP(2) _          
                    + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out   
             
             
             
    ' LIST lines, print nuclide yields         
    I_NS = I_NS + 1        
    C_out = ""   
    For IZ = IZfirst_independent To IZlast_independent
      For IN = INfirst_independent(IZ) To INlast_independent(IZ)
        If NStates_for_ZA(IZ,IZ+IN) = 1 Then  ' number of states including ground state
          C_out = C_out + CDouble(1000*IZ+IZ+IN)   ' Nuclide
          Testprint(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NS),I_NS)
          C_out = C_out + CDouble(0.E0)            ' Isomer  
          Testprint(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NS),I_NS)
          C_out = C_out + CDouble(NZPOST(IN,IZ)/R_Norm)   ' Yield
          Testprint(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NS),I_NS)
          C_out = C_out + CDouble(d_NZPOST(0,IN,IZ)/R_Norm) ' Uncertainty
          Testprint(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NS),I_NS)
        Else
      
          I = ISO_for_ZA(IZ,IZ+IN)     ' Index of Isostab array for this nucleus.
          For J = 0 To Isotab(I).N_STATES-1  ' Loop over all (N_STATES) states (0=ground state)
            For K = 1 To Isotab(I).N_STATES  ' Loop over all (N_STATES) states (0=ground state)
              IF Isotab(I).I_ISO(K) = J Then ' Get ENDF order of isomers
'Print "Z;A;J;Prob,Norm ";IZ;IZ+IN;J,Isotab(I).R_prob(K);R_Norm
                C_out = C_out + CDouble(1000*IZ+IZ+IN)   ' Nuclide
                Testprint(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NS),I_NS)
                C_out = C_out + CDouble(J)               ' Isomer  
                Testprint(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NS),I_NS)
                C_out = C_out + CDouble(NZPOST(IN,IZ)*Isotab(I).R_prob(K)/R_Norm)   ' Yield
                Testprint(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NS),I_NS)
                C_out = C_out + CDouble(d_NZPOST(0,IN,IZ)*Isotab(I).R_prob(K)/R_Norm) ' Uncertainty
                Testprint(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NS),I_NS)
              End If
            Next      
          Next
        End If 
      Next
    Next    
    IF C_out <> "" Then 
      C_out = Mid(C_out + String(66," "),1,66)
      C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)
      Print #fENDF,C_out
    Else
      I_NS = I_NS - 1  
    End If     
    
    IF B_Error_Analysis = 0 Then I_NS_mem = I_NS     
    
  End If  
  
'Print "ENDF 4"
  
  ' Cumulative yields     
  
  ' Spontaneous fission or random files or n-induced fission with 1 energy
  IF B_CY_direct Then
  
    ' Short header, only when switching from independent to cumulative yields
    
    ' SEND line
    I_MT = 0
    I_NS = 99999 
    C_out = " 0.000000+0 0.000000+0          0          0          0          0"
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)              
    Print #fENDF,C_out                 
   
    ' HEAD line
    I_LE = 0         ' No energy dependence given 
    ' I_MAT =  I_MAT_ENDF(Int(P_Z_CN),Int(A_target))     ' I_MAT is already set 
    I_MF = 8         ' File number (reaction products)
    I_MT = 459       ' 454: Independent yields
    I_NS = 1         ' Line counter

    C_LEplus1 = CInteger(I_LE + 1,11)
    C_LFI = CInteger(I_LFI,11)
    C_INull = CInteger(0,11)

    C_out = C_ZA + C_AWR + C_LEplus1+ C_INull + C_INull + C_INull _
               + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out                 
         
  ' LIST line   
  ' I_NFP(3)      ' Number of fission-product nuclide states (<= 2500)   
    R_E(1) = E_eV
    I_NN = 4 * IA_NFP(3)   ' Number of numerical values
    I_NS = I_NS + 1    ' Line counter

    C_E(1) = CDouble(R_E(1)) 
    C_RNull = CDouble(0)
    C_LE = CInteger(I_LE,11)  
    C_INull = CInteger(0,11)
    C_NN = CInteger(I_NN,11)
    CA_NFP(3) = CInteger(IA_NFP(3),11)          
    C_Out = C_E(1) + C_RNull + C_LE + C_INull + C_NN + CA_NFP(3) _          
                    + CTrailer(I_MAT,I_MF,I_MT,I_NS)
    Print #fENDF,C_out            
         
    ' LIST lines, print cumulative nuclide yields          
    I_NS = I_NS + 1        
    C_out = ""   
    
    For IZ = IZfirst_cumulative To IZlast_cumulative
      For IN = INfirst_cumulative(IZ) To INlast_cumulative(IZ)
        If NStates_for_ZA(IZ,IZ+IN) = 1 Then  ' number of states including ground state
          C_out = C_out + CDouble(1000*IZ+IZ+IN)   ' Nuclide
          Testprint(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NS),I_NS)
          C_out = C_out + CDouble(0.E0)            ' Isomer  
          Testprint(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NS),I_NS)
          C_out = C_out + CDouble(NZIcumu(IN,IZ,0)/R_Norm)   ' Yield
          Testprint(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NS),I_NS)
          C_out = C_out + CDouble(d_NZIcumu(0,IN,IZ,0)/R_Norm) ' Uncertainty
          Testprint(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NS),I_NS)
        Else
          I = ISO_for_ZA(IZ,IZ+IN)     ' Index of Isostab array for this nucleus.
          For J = 0 To Isotab(I).N_STATES-1  ' Loop over all (N_STATES) states (0=ground state)
            For K = 1 To Isotab(I).N_STATES  ' Loop over all (N_STATES) states (0=ground state)
              IF Isotab(I).I_ISO(K) = J Then ' Get ENDF order of isomers
                C_out = C_out + CDouble(1000*IZ+IZ+IN)   ' Nuclide
                Testprint(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NS),I_NS)
                C_out = C_out + CDouble(J)               ' Isomer  
                Testprint(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NS),I_NS)
                C_out = C_out + CDouble(NZIcumu(IN,IZ,J)/R_Norm)   ' Yield
                Testprint(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NS),I_NS)
                C_out = C_out + CDouble(d_NZIcumu(0,IN,IZ,J)/R_Norm) ' Uncertainty
                Testprint(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NS),I_NS)
              End If
            Next      
          Next
        End If 
      Next
    Next    
    
    IF C_out <> "" Then 
      C_out = Mid(C_out + String(66," "),1,66)
      C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)
      Print #fENDF,C_out
    Else
      I_NS = I_NS - 1  
    End If     

   ' SEND line
    I_MT = 0
    I_NS = 99999 
    C_out = " 0.000000+0 0.000000+0          0          0          0          0"
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NS)              
    Print #fENDF,C_out                 

    I_MF = 0
    I_MT = 0          
    I_NS = 0             
    C_out = String(66," ") + CTrailer(I_MAT,I_MF,I_MT,I_NS) 
    Print #fENDF,C_out  
                        
    I_MAT = 0
    C_out = String(66," ") + CTrailer(I_MAT,I_MF,I_MT,I_NS) 
    Print #fENDF,C_out  

  End If

'Print "ENDF 5"
   
  If B_CY_write Then 
  
    fCUMU = FreeFile
    
    If Empty_FCUMU Then
      Open CFCUMU For Output As #fCUMU
      
      ' Short header, only when switching from independent to cumulative yields

      ' SEND line
      I_MT = 0
      I_NSC = 99999 
      C_out = " 0.000000+0 0.000000+0          0          0          0          0"
      C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NSC)              
      Print #fCUMU,C_out                 
      I_NSC = 1         ' Line counter
      
    ' HEAD line
    If B_Error_Analysis = 1 Then
      I_LE = 0
    Else  
      I_LE = E_Steps - 1   ' E_step energy dependent yields given
    End If
    ' I_MAT =  I_MAT_ENDF(Int(P_Z_CN),Int(A_target))     ' I_MAT is already set 
    I_MF = 8         ' File number (reaction products)
    I_MT = 459       ' 459: Cumulative yields

    C_LEplus1 = CInteger(I_LE + 1,11)
    C_LFI = CInteger(I_LFI,11)
    C_INull = CInteger(0,11)

    C_out = C_ZA + C_AWR + C_LEplus1+ C_INull + C_INull + C_INull _
             + CTrailer(I_MAT,I_MF,I_MT,I_NSC)
    Print #fCUMU,C_out       
      
      Empty_FCUMU = 0
    Else
      Open CFCUMU For Append As #fCUMU
    End If  
  


      

  
'Print "ENDF 6"  

  ' LIST line   
  ' I_NFP(2)      ' Number of fission-product nuclide states (<= 2500)   
    R_E(1) = E_ev
    I_NN = 4 * IA_NFP(3)   ' Number of numerical values
    I_MF = 8         ' File number (reaction products)
    I_MT = 459       ' 459: Cumulative yields
    I_NSC = I_NSC + 1    ' Line counter

    C_E(1) = CDouble(R_E(1)) 
    C_RNull = CDouble(0)
    If I_Endf_Mode = 3 Then 
      C_LE = CInteger(I_INT,11)  ' Interpolation scheme (C_LE is misused!)
    Else
      C_LE = CInteger(I_LE,11)   ' Energy values - 1
    End If  
    C_INull = CInteger(0,11)
    C_NN = CInteger(I_NN,11)
    CA_NFP(3) = CInteger(IA_NFP(3),11)          
    C_Out = C_E(1) + C_RNull + C_LE + C_INull + C_NN + CA_NFP(3) _          
                    + CTrailer(I_MAT,I_MF,I_MT,I_NSC)
    Print #fCUMU,C_out   

    ' LIST lines, print cumulative nuclide yields          
    I_NSC = I_NSC + 1        
    C_out = ""   
    
    For IZ = IZfirst_cumulative To IZlast_cumulative
      For IN = INfirst_cumulative(IZ) To INlast_cumulative(IZ)
        If NStates_for_ZA(IZ,IZ+IN) = 1 Then  ' number of states including ground state
          C_out = C_out + CDouble(1000*IZ+IZ+IN)   ' Nuclide
          TestprintC(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NSC),I_NSC)
          C_out = C_out + CDouble(0.E0)            ' Isomer  
          TestprintC(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NSC),I_NSC)
          C_out = C_out + CDouble(NZIcumu(IN,IZ,0)/R_Norm)   ' Yield
          TestprintC(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NSC),I_NSC)
          C_out = C_out + CDouble(d_NZIcumu(0,IN,IZ,0)/R_Norm) ' Uncertainty
          TestprintC(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NSC),I_NSC)
        Else
          I = ISO_for_ZA(IZ,IZ+IN)     ' Index of Isostab array for this nucleus.
          For J = 0 To Isotab(I).N_STATES-1  ' Loop over all (N_STATES) states (0=ground state)
            For K = 1 To Isotab(I).N_STATES  ' Loop over all (N_STATES) states (0=ground state)
              IF Isotab(I).I_ISO(K) = J Then ' Get ENDF order of isomers
                C_out = C_out + CDouble(1000*IZ+IZ+IN)   ' Nuclide
                TestprintC(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NSC),I_NSC)
                C_out = C_out + CDouble(J)               ' Isomer  
                TestprintC(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NSC),I_NSC)
                C_out = C_out + CDouble(NZIcumu(IN,IZ,J)/R_Norm)   ' Yield
                TestprintC(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NSC),I_NSC)
                C_out = C_out + CDouble(d_NZIcumu(0,IN,IZ,J)/R_Norm) ' Uncertainty
                TestprintC(C_out,CTrailer(I_MAT,I_MF,I_MT,I_NSC),I_NSC)
              End If
            Next      
          Next
        End If 
      Next
    Next    
    
    IF C_out <> "" Then 
      C_out = Mid(C_out + String(66," "),1,66)
      C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NSC)
      Print #fCUMU,C_out
    Else
      I_NSC = I_NSC - 1  
    End If     

    Close #fCUMU
  End If
    

'Print "ENDF 7"  

     
  Close #fENDF
  
  If B_write_EOT Then
  
  ' SEND line

    fCUMU = Freefile
    Open CFCUMU For Append As #fCUMU

    I_MT = 0
    I_MF = 8
    I_NSC = 99999 
    C_out = " 0.000000+0 0.000000+0          0          0          0          0"
    C_out = C_out + CTrailer(I_MAT,I_MF,I_MT,I_NSC)              
    Print #fCUMU,C_out                 

    I_MF = 0
    I_MT = 0          
    I_NSC = 0             
    C_out = String(66," ") + CTrailer(I_MAT,I_MF,I_MT,I_NSC) 
    Print #fCUMU,C_out  

    I_MF = 0 
    I_MAT = 0
    C_out = String(66," ") + CTrailer(I_MAT,I_MF,I_MT,I_NSC) 
    Print #fCUMU,C_out    

    Close #fCUMU
  End If
  
  
'Print "ENDF 8"

  ' Copy cumulative yields to ENDF.dat file
  Scope
  
  If B_CY_read Then    
     
    Dim As String Cline
    Dim As Integer I, Lines = 0
    fCUMU = Freefile  
    Open CFCUMU For Input As #fCUMU
    fENDF = Freefile
    Open CGEFY For Append As #fENDF

    Do Until EOF(fCUMU)
      Line Input #fCUMU, Cline
      Print #fENDF, Cline
    Loop 
  
    Close #fCUMU
    Close #fENDF
  End If 
  End Scope
  

  I_MAT_last = I_MAT

  If B_Error_Analysis = 1 Then
    C_out = " 0.000000+0 0.000000+0          0          0          0          0  -1 0  0    0"
    fENDF = Freefile
    Open CGEFY_random For Append As #fENDF
    Print #fENDF,C_out 
    Close #fENDF 
    I_Print_Title_Line = 1
  ElseIf B_write_EOT Then
    C_out = " 0.000000+0 0.000000+0          0          0          0          0  -1 0  0    0"
    fENDF = Freefile
    Open CGEFY For Append As #fENDF
    Print #fENDF,C_out 
    Close #fENDF 
    I_Print_Title_Line = 1
  End If       

  Print "End ENDF routine."
'Print "ENDF 9"  

End Scope

End If   ' If B_Error_Analysis = 0 Or B_Random_On = 1 Then

End If   ' If B_ENDF = 1
